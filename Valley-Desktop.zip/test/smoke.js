'use strict';
// Offline checks that don't need Electron: syntax of every script, filter engine, asset rewriting, bridge coverage.
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..', 'app');
let fail = 0;
const ok = (c, m) => { if (!c) { fail++; console.error('FAIL', m); } else console.log('ok  ', m); };

// 1. every JS file and every inline <script> parses
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
for (const f of walk(root)) {
  if (f.endsWith('.js')) { try { new vm.Script(fs.readFileSync(f, 'utf8'), { filename: f }); ok(true, 'parses ' + path.relative(root, f)); } catch (e) { ok(false, f + ': ' + e.message); } }
  if (f.endsWith('.html')) {
    const html = fs.readFileSync(f, 'utf8');
    const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi; let m, n = 0;
    while ((m = re.exec(html))) { n++; try { new vm.Script(m[1]); } catch (e) { ok(false, path.basename(f) + ' inline script ' + n + ': ' + e.message); } }
    ok(true, 'inline scripts parse ' + path.basename(f) + ' (' + n + ')');
  }
}

// 2. filter engine
const { Filter } = require('../app/lib/filter');
const f = new Filter();
f.loadDomains(fs.readFileSync(path.join(root, 'assets/blocklist.txt'), 'utf8'));
f.loadRules(fs.readFileSync(path.join(root, 'assets/ubo-filters.txt'), 'utf8'));
ok(f.shouldBlock('https://ib.adnxs.com/pixel', 'news.example', 'image'), 'blocks listed ad domain');
ok(!f.shouldBlock('https://news.example/app.js', 'news.example', 'script'), 'allows first-party script');
ok(f.shouldBlock('https://www.google-analytics.com/analytics.js', 'news.example', 'script'), 'blocks third-party analytics');
const g = new Filter(); g.loadRules('||tracker.test^$third-party\n@@||tracker.test/ok.js\n||cdn.test/ads/*$script,domain=~safe.test');
ok(g.shouldBlock('https://tracker.test/t.gif', 'site.test', 'image'), 'third-party rule blocks cross-site');
ok(!g.shouldBlock('https://tracker.test/t.gif', 'tracker.test', 'image'), 'third-party rule skips first party');
ok(!g.shouldBlock('https://tracker.test/ok.js', 'site.test', 'script'), '@@ exception wins');
ok(g.shouldBlock('https://cdn.test/ads/a.js', 'site.test', 'script') && !g.shouldBlock('https://cdn.test/ads/a.js', 'safe.test', 'script') && !g.shouldBlock('https://cdn.test/ads/a.png', 'site.test', 'image'), 'domain= and type options');
ok(f.cosmeticCss('example.com').includes('display:none'), 'cosmetic css generated');

// 3. search routing
const { routeSearch } = require('../app/lib/search');
ok(routeSearch('example.com', true, 'S') === 'https://example.com', 'bare host -> https');
ok(routeSearch('flipkart phone', true, 'S').startsWith('https://www.flipkart.com/search?q='), 'smart shopping route');

// 4. every ValleyNative call the toolbar makes is handled by main.js, and exposed by the preload
const main = fs.readFileSync(path.join(root, 'main.js'), 'utf8');
const pre = fs.readFileSync(path.join(root, 'preload.js'), 'utf8');
const names = ['searchSettings','nav','addtabmenu','tabactions','menu','reader','zoomIn','zoomOut','zoomReset','eraserMenu','eraserErase','eraserRestore','reload','voiceSearch','voiceCancel','findInPage','address','folded','hidebar','surface','smartsetting','smartstate','search','navmode','action','tabSwipe','tool'];
for (const n of names) ok(main.includes("case '" + n + "'") && pre.includes("'" + n + "'"), 'bridge ' + n);
const toolbar = fs.readFileSync(path.join(root, 'assets/toolbar.html'), 'utf8');
const used = new Set([...toolbar.matchAll(/native\('([a-zA-Z]+)'/g)].map(m => m[1]));
for (const u of used) ok(names.includes(u), 'toolbar call native(' + u + ') is bridged');

// 5. host rewriting leaves no Android host in served text
const src = main.slice(main.indexOf('function rewriteHost'), main.indexOf('function serveAsset'));
const rewriteHost = new Function(src + '; return rewriteHost;')();
for (const a of ['index.html', 'toolbar.html', 'spark.js', 'reader.js', 'privacy_shield.js']) {
  const out = rewriteHost(fs.readFileSync(path.join(root, 'assets', a), 'utf8'));
  ok(!out.includes('androidplatform'), 'no android host in ' + a);
}

// 6. every overlay invoke() in the desktop pages has a handler in main.js
for (const page of ['sidebar.html', 'panel.html', 'find.html', 'voice.html']) {
  const html = fs.readFileSync(path.join(root, 'assets', page), 'utf8');
  for (const m of new Set([...html.matchAll(/invoke\('([a-zA-Z]+:[a-zA-Z]+)'/g)].map(x => x[1]))) ok(main.includes("'overlay:" + m + "'"), page + ' -> overlay:' + m);
}
// 7. token-indexed rules still match, regex rules work, and 30k rules stay fast
const h = new Filter(); h.loadRules('/banner[0-9]+\\.gif/\n/adserver/*/track\n||x.test/pixel');
ok(h.shouldBlock('https://a.test/banner12.gif', 's.test', 'image') && h.shouldBlock('https://a.test/adserver/9/track', 's.test', 'xhr'), 'regex + wildcard rules');
const big = new Filter(); let txt = ''; for (let i = 0; i < 30000; i++) txt += '/seg' + i + 'ads/*&k=' + i + '\n';
big.loadRules(txt); const t0 = Date.now(); for (let i = 0; i < 2000; i++) big.shouldBlock('https://cdn.example/assets/app' + i + '.js?v=1', 'example.com', 'script');
ok(Date.now() - t0 < 400, '2000 lookups against 30k rules in ' + (Date.now() - t0) + 'ms');
// 8. tracking-parameter stripper
const sSrc = main.slice(main.indexOf('const TRACKING'), main.indexOf('// ------------------------------------------------------------------ downloads'));
const strip = new Function('isAuthHost', 'isExempt', sSrc + '; return stripTracking;')(() => false, () => false);
ok(strip('https://a.test/p?utm_source=x&id=4&fbclid=z') === 'https://a.test/p?id=4', 'strips utm/fbclid, keeps id');
ok(strip('https://a.test/p?id=4') === null && strip('https://a.test/?client_id=1&utm_x=2') === null, 'leaves clean and OAuth urls alone');

// 9. scriptlets + procedural filters: parse and actually run against a fake page
const { SCRIPTLET_RUNTIME, PROCEDURAL_RUNTIME } = require('../app/lib/filter');
const sf = new Filter();
sf.loadRules('a.test##+js(set, adsEnabled, false)\na.test##+js(nostif, popup)\na.test##+js(aopr, tracker.id)\na.test##+js(json-prune, ads banner)\n##div:has-text(/sponsored/i):upward(1)');
const rt = sf.scriptletsFor('www.a.test');
ok(rt.length === 4 && sf.proceduralFor('x.com').length === 1, 'scriptlet + procedural rules parsed');
const calls = [];
const fakeWin = { setTimeout: (f, t) => { calls.push(String(f)); return 7; }, setInterval() {}, open() {}, fetch() {}, eval() {} };
fakeWin.window = fakeWin;
vm.runInNewContext(SCRIPTLET_RUNTIME + '(' + JSON.stringify(rt) + ');', Object.assign(fakeWin, { JSON, Object, Math, EventTarget: function () {}, ReferenceError, Response: function () {}, document: { querySelectorAll() { return []; } }, MutationObserver: function () { this.observe = () => {}; }, Promise, String, Number, RegExp, Error, Array }));
ok(fakeWin.adsEnabled === false, 'set-constant defines window.adsEnabled=false');
ok(fakeWin.setTimeout('popup()', 1) === 0 && fakeWin.setTimeout('keep()', 1) === 7, 'no-setTimeout-if blocks only matching timers');
let thrown = false; try { void fakeWin.tracker; fakeWin.tracker = { id: 1 }; void fakeWin.tracker.id; } catch (e) { thrown = true; }
ok(thrown, 'abort-on-property-read throws on tracker.id');
const pruned = fakeWin.JSON.parse('{"ads":1,"banner":2,"keep":3}');
ok(pruned.keep === 3 && pruned.ads === undefined && pruned.banner === undefined, 'json-prune removes listed keys');
try { new vm.Script(PROCEDURAL_RUNTIME + '([])'); ok(true, 'procedural runtime parses'); } catch (e) { ok(false, 'procedural runtime: ' + e.message); }
console.log(fail ? `\n${fail} check(s) failed` : '\nall checks passed');
process.exit(fail ? 1 : 0);
