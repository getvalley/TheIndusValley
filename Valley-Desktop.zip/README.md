# Valley for desktop (Windows + macOS)

Electron is Chromium, so this reuses Valley's own HTML/JS layer from the Android app unchanged
(start page, toolbar pill, reader mode, "Hide Distracting Items", privacy shield, filter lists, Bricolage font).
`app/main.js` replaces the Kotlin shell; `app/preload.js` recreates the `ValleyNative / ValleyHistory /
ValleyDownloads / ValleyTour` bridges those pages already call.

## Run
    npm install
    npm start          # launches Valley
    npm test           # offline checks (syntax, filter engine, bridge coverage)

## Build installers
    npm run dist:win   # on Windows -> dist/*.exe (NSIS installer + portable)
    npm run dist:mac   # on a Mac   -> dist/*.dmg (universal)
No Mac/PC for both? Push to GitHub and run the **Build Valley desktop** workflow (.github/workflows/build.yml);
installers appear as downloadable artifacts. Builds are unsigned: Windows SmartScreen and macOS Gatekeeper will warn
until you add a code-signing certificate / Apple Developer ID (electron-builder docs: "Code Signing").

## Shortcuts
Ctrl/Cmd+T new tab · +Shift+N private tab · W close · L search/address · F find · R reload · Alt+Cmd+R reader ·
Shift+A tab grid with previews · Shift+S show/hide tab sidebar · Shift+O bookmarks · J downloads · Y history ·
Shift+B hide/show toolbar · 1-9 jump to tab · Ctrl+Tab next tab · +/-/0 zoom.

## What's in it
- **Vertical tab sidebar** (left, collapsible to icons): hover any tab, including the Valley start page, for a
  live preview card; drag to reorder or drop onto a group; right-click for pin, groups, duplicate, close others.
- **Tab groups and pinned tabs**, **profiles** (separate cookies, history, downloads, bookmarks) and a private mode.
- **Web apps**: "Install site as app" opens a site in its own window (Windows also gets a desktop shortcut).
- **Filters**: bundled lists plus Privacy > "Update filter lists now" (EasyList, EasyPrivacy, uBlock filters), regex and
  `$option` rules, tracking-parameter stripping, optional weekly auto-update. Your own list: `<userData>/filters.txt`.
- Everything from the Android app that has a desktop meaning: pill toolbar, smart search, start page, reader mode,
  Hide Distracting Items, translate/summarise, find, zoom, mobile-site toggle, downloads, history, bookmarks, theme.
- File drag-and-drop onto pages works natively in Chromium.

## Voice search
On-device Whisper (transformers.js): no account or API key. The first use downloads a ~40 MB model from the
jsDelivr / Hugging Face CDNs, then it is cached. Supports many languages, including Hindi; tiny model, so accuracy
is modest in noisy rooms. Needs an internet connection for that first download only.

## Filter engine
Network rules (domain list, `||host^`, regex, `$third-party/$domain/$type`, `@@` exceptions), cosmetic rules,
procedural cosmetics (`:has-text :contains :upward :xpath :matches-css :remove :style`) and scriptlets
(`##+js`: set-constant, abort-on-property-read/write, abort-current-script, no-setTimeout/Interval-if,
prevent-addEventListener, remove-attr/class, json-prune, noeval, nowebrtc, prevent-window-open, no-fetch-if).

## Known limits
- Google may still show "this browser may not be secure" for some accounts; client hints are normalised to Chrome's
  but Electron can't be made indistinguishable.
- Not run on real hardware yet: expect small fixes on first launch.
- iOS is a separate WebKit/Swift project (Apple does not allow Chromium on iOS) and is not part of this folder.

## Data
Preferences, history and downloads list: `valley-prefs.json` in the app's userData folder
(`%APPDATA%\Valley` on Windows, `~/Library/Application Support/Valley` on macOS).
