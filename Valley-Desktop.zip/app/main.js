'use strict';
/* Valley for desktop (Windows + macOS). Electron = Chromium, so the Android app's HTML/JS layer
   (start page, toolbar pill, reader, eraser, privacy shield, filter lists) is reused as-is and this
   file replaces the Kotlin shell: tabs, toolbar overlay, menus, downloads, history, settings. */
const { app, BrowserWindow, WebContentsView, Menu, MenuItem, ipcMain, session, shell, nativeTheme, dialog, clipboard, net } = require('electron');
const path = require('path');
const fs = require('fs');
const { protocol } = require('electron');
const { Store, prettyUrl } = require('./lib/store');
const { Filter, SCRIPTLET_RUNTIME, PROCEDURAL_RUNTIME } = require('./lib/filter');
const { routeSearch } = require('./lib/search');

protocol.registerSchemesAsPrivileged([
  { scheme: 'valley', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } }
]);

const ASSETS = path.join(__dirname, 'assets');
const START_URL = 'valley://app/index.html';
const PRELOAD = path.join(__dirname, 'preload.js');
const IS_MAC = process.platform === 'darwin';
const AUTH_HOSTS = ['accounts.google.com', 'accounts.youtube.com', 'gsi.google.com', 'oauth2.googleapis.com',
  'apis.google.com', 'content.googleapis.com', 'ssl.gstatic.com', 'www.gstatic.com', 'login.microsoftonline.com',
  'login.live.com', 'appleid.apple.com', 'idmsa.apple.com', 'login.yahoo.com'];
const PRIVATE_PARTITION = 'valley-private';
const PROFILE_COLORS = ['#e8622a', '#3b82f6', '#22a06b', '#a855f7', '#e0a100', '#ec4899'];
const sideWidth = () => (sideCollapsed ? 56 : 240);

let store, filter, shieldSource, readerJs, cleanupJs, sparkJs;
let win = null, toolbar = null, handle = null, panel = null, findBar = null, sidebar = null, voiceWin = null;
let sideCollapsed = false, sideHover = false, profileId = 'default', sideTimer = null;
const appWindows = new Map();
let tabs = [], activeId = null, nextId = 1;
let navForward = false, toolbarExpanded = false, toolbarHidden = false, eraserHold = false, tourOwnerId = null;
let blockedCount = 0, quitting = false;
let panelMode = null;

const isStart = (u) => typeof u === 'string' && u.startsWith('valley://app/');
const isTrusted = (e) => { try { return String(e.senderFrame.url).startsWith('valley://app/'); } catch (_) { return false; } };
const activeTab = () => tabs.find(t => t.id === activeId) || null;
const tabByWc = (wc) => tabs.find(t => t.view.webContents === wc) || null;
const q = (s) => JSON.stringify(String(s));

function chromeUA(mobile) {
  const major = process.versions.chrome.split('.')[0];
  if (mobile) return `Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${major}.0.0.0 Mobile Safari/537.36`;
  const plat = IS_MAC ? 'Macintosh; Intel Mac OS X 10_15_7' : 'Windows NT 10.0; Win64; x64';
  return `Mozilla/5.0 (${plat}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${major}.0.0.0 Safari/537.36`;
}

// ------------------------------------------------------------------ assets (valley://app/...)
const TEXT_EXT = new Set(['.html', '.js', '.css', '.txt', '.json', '.svg']);
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.txt': 'text/plain; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf' };

function readAsset(rel) {
  const file = path.normalize(path.join(ASSETS, rel));
  if (!file.startsWith(ASSETS + path.sep)) return null;
  try { return { file, data: fs.readFileSync(file) }; } catch (_) { return null; }
}
function rewriteHost(text) {
  return text.split('https://appassets.androidplatform.net/assets').join('valley://app')
    .split('https://appassets.androidplatform.net').join('valley://app')
    .split('appassets.androidplatform.net/assets').join('app')
    .split('appassets.androidplatform.net').join('app');
}
function serveAsset(request) {
  const u = new URL(request.url);
  if (u.host !== 'app') return new Response('Not found', { status: 404 });
  const rel = (decodeURIComponent(u.pathname).replace(/^\/+/, '').replace(/^assets\//, '')) || 'index.html';
  const a = readAsset(rel);
  if (!a) return new Response('Not found', { status: 404 });
  const ext = path.extname(a.file).toLowerCase();
  const body = TEXT_EXT.has(ext) ? Buffer.from(rewriteHost(a.data.toString('utf8'))) : a.data;
  return new Response(body, { headers: { 'content-type': MIME[ext] || 'application/octet-stream',
    'access-control-allow-origin': '*', 'cache-control': 'no-cache' } });
}
function loadText(rel) { const a = readAsset(rel); return a ? a.data.toString('utf8') : ''; }

// ------------------------------------------------------------------ privacy
function pref(key, def) { return store.get(key, def); }
function shieldCfg() {
  return JSON.stringify({ ads: pref('privacy_block_ads', true), banners: pref('privacy_hide_banners', true),
    fp: pref('privacy_fingerprint', true), webrtc: pref('privacy_webrtc', false), gpc: pref('privacy_gpc', true),
    home: 'app', exceptions: pref('privacy_exceptions', []).concat(AUTH_HOSTS) });
}
const hostOf = (u) => { try { return new URL(u).hostname.toLowerCase(); } catch (_) { return ''; } };
const isAuthHost = (h) => !!h && AUTH_HOSTS.some(a => h === a || h.endsWith('.' + a));
const isExempt = (h) => isAuthHost(h) || pref('privacy_exceptions', []).some(x => h === x || h.endsWith('.' + x));

const prepared = new WeakSet();
function setupSession(ses) {
  if (prepared.has(ses)) return;
  prepared.add(ses);
  ses.protocol.handle('valley', serveAsset);
  ses.setUserAgent(chromeUA(false));
  ses.webRequest.onBeforeRequest((d, cb) => {
    try {
      if (d.resourceType === 'mainFrame' && pref('privacy_strip_params', true) && /^https?:/.test(d.url)) { const clean = stripTracking(d.url); if (clean) return cb({ redirectURL: clean }); }
      if (d.resourceType === 'mainFrame' || !pref('privacy_block_ads', true) || !/^(https?|wss?):/.test(d.url)) return cb({});
      const pageHost = hostOf((d.webContents && d.webContents.getURL()) || d.referrer || '');
      if (isExempt(hostOf(d.url)) || isExempt(pageHost)) return cb({});
      if (filter.shouldBlock(d.url, pageHost, d.resourceType)) { blockedCount++; return cb({ cancel: true }); }
    } catch (_) {}
    cb({});
  });
  ses.webRequest.onBeforeSendHeaders((d, cb) => {
    const h = d.requestHeaders;
    if (pref('privacy_gpc', true) && !isAuthHost(hostOf(d.url))) { h['Sec-GPC'] = '1'; h['DNT'] = '1'; }
    const major = process.versions.chrome.split('.')[0];
    for (const k of Object.keys(h)) if (k.toLowerCase() === 'sec-ch-ua') h[k] = `"Chromium";v="${major}", "Google Chrome";v="${major}", "Not_A Brand";v="24"`;
    cb({ requestHeaders: h });
  });
  ses.setPermissionRequestHandler((wc, permission, cb, details) => {
    const url = (details && details.requestingUrl) || wc.getURL();
    if (voiceWin && !voiceWin.isDestroyed() && wc === voiceWin.webContents) return cb(permission === 'media');
    const okAlways = ['clipboard-sanitized-write', 'fullscreen', 'pointerLock', 'window-management'];
    if (okAlways.includes(permission)) return cb(true);
    if (!['media', 'geolocation', 'notifications', 'clipboard-read', 'midi'].includes(permission)) return cb(false);
    const host = hostOf(url) || 'This page';
    dialog.showMessageBox(win, { type: 'question', buttons: ['Allow', 'Block'], defaultId: 1, cancelId: 1,
      message: `${host} wants to use: ${permission === 'media' ? 'camera / microphone' : permission}`, noLink: true })
      .then(r => cb(r.response === 0)).catch(() => cb(false));
  });
  ses.on('will-download', (event, item, wc) => onDownload(ses, item, wc));
}
function profileSession(id) {
  if (!id || id === 'default') return session.defaultSession;
  const s = session.fromPartition('persist:valley-' + id); setupSession(s); return s;
}
function privateSession() { const s = session.fromPartition(PRIVATE_PARTITION); setupSession(s); return s; }

// ------------------------------------------------------------------ tabs
function createTab(url, priv, activate = true, opts = {}) {
  const ses = priv ? privateSession() : profileSession(opts.profile || profileId);
  const view = new WebContentsView({ webPreferences: { session: ses, preload: PRELOAD, sandbox: true, contextIsolation: true,
    nodeIntegration: false, nodeIntegrationInSubFrames: true, spellcheck: true } });
  const tab = { id: nextId++, view, private: !!priv, url: url || START_URL, title: '', favicon: '', loading: false,
    mobile: false, readerOn: false, homeView: 'home', zoom: 0, group: opts.group || '', pinned: !!opts.pinned,
    profile: priv ? null : (opts.profile || profileId), thumb: '' };
  tabs.push(tab);
  wireTab(tab);
  view.webContents.loadURL(routeIfNeeded(tab.url)).catch(() => {});
  if (activate) activateTab(tab);
  else pushToolbarState();
  return tab;
}
const routeIfNeeded = (u) => (/^[a-z][a-z0-9+.-]*:/i.test(u) ? u : routeSearch(u, pref('smart_search', true), START_URL));

function activateTab(tab) {
  if (!tab || !win) return;
  const old = activeTab();
  if (old && old !== tab) { captureThumb(old); try { win.contentView.removeChildView(old.view); } catch (_) {} stopEraser(old); }
  activeId = tab.id;
  try { win.contentView.removeChildView(tab.view); } catch (_) {}
  win.contentView.addChildView(tab.view, 0);
  layout();
  tab.view.webContents.focus();
  pushToolbarState();
  win.setTitle(tab.title ? `${tab.title} — Valley` : 'Valley');
  closePanel();
}
function closeTab(tab) {
  if (!tab) return;
  const i = tabs.indexOf(tab);
  const wasActive = tab.id === activeId;
  try { win.contentView.removeChildView(tab.view); } catch (_) {}
  tabs.splice(i, 1);
  try { tab.view.webContents.close(); } catch (_) {}
  if (tab.private && !tabs.some(t => t.private)) { const s = privateSession(); s.clearStorageData().catch(() => {}); s.clearCache().catch(() => {}); }
  if (wasActive) {
    const mine = tabs.filter(t => t.private === tab.private && (tab.private || t.profile === tab.profile));
    const next = mine.length ? mine[Math.min(Math.max(0, mine.findIndex(t => tabs.indexOf(t) >= i)), mine.length - 1)] : null;
    if (next) activateTab(next); else createTab(START_URL, false, true, { profile: tab.private ? profileId : tab.profile });
  } else if (tabs.length === 0) createTab(START_URL, false);
  else pushToolbarState();
}
function visibleTabs() {
  const a = activeTab();
  const priv = !!(a && a.private);
  const list = tabs.filter(t => t.private === priv && (priv || t.profile === profileId));
  return list.sort((x, y) => (y.pinned ? 1 : 0) - (x.pinned ? 1 : 0));
}
function switchBy(delta) {
  const vis = visibleTabs();
  if (vis.length < 2) return;
  const i = vis.indexOf(activeTab());
  activateTab(vis[(i + delta + vis.length) % vis.length]);
}

function wireTab(tab) {
  const wc = tab.view.webContents;
  const sync = () => { tab.url = wc.getURL() || tab.url; if (tab.id === activeId) pushToolbarState(); };
  wc.on('did-start-loading', () => { tab.loading = true; });
  wc.on('did-stop-loading', () => { tab.loading = false; });
  wc.on('did-navigate', (_e, url) => { tab.readerOn = false; tab.url = url; if (tab.id === activeId) pushToolbarState(); });
  wc.on('did-navigate-in-page', (_e, url, isMain) => { if (isMain) { tab.url = url; sync(); } });
  wc.on('page-title-updated', (_e, title) => { tab.title = title; notifySide(); if (tab.id === activeId) win && win.setTitle(`${title} — Valley`); });
  wc.on('page-favicon-updated', (_e, icons) => { tab.favicon = icons[0] || ''; notifySide(); });
  wc.on('dom-ready', () => onDomReady(tab));
  wc.on('did-finish-load', () => {
    const url = wc.getURL();
    if (!tab.private && !isStart(url)) store.recordOpened(url, wc.getTitle());
    if (!isStart(url)) { wc.executeJavaScript(cleanupJs).catch(() => {}); wc.executeJavaScript(sparkJs + '\n;try{window.ulaaHidePill&&window.ulaaHidePill()}catch(e){}').catch(() => {}); }
    sync();
    scheduleThumb(tab);
  });
  wc.on('found-in-page', (_e, r) => { if (tab.id === activeId && findBar) findBar.webContents.send('overlay:find:result', r.activeMatchOrdinal, r.matches); });
  wc.on('render-process-gone', () => { try { wc.reload(); } catch (_) {} });
  wc.on('zoom-changed', () => {});
  wc.on('will-navigate', (e, url) => {
    const p = url.split(':')[0].toLowerCase();
    if (['http', 'https', 'valley', 'about', 'blob', 'data', 'file', 'view-source', 'devtools'].includes(p)) return;
    e.preventDefault();
    if (['mailto', 'tel', 'sms'].includes(p)) shell.openExternal(url).catch(() => {});
  });
  wc.setWindowOpenHandler(({ url, features, disposition }) => {
    const popup = /width=|height=/i.test(features || '') || disposition === 'new-window';
    if (popup && /^https?:/i.test(url)) {
      // sign-in popups (Google / Microsoft / Apple): a real child window so window.opener and window.close() work
      return { action: 'allow', overrideBrowserWindowOptions: { parent: win, width: 520, height: 700, autoHideMenuBar: true,
        webPreferences: { sandbox: true, contextIsolation: true, preload: PRELOAD, nodeIntegrationInSubFrames: true } } };
    }
    if (/^https?:|^valley:|^about:blank/i.test(url)) createTab(url, tab.private, disposition !== 'background-tab');
    return { action: 'deny' };
  });
  wc.on('context-menu', (_e, p) => showContextMenu(tab, p));
  wc.on('before-input-event', (e, input) => { if (input.type === 'keyDown' && input.key === 'Escape' && findBar && findBar.webContents.getURL()) hideFind(); });
}

function onDomReady(tab) {
  const wc = tab.view.webContents;
  const url = wc.getURL();
  if (isStart(url) || !/^https?:/.test(url)) return;
  const host = hostOf(url);
  if (pref('privacy_hide_banners', true) && !isExempt(host)) {
    const css = filter.cosmeticCss(host);
    if (css) wc.insertCSS(css).catch(() => {});
    const proc = filter.proceduralFor(host);
    if (proc.length) wc.executeJavaScript(PROCEDURAL_RUNTIME + '(' + JSON.stringify(proc) + ');').catch(() => {});
  }
}

// ------------------------------------------------------------------ window, layout, toolbar overlay
function overlayView(file) {
  const v = new WebContentsView({ webPreferences: { session: session.defaultSession, preload: PRELOAD, sandbox: true, contextIsolation: true } });
  v.setBackgroundColor('#00000000');
  v.webContents.loadURL('valley://app/' + file).catch(() => {});
  return v;
}

function createWindow() {
  win = new BrowserWindow({ width: 1240, height: 840, minWidth: 440, minHeight: 460, title: 'Valley',
    backgroundColor: '#0f0f12', icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: { sandbox: true, contextIsolation: true } });
  // The window has no page of its own (only child views), so 'ready-to-show' never fires. Show it right away.
  win.show();
  win.setMenuBarVisibility(false);
  toolbar = overlayView('toolbar.html');
  handle = overlayView('handle.html');
  panel = overlayView('panel.html');
  findBar = overlayView('find.html');
  sidebar = overlayView('sidebar.html');
  for (const v of [sidebar, toolbar, handle, panel, findBar]) win.contentView.addChildView(v);
  sidebar.webContents.on('did-finish-load', notifySide);
  panel.setVisible(false); findBar.setVisible(false); handle.setVisible(false);
  toolbar.webContents.on('did-finish-load', pushToolbarState);
  win.on('resize', layout);
  win.on('enter-full-screen', layout); win.on('leave-full-screen', layout);
  win.on('closed', () => { win = null; });
  layout();
}

function toolbarShouldShow() {
  const t = activeTab();
  const tourHides = t && tourOwnerId === t.id && isStart(t.url);
  return !toolbarHidden && !eraserHold && !tourHides;
}
function layout() {
  if (!win) return;
  const [w, h] = win.getContentSize();
  const t = activeTab();
  const sw = sideWidth(), pw = Math.max(200, w - sw);
  if (t) t.view.setBounds({ x: sw, y: 0, width: pw, height: h });
  sidebar.setBounds({ x: 0, y: 0, width: sideHover ? sw + 310 : sw, height: h });
  const tbW = Math.min(pw, 760), tbH = toolbarExpanded ? 360 : 78;
  toolbar.setBounds({ x: sw + Math.round((pw - tbW) / 2), y: h - tbH, width: tbW, height: tbH });
  toolbar.setVisible(toolbarShouldShow());
  handle.setBounds({ x: sw + Math.round((pw - 72) / 2), y: h - 26, width: 72, height: 26 });
  handle.setVisible(toolbarHidden);
  panel.setBounds({ x: sw, y: 0, width: pw, height: h });
  findBar.setBounds({ x: Math.max(sw + 8, w - 420), y: 8, width: 412, height: 56 });
}
function tbJs(code) { try { if (toolbar && !toolbar.webContents.isDestroyed()) toolbar.webContents.executeJavaScript(code).catch(() => {}); } catch (_) {} }
function toast(msg) {
  tbJs(`(function(){var d=document.getElementById('valley-toast');if(!d){d=document.createElement('div');d.id='valley-toast';
  d.style.cssText='position:fixed;left:50%;bottom:92px;transform:translateX(-50%);padding:9px 16px;border-radius:999px;background:rgba(20,20,23,.94);color:#f7f5f2;font:600 13px "Bricolage Grotesque",system-ui,sans-serif;z-index:99999;pointer-events:none;transition:opacity .2s;max-width:90vw;text-align:center';
  document.body.appendChild(d);}d.textContent=${q(msg)};d.style.opacity=1;clearTimeout(window.__vt);window.__vt=setTimeout(function(){d.style.opacity=0},2200);})()`);
}

function pushToolbarState() {
  const t = activeTab();
  if (!t || !toolbar) return;
  const wc = t.view.webContents;
  const home = isStart(t.url);
  const nav = wc.navigationHistory;
  const can = navForward ? nav.canGoForward() : nav.canGoBack();
  const label = home ? 'Valley' : prettyUrl(t.url);
  const n = visibleTabs().length;
  const dark = nativeTheme.shouldUseDarkColors;
  const settings = home && t.homeView !== 'home';
  tbJs(`(function(w){try{
    w.ulaaSetTheme&&w.ulaaSetTheme(${dark});
    w.ulaaSetAddr&&w.ulaaSetAddr(${q(label)});
    w.ulaaCount&&w.ulaaCount(${n});
    w.ulaaNavLabel&&w.ulaaNavLabel(${q(navForward ? 'Forward' : 'Back')});
    w.ulaaForward&&w.ulaaForward(${navForward});
    w.ulaaDim&&w.ulaaDim(${!can});
    w.ulaaSettingsMode&&w.ulaaSettingsMode(${settings});
    w.ulaaHomeMode&&w.ulaaHomeMode(${home});
    w.ulaaSetReaderActive&&w.ulaaSetReaderActive(${!!t.readerOn});
    w.ulaaSetDesktopMode&&w.ulaaSetDesktopMode(${!t.mobile});
  }catch(e){}})(window)`);
  layout();
  notifySide();
}
function pushTheme() {
  const dark = nativeTheme.shouldUseDarkColors;
  tbJs(`window.ulaaSetTheme&&window.ulaaSetTheme(${dark})`);
  for (const t of tabs) if (isStart(t.url)) t.view.webContents.executeJavaScript(`window.ulaaSetTheme&&window.ulaaSetTheme(${dark})`).catch(() => {});
}

function sideState() {
  const a = activeTab();
  const priv = !!(a && a.private);
  const profiles = store.get('profiles', null) || [{ id: 'default', name: 'Personal', color: PROFILE_COLORS[0] }];
  return { collapsed: sideCollapsed, activeId, private: priv, profileId, profiles, groups: store.get('groups', []), webapps: store.get('webapps', []),
    tabs: visibleTabs().map(t => ({ id: t.id, title: t.title || (isStart(t.url) ? 'Valley' : prettyUrl(t.url)), url: isStart(t.url) ? '' : t.url, favicon: t.favicon, home: isStart(t.url), group: t.group, pinned: t.pinned })) };
}
function notifySide() {
  if (sideTimer || !sidebar) return;
  sideTimer = setTimeout(() => { sideTimer = null; try { if (sidebar && !sidebar.webContents.isDestroyed()) sidebar.webContents.send('overlay:side:update', sideState()); } catch (_) {} }, 40);
}
const thumbTimers = new Map();
function scheduleThumb(tab) { clearTimeout(thumbTimers.get(tab.id)); thumbTimers.set(tab.id, setTimeout(() => captureThumb(tab), 900)); }
function captureThumb(tab) {
  try {
    if (!tab || tab.id !== activeId || tab.view.webContents.isDestroyed()) return;
    tab.view.webContents.capturePage().then(img => {
      if (img.isEmpty()) return;
      const sz = img.getSize();
      tab.thumb = img.resize({ width: Math.min(480, sz.width), quality: 'good' }).toDataURL();
    }).catch(() => {});
  } catch (_) {}
}

// ------------------------------------------------------------------ page actions
function openHomeView(view) {
  const t = activeTab();
  if (!t) return;
  if (t.private) { createTab(`${START_URL}#${view}`, false); return; }
  if (isStart(t.url)) {
    t.view.webContents.executeJavaScript(`(function(){try{history.replaceState(null,'','#${view}')}catch(e){}window.ulaaShowView&&window.ulaaShowView('${view}')})()`).catch(() => {});
    if (view === 'downloads') refreshDownloadsPage();
  } else t.view.webContents.loadURL(`${START_URL}#${view}`).catch(() => {});
}
function saveLink(key) {
  const t = activeTab();
  if (!t || isStart(t.url)) return toast('Open a webpage to save it');
  const list = store.get(key, []).filter(x => x.u !== t.url);
  list.unshift({ u: t.url, n: t.title || prettyUrl(t.url), t: Date.now() });
  store.set(key, list);
  toast(key === 'list_favs' ? 'Added to Favourites' : 'Bookmarked');
}
function copyLink() { const t = activeTab(); if (t && !isStart(t.url)) { clipboard.writeText(t.url); toast('Link copied'); } }
function setMobile(t, on) {
  t.mobile = on;
  t.view.webContents.setUserAgent(on ? chromeUA(true) : chromeUA(false));
  if (!isStart(t.url)) t.view.webContents.reload();
  pushToolbarState();
  toast(on ? 'Mobile site enabled' : 'Desktop site enabled');
}
function zoom(delta) {
  const t = activeTab(); if (!t) return;
  const wc = t.view.webContents;
  t.zoom = delta === 0 ? 0 : Math.max(-3, Math.min(5, wc.getZoomLevel() + delta * 0.5));
  wc.setZoomLevel(t.zoom);
  const pct = Math.round(Math.pow(1.2, t.zoom) * 100);
  tbJs(`window.ulaaShowZoom&&window.ulaaShowZoom(${pct})`);
  clearTimeout(zoom._t); zoom._t = setTimeout(() => tbJs('window.ulaaHideZoom&&window.ulaaHideZoom()'), 1500);
}
async function toggleReader(t) {
  t = t || activeTab(); if (!t) return;
  if (isStart(t.url)) return toast('Reader is available on webpages');
  const wc = t.view.webContents;
  const invoke = readerJs + `\n;(function(){try{var had=!!document.getElementById('valley-reader-overlay');
    if(window.ulaaReaderToggle)window.ulaaReaderToggle();else if(window.ulaaReaderOpen)window.ulaaReaderOpen();else return 'failed';
    if(had)return 'closed';var s=window.ulaaReaderState?window.ulaaReaderState():'none';
    return s==='open'?'opened':(s==='pending'?'pending':'failed');}catch(e){return 'failed';}})();`;
  try {
    const r = await wc.executeJavaScript(invoke);
    if (r === 'opened' || r === 'pending') t.readerOn = true; else if (r === 'closed') t.readerOn = false;
    else toast('Reader mode is not available on this page');
  } catch (_) { toast('Reader mode could not start'); }
  if (t.id === activeId) pushToolbarState();
}
async function startEraser() {
  const t = activeTab(); if (!t) return;
  if (isStart(t.url) || !/^https?:/.test(t.url)) return toast('Hide Distracting Items is available on webpages');
  const wc = t.view.webContents;
  try {
    const ok = await wc.executeJavaScript(cleanupJs + `\n;(function(){try{return !!(window.ValleyPageCleanup&&window.ValleyPageCleanup.start({dark:${nativeTheme.shouldUseDarkColors}}))}catch(e){return false}})()`);
    if (!ok) return toast('Hide Distracting Items could not start on this page. Try reloading it.');
  } catch (_) { return toast('Hide Distracting Items could not start'); }
  eraserHold = true; layout();
  const poll = async () => {
    if (activeId !== t.id || t.view.webContents.isDestroyed()) { eraserHold = false; layout(); return; }
    let on = false;
    try { on = await wc.executeJavaScript('(function(){try{return !!(window.ValleyPageCleanup&&window.ValleyPageCleanup.isActive&&window.ValleyPageCleanup.isActive())}catch(e){return false}})()'); } catch (_) {}
    if (on) setTimeout(poll, 300); else { eraserHold = false; layout(); }
  };
  setTimeout(poll, 500);
}
function stopEraser(t) {
  if (eraserHold) { eraserHold = false; layout(); }
  try { t.view.webContents.executeJavaScript('try{window.ValleyPageCleanup&&window.ValleyPageCleanup.stop()}catch(e){}').catch(() => {}); } catch (_) {}
}
async function pageCleanupCount(t) {
  try { return Number(await t.view.webContents.executeJavaScript('(function(){return window.ValleyPageCleanup?window.ValleyPageCleanup.count():0})()')) || 0; } catch (_) { return 0; }
}
async function sparkAction(name) {
  const t = activeTab(); if (!t) return;
  if (isStart(t.url)) return toast('This tool is available on webpages');
  try {
    const ok = await t.view.webContents.executeJavaScript(sparkJs + `\n;(function(){try{return typeof window.${name}==='function'?!!window.${name}():false}catch(e){return false}})()`);
    if (!ok) toast('Page tool unavailable on this page');
  } catch (_) { toast('Page tool unavailable'); }
}
function translatePage() {
  const t = activeTab(); if (!t) return;
  try {
    const u = new URL(t.url);
    if (u.hostname.endsWith('.translate.goog')) return toast('This page is already translated.');
    if (!/^https?:$/.test(u.protocol)) return toast("This page can't be translated.");
    const proxy = u.hostname.replace(/-/g, '--').replace(/\./g, '-') + '.translate.goog';
    t.view.webContents.loadURL(`https://${proxy}${u.pathname}${u.search}${u.search ? '&' : '?'}_x_tr_sl=auto&_x_tr_tl=en&_x_tr_hl=en`).catch(() => {});
  } catch (_) { toast('Open a webpage before translating.'); }
}

// ---- find in page
let findText = '';
function showFind() { findBar.setVisible(true); win.contentView.addChildView(findBar); findBar.webContents.focus(); findBar.webContents.send('overlay:find:show', findText); }
function hideFind() { findBar.setVisible(false); const t = activeTab(); if (t) { try { t.view.webContents.stopFindInPage('clearSelection'); } catch (_) {} t.view.webContents.focus(); } }

// ---- tabs / bookmarks panel
function openPanel(mode) { panelMode = mode; panel.setVisible(true); win.contentView.addChildView(panel); panel.webContents.focus(); panel.webContents.send('overlay:panel:show', mode); }
function closePanel() { if (panel && panelMode) { panelMode = null; panel.setVisible(false); const t = activeTab(); if (t) t.view.webContents.focus(); } }

// ------------------------------------------------------------------ menus
function popup(tpl) { Menu.buildFromTemplate(tpl).popup({ window: win }); }
const sep = { type: 'separator' };
function newTabItems() {
  return [{ label: 'New Tab', accelerator: 'CmdOrCtrl+T', click: () => createTab(START_URL, false) },
    { label: 'New Private Tab', accelerator: 'CmdOrCtrl+Shift+N', click: () => createTab(START_URL, true) }];
}
function showPageMenu() {
  const t = activeTab(); if (!t) return;
  const web = !isStart(t.url);
  popup([
    IS_MAC ? { role: 'shareMenu', sharingItem: { urls: web ? [t.url] : [] } } : { label: 'Copy link to share', enabled: web, click: copyLink },
    { label: 'Add to Favourites', enabled: web, click: () => saveLink('list_favs') },
    { label: 'Add Bookmark', enabled: web, click: () => saveLink('list_bookmarks') },
    { label: 'Bookmarks & Favourites', accelerator: 'CmdOrCtrl+Shift+O', click: () => openPanel('bookmarks') },
    { label: 'Downloads', accelerator: 'CmdOrCtrl+J', click: () => openHomeView('downloads') },
    { label: 'History', accelerator: 'CmdOrCtrl+Y', click: () => openHomeView('history') },
    sep, ...newTabItems(), sep,
    { label: 'Reader mode', enabled: web, click: () => toggleReader(t) },
    { label: 'Translate page', enabled: web, click: translatePage },
    { label: 'Summarise page', enabled: web, click: () => sparkAction('ulaaSummarise') },
    { label: 'Hide Distracting Items', enabled: web, click: startEraser },
    { label: 'Find in page', accelerator: 'CmdOrCtrl+F', click: showFind },
    sep,
    { label: 'Install site as app', enabled: web, click: () => installApp(t) },
    { label: 'Mobile site', type: 'checkbox', checked: !!t.mobile, click: () => setMobile(t, !t.mobile) },
    { label: 'Zoom in', accelerator: 'CmdOrCtrl+Plus', click: () => zoom(1) },
    { label: 'Zoom out', accelerator: 'CmdOrCtrl+-', click: () => zoom(-1) },
    { label: 'Reset zoom', accelerator: 'CmdOrCtrl+0', click: () => zoom(0) },
    sep,
    { label: 'Home', click: () => t.view.webContents.loadURL(START_URL) },
    { label: 'Print…', accelerator: 'CmdOrCtrl+P', click: () => t.view.webContents.print() },
    { label: 'Developer tools', accelerator: IS_MAC ? 'Alt+Cmd+I' : 'F12', click: () => t.view.webContents.toggleDevTools() }
  ]);
}
function showTabActions() {
  const t = activeTab(); if (!t) return;
  const mine = visibleTabs().length;
  popup([
    { label: `${mine} ${mine === 1 ? 'Tab' : 'Tabs'}  ·  View All`, accelerator: 'CmdOrCtrl+Shift+A', click: () => openPanel('tabs') },
    sep, ...newTabItems(), sep,
    { label: 'Close This Tab', accelerator: 'CmdOrCtrl+W', click: () => closeTab(t) },
    { label: `Close All ${mine} Tabs`, click: () => closeAllTabs(t.private) }
  ]);
}
function closeAllTabs(priv) {
  const doomed = visibleTabs().filter(x => x.private === priv);
  const keep = tabs.some(x => x.private !== priv);
  for (const d of doomed) closeTab(d);
  if (!tabs.length || (keep && !activeTab())) createTab(START_URL, false);
}
function showContextMenu(tab, p) {
  const wc = tab.view.webContents;
  const items = [];
  if (p.linkURL) {
    items.push({ label: 'Open link in new tab', click: () => createTab(p.linkURL, tab.private, false) },
      { label: 'Open link in private tab', click: () => createTab(p.linkURL, true, false) },
      { label: 'Copy link address', click: () => clipboard.writeText(p.linkURL) }, sep);
  }
  if (p.mediaType === 'image' && p.srcURL) {
    items.push({ label: 'Open image in new tab', click: () => createTab(p.srcURL, tab.private, false) },
      { label: 'Save image as…', click: () => wc.downloadURL(p.srcURL) },
      { label: 'Copy image', click: () => wc.copyImageAt(p.x, p.y) }, sep);
  }
  if (p.isEditable) items.push({ role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }, sep);
  else if (p.selectionText) {
    const s = p.selectionText.trim();
    items.push({ role: 'copy' },
      { label: `Search for “${s.length > 28 ? s.slice(0, 28) + '…' : s}”`, click: () => createTab(routeSearch(s, false, START_URL), tab.private, true) }, sep);
  }
  if (p.misspelledWord) for (const sg of p.dictionarySuggestions.slice(0, 4)) items.push({ label: sg, click: () => wc.replaceMisspelling(sg) });
  const nav = wc.navigationHistory;
  items.push({ label: 'Back', enabled: nav.canGoBack(), click: () => nav.goBack() },
    { label: 'Forward', enabled: nav.canGoForward(), click: () => nav.goForward() },
    { label: 'Reload', click: () => wc.reload() }, sep,
    { label: 'Inspect', click: () => wc.inspectElement(p.x, p.y) });
  popup(items);
}

// ------------------------------------------------------------------ toolbar bridge (ValleyNative)
async function onNative(name, arg) {
  const t = activeTab();
  const wc = t && t.view.webContents;
  switch (name) {
    case 'searchSettings':
      if (t && isStart(t.url)) wc.executeJavaScript(`window.valleySettingsSearch&&window.valleySettingsSearch(${q(String(arg || '').trim())})`).catch(() => {});
      break;
    case 'nav': {
      if (!t) break;
      const nav = wc.navigationHistory;
      if (navForward) { if (nav.canGoForward()) nav.goForward(); else toast('No page to go forward to'); }
      else if (nav.canGoBack()) nav.goBack(); else toast('No page to go back to');
      break;
    }
    case 'addtabmenu': popup(newTabItems()); break;
    case 'tabactions': showTabActions(); break;
    case 'menu': showPageMenu(); break;
    case 'reader': toggleReader(t); break;
    case 'zoomIn': zoom(1); break;
    case 'zoomOut': zoom(-1); break;
    case 'zoomReset': zoom(0); break;
    case 'eraserMenu':
      if (!t || isStart(t.url)) return toast('Hide Distracting Items is available on webpages');
      tbJs(`window.ulaaSetEraserCount&&window.ulaaSetEraserCount(${await pageCleanupCount(t)})`);
      break;
    case 'eraserErase': startEraser(); break;
    case 'eraserRestore': {
      if (!t) return toast('No active page');
      let n = 0;
      try { n = Number(await wc.executeJavaScript('(function(){try{return window.ValleyPageCleanup?window.ValleyPageCleanup.restore():0}catch(e){return 0}})()')) || 0; } catch (_) {}
      toast(n > 0 ? `Showing ${n} hidden item${n === 1 ? '' : 's'}` : 'No hidden items on this page');
      tbJs(`window.ulaaSetEraserCount&&window.ulaaSetEraserCount(${await pageCleanupCount(t)})`);
      break;
    }
    case 'reload': if (t) { if (t.loading) wc.stop(); else wc.reload(); } break;
    case 'voiceSearch': startVoice(); break;
    case 'voiceCancel': stopVoice(); break;
    case 'findInPage': showFind(); break;
    case 'address': toolbar.webContents.focus(); break;
    case 'folded': case 'surface': toolbarExpanded = !!arg; layout(); break;
    case 'hidebar': toolbarHidden = true; layout(); break;
    case 'smartsetting': {
      store.set('smart_search', !!arg);
      const v = arg ? '1' : '0';
      for (const x of tabs) if (isStart(x.url)) x.view.webContents.executeJavaScript(`try{localStorage.setItem('hp.smart','${v}');localStorage.setItem('ulaa-smart','${v}')}catch(e){}`).catch(() => {});
      break;
    }
    case 'smartstate': tbJs(`window.ulaaSetSmart&&window.ulaaSetSmart(${!!pref('smart_search', true)})`); break;
    case 'search': {
      const text = String(arg || '').trim();
      if (!text || !t) break;
      if (!t.private) store.recordSearch(text);
      let smart = pref('smart_search', true);
      if (isStart(t.url)) {
        try {
          const raw = await wc.executeJavaScript("(function(){try{var s=localStorage.getItem('hp.smart');if(s===null)s=localStorage.getItem('ulaa-smart');return s}catch(e){return null}})()");
          if (raw === '0') smart = false; else if (raw === '1') smart = true;
          store.set('smart_search', smart);
        } catch (_) {}
      }
      wc.loadURL(routeSearch(text, smart, START_URL)).catch(() => {});
      wc.focus();
      break;
    }
    case 'navmode': navForward = arg === 'Forward'; pushToolbarState(); break;
    case 'action': onAction(String(arg)); break;
    case 'tabSwipe': switchBy(arg === 'next' ? 1 : -1); break;
    case 'tool': onTool(String(arg)); break;
  }
}
function onAction(a) {
  const t = activeTab(); if (!t) return;
  const wc = t.view.webContents;
  switch (a) {
    case 'share': copyLink(); break;
    case 'favourite': saveLink('list_favs'); break;
    case 'bookmark': saveLink('list_bookmarks'); break;
    case 'desktop': setMobile(t, !t.mobile); break;
    case 'installapp': installApp(); break;
    case 'downloads': openHomeView('downloads'); break;
    case 'home': wc.loadURL(START_URL); break;
    case 'newtab': createTab(START_URL, false); break;
    case 'reader': toggleReader(t); break;
    case 'privatetab': createTab(START_URL, true); break;
    case 'bookmarks': openPanel('bookmarks'); break;
    case 'privacy': openPrivacyMenu(); break;
    case 'alltabs': openPanel('tabs'); break;
    case 'closetab': closeTab(t); break;
    case 'navback': if (wc.navigationHistory.canGoBack()) wc.navigationHistory.goBack(); break;
    case 'navforward': if (wc.navigationHistory.canGoForward()) wc.navigationHistory.goForward(); break;
    case 'showbar': toolbarHidden = false; layout(); break;
  }
}
function onTool(n) {
  switch (n) {
    case 'voiceSearch': onNative('voiceSearch'); break;
    case 'findInPage': showFind(); break;
    case 'translate': translatePage(); break;
    case 'eraser': startEraser(); break;
    case 'summarise': sparkAction('ulaaSummarise'); break;
    case 'copy': copyLink(); break;
    case 'home': { const t = activeTab(); if (t) t.view.webContents.loadURL(START_URL); tbJs('window.ulaaFold&&window.ulaaFold(false)'); break; }
    case 'hidebar': toolbarHidden = true; layout(); break;
  }
}
function openPrivacyMenu() {
  const flag = (label, key, def) => ({ label, type: 'checkbox', checked: !!pref(key, def), click: (mi) => { store.set(key, mi.checked); toast('Applies to pages you open next'); } });
  const t = activeTab();
  const host = t && /^https?:/.test(t.url) ? hostOf(t.url) : '';
  const ex = pref('privacy_exceptions', []);
  popup([
    flag('Block ads and trackers', 'privacy_block_ads', true),
    flag('Hide cookie banners', 'privacy_hide_banners', true),
    flag('Fingerprint protection', 'privacy_fingerprint', true),
    flag('Block WebRTC IP leaks', 'privacy_webrtc', false),
    flag('Send Global Privacy Control', 'privacy_gpc', true),
    flag('Strip tracking parameters from links', 'privacy_strip_params', true),
    sep,
    { label: 'Update filter lists now (EasyList, EasyPrivacy, uBlock)', click: () => updateFilterLists(false) },
    { label: 'Auto-update filter lists weekly', type: 'checkbox', checked: !!pref('filters_auto', false), click: (mi) => { store.set('filters_auto', mi.checked); if (mi.checked) updateFilterLists(false); } },
    sep,
    { label: `${blockedCount} trackers blocked this session`, enabled: false },
    ...(host ? [{ label: ex.includes(host) ? `Resume protection on ${host}` : `Turn protection off for ${host}`,
      click: () => { store.set('privacy_exceptions', ex.includes(host) ? ex.filter(x => x !== host) : ex.concat(host)); t.view.webContents.reload(); } }] : [])
  ]);
}


// ------------------------------------------------------------------ groups, pins, profiles
function ensureGroup(name) {
  const gs = store.get('groups', []);
  if (!gs.some(g => g.name.toLowerCase() === name.toLowerCase())) { gs.push({ name, collapsed: false }); store.set('groups', gs); }
  return (store.get('groups', []).find(g => g.name.toLowerCase() === name.toLowerCase()) || { name }).name;
}
function setTabGroup(tab, name) { tab.group = name ? ensureGroup(name) : ''; if (name) tab.pinned = false; notifySide(); }
function moveTab(id, beforeId, group) {
  const t = tabs.find(x => x.id === id); if (!t) return;
  if (beforeId != null) {
    const b = tabs.find(x => x.id === beforeId); if (!b) return;
    t.group = b.group; t.pinned = b.pinned;
    tabs.splice(tabs.indexOf(t), 1); tabs.splice(tabs.indexOf(b), 0, t);
  } else if (group !== null && group !== undefined) { t.pinned = false; t.group = group ? ensureGroup(group) : ''; }
  notifySide();
}
function groupMenu(name) {
  popup([
    { label: 'Rename group…', click: () => sidebar.webContents.send('overlay:side:ask', { kind: 'rename', name }) },
    { label: 'New tab in group', click: () => createTab(START_URL, false, true, { group: name }) },
    sep,
    { label: 'Ungroup tabs', click: () => { tabs.forEach(t => { if (t.group === name) t.group = ''; }); store.set('groups', store.get('groups', []).filter(g => g.name !== name)); notifySide(); } },
    { label: 'Close all tabs in group', click: () => { tabs.filter(t => t.group === name && t.profile === profileId).forEach(closeTab); store.set('groups', store.get('groups', []).filter(g => g.name !== name)); notifySide(); } }
  ]);
}
function tabMenu(id) {
  const t = tabs.find(x => x.id === id); if (!t) return;
  const groups = store.get('groups', []);
  const web = !isStart(t.url);
  popup([
    { label: t.pinned ? 'Unpin tab' : 'Pin tab', click: () => { t.pinned = !t.pinned; if (t.pinned) t.group = ''; notifySide(); } },
    { label: 'Move to group', submenu: [
      ...groups.map(g => ({ label: g.name, type: 'radio', checked: t.group === g.name, click: () => setTabGroup(t, g.name) })),
      ...(groups.length ? [sep] : []),
      { label: 'New group…', click: () => sidebar.webContents.send('overlay:side:ask', { kind: 'group', tab: t.id }) },
      { label: 'No group', enabled: !!t.group, click: () => setTabGroup(t, '') }] },
    sep,
    { label: 'Duplicate tab', enabled: web, click: () => createTab(t.url, t.private, true, { group: t.group, profile: t.profile }) },
    { label: 'Reload tab', click: () => t.view.webContents.reload() },
    { label: 'Install site as app', enabled: web, click: () => installApp(t) },
    sep,
    { label: 'Close tab', click: () => closeTab(t) },
    { label: 'Close other tabs', click: () => visibleTabs().filter(x => x !== t && !x.pinned).forEach(closeTab) }
  ]);
}
function switchProfile(id) {
  const profiles = store.get('profiles', null) || [];
  if (id !== 'default' && !profiles.some(p => p.id === id)) return;
  profileId = id;
  store.ns = id === 'default' ? '' : id + ':';
  store.set('currentProfile', id);
  const cur = tabs.find(t => !t.private && t.profile === id && t.id === (switchProfile.last || {})[id]) || tabs.find(t => !t.private && t.profile === id);
  if (cur) activateTab(cur); else createTab(START_URL, false, true, { profile: id });
  notifySide();
}
function newProfile(name) {
  const profiles = store.get('profiles', null) || [{ id: 'default', name: 'Personal', color: PROFILE_COLORS[0] }];
  const id = 'p' + Date.now().toString(36);
  profiles.push({ id, name: name.slice(0, 24), color: PROFILE_COLORS[profiles.length % PROFILE_COLORS.length] });
  store.set('profiles', profiles);
  switchProfile(id);
}

// ------------------------------------------------------------------ web apps ("Install as App")
function installApp(tab) {
  const t = tab || activeTab();
  if (!t || isStart(t.url) || !/^https?:/.test(t.url)) return toast('Open a website to install it as an app');
  const apps = store.get('webapps', []);
  const origin = new URL(t.url).origin;
  if (apps.some(a => a.origin === origin)) return toast('Already installed');
  const app_ = { id: 'a' + Date.now().toString(36), name: (t.title || prettyUrl(t.url)).slice(0, 40), url: t.url, origin };
  apps.push(app_); store.set('webapps', apps);
  let extra = '';
  if (process.platform === 'win32') {
    try {
      shell.writeShortcutLink(path.join(app.getPath('desktop'), `${app_.name.replace(/[\\/:*?"<>|]/g, '')}.lnk`), 'create',
        { target: process.execPath, args: `--app=${app_.url}`, description: app_.name, icon: process.execPath, iconIndex: 0 });
      extra = ' (desktop shortcut added)';
    } catch (_) {}
  }
  toast(`Installed ${app_.name}${extra}`);
  notifySide();
}
function openApp(id) {
  const a = store.get('webapps', []).find(x => x.id === id); if (a) openAppWindow(a.url, a.name);
}
function openAppWindow(url, name) {
  let origin = ''; try { origin = new URL(url).origin; } catch (_) { return; }
  const existing = appWindows.get(origin);
  if (existing && !existing.isDestroyed()) { if (existing.isMinimized()) existing.restore(); existing.focus(); return; }
  const w = new BrowserWindow({ width: 1100, height: 760, title: name || prettyUrl(url), autoHideMenuBar: true,
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: { session: session.defaultSession, preload: PRELOAD, sandbox: true, contextIsolation: true, nodeIntegrationInSubFrames: true } });
  appWindows.set(origin, w);
  w.on('closed', () => appWindows.delete(origin));
  w.webContents.setWindowOpenHandler(({ url: u, features }) => {
    if (/width=|height=/i.test(features || '') && /^https?:/.test(u)) return { action: 'allow', overrideBrowserWindowOptions: { parent: w, width: 520, height: 700, autoHideMenuBar: true,
      webPreferences: { sandbox: true, contextIsolation: true, preload: PRELOAD, nodeIntegrationInSubFrames: true } } };
    try { if (new URL(u).origin === origin) { w.loadURL(u); return { action: 'deny' }; } } catch (_) {}
    if (win && /^https?:/.test(u)) createTab(u, false, true);
    return { action: 'deny' };
  });
  w.webContents.on('page-title-updated', (_e, t) => w.setTitle(t));
  w.loadURL(url).catch(() => {});
}

// ------------------------------------------------------------------ voice search
async function startVoice() {
  if (IS_MAC) { try { const { systemPreferences } = require('electron'); await systemPreferences.askForMediaAccess('microphone'); } catch (_) {} }
  if (!voiceWin || voiceWin.isDestroyed()) {
    voiceWin = new BrowserWindow({ show: false, width: 320, height: 200, webPreferences: { sandbox: true, contextIsolation: true, preload: PRELOAD, backgroundThrottling: false } });
    await voiceWin.loadURL('valley://app/voice.html').catch(() => {});
  }
  tbJs("window.ulaaVoice&&window.ulaaVoice('start','')");
  voiceWin.webContents.send('overlay:voice:start');
}
function stopVoice() {
  try { if (voiceWin && !voiceWin.isDestroyed()) voiceWin.webContents.send('overlay:voice:stop'); } catch (_) {}
  tbJs("window.ulaaVoice&&window.ulaaVoice('stop','')");
}
function onVoiceEvent(state, text) {
  tbJs(`window.ulaaVoice&&window.ulaaVoice(${q(state)},${q(text)})`);
  if (state === 'final' && text) setTimeout(() => { stopVoice(); onNative('search', text); }, 450);
  else if (state === 'error') setTimeout(stopVoice, 2600);
}

// ------------------------------------------------------------------ filters: build, download, tracking params
const FILTER_LISTS = [
  ['EasyList', 'https://easylist.to/easylist/easylist.txt'],
  ['EasyPrivacy', 'https://easylist.to/easylist/easyprivacy.txt'],
  ['uBlock filters', 'https://ublockorigin.github.io/uAssets/filters/filters.txt']
];
const downloadedListFile = () => path.join(app.getPath('userData'), 'filters-downloaded.txt');
function buildFilter() {
  const f = new Filter();
  f.loadDomains(loadText('blocklist.txt'));
  f.loadRules(loadText('ubo-filters.txt'));
  for (const file of [downloadedListFile(), path.join(app.getPath('userData'), 'filters.txt')]) {
    try { if (fs.existsSync(file)) f.loadRules(fs.readFileSync(file, 'utf8')); } catch (_) {}
  }
  return f;
}
let updatingFilters = false;
async function updateFilterLists(silent) {
  if (updatingFilters) return;
  updatingFilters = true;
  if (!silent) toast('Updating filter lists…');
  try {
    const parts = [];
    for (const [name, url] of FILTER_LISTS) {
      const r = await net.fetch(url, { headers: { 'user-agent': chromeUA(false) } });
      if (!r.ok) throw new Error(`${name}: HTTP ${r.status}`);
      parts.push(await r.text());
    }
    fs.writeFileSync(downloadedListFile(), parts.join('\n'));
    store.set('filters_updated', Date.now());
    filter = buildFilter();
    if (!silent) toast(`Filters updated: ${filter.networkRuleCount.toLocaleString()} network and ${filter.cosmeticRuleCount.toLocaleString()} cosmetic rules`);
  } catch (e) { if (!silent) toast('Could not update filter lists. Check your connection.'); }
  updatingFilters = false;
}
const TRACKING = /^(utm_[a-z]+|fbclid|gclid|dclid|gbraid|wbraid|msclkid|mc_eid|mc_cid|igshid|_hsenc|_hsmi|yclid|twclid|ttclid|mkt_tok|vero_id|oly_enc_id|oly_anon_id|spm|ref_src|ref_url)$/i;
function stripTracking(url) {
  try {
    const u = new URL(url);
    if (!u.search || isAuthHost(u.hostname) || isExempt(u.hostname) || u.searchParams.has('redirect_uri') || u.searchParams.has('client_id')) return null;
    let changed = false;
    for (const k of [...u.searchParams.keys()]) if (TRACKING.test(k)) { u.searchParams.delete(k); changed = true; }
    return changed ? u.toString() : null;
  } catch (_) { return null; }
}

// ------------------------------------------------------------------ downloads
function dlRecords() { return store.get('downloads', []); }
function dlSave(list) { store.set('downloads', list.slice(0, 300)); }
function dlUpdate(id, fn) { const l = dlRecords(); const r = l.find(x => x.id === id); if (r) { fn(r); dlSave(l); } }
function uniqueName(dir, name) {
  const ext = path.extname(name), base = path.basename(name, ext);
  let out = name, i = 1;
  while (fs.existsSync(path.join(dir, out))) out = `${base} (${i++})${ext}`;
  return out;
}
function dlJson() {
  return JSON.stringify(dlRecords().map(r => Object.assign({}, r, { missing: r.status === 'Downloaded' && !(r.path && fs.existsSync(r.path)) })));
}
function refreshDownloadsPage() {
  const payload = JSON.stringify(dlJson());
  for (const t of tabs) if (isStart(t.url)) t.view.webContents.executeJavaScript(`window.valleyRenderDownloads&&window.valleyRenderDownloads(${payload})`).catch(() => {});
}
let lastDlPush = 0;
function onDownload(ses, item, wc) {
  const owner = wc ? tabByWc(wc) : null;
  const dir = app.getPath('downloads');
  const name = uniqueName(dir, item.getFilename() || 'download');
  const savePath = path.join(dir, name);
  item.setSavePath(savePath);
  const id = Date.now() * 1000 + Math.floor(Math.random() * 1000);
  const list = dlRecords();
  list.unshift({ id, title: name, url: item.getURL(), mime: item.getMimeType() || '', status: 'Downloading',
    total: item.getTotalBytes(), done: 0, time: Date.now(), path: savePath, tabId: owner ? owner.id : null });
  dlSave(list);
  toast(`Downloading ${name}`);
  refreshDownloadsPage();
  item.on('updated', (_e, state) => {
    dlUpdate(id, r => { r.done = item.getReceivedBytes(); r.total = item.getTotalBytes(); r.status = state === 'interrupted' ? 'Failed' : item.isPaused() ? 'Paused' : 'Downloading'; });
    if (Date.now() - lastDlPush > 600) { lastDlPush = Date.now(); refreshDownloadsPage(); }
  });
  item.once('done', (_e, state) => {
    dlUpdate(id, r => {
      r.status = state === 'completed' ? 'Downloaded' : 'Failed';
      if (state !== 'completed') r.error = state === 'cancelled' ? 'Cancelled' : 'The download was interrupted';
      else { r.done = r.total = item.getReceivedBytes(); }
    });
    toast(state === 'completed' ? `Downloaded ${name}` : `Download failed: ${name}`);
    refreshDownloadsPage();
  });
}

// ------------------------------------------------------------------ IPC
function wireIpc() {
  ipcMain.on('native', (e, name, arg) => { if (toolbar && e.sender === toolbar.webContents) onNative(name, arg); else if (handle && e.sender === handle.webContents) onAction('showbar'); });
  ipcMain.on('shield:get', (e, url) => {
    let out = '';
    try {
      if (shieldSource) out = shieldSource.replace('__VALLEY_CFG__', shieldCfg());
      const host = hostOf(url);
      if (host && pref('privacy_block_ads', true) && !isExempt(host)) {
        const sl = filter.scriptletsFor(host);
        if (sl.length) out += '\n;' + SCRIPTLET_RUNTIME + '(' + JSON.stringify(sl) + ');';
      }
    } catch (_) {}
    e.returnValue = out;
  });
  ipcMain.on('hist', (e, op, a, b) => {
    let rv = '';
    try {
      if (!isTrusted(e)) { rv = (op === 'snapshot' || op === 'stats') ? '{}' : ''; return; }
      const t = activeTab();
      switch (op) {
        case 'appVersion': rv = app.getVersion(); break;
        case 'setTheme': { const p = a === 'light' || a === 'dark' ? a : 'system'; store.set('themePref', p); nativeTheme.themeSource = p; break; }
        case 'recordSearch': if (!(t && t.private)) store.recordSearch(a); break;
        case 'removeSearch': store.removeSearch(a); break;
        case 'clearSearches': store.clearSearches(); break;
        case 'recordOpened': if (!(t && t.private)) store.recordOpened(a, b); break;
        case 'removeOpened': store.removeOpened(a); break;
        case 'clearOpened': store.clearOpened(); break;
        case 'snapshot': rv = JSON.stringify({ s: store.history('history_searches'), o: store.history('history_opened') }); break;
        case 'stats': rv = JSON.stringify({ blocked: blockedCount, domains: filter.domains.size + filter.networkRuleCount }); break;
      }
    } finally { e.returnValue = rv; }
  });
  ipcMain.on('dl', (e, op, id) => {
    let rv = '[]';
    try {
      if (!isTrusted(e)) return;
      switch (op) {
        case 'list': rv = dlJson(); break;
        case 'open': { const r = dlRecords().find(x => x.id === id); if (r && r.path && fs.existsSync(r.path)) shell.openPath(r.path); else refreshDownloadsPage(); break; }
        case 'refresh': refreshDownloadsPage(); break;
        case 'remove': dlSave(dlRecords().filter(x => x.id !== id)); refreshDownloadsPage(); break;
        case 'clearAll': dlSave(dlRecords().filter(x => x.status === 'Downloading' || x.status === 'Paused')); refreshDownloadsPage(); break;
        case 'retry': {
          const r = dlRecords().find(x => x.id === id); if (!r) break;
          const owner = tabs.find(x => x.id === r.tabId) || activeTab();
          dlSave(dlRecords().filter(x => x.id !== id));
          if (owner) owner.view.webContents.downloadURL(r.url);
          break;
        }
      }
    } finally { e.returnValue = rv; }
  });
  ipcMain.on('tour', (e, op, v) => {
    if (!isTrusted(e)) return;
    const tab = tabByWc(e.sender);
    if (!tab) return;
    if (op === 'view') { tab.homeView = String(v || 'home').toLowerCase().replace(/[^a-z0-9-]/g, '') || 'home'; if (tab.id === activeId) pushToolbarState(); }
    else if (op === 'active') { if (v) tourOwnerId = tab.id; else if (tourOwnerId === tab.id) tourOwnerId = null; layout(); }
  });

  // overlays written for desktop: tabs / bookmarks panel and the find bar
  const guard = (fn) => (e, ...a) => (isTrusted(e) ? fn(...a) : null);
  ipcMain.handle('overlay:panel:data', guard(() => {
    const a = activeTab();
    return { mode: panelMode || 'tabs', private: !!(a && a.private), activeId,
      tabs: visibleTabs().map(t => ({ id: t.id, thumb: t.thumb, title: t.title || prettyUrl(t.url), url: isStart(t.url) ? '' : t.url, favicon: t.favicon, home: isStart(t.url) })),
      favs: store.get('list_favs', []), bookmarks: store.get('list_bookmarks', []), dark: nativeTheme.shouldUseDarkColors };
  }));
  ipcMain.handle('overlay:panel:switch', guard((id) => { const t = tabs.find(x => x.id === id); if (t) activateTab(t); }));
  ipcMain.handle('overlay:panel:close', guard((id) => { const t = tabs.find(x => x.id === id); if (t) { const keepOpen = panelMode === 'tabs'; closeTab(t); if (keepOpen && tabs.length) openPanel('tabs'); } }));
  ipcMain.handle('overlay:panel:new', guard((priv) => { createTab(START_URL, !!priv); }));
  ipcMain.handle('overlay:panel:dismiss', guard(() => closePanel()));
  ipcMain.handle('overlay:panel:open', guard((url) => { const t = activeTab(); closePanel(); if (t) t.view.webContents.loadURL(url).catch(() => {}); }));
  ipcMain.handle('overlay:panel:remove', guard((key, url) => { store.set(key, store.get(key, []).filter(x => x.u !== url)); }));
  ipcMain.handle('overlay:panel:closeAll', guard(() => { const a = activeTab(); closePanel(); closeAllTabs(!!(a && a.private)); }));
  ipcMain.handle('overlay:find:query', guard((text, forward, next) => {
    const t = activeTab(); if (!t) return;
    findText = String(text || '');
    if (!findText) { t.view.webContents.stopFindInPage('clearSelection'); return; }
    t.view.webContents.findInPage(findText, { forward: forward !== false, findNext: !!next });
  }));
  ipcMain.handle('overlay:find:close', guard(() => hideFind()));

  // vertical tab sidebar
  ipcMain.handle('overlay:side:data', guard(() => sideState()));
  ipcMain.handle('overlay:side:activate', guard((id) => { const t = tabs.find(x => x.id === id); if (t) { activateTab(t); (switchProfile.last = switchProfile.last || {})[t.profile] = t.id; } }));
  ipcMain.handle('overlay:side:close', guard((id) => closeTab(tabs.find(x => x.id === id))));
  ipcMain.handle('overlay:side:new', guard((priv) => createTab(START_URL, !!priv)));
  ipcMain.handle('overlay:side:collapse', guard(() => { sideCollapsed = !sideCollapsed; store.set('sideCollapsed', sideCollapsed); layout(); notifySide(); }));
  ipcMain.handle('overlay:side:hover', guard((on) => { sideHover = !!on; layout(); }));
  ipcMain.handle('overlay:side:thumb', guard((id) => { const t = tabs.find(x => x.id === id); return t ? t.thumb || '' : ''; }));
  ipcMain.handle('overlay:side:tabMenu', guard((id) => tabMenu(id)));
  ipcMain.handle('overlay:side:groupMenu', guard((name) => groupMenu(name)));
  ipcMain.handle('overlay:side:groupToggle', guard((name) => { store.set('groups', store.get('groups', []).map(g => g.name === name ? Object.assign({}, g, { collapsed: !g.collapsed }) : g)); notifySide(); }));
  ipcMain.handle('overlay:side:newGroup', guard((name, tabId) => { const n = ensureGroup(String(name).slice(0, 24)); const t = tabs.find(x => x.id === tabId); if (t) setTabGroup(t, n); else notifySide(); }));
  ipcMain.handle('overlay:side:renameGroup', guard((old, name) => {
    name = String(name).slice(0, 24);
    store.set('groups', store.get('groups', []).map(g => g.name === old ? Object.assign({}, g, { name }) : g));
    tabs.forEach(t => { if (t.group === old) t.group = name; }); notifySide();
  }));
  ipcMain.handle('overlay:side:move', guard((id, beforeId, group) => moveTab(id, beforeId, group)));
  ipcMain.handle('overlay:side:profile', guard((id) => switchProfile(id)));
  ipcMain.handle('overlay:side:newProfile', guard((name) => newProfile(String(name))));
  ipcMain.handle('overlay:side:app', guard((id) => openApp(id)));
  ipcMain.handle('overlay:side:appMenu', guard((id) => popup([{ label: 'Open', click: () => openApp(id) }, { label: 'Remove app', click: () => { store.set('webapps', store.get('webapps', []).filter(a => a.id !== id)); notifySide(); } }])));
  ipcMain.handle('overlay:side:action', guard((a) => {
    if (a === 'bookmarks') openPanel('bookmarks');
    else if (a === 'downloads' || a === 'history') openHomeView(a);
    else if (a === 'privacy') openPrivacyMenu();
    else if (a === 'settings') { const t = activeTab(); if (t) (isStart(t.url) ? t.view.webContents.executeJavaScript("window.ulaaShowView&&window.ulaaShowView('settings')").catch(() => {}) : t.view.webContents.loadURL(START_URL + '#settings')); }
  }));
  ipcMain.handle('overlay:voice:event', guard((state, text) => onVoiceEvent(String(state), String(text || ''))));
}

// ------------------------------------------------------------------ application menu + shortcuts
function buildAppMenu() {
  const nav = (fn) => () => { const t = activeTab(); if (t) fn(t.view.webContents); };
  const tabItems = [];
  for (let i = 1; i <= 9; i++) tabItems.push({ label: `Tab ${i}`, accelerator: `CmdOrCtrl+${i}`, visible: false,
    click: () => { const vis = visibleTabs(); const t = i === 9 ? vis[vis.length - 1] : vis[i - 1]; if (t) activateTab(t); } });
  const tpl = [
    ...(IS_MAC ? [{ label: 'Valley', submenu: [{ role: 'about' }, sep, { role: 'services' }, sep, { role: 'hide' }, { role: 'hideOthers' }, { role: 'unhide' }, sep, { role: 'quit' }] }] : []),
    { label: 'File', submenu: [
      ...newTabItems(),
      { label: 'Open Location', accelerator: 'CmdOrCtrl+L', click: focusAddress },
      { label: 'Close Tab', accelerator: 'CmdOrCtrl+W', click: () => closeTab(activeTab()) },
      { label: 'Print…', accelerator: 'CmdOrCtrl+P', click: nav(wc => wc.print()) },
      ...(IS_MAC ? [] : [sep, { role: 'quit' }]) ] },
    { label: 'Edit', submenu: [{ role: 'undo' }, { role: 'redo' }, sep, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }, sep,
      { label: 'Find in Page', accelerator: 'CmdOrCtrl+F', click: showFind }] },
    { label: 'View', submenu: [
      { label: 'Reload', accelerator: 'CmdOrCtrl+R', click: nav(wc => wc.reload()) },
      { label: 'Hard Reload', accelerator: 'CmdOrCtrl+Shift+R', click: nav(wc => wc.reloadIgnoringCache()) },
      { label: 'Reader Mode', accelerator: 'CmdOrCtrl+Alt+R', click: () => toggleReader() },
      sep,
      { label: 'Zoom In', accelerator: 'CmdOrCtrl+=', click: () => zoom(1) },
      { label: 'Zoom In (numpad)', accelerator: 'CmdOrCtrl+numadd', visible: false, click: () => zoom(1) },
      { label: 'Zoom Out', accelerator: 'CmdOrCtrl+-', click: () => zoom(-1) },
      { label: 'Actual Size', accelerator: 'CmdOrCtrl+0', click: () => zoom(0) },
      sep,
      { label: 'Show / Hide Toolbar', accelerator: 'CmdOrCtrl+Shift+B', click: () => { toolbarHidden = !toolbarHidden; layout(); } },
      { label: 'Privacy…', click: openPrivacyMenu },
      { role: 'togglefullscreen' },
      { label: 'Developer Tools', accelerator: IS_MAC ? 'Alt+Cmd+I' : 'F12', click: nav(wc => wc.toggleDevTools()) } ] },
    { label: 'History', submenu: [
      { label: 'Back', accelerator: IS_MAC ? 'Cmd+[' : 'Alt+Left', click: nav(wc => wc.navigationHistory.canGoBack() && wc.navigationHistory.goBack()) },
      { label: 'Forward', accelerator: IS_MAC ? 'Cmd+]' : 'Alt+Right', click: nav(wc => wc.navigationHistory.canGoForward() && wc.navigationHistory.goForward()) },
      { label: 'Home', accelerator: IS_MAC ? 'Cmd+Shift+H' : 'Alt+Home', click: nav(wc => wc.loadURL(START_URL)) },
      sep,
      { label: 'Show History', accelerator: 'CmdOrCtrl+Y', click: () => openHomeView('history') },
      { label: 'Downloads', accelerator: 'CmdOrCtrl+J', click: () => openHomeView('downloads') },
      { label: 'Bookmarks & Favourites', accelerator: 'CmdOrCtrl+Shift+O', click: () => openPanel('bookmarks') } ] },
    { label: 'Tabs', submenu: [
      { label: 'Show All Tabs', accelerator: 'CmdOrCtrl+Shift+A', click: () => openPanel('tabs') },
      { label: 'Show / Hide Tab Sidebar', accelerator: 'CmdOrCtrl+Shift+S', click: () => { sideCollapsed = !sideCollapsed; store.set('sideCollapsed', sideCollapsed); layout(); notifySide(); } },
      { label: 'Pin / Unpin Tab', click: () => { const t = activeTab(); if (t) { t.pinned = !t.pinned; if (t.pinned) t.group = ''; notifySide(); } } },
      { label: 'Next Tab', accelerator: 'Ctrl+Tab', click: () => switchBy(1) },
      { label: 'Previous Tab', accelerator: 'Ctrl+Shift+Tab', click: () => switchBy(-1) },
      ...tabItems ] },
    { label: 'Window', submenu: [{ role: 'minimize' }, { role: 'zoom' }, ...(IS_MAC ? [sep, { role: 'front' }] : [{ label: 'Close Window', click: () => win && win.close() }])] }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
}
function focusAddress() {
  toolbarHidden = false; layout();
  toolbar.webContents.focus();
  tbJs("window.ulaaOpenPanel&&window.ulaaOpenPanel('search')");
}

// ------------------------------------------------------------------ lifecycle
function openExternalUrl(u) {
  if (!/^https?:\/\//i.test(u)) return;
  if (!win) return;
  createTab(u, false);
  if (win.isMinimized()) win.restore();
  win.focus();
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
app.setName('Valley');

app.on('second-instance', (_e, argv) => {
  const aa = argv.find(a => a.startsWith('--app='));
  if (aa) return openAppWindow(aa.slice(6), '');
  if (!win && app.isReady()) { createWindow(); createTab(START_URL, false); }
  const u = argv.find(a => /^https?:\/\//i.test(a)); if (win) { if (win.isMinimized()) win.restore(); win.focus(); } if (u) openExternalUrl(u); });
app.on('open-url', (e, u) => { e.preventDefault(); if (app.isReady()) openExternalUrl(u); else app.once('ready', () => setTimeout(() => openExternalUrl(u), 800)); });

app.whenReady().then(() => {
  if (!gotLock) return;
  store = new Store(path.join(app.getPath('userData'), 'valley-prefs.json'));
  nativeTheme.themeSource = store.get('themePref', 'system');
  filter = buildFilter();                                  // bundled lists + downloaded lists + optional <userData>/filters.txt
  sideCollapsed = !!store.get('sideCollapsed', false);
  profileId = store.get('currentProfile', 'default');
  if (!(store.get('profiles', []) || []).some(p => p.id === profileId)) profileId = 'default';
  store.ns = profileId === 'default' ? '' : profileId + ':';
  if (store.get('filters_auto', false) && Date.now() - store.get('filters_updated', 0) > 7 * 864e5) updateFilterLists(true);
  shieldSource = loadText('privacy_shield.js');
  readerJs = loadText('reader.js'); cleanupJs = loadText('page_cleanup.js'); sparkJs = loadText('spark.js');

  setupSession(session.defaultSession);
  wireIpc();
  buildAppMenu();
  nativeTheme.on('updated', pushTheme);
  const appArg = process.argv.find(a => a.startsWith('--app='));
  if (appArg) { openAppWindow(appArg.slice(6), ''); return; }
  createWindow();

  const saved = store.get('session', []);
  const argUrl = process.argv.slice(1).find(a => /^https?:\/\//i.test(a));
  if (Array.isArray(saved) && saved.length && !argUrl) {
    const profs = (store.get('profiles', null) || []).map(p => p.id).concat('default');
    saved.forEach(e => { const o = typeof e === 'string' ? { u: e } : e; createTab(o.u, false, false, { group: o.g, pinned: o.p, profile: profs.includes(o.pr) ? o.pr : 'default' }); });
    const vis = tabs.filter(t => t.profile === profileId);
    const idx = Math.min(store.get('sessionActive', 0), Math.max(0, vis.length - 1));
    activateTab(vis[idx] || tabs[0]);
  } else createTab(argUrl || START_URL, false);

  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) { createWindow(); createTab(START_URL, false); } });
}).catch((e) => { try { dialog.showErrorBox('Valley failed to start', String((e && e.stack) || e)); } catch (_) {} });

app.on('before-quit', () => {
  quitting = true;
  try {
    const keep = tabs.filter(t => !t.private);
    store.set('session', keep.filter(t => t.url).map(t => ({ u: t.url, g: t.group, p: t.pinned, pr: t.profile })));
    store.set('sessionActive', Math.max(0, keep.filter(t => t.profile === profileId).indexOf(activeTab())));
    store.flush();
  } catch (_) {}
});
app.on('window-all-closed', () => { if (!IS_MAC) app.quit(); else { tabs = []; activeId = null; } });
