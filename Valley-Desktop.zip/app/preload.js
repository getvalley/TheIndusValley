'use strict';
// One preload for every Valley view (sandboxed, context-isolated, no Node access).
//  - valley://app pages (toolbar, start page, tabs/find overlays) get the same bridge objects the
//    Android WebViews had: ValleyNative, ValleyHistory, ValleyDownloads, ValleyTour.
//  - http(s) pages get the privacy shield injected into the page's own world before any page script.
const { contextBridge, ipcRenderer, webFrame } = require('electron');

if (location.protocol === 'valley:') {
  const post = (name) => (arg) => ipcRenderer.send('native', name, arg);
  const NATIVE = ['searchSettings', 'nav', 'addtabmenu', 'tabactions', 'menu', 'reader', 'zoomIn', 'zoomOut', 'zoomReset',
    'eraserMenu', 'eraserErase', 'eraserRestore', 'reload', 'voiceSearch', 'voiceCancel', 'findInPage', 'address', 'folded',
    'hidebar', 'surface', 'smartsetting', 'smartstate', 'search', 'navmode', 'action', 'tabSwipe', 'tool'];
  const native = {};
  for (const n of NATIVE) native[n] = post(n);
  contextBridge.exposeInMainWorld('ValleyNative', native);

  const sync = (ch, ...a) => ipcRenderer.sendSync(ch, ...a);
  contextBridge.exposeInMainWorld('ValleyHistory', {
    appVersion: () => sync('hist', 'appVersion'),
    setTheme: (p) => ipcRenderer.send('hist', 'setTheme', p),
    recordSearch: (q) => ipcRenderer.send('hist', 'recordSearch', q),
    removeSearch: (q) => sync('hist', 'removeSearch', q),
    clearSearches: () => sync('hist', 'clearSearches'),
    recordOpened: (u, t) => ipcRenderer.send('hist', 'recordOpened', u, t),
    removeOpened: (u) => sync('hist', 'removeOpened', u),
    clearOpened: () => sync('hist', 'clearOpened'),
    snapshot: () => sync('hist', 'snapshot'),
    stats: () => sync('hist', 'stats')
  });
  contextBridge.exposeInMainWorld('ValleyDownloads', {
    list: () => sync('dl', 'list'),
    open: (id) => ipcRenderer.send('dl', 'open', id),
    refresh: () => ipcRenderer.send('dl', 'refresh'),
    remove: (id) => ipcRenderer.send('dl', 'remove', id),
    retry: (id) => ipcRenderer.send('dl', 'retry', id),
    clearAll: () => ipcRenderer.send('dl', 'clearAll')
  });
  contextBridge.exposeInMainWorld('ValleyTour', {
    view: (n) => ipcRenderer.send('tour', 'view', n),
    active: (on) => ipcRenderer.send('tour', 'active', !!on)
  });
  // used by the tabs / bookmarks / find overlays written for the desktop build
  contextBridge.exposeInMainWorld('ValleyDesktop', {
    platform: process.platform,
    invoke: (ch, ...a) => ipcRenderer.invoke('overlay:' + ch, ...a),
    on: (ch, fn) => { ipcRenderer.on('overlay:' + ch, (_e, ...a) => fn(...a)); }
  });
} else if (location.protocol === 'http:' || location.protocol === 'https:') {
  try {
    const code = ipcRenderer.sendSync('shield:get', location.href);
    if (code) webFrame.executeJavaScript(code).catch(() => {});
  } catch (_) { /* never let the shield break a page */ }
}
