VALLEY WEBSITE - GITHUB REPOSITORY DROP-IN

Extract this ZIP into the ROOT of your existing Valley Android repository.
It does not replace your Android source or existing Android build workflows.

Included:
- website/index.html
- website/Valley-1.0.apk
- website/assets/ (cropped screenshots and edited MP4 demonstrations)
- .github/workflows/deploy-valley-website.yml

Video edits:
1. Smart Search uses the actual Valley home/search screen recording. The camera stays close to the search bar while "open oneplus nord ce 6 on Flipkart" is typed, then smoothly moves to the first Flipkart product result and holds there.
2. Tab management shows the complete portrait tab manager and the first two group changes only (3 Tabs -> Important -> 3 Tabs). It ends before the third group change and recording controls.

Comparison order:
- Reader Mode: original webpage on the LEFT, Valley Reader on the RIGHT.
- Translation: Hindi at the TOP, English translation at the BOTTOM.
- Both animated dividers reveal the translated/reader result in the correct direction.

Install into your existing GitHub repository:
1. Extract this ZIP.
2. Merge its .github and website folders into the ROOT of your Valley repository.
3. Do not delete or replace existing Android files or workflows.
4. Push to main or master.
5. In GitHub, open Settings -> Pages and set the deployment source to "GitHub Actions".
6. The workflow deploys the contents of website/ as the GitHub Pages site.

The APK is the exact file you supplied earlier, renamed Valley-1.0.apk. This package does not independently certify its safety or compatibility.
