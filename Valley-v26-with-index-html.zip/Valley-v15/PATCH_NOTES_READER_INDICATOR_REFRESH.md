# Valley v26 Reader Indicator + Refresh Safety Fix

## Reader active indicator
- Reworked the native Reader button active background as a layered cyan-blue circular indicator with a subtle halo.
- Reset the icon tint and background cleanly when Reader Mode is inactive.
- Kept the existing Reader Mode JavaScript toggle and callback flow unchanged.

## Refresh action
- Kept the existing native refresh button and `ValleyNative.reload()` JavaScript bridge.
- Routed both through one `reloadActivePage()` helper.
- The helper resolves the WebView from the selected tab, handles a missing active tab/WebView safely, reloads a blank tab to the Valley start page, and otherwise calls `WebView.reload()`.
- Avoided adding a duplicate `@JavascriptInterface` method because the toolbar already invokes the existing annotated `reload()` bridge method.

Validation: ZIP integrity and targeted source checks passed. Full Android Gradle compilation and device UI testing were not run.
