# Valley V26: Mozilla Reader extraction integration

- Added lazy loading of Mozilla Readability 0.6.0 when Reader is first opened.
- Uses a cloned page document so parsing does not mutate the active webpage.
- Sanitizes extracted markup to a small text-focused allowlist and removes images/media.
- Preserves Valley's existing Reader overlay, font picker, light/dark toggle, and native bridge.
- Keeps the existing local extractor as an offline or library-load-failure fallback.
- Added Apache-2.0 dependency attribution in `app/src/main/assets/READABILITY-LICENSE.txt`.

Validation: JavaScript syntax and ZIP integrity checked. Android build and on-device
behavior have not been verified in this environment.
