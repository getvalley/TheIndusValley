# Icon refresh

All in-app icons redrawn as one consistent set: 24px grid, rounded caps and joins,
1.8 to 2.3 stroke, Safari-style outlines with Google-style simplicity.

Redrawn: back, chevrons, home, reload, reader, more, share, plus, copy, eraser,
summary, shield, smart, star, bookmark, bookmarks, tabs, group, private (incognito hat and glasses).

New (menus were reusing wrong icons before):
ic_close, ic_close_others, ic_duplicate, ic_select, ic_pin, ic_download, ic_print,
ic_zoom_in, ic_zoom_out, ic_zoom_reset, ic_desktop, ic_mobile, ic_new_group, ic_move.

MainActivity.kt: only the icon argument of menuRow(...) calls changed.
toolbar.html: inline SVGs updated to match; nav chevron paths left untouched
(the JS swaps them by exact path string). Launcher icon, logo and index.html untouched.

## Hide Address Bar fix
Cause: hideBar() only touched the legacy native toolbar (R.id.toolbar, visibility="gone"),
so nothing visible changed. It now slides the real toolbar (toolbarWeb) off the bottom
and shows a small grip handle. Tap the handle, scroll up, or switch tabs to bring it back.
