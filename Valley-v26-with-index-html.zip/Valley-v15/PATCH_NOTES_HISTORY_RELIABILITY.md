# History reliability fix

- Added native WebView `onJsConfirm` handling so JavaScript confirmation dialogs used by the History page are displayed and return the user's choice.
- Serialized native history mutations, removals, clears, and snapshots behind one lock.
- Changed history persistence writes to synchronous commits for mutation operations, preventing a queued write from completing after a clear operation.
- Removed UI-thread-queued history bridge writes, which could previously execute after a clear and recreate deleted entries.
- Kept Android SharedPreferences as the authoritative history store; homepage and History views continue to refresh from native snapshots.
- Preserved the existing History page layout and interactions.

Build verification: not run in this environment because neither Gradle wrapper nor system Gradle is present in the supplied project/runtime.
