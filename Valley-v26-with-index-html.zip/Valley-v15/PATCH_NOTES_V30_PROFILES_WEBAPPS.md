# V30 - download name clashes, profiles, install as app, settings search, light-mode contrast

Not built or tested here (no Gradle/Android SDK in this environment). Needs a build and a run on a device.
build.gradle: androidx.webkit 1.11.0 -> 1.12.1 (needed for profiles).

## 1. Downloads that failed when the file name already existed
Root cause: on Android 10+ an app can't see files that other apps (or an earlier install) put in Downloads, so the
MediaStore / File.exists() check said "free", then DownloadManager hit the real file and cancelled the download.
- A download that fails with "file already exists" is now queued again as "name (1).ext", "(2)", ... automatically
  (up to 25 tries), keeping the same cookies/referer/tab. It no longer ends up as a red failed entry.
- Valley also remembers the names it saved itself and avoids them up front.
- Records now store the user agent and referer so the re-queue behaves like the first request.

## 2. Profiles (Tabs page)
- New pill at the top of the Tabs page: coloured dot + profile name. Tap it to switch, create, rename or delete a profile.
- Starts with Personal and Work. Personal uses the WebView's default storage, so existing logins stay put.
- Each tab belongs to a profile. The Tabs page, the tab count, "Close all" and closing a tab stay inside the current profile.
  Swiping to a tab from another profile switches the active profile to match.
- Other profiles get their own cookies and site storage through androidx.webkit profiles (WebViewFeature.MULTI_PROFILE).
  If the phone's WebView is too old, profiles still keep tabs apart but share one cookie jar; the menu says so.
- Saved and restored with the tabs. Pop-up windows and downloads use the profile of the tab that opened them.
- Tab groups are still shared across profiles. Private tabs ignore profiles.
- Deleting a profile closes its tabs and removes its saved logins.

## 3. Install as App
- "Install as App" in the page menu (toolbar settings sheet and the native menu). Pick a name, confirm the launcher prompt,
  and a home-screen icon appears that opens the site in its own window with no toolbar, in its own recents entry.
- The app keeps the profile it was installed from. Links to other sites open in your default browser.
- App windows never overwrite the browser's saved tabs, history or active profile, and skip the default-browser prompt.
- Not available in private tabs or on the start page. Needs a launcher that supports pinned shortcuts.
- This is a shortcut to a standalone window, not a full PWA install (no offline service worker or manifest handling).

## 4. Grey text on light mode
- Light-mode greys on the start-page subpages are much darker (--ink-2/--ink-3), card backing is more solid, and small grey
  text is a bit heavier. Native menus and the Tabs page use the same darker greys (Pal.kt, colors.xml). Dark mode unchanged.

## 5. Toolbar searches settings on subpages
- While a start-page subpage (History, Downloads, Security, Changelogs, General, About) is open, the toolbar pill and its
  search box say "Search settings". Results appear as you type; tapping one opens that page, scrolls to the item and flashes it.
- Smart-search toggle is hidden in that mode. On the main start page and on websites nothing changes.
- The start page reports its open view through ValleyTour.view(name).
