# V29 – page taps near the toolbar

The toolbar WebView is a transparent overlay (78dp tall, full width). A WebView eats every touch in its
bounds, so page content beside/above the visible pill was dead.

- New `PassThroughWebView`: declines ACTION_DOWN outside the toolbar's touchable rects, so the page gets the gesture.
- `toolbar.html` reports visible interactive rects (bar, tools, sheet, eraser menu, zoom float) via `ValleyNative.hit`.
- While a panel is open (WebView expanded) it still claims all touches so tap-outside-to-dismiss works.

## Blurred toolbar background
The toolbar is a separate WebView, so CSS backdrop-filter could never see the page (the glass was just a 90% dark tint).
Now `captureFrost()` (MainActivity) draws the bottom 78dp of the page into a 1/8-scale bitmap, blurs it with `Frost.blur`,
and sends it to toolbar.html (`ulaaSetFrostImg`). Each pill/circle paints its own slice of it as a background and the
tint drops from 90% to ~62% so the blur shows. Refreshed after page load, tab switch and when scrolling settles.
