# Valley V26 tabs pill and group picker polish

- Removed both horizontal parallel rails and their custom Canvas drawing.
- Replaced the rail graphic with a single outlined rounded capsule containing only the current `N Tab(s)` count.
- Added a subtle scale/fade settle animation to the count capsule.
- Removed excess right-side blank space from the group picker by narrowing its container.
- Tightened group-pill label and chevron spacing.
- Chevron now flips vertically using scaleY, rather than rotating through 180 degrees.
- Chevron returns to its normal orientation when the picker closes.
- Reduced the gap between the plus/check side controls and the central count capsule.
- Kept the three dock controls on a common vertical centre line.

Validation: ZIP integrity and source patch assertions. Android build and device rendering are not verified.
