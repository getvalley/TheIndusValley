# V38 - Google sign-in fixes and robustness

## Google sign-in glitch
- Sign-in popups never closed: no `onCloseWindow`. The popup stayed as a blank tab and the site never resumed. Added; it returns to the opener tab. Back on a popup does the same.
- User agent still had `Version/4.0` (only `; wv` was removed), which Google reads as an embedded WebView. Both removed (`browserUserAgent`).
- `X-Requested-With: <package>` header is no longer sent (`REQUESTED_WITH_HEADER_ALLOW_LIST`).
- Third-party cookies were off by default, which breaks the Google button, One Tap and the account chooser frames. They are turned on for the tab when a sign-in provider frame loads (`authHosts`).
- Sign-in hosts are exempt from tracker blocking, uBlock rules, the fingerprint shield (canvas/WebGL/hardware spoofing triggers "this browser may not be secure") and tracking-parameter stripping. OAuth-looking URLs (client_id, state, code, redirect_uri ...) are never rewritten.

## Other faults fixed
- `alert()` and `prompt()` were not handled by the WebChromeClient (only confirm was). Added.
- mailto:, tel:, sms:, market:, intent: links showed ERR_UNKNOWN_URL_SCHEME. Now handed to the system (intent:// honours browser_fallback_url).
- A killed renderer process crashed the whole app. `onRenderProcessGone` now reloads the tab.
