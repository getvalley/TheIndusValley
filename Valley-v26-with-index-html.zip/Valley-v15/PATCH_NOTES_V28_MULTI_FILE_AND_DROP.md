# Multi-file chooser + drag and drop
- onShowFileChooser now builds its own ACTION_GET_CONTENT intent with EXTRA_ALLOW_MULTIPLE (from the input's `multiple`), honours accept types, and no longer wraps it in createChooser.
- onActivityResult reads every ClipData item (fallback: data) instead of parseResult, so all picked files reach the page.
- Dropping files onto a page (split-screen / other apps) fires dragenter/dragover/drop with real File objects at the drop point; if the page doesn't handle the drop, the files are put into the nearest file input. 40 MB total limit.

# APK downloads: Show in File Manager
Tapping a finished .apk on the Downloads page now shows a dialog: "Install" / "Show in Files Manager" / Cancel. The file-manager option opens the Downloads folder (falls back to the system Downloads app).

# Core browser functions
- Camera / microphone for websites: allow/deny prompt per site, then the Android runtime permission (manifest now declares CAMERA, RECORD_AUDIO, MODIFY_AUDIO_SETTINGS). Allowed sites are remembered for the session.
- Location for websites now prompts too (Valley's own start page is still allowed silently).
- Fullscreen video: onShowCustomView/onHideCustomView with landscape + immersive mode; Back exits fullscreen.
- Certificate errors: "This connection isn't private" dialog (Go back / Continue anyway); subresource errors are refused.
- HTTP auth: username/password sign-in dialog.
- Print / Save as PDF in the page tools menu.
- Autofill: WebViews opt in to the system autofill service (disabled in private tabs).
