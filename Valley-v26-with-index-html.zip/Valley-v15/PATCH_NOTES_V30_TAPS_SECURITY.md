# V30 – taps, upright headings, security counter
- History: the whole row opens the page (previously only the small title link did).
- Security and About: h1/h3 upright, Bricolage Grotesque Bold (same as History).
- Security: "Protection status" card with the live tracker-blocked counter and blocklist size (`ValleyHistory.stats()`), refreshed every 2 s while the page is open.
Not built here (no Gradle/Android SDK).
- Filter lists: uBO-style rules no longer apply to a site's own (first-party) requests, matching the host list and URL-pattern checks. A broad rule could return an empty reply for a page's own data fetch (Brave Search shows "500" when switching sections).
