# V29 - pill icons, tab group slider, download fixes

## Toolbar pill (assets/toolbar.html)
- Reader icon: Safari-style page (rounded top block + two text lines).
- Refresh icon: heavier clockwise arrow.
- Both icons are slightly larger (19px) with a 2.1 stroke. Updated in the markup and in ulaaHomeMode().

## Tab Groups slider (MainActivity.kt, tabs overview)
- The slider now sits inside one rounded glass capsule between + and the blue check.
- Names fade out at both ends; only the open group has an outlined capsule, the others are plain text.
- + and check are 44dp circles to match the capsule height.

## Downloads
- blob: and data: links used to be rejected ("This download type is not supported"). They are now read inside the page and saved to Downloads (MediaStore on Android 10+). A page can't write files itself: every call needs a one-time token created by Valley.
- Referer header is sent, since many hosts return 403 without it.
- Roaming no longer blocks downloads (they used to sit in "Queued").
- Existing file names get " (1)", " (2)"... instead of failing.
- If DownloadManager reports a failure, Valley retries once from inside the current page (same cookies and session) when the file is on the same site. Files over 150 MB are not retried this way.
Not built or tested here (no Gradle/Android SDK in this environment).

## Drag and drop 0 byte files
- Dropped files are now opened on the UI thread during the drop itself. Many sources revoke access the moment the drag ends, so the old code (which opened them later on a worker thread) read nothing and the page got empty files.
- A file that still reads as empty is skipped with a toast instead of being delivered as 0 bytes.
- Chunks are appended to the last entry on the page side, so a skipped file can no longer push data onto the wrong file.
