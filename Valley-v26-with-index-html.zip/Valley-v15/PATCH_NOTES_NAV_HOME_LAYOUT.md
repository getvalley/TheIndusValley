# Back/Forward panel layout adjustment

- Back and Forward direction selectors remain on the upper row.
- The selected-direction action is on the lower row and uses the available width.
- Added a separate 48dp circular Home button immediately to the right of that action.
- Reduced the long action button width to make room for Home.
