# Valley v26 - Gemini-requested UI and state updates

Implemented from the user's supplied Gemini snippets, adapted to Valley's native Android/WebView architecture.

- Added Downloads to the native page menu directly above Add Bookmark.
- Added Home as a third action in the Back/Forward panel.
- Added glass-style download toast notifications for Downloading, Downloaded, and failed states.
- Reworked the Downloads page into persistent native DownloadManager-backed cards with file-type labels, file sizes/progress, and Open actions.
- Added Clear All, which removes the selected DownloadManager records/files.
- Kept DownloadManager as the durable source of download records and files rather than duplicating metadata in localStorage.
- Excluded Valley's own homepage from browsing history.
- Synced native history mutations back to homepage history widgets.
- Added heading typography rules for history and downloads views.

Build and device-test before distribution. No APK is included.
