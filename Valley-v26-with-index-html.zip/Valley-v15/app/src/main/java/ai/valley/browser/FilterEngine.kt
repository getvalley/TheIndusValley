package ai.valley.browser

import java.io.BufferedReader
import java.util.regex.Pattern

/**
 * A compact engine for uBlock Origin / Adblock Plus style filter lists.
 *
 * Network filters: ||host^, |anchors, *, ^, @@ exceptions, and the options
 * third-party, script/image/stylesheet/xhr/subdocument/media/font/ping/websocket/object/other,
 * domain=, denyallow=, important, generichide.
 * Cosmetic filters: ##selector, domain##selector, #@# exceptions (plain CSS selectors only).
 *
 * Not supported (rules using them are skipped, never half-applied): regex filters, removeparam,
 * csp, redirect-rule, scriptlets (##+js), procedural cosmetics (:has-text, :xpath, ...), $popup,
 * $document, $replace, $header.
 *
 * An engine is immutable once built, so shouldBlock() is safe to call from WebView's
 * background request threads.
 */
class FilterEngine private constructor(
    private val block: RuleIndex,
    private val allow: RuleIndex,
    private val generic: List<String>,
    private val genericNot: Map<String, List<String>>,
    private val specific: Map<String, List<String>>,
    private val cosmeticExceptions: Map<String, Set<String>>,
    private val genericHideSites: Set<String>,
    val networkRuleCount: Int,
    val cosmeticRuleCount: Int
) {
    // ------------------------------------------------------------------ public API

    /** True when the request should be answered with nothing. Never call this for the main frame. */
    fun shouldBlock(url: String, host: String, pageHost: String?, headers: Map<String, String>?): Boolean {
        val scheme = url.substringBefore(':', "").lowercase()
        if (scheme != "http" && scheme != "https" && scheme != "ws" && scheme != "wss") return false
        val lower = url.substringBefore('#').lowercase()
        val h = host.lowercase().trimEnd('.')
        val hs = lower.indexOf(h, lower.indexOf("://") + 3)
        if (hs < 0) return false
        val ctx = Ctx(
            type = guessType(lower, scheme, headers),
            thirdParty = pageHost != null && site(pageHost) != site(h),
            pageHost = pageHost,
            host = h
        )
        val hit = block.find(lower, h, hs + h.length, ctx) ?: return false
        if (hit.important) return true
        return allow.find(lower, h, hs + h.length, ctx) == null
    }

    /** CSS that hides ad slots for this page, or null when there is nothing to hide. */
    fun cosmeticCss(pageHost: String): String? {
        val host = pageHost.lowercase().trimEnd('.')
        synchronized(cssCache) { if (cssCache.containsKey(host)) return cssCache[host] }
        val excluded = HashSet<String>()
        val sels = ArrayList<String>()
        var h = host
        while (true) {
            cosmeticExceptions[h]?.let { excluded.addAll(it) }
            specific[h]?.let { sels.addAll(it) }
            val dot = h.indexOf('.')
            if (dot < 0) break
            h = h.substring(dot + 1)
        }
        if (!isGenericHideSite(host)) {
            var added = 0
            for (s in generic) {
                if (added >= MAX_GENERIC) break
                if (s in excluded) continue
                val not = genericNot[s]
                if (not != null && not.any { host == it || host.endsWith(".$it") }) continue
                sels.add(s); added++
            }
        }
        val kept = sels.filter { it !in excluded }.distinct()
        val css = if (kept.isEmpty()) null else {
            val sb = StringBuilder()
            var i = 0
            while (i < kept.size) {
                val end = minOf(i + CHUNK, kept.size)
                sb.append(kept.subList(i, end).joinToString(","))
                sb.append("{display:none!important}\n")
                i = end
            }
            sb.toString()
        }
        synchronized(cssCache) { cssCache[host] = css }
        return css
    }

    private fun isGenericHideSite(host: String): Boolean {
        var h = host
        while (true) {
            if (h in genericHideSites) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
        }
    }

    private val cssCache = object : LinkedHashMap<String, String?>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String?>?) = size > 24
    }

    // ------------------------------------------------------------------ request context

    private class Ctx(val type: Int, val thirdParty: Boolean, val pageHost: String?, val host: String)

    private fun guessType(url: String, scheme: String, headers: Map<String, String>?): Int {
        if (scheme == "ws" || scheme == "wss") return T_WS
        val path = url.substringBefore('?').substringAfterLast('/')
        val ext = if (path.contains('.')) path.substringAfterLast('.') else ""
        when (ext) {
            "js", "mjs" -> return T_SCRIPT
            "css" -> return T_STYLE
            "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "avif", "bmp" -> return T_IMAGE
            "woff", "woff2", "ttf", "otf", "eot" -> return T_FONT
            "mp4", "webm", "mp3", "m4a", "ogg", "m3u8", "mpd", "ts", "wav" -> return T_MEDIA
            "swf" -> return T_OBJECT
            "html", "htm" -> return T_SUBDOC
        }
        val accept = headers?.entries?.firstOrNull { it.key.equals("accept", true) }?.value?.lowercase() ?: ""
        val xrw = headers?.keys?.any { it.equals("x-requested-with", true) } == true
        return when {
            accept.contains("text/css") -> T_STYLE
            accept.startsWith("image/") || accept.contains("image/avif") || accept.contains("image/webp") -> T_IMAGE
            accept.contains("text/html") -> T_SUBDOC
            xrw || accept.contains("application/json") -> T_XHR
            else -> T_OTHER
        }
    }

    // ------------------------------------------------------------------ rules

    private class Rule(
        val pattern: String,
        val hostAnchor: Boolean,
        val startAnchor: Boolean,
        val endAnchor: Boolean,
        val hostKey: String?,
        val types: Int,
        val party: Int,            // 0 any, 1 third-party only, 2 first-party only
        val important: Boolean,
        val domains: Array<String>?,
        val notDomains: Array<String>?,
        val denyAllow: Array<String>?
    ) {
        @Volatile private var re: Pattern? = null
        private val trivial: Boolean =
            hostKey != null && (pattern.length == hostKey.length || pattern.substring(hostKey.length) == "^")

        private fun regex(): Pattern {
            re?.let { return it }
            val body = if (hostKey != null) pattern.substring(hostKey.length) else pattern
            val built = Pattern.compile(
                (if (hostAnchor && hostKey == null) HOST_PREFIX else "") + toRegex(body) + (if (endAnchor) "\$" else "")
            )
            re = built
            return built
        }

        fun test(url: String, hostEnd: Int, ctx: Ctx): Boolean {
            if ((types and ctx.type) == 0) return false
            if (party == 1 && !ctx.thirdParty) return false
            if (party == 2 && ctx.thirdParty) return false
            if (domains != null || notDomains != null) {
                val ph = ctx.pageHost
                if (notDomains != null && ph != null && notDomains.any { ph == it || ph.endsWith(".$it") }) return false
                if (domains != null && (ph == null || domains.none { ph == it || ph.endsWith(".$it") })) return false
            }
            if (denyAllow != null && denyAllow.any { ctx.host == it || ctx.host.endsWith(".$it") }) return false
            if (trivial) return !endAnchor || pattern.length == hostKey!!.length && url.length == hostEnd
            return try {
                val m = regex().matcher(url)
                when {
                    hostKey != null -> { m.region(hostEnd, url.length); m.lookingAt() }
                    hostAnchor || startAnchor -> m.lookingAt()
                    else -> m.find()
                }
            } catch (_: Throwable) { false }
        }
    }

    private class RuleIndex {
        val byHost = HashMap<String, ArrayList<Rule>>()
        val byToken = HashMap<String, ArrayList<Rule>>()
        val other = ArrayList<Rule>()

        fun add(r: Rule, token: String?) {
            when {
                r.hostKey != null -> byHost.getOrPut(r.hostKey) { ArrayList(1) }.add(r)
                token != null -> byToken.getOrPut(token) { ArrayList(1) }.add(r)
                else -> other.add(r)
            }
        }

        fun find(url: String, host: String, hostEnd: Int, ctx: Ctx): Rule? {
            var h = host
            while (true) {
                byHost[h]?.let { list -> for (r in list) if (r.test(url, hostEnd, ctx)) return r }
                val dot = h.indexOf('.')
                if (dot < 0) break
                h = h.substring(dot + 1)
            }
            var i = 0
            val n = url.length
            while (i < n) {
                if (isAlnum(url[i])) {
                    var j = i + 1
                    while (j < n && isAlnum(url[j])) j++
                    if (j - i >= 3) {
                        byToken[url.substring(i, j)]?.let { list -> for (r in list) if (r.test(url, hostEnd, ctx)) return r }
                    }
                    i = j
                } else i++
            }
            for (r in other) if (r.test(url, hostEnd, ctx)) return r
            return null
        }
    }

    // ------------------------------------------------------------------ builder / parser

    class Builder {
        private val block = RuleIndex()
        private val allow = RuleIndex()
        private val generic = LinkedHashSet<String>()
        private val genericNot = HashMap<String, ArrayList<String>>()
        private val specific = HashMap<String, ArrayList<String>>()
        private val cosmeticExc = HashMap<String, HashSet<String>>()
        private val genericHide = HashSet<String>()
        private var nNet = 0
        private var nCos = 0

        fun addReader(r: BufferedReader) {
            while (true) {
                val line = r.readLine() ?: break
                addLine(line)
            }
        }

        fun addText(text: String) {
            for (line in text.lineSequence()) addLine(line)
        }

        fun addLine(raw: String) {
            val line = raw.trim()
            if (line.isEmpty() || line[0] == '!' || line[0] == '[' || line[0] == '#' && !line.contains("##") && !line.contains("#@#")) return
            try {
                // hosts-file format (Peter Lowe's list etc.)
                if (line[0].isDigit()) {
                    val parts = line.split(Regex("\\s+"))
                    if (parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1")) {
                        val d = parts[1].lowercase()
                        if (d.contains('.') && d != "localhost") { addNetwork("||$d^"); }
                        return
                    }
                }
                val cos = indexOfCosmetic(line)
                if (cos >= 0) addCosmetic(line, cos) else addNetwork(line)
            } catch (_: Throwable) { /* a bad rule never breaks the list */ }
        }

        private fun indexOfCosmetic(line: String): Int {
            val a = line.indexOf("##")
            val b = line.indexOf("#@#")
            val c = line.indexOf("#?#")
            val d = line.indexOf("#\$#")
            val e = line.indexOf("#@\$#")
            val f = line.indexOf("#%#")
            val all = listOf(a, b, c, d, e, f).filter { it >= 0 }
            return all.minOrNull() ?: -1
        }

        private fun addCosmetic(line: String, at: Int) {
            val isException = line.startsWith("#@#", at)
            if (!line.startsWith("##", at) && !isException) return   // #?#, #$#, #%# are procedural / style injection
            val domainPart = line.substring(0, at)
            val sel = line.substring(at + (if (isException) 3 else 2)).trim()
            if (sel.isEmpty() || sel.startsWith("+js(") || !isPlainSelector(sel)) return
            val pos = ArrayList<String>()
            val neg = ArrayList<String>()
            if (domainPart.isNotEmpty()) {
                for (d0 in domainPart.split(',')) {
                    val d = d0.trim().lowercase()
                    if (d.isEmpty() || d.contains('*') || d.startsWith("/")) return
                    if (d.startsWith("~")) neg.add(d.substring(1)) else pos.add(d)
                }
            }
            nCos++
            if (isException) {
                if (pos.isEmpty()) return
                for (d in pos) cosmeticExc.getOrPut(d) { HashSet() }.add(sel)
                return
            }
            if (pos.isEmpty()) {
                generic.add(sel)
                if (neg.isNotEmpty()) genericNot.getOrPut(sel) { ArrayList() }.addAll(neg)
            } else {
                for (d in pos) specific.getOrPut(d) { ArrayList() }.add(sel)
            }
        }

        private val procedural = listOf(
            ":has-text(", ":xpath(", ":matches-css", ":matches-media(", ":matches-path(", ":upward(", ":remove(",
            ":style(", ":-abp-", ":contains(", ":nth-ancestor(", ":min-text-length(", ":watch-attr(", ":others(",
            ":matches-attr(", ":matches-prop(", ":not(:has-text", "{", "}", "<", ">>>", "\\\\"
        )

        private fun isPlainSelector(sel: String): Boolean {
            if (sel.length > 300) return false
            for (p in procedural) if (sel.contains(p)) return false
            var paren = 0; var brack = 0
            for (ch in sel) {
                when (ch) { '(' -> paren++; ')' -> paren--; '[' -> brack++; ']' -> brack-- }
                if (paren < 0 || brack < 0) return false
            }
            return paren == 0 && brack == 0
        }

        private fun addNetwork(raw: String) {
            var line = raw
            var exception = false
            if (line.startsWith("@@")) { exception = true; line = line.substring(2) }
            var opts = ""
            val d = line.lastIndexOf('$')
            if (d >= 0) {
                val tail = line.substring(d + 1)
                if (tail.isNotEmpty() && tail.all { it.isLetterOrDigit() || it in "-_=,~|.*:/" }) {
                    opts = tail; line = line.substring(0, d)
                }
            }
            if (line.length >= 2 && line.startsWith("/") && line.endsWith("/")) return  // regex filter
            if (line.any { it.code > 126 || it == ' ' }) return

            var inc = 0; var excl = 0; var party = 0
            var important = false; var generichide = false
            var domains: Array<String>? = null; var notDomains: Array<String>? = null; var denyAllow: Array<String>? = null
            if (opts.isNotEmpty()) {
                for (o0 in opts.split(',')) {
                    val o = o0.trim().lowercase()
                    if (o.isEmpty()) continue
                    val neg = o.startsWith("~")
                    val name = if (neg) o.substring(1) else o
                    when {
                        name == "third-party" || name == "3p" || name == "strict3p" -> party = if (neg) 2 else 1
                        name == "first-party" || name == "1p" || name == "strict1p" -> party = if (neg) 1 else 2
                        name == "important" -> important = true
                        name == "match-case" || name == "all" -> {}
                        name == "generichide" || name == "ghide" -> generichide = true
                        name.startsWith("domain=") -> {
                            val p = ArrayList<String>(); val n = ArrayList<String>()
                            for (x in name.substring(7).split('|')) {
                                if (x.isEmpty() || x.contains('*') || x.startsWith("/")) continue
                                if (x.startsWith("~")) n.add(x.substring(1)) else p.add(x)
                            }
                            if (p.isNotEmpty()) domains = p.toTypedArray()
                            if (n.isNotEmpty()) notDomains = n.toTypedArray()
                        }
                        name.startsWith("denyallow=") ->
                            denyAllow = name.substring(10).split('|').filter { it.isNotEmpty() }.toTypedArray()
                        name.startsWith("redirect=") -> {}       // treated as a plain block
                        else -> {
                            val bit = typeBit(name) ?: return    // unsupported option: skip the whole rule
                            if (neg) excl = excl or bit else inc = inc or bit
                        }
                    }
                }
            }
            var types = if (inc != 0) inc else ALL
            types = types and excl.inv()

            if (generichide) {
                if (exception && line.startsWith("||")) {
                    val host = line.substring(2).trimEnd('^', '/').lowercase()
                    if (host.contains('.')) genericHide.add(host)
                }
                return
            }

            var hostAnchor = false; var startAnchor = false; var endAnchor = false
            var p = line.lowercase()
            if (p.startsWith("||")) { hostAnchor = true; p = p.substring(2) }
            else if (p.startsWith("|")) { startAnchor = true; p = p.substring(1) }
            if (p.endsWith("|")) { endAnchor = true; p = p.dropLast(1) }
            if (!hostAnchor && !startAnchor) p = p.trimStart('*')
            if (!endAnchor) p = p.trimEnd('*')
            if (p.isEmpty() && domains == null) return
            if (p.isEmpty()) return

            var hostKey: String? = null
            if (hostAnchor) {
                var i = 0
                while (i < p.length && p[i] !in "^/*?:|") i++
                val term = if (i < p.length) p[i] else '\u0000'
                val hp = p.substring(0, i)
                if (hp.contains('.') && term != '*' && hp.all { it.isLetterOrDigit() || it == '.' || it == '-' || it == '_' }) hostKey = hp
            }
            val token = if (hostKey == null) pickToken(p, hostAnchor || startAnchor, endAnchor) else null
            val rule = Rule(p, hostAnchor, startAnchor, endAnchor, hostKey, types, party, important, domains, notDomains, denyAllow)
            if (exception) allow.add(rule, token) else block.add(rule, token)
            nNet++
        }

        private fun typeBit(name: String): Int? = when (name) {
            "script" -> T_SCRIPT
            "image" -> T_IMAGE
            "stylesheet", "css" -> T_STYLE
            "xmlhttprequest", "xhr" -> T_XHR
            "subdocument", "frame" -> T_SUBDOC
            "media" -> T_MEDIA
            "font" -> T_FONT
            "ping", "beacon" -> T_PING
            "websocket" -> T_WS
            "object", "object-subrequest" -> T_OBJECT
            "other" -> T_OTHER
            else -> null
        }

        /** longest alphanumeric run that is fully delimited inside the pattern, so it appears as a whole run in any matching URL */
        private fun pickToken(p: String, anchoredStart: Boolean, anchoredEnd: Boolean): String? {
            var best: String? = null
            var i = 0
            while (i < p.length) {
                if (isAlnum(p[i])) {
                    var j = i + 1
                    while (j < p.length && isAlnum(p[j])) j++
                    val leftOk = if (i == 0) anchoredStart else p[i - 1] != '*'
                    val rightOk = if (j == p.length) anchoredEnd else p[j] != '*'
                    if (leftOk && rightOk && j - i >= 3 && (best == null || j - i > best.length)) best = p.substring(i, j)
                    i = j
                } else i++
            }
            return best
        }

        fun build(): FilterEngine = FilterEngine(
            block, allow, generic.toList(), genericNot, specific, cosmeticExc, genericHide, nNet, nCos
        )
    }

    companion object {
        const val T_SCRIPT = 1
        const val T_IMAGE = 2
        const val T_STYLE = 4
        const val T_XHR = 8
        const val T_SUBDOC = 16
        const val T_MEDIA = 32
        const val T_FONT = 64
        const val T_PING = 128
        const val T_WS = 256
        const val T_OBJECT = 512
        const val T_OTHER = 1024
        const val ALL = 2047

        private const val MAX_GENERIC = 6000
        private const val CHUNK = 25
        private const val HOST_PREFIX = "^[a-z][a-z0-9+.-]*://(?:[^/?#]*\\.)?"

        private val multiPartTlds = setOf(
            "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au", "co.in", "net.in", "org.in",
            "co.jp", "ne.jp", "or.jp", "com.br", "com.cn", "com.mx", "com.tr", "co.nz", "co.za", "com.sg",
            "com.hk", "com.tw", "co.kr", "com.ar", "com.pk", "com.ng"
        )

        internal fun site(host: String): String {
            val h = host.lowercase().trimEnd('.')
            val parts = h.split('.')
            if (parts.size <= 2) return h
            val last2 = parts.takeLast(2).joinToString(".")
            return if (last2 in multiPartTlds) parts.takeLast(3).joinToString(".") else last2
        }

        private fun isAlnum(c: Char) = c in 'a'..'z' || c in '0'..'9'

        /** ABP pattern body -> regex source ('^' is the separator class, '*' is any run) */
        private fun toRegex(p: String): String {
            val sb = StringBuilder()
            for (c in p) {
                when (c) {
                    '*' -> sb.append(".*")
                    '^' -> sb.append("(?:[^a-z0-9_.%-]|\$)")
                    else -> {
                        if (c in "\\.+?()[]{}|\$") sb.append('\\')
                        sb.append(c)
                    }
                }
            }
            return sb.toString()
        }
    }
}
