package ai.valley.browser

import android.content.Context
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.webkit.WebView

/**
 * The toolbar WebView is a transparent overlay that sits on top of the page WebView.
 * A WebView swallows every touch inside its bounds, even over transparent pixels, so
 * anything on the page near the toolbar was dead. This view only claims a touch when it
 * lands on something visible in the toolbar; otherwise it declines the DOWN event and
 * Android hands the whole gesture to the page underneath.
 */
class PassThroughWebView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : WebView(context, attrs) {

    /** false while a panel/menu is open: the toolbar must see every tap so it can dismiss itself */
    @Volatile var passThrough = true

    /** touchable regions in view pixels, reported by toolbar.html; empty = not reported yet, claim everything */
    @Volatile private var hitRects: List<RectF> = emptyList()

    private var claiming = true

    fun setHitRects(rects: List<RectF>) { hitRects = rects }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            val rects = hitRects
            claiming = !passThrough || rects.isEmpty() || rects.any { it.contains(e.x, e.y) }
        }
        if (!claiming) return false
        return super.dispatchTouchEvent(e)
    }
}
