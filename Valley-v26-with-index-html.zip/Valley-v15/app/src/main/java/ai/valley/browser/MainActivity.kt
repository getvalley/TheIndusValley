package ai.valley.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.SharedPreferences
import android.content.Intent
import android.speech.RecognizerIntent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.Bitmap
import android.graphics.Outline
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import java.io.ByteArrayInputStream
import java.net.URLEncoder

class MainActivity : Activity() {

    private inner class Tab(val web: WebView) {
        var title: String = "New Tab"
        var isPrivate: Boolean = false
        var isPinned: Boolean = false
    }

    private lateinit var container: FrameLayout
    private lateinit var urlView: TextView
    private lateinit var glow: PillGlowView
    private lateinit var assetLoader: WebViewAssetLoader
    private var sparkJs: String? = null
    private var readerJs: String? = null

    private val tabs = ArrayList<Tab>()
    private val selectedTabs = linkedSetOf<Tab>()
    private var selectingTabs = false
    private var editingTabGroups = false
    private var current = 0
    private var privateCount = 0

    // protection is always on - there is nothing to switch off

    /** hosts that serve ads and trackers; a request to one of these is answered with nothing */
    private val blocked: HashSet<String> by lazy {
        RAW_BLOCKLIST.trim().lines().map { it.trim() }.filter { it.isNotEmpty() }.toHashSet()
    }
    private val active: Tab get() = tabs[current]
    private val web: WebView get() = active.web

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$HOST/assets/index.html"

        private val RAW_BLOCKLIST = """
            doubleclick.net
            googlesyndication.com
            googleadservices.com
            google-analytics.com
            googletagmanager.com
            googletagservices.com
            adservice.google.com
            pagead2.googlesyndication.com
            facebook.net
            connect.facebook.net
            scorecardresearch.com
            quantserve.com
            quantcount.com
            moatads.com
            adsafeprotected.com
            adnxs.com
            adsrvr.org
            rubiconproject.com
            pubmatic.com
            casalemedia.com
            openx.net
            appnexus.com
            criteo.com
            criteo.net
            taboola.com
            outbrain.com
            revcontent.com
            mgid.com
            zergnet.com
            popads.net
            propellerads.com
            adcash.com
            exoclick.com
            juicyads.com
            trafficjunky.net
            media.net
            smartadserver.com
            teads.tv
            spotxchange.com
            tremorhub.com
            amazon-adsystem.com
            ads.yahoo.com
            adtech.de
            adform.net
            serving-sys.com
            flashtalking.com
            mathtag.com
            turn.com
            tapad.com
            bidswitch.net
            sharethrough.com
            triplelift.com
            indexexchange.com
            sovrn.com
            gumgum.com
            districtm.io
            yieldmo.com
            sonobi.com
            lijit.com
            krxd.net
            bluekai.com
            demdex.net
            omtrdc.net
            2o7.net
            everesttech.net
            adsymptotic.com
            agkn.com
            rlcdn.com
            tapfiliate.com
            branch.io
            appsflyer.com
            adjust.com
            kochava.com
            amplitude.com
            mixpanel.com
            segment.com
            segment.io
            heap.io
            hotjar.com
            hotjar.io
            fullstory.com
            clarity.ms
            inspectlet.com
            mouseflow.com
            smartlook.com
            luckyorange.com
            crazyegg.com
            optimizely.com
            vwo.com
            newrelic.com
            nr-data.net
            bugsnag.com
            rollbar.com
            sentry.io
            loggly.com
            chartbeat.com
            chartbeat.net
            parsely.com
            nr-data.net
            clicktale.net
            userreport.com
            mc.yandex.ru
            top-fwz1.mail.ru
            hb.wrating.com
            ctnsnet.com
            creativecdn.com
            adroll.com
            perfectaudience.com
            rebound.net
            retargeter.com
            steelhousemedia.com
            simpli.fi
            audienceproject.com
            narrative.io
            permutive.com
            id5-sync.com
            liadm.com
            pippio.com
            ads.linkedin.com
            analytics.tiktok.com
            business-api.tiktok.com
            ads.tiktok.com
            analytics.twitter.com
            static.ads-twitter.com
            ads.pinterest.com
            ads.reddit.com
            ads.snapchat.com
            sc-static.net
            tr.snapchat.com
        """
    }

    private fun isBlocked(host: String?): Boolean {
        if (host == null) return false
        val h = host.lowercase()
        if (blocked.contains(h)) return true
        // walk the parent domains instead of scanning the whole list per request
        var i = h.indexOf('.')
        while (i != -1) {
            if (blocked.contains(h.substring(i + 1))) return true
            i = h.indexOf('.', i + 1)
        }
        return false
    }

    private fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        loadTabGroups()

        container = findViewById(R.id.web_container)
        urlView = findViewById(R.id.url)
        glow = findViewById(R.id.glow)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        sparkJs = readAsset("spark.js")
        readerJs = readAsset("reader.js")


        val navBtn = findViewById<ImageButton>(R.id.back)
        navBtn.setOnClickListener {
            if (mode != Mode.BROWSING) {
                exitOverview()
                newTab(START_URL)
                return@setOnClickListener
            }
            if (navForward) {
                if (web.canGoForward()) web.goForward() else toast("No page to go forward to")
            } else {
                if (web.canGoBack()) web.goBack() else toast("No page to go back to")
            }
        }
        navBtn.setOnLongClickListener { showBackForward(); true }

        findViewById<ImageButton>(R.id.reload).setOnClickListener { web.reload() }
        urlView.setOnClickListener { editUrl() }
        findViewById<View>(R.id.urlScroll).setOnClickListener { editUrl() }
        try {
            (findViewById<View>(R.id.urlScroll) as android.widget.HorizontalScrollView)
                .isHorizontalFadingEdgeEnabled = true
        } catch (e: Exception) {}
        findViewById<ImageButton>(R.id.reader).setOnClickListener { toggleReader() }

        val settingsBtn = findViewById<ImageButton>(R.id.settings)
        settingsBtn.setOnClickListener {
            if (mode != Mode.BROWSING) showTabActions() else showPageMenu()
        }
        settingsBtn.setOnLongClickListener {
            if (mode != Mode.BROWSING) showTabActions() else showPageTools()
            true
        }
        // the html pill owns the long-press now: it folds into the orb

        listOf(R.id.back, R.id.reader, R.id.reload, R.id.settings).forEach { id ->
            pressable(findViewById(id))
        }
        pressable(findViewById(R.id.pill))

        // clip the frost layer to the pill's rounded shape
        val pillView = findViewById<View>(R.id.pill)
        pillView.clipToOutline = true
        pillView.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.height / 2f)
            }
        }
        setUpToolbarWeb()
        findViewById<View>(R.id.toolbar).visibility = View.GONE

        newTab(START_URL)
    }

    // ---------------------------------------------------------------- tabs

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWeb(private: Boolean = false): WebView {
        val w = WebView(this)
        w.settings.apply {
            javaScriptEnabled = true
            // a private tab writes no site storage at all
            domStorageEnabled = !private
            databaseEnabled = !private
            // hardening: no local file access, no popups, no saved form data
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            saveFormData = false
            if (android.os.Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            // nothing is read from or written to the disk cache
            cacheMode = if (private) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            userAgentString = userAgentString.replace("; wv", "")
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            // third-party cookies are blocked per-WebView, so this really is per-tab
            // third-party cookies are blocked everywhere except where a site needs them
            setAcceptThirdPartyCookies(w, false)
        }

        w.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                assetLoader.shouldInterceptRequest(request.url)?.let { return it }
                // never block the page itself, only what it pulls in
                if (!request.isForMainFrame && isBlocked(request.url.host)) return emptyResponse()
                return null
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val u = request.url
                // HTTPS only: upgrade plain http, refuse it if the host has no https
                if (u.scheme == "http") {
                    val secure = u.toString().replaceFirst("http://", "https://")
                    view.loadUrl(secure)
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                // Expose the history bridge only while the trusted Valley homepage is loaded.
                view.removeJavascriptInterface("ValleyHistory")
                if (view == web) setLoading(true)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                val tab = tabs.firstOrNull { it.web === view }
                if (url != null && tab != null && (tab.title == "New Tab" || tab.title.isBlank())) {
                    tab.title = prettyUrl(url)
                }
                if (url != null && tab != null && !tab.isPrivate) {
                    recordOpenedPage(url, view.title?.takeIf { it.isNotBlank() } ?: tab.title)
                }
                if (view == web) {
                    setLoading(false)
                    if (url != null) {
                        showAddress(url)
                        val isHome = url == START_URL || url.startsWith(START_URL + "?")
                        toolbarJs("window.ulaaHomeMode && window.ulaaHomeMode(" + isHome + ")")
                        urlView.alpha = 0.35f
                        urlView.animate().alpha(1f).setDuration(260).start()
                        pulsePill()
                        scheduleFrost()
                    }
                    refreshBack()
                }
                injectSpark(view, url)
                if (url != null && url.contains(HOST) && url.contains("index.html") && tab?.isPrivate != true) {
                    view.addJavascriptInterface(HistoryBridge(), "ValleyHistory")
                    view.postDelayed({ if (view == web) { syncWithHomepage(); syncHistoryWithHomepage() } }, 220)
                }
            }
        }

        watchScroll(w)

        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (view == web) setLoading(newProgress in 1..99)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                val tab = tabs.firstOrNull { it.web === view }
                if (tab != null && !title.isNullOrBlank()) tab.title = title
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                callback?.invoke(origin, origin != null && origin.contains(HOST), false)
            }
        }
        return w
    }

    /** a new tab gets its own WebView, so scroll position and form state survive switching */
    private fun newTab(url: String, private: Boolean = false) {
        val w = buildWeb(private)
        val tab = Tab(w)
        tab.isPrivate = private
        if (private) tab.title = "Private"
        privateCount += if (private) 1 else 0
        tabs.add(tab)
        current = tabs.size - 1
        val wasOverview = mode != Mode.BROWSING
        if (wasOverview) {
            mode = Mode.BROWSING
            filterGroup = null
            val overviewView = overview()
            overviewView.animate().cancel()
            overviewView.alpha = 1f
            overviewView.translationY = 0f
            overviewView.visibility = View.GONE
            overviewView.removeAllViews()
        }
        attach()
        w.loadUrl(url)
        showAddress(url)
        refreshBack()
        if (wasOverview) applyModeChrome()
    }

    private fun attach() {
        setReaderButtonActive(false)
        showBar()
        container.removeAllViews()
        val w = active.web
        container.addView(w, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        showAddress(w.url ?: START_URL)
        refreshBack()
    }

    private var readerIsActive = false

    private fun setReaderButtonActive(active: Boolean) {
        readerIsActive = active
        val button = findViewById<ImageButton>(R.id.reader) ?: return
        button.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (active) 0xFF19B9F4.toInt() else Color.TRANSPARENT)
        }
        button.imageTintList = android.content.res.ColorStateList.valueOf(
            if (active) 0xFF071A2A.toInt() else 0xFFF6F0E8.toInt()
        )
        button.invalidate()
    }

    private fun toggleReaderForActiveTab() {
        toggleReaderOn(active.web)
    }

    private fun toggleReader() {
        toggleReaderOn(web)
    }

    private fun toggleReaderOn(target: WebView) {
        val source = readerJs
        if (source.isNullOrBlank()) {
            toast("Reader mode could not be loaded")
            return
        }
        target.post {
            try {
                target.evaluateJavascript(source) {
                    target.evaluateJavascript(
                        "(function(){try{return window.ulaaReaderToggle ? window.ulaaReaderToggle() : false;}catch(e){return false;}})()"
                    ) { result ->
                        if (result != "true") {
                            runOnUiThread { toast("Couldn't find enough article text on this page") }
                        } else {
                            target.evaluateJavascript(
                                "(function(){return !!document.getElementById('valley-reader-overlay');})()"
                            ) { state ->
                                runOnUiThread {
                                    if (target === web) setReaderButtonActive(state == "true")
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Reader mode failed to run") }
            }
        }
    }

    private fun readerUnavailable() {
        val card = menuCard()
        val msg = TextView(this).apply {
            text = "Reader mode is not available for this page."
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 14f
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        card.addView(msg)
        showCard(card, Align.LEFT)
    }

    private fun setLoading(loading: Boolean) {
        try { if (loading) glow.start() else glow.stop() } catch (e: Exception) {}
    }

    private var frostBusy = false
    private var frostRunnable: Runnable? = null

    /**
     * Render the active page into a bitmap, crop the pixels beneath the floating toolbar,
     * blur them, then feed those pixels to the transparent toolbar WebView. CSS backdrop-filter
     * cannot sample a separate Android WebView, so this is the real page-backed frost layer.
     */
    private fun refreshFrost() {
        if (frostBusy || tabs.isEmpty()) return
        val source = active.web
        if (source.width <= 0 || source.height <= 0 || source.isShown.not()) return
        frostBusy = true
        try {
            val page = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
            source.draw(android.graphics.Canvas(page))

            val pillWidth = (source.width * 0.64f).toInt().coerceAtLeast(dp(120)).coerceAtMost(source.width)
            val pillHeight = dp(48).coerceAtMost(source.height)
            val pillLeft = ((source.width - pillWidth) / 2).coerceAtLeast(0)
            val pillTop = (source.height - dp(53)).coerceIn(0, (source.height - pillHeight).coerceAtLeast(0))
            val pillCrop = Bitmap.createBitmap(page, pillLeft, pillTop, pillWidth, pillHeight)
            val pillBlur = Frost.blur(pillCrop, 3, 5)

            val panelWidth = (source.width - dp(32)).coerceAtLeast(1)
            val panelHeight = dp(380).coerceAtMost(source.height)
            val panelLeft = ((source.width - panelWidth) / 2).coerceAtLeast(0)
            val panelTop = (source.height - panelHeight).coerceAtLeast(0)
            val panelCrop = Bitmap.createBitmap(page, panelLeft, panelTop, panelWidth, panelHeight)
            val panelBlur = Frost.blur(panelCrop, 4, 8)

            fun data(bitmap: Bitmap): String {
                val out = java.io.ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 58, out)
                return "data:image/jpeg;base64," + android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
            }
            val pillData = org.json.JSONObject.quote(data(pillBlur))
            val panelData = org.json.JSONObject.quote(data(panelBlur))
            toolbarJs("window.ulaaSetFrost && window.ulaaSetFrost($pillData,$panelData)")
            page.recycle(); pillCrop.recycle(); panelCrop.recycle()
            pillBlur.recycle(); panelBlur.recycle()
        } catch (e: Exception) {
            // Keep the translucent material fallback if WebView drawing is unavailable.
        } finally {
            frostBusy = false
        }
    }

    /** debounce: blur once the page stops moving */
    private fun scheduleFrost() {
        frostRunnable?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
        val r = Runnable { refreshFrost() }
        frostRunnable = r
        Handler(Looper.getMainLooper()).postDelayed(r, 240)
    }

    private fun pulsePill() {
        val pill = findViewById<View>(R.id.pill)
        pill.animate().scaleX(1.035f).scaleY(1.035f).setDuration(130)
            .withEndAction {
                pill.animate().scaleX(1f).scaleY(1f).setDuration(340)
                    .setInterpolator(Motion.spring).start()
            }.start()
    }

    private fun showAddress(url: String) {
        val label = addressLabel(url)
        if (active.isPrivate) {
            urlView.text = "\u25D0  " + label
            urlView.setTextColor(0xFFCBA8FF.toInt())
        } else {
            urlView.text = label
            urlView.setTextColor(0xFFF6F0E8.toInt())
        }
        toolbarJs("window.ulaaSetAddr && window.ulaaSetAddr(" + org.json.JSONObject.quote(label) + ")")
        try { findViewById<android.widget.HorizontalScrollView>(R.id.urlScroll).scrollTo(0, 0) } catch (e: Exception) {}
    }

    private fun switchTo(index: Int) {
        if (index !in tabs.indices) return
        current = index
        attach()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val gone = tabs.removeAt(index)
        selectedTabs.remove(gone)
        if (gone.isPrivate) privateCount = (privateCount - 1).coerceAtLeast(0)
        val needWipe = gone.isPrivate && privateCount == 0
        try { gone.web.destroy() } catch (e: Exception) {}
        if (tabs.isEmpty()) {
            newTab(START_URL)
        } else {
            current = index.coerceAtMost(tabs.size - 1)
            attach()
        }
        if (needWipe) wipePrivateSession()
        if (mode != Mode.BROWSING) applyModeChrome()
    }

    /**
     * Android gives the whole app one cookie jar, so a private tab cannot have a separate one.
     * What we can do: while private tabs are open nothing is written to site storage or the
     * disk cache, and when the last one closes the cookies and cache are destroyed.
     */
    private fun wipePrivateSession() {
        try {
            val cm = CookieManager.getInstance()
            cm.removeAllCookies(null)
            cm.flush()
        } catch (e: Exception) {}
        try { web.clearCache(true) } catch (e: Exception) {}
        try { web.clearFormData() } catch (e: Exception) {}
        try { web.clearHistory() } catch (e: Exception) {}
    }

    private fun refreshBack() {
        if (mode != Mode.BROWSING) { findViewById<ImageButton>(R.id.back).alpha = 1f; toolbarJs("window.ulaaDim && window.ulaaDim(false)"); return }
        val can = if (navForward) web.canGoForward() else web.canGoBack()
        findViewById<ImageButton>(R.id.back).alpha = if (can) 1f else 0.35f
        toolbarJs("window.ulaaDim && window.ulaaDim(" + (!can) + ")")
    }

    private fun addressLabel(url: String): String =
        if (url.contains(HOST) && url.contains("index.html")) "Search or enter website"
        else prettyUrl(url)

    private fun prettyUrl(url: String): String = try {
        if (url.contains(HOST)) "Valley" else java.net.URL(url).host.replace("^www\\.".toRegex(), "")
    } catch (e: Exception) {
        url
    }

    // ---------------------------------------------------------------- html toolbar

    inner class HistoryBridge {
        @android.webkit.JavascriptInterface
        fun recordSearch(query: String?) = runOnUiThread { if (!active.isPrivate) recordSearchQuery(query.orEmpty()) }

        @android.webkit.JavascriptInterface
        fun removeSearch(query: String?) = runOnUiThread { removeSearchQuery(query.orEmpty()) }

        @android.webkit.JavascriptInterface
        fun clearSearches() = runOnUiThread { prefs().edit().putString("history_searches", "[]").apply() }

        @android.webkit.JavascriptInterface
        fun recordOpened(url: String?, title: String?) = runOnUiThread { if (!active.isPrivate) recordOpenedPage(url.orEmpty(), title) }

        @android.webkit.JavascriptInterface
        fun removeOpened(url: String?) = runOnUiThread { removeOpenedPage(url.orEmpty()) }

        @android.webkit.JavascriptInterface
        fun clearOpened() = runOnUiThread { prefs().edit().putString("history_opened", "[]").apply() }
    }

    inner class ToolbarBridge {
        @android.webkit.JavascriptInterface
        fun nav() = runOnUiThread {
            val target = web
            if (navForward) {
                if (target.canGoForward()) target.goForward() else toast("No page to go forward to")
            } else {
                if (target.canGoBack()) target.goBack() else toast("No page to go back to")
            }
            refreshBack()
        }

        @android.webkit.JavascriptInterface
        fun addtabmenu() = runOnUiThread { showAddTabMenu() }

        @android.webkit.JavascriptInterface
        fun tabactions() = runOnUiThread { showTabActions() }

        @android.webkit.JavascriptInterface
        fun menu() = runOnUiThread { showPageMenu() }

        @android.webkit.JavascriptInterface
        fun reader() = runOnUiThread { toggleReaderForActiveTab() }

        @android.webkit.JavascriptInterface
        fun reload() = runOnUiThread {
            val target = active.web
            if (target.url.isNullOrBlank()) target.loadUrl(START_URL) else target.reload()
            if (target === web) setLoading(true)
        }

        @android.webkit.JavascriptInterface
        fun voiceSearch() = runOnUiThread { launchVoiceSearch() }

        @android.webkit.JavascriptInterface
        fun address() = runOnUiThread { editUrl() }

        @android.webkit.JavascriptInterface
        fun folded(on: Boolean) = runOnUiThread { resizeToolbarWeb(on) }

        @android.webkit.JavascriptInterface
        fun hidebar() = runOnUiThread { hideBar() }

        @android.webkit.JavascriptInterface
        fun surface(open: Boolean) = runOnUiThread { resizeToolbarWeb(open) }

        @android.webkit.JavascriptInterface
        fun smartsetting(enabled: Boolean) = runOnUiThread {
            prefs().edit().putBoolean("smart_search", enabled).apply()
            val value = if (enabled) "1" else "0"
            web.evaluateJavascript("(function(){try{localStorage.setItem('hp.smart','$value');localStorage.setItem('ulaa-smart','$value')}catch(e){}})()", null)
        }

        @android.webkit.JavascriptInterface
        fun smartstate() = runOnUiThread {
            val enabled = prefs().getBoolean("smart_search", true)
            toolbarJs("window.ulaaSetSmart && window.ulaaSetSmart($enabled)")
        }

        @android.webkit.JavascriptInterface
        fun search(query: String?) = runOnUiThread {
            val q = query?.trim().orEmpty()
            if (q.isEmpty()) return@runOnUiThread
            if (!active.isPrivate) recordSearchQuery(q)
            // Respect the setting from Valley's homepage (hp.smart) or the page pill (ulaa-smart).
            // The native preference is the fallback for pages that have never set either value.
            val readSetting = "(function(){try{var s=localStorage.getItem('hp.smart');" +
                "if(s===null)s=localStorage.getItem('ulaa-smart');return s;}catch(e){return null;}})()"
            web.evaluateJavascript(readSetting) { raw ->
                val smart = when (raw?.trim('"')) {
                    "0" -> false
                    "1" -> true
                    else -> prefs().getBoolean("smart_search", true)
                }
                prefs().edit().putBoolean("smart_search", smart).apply()
                web.loadUrl(routeSearch(q, smart))
            }
        }

        @android.webkit.JavascriptInterface
        fun navmode(name: String?) = runOnUiThread {
            navForward = name == "Forward"
            applyNavMode()
        }

        @android.webkit.JavascriptInterface
        fun action(name: String?) = runOnUiThread {
            when (name) {
                "share" -> shareCurrent()
                "favourite" -> addToList("list_favs")
                "bookmark" -> addToList("list_bookmarks")
                "newtab" -> newTab(START_URL)
                "privatetab" -> newTab(START_URL, true)
                "bookmarks" -> enterOverview(Mode.BOOKMARKS)
                "alltabs" -> enterOverview(Mode.TABS)
                "closetab" -> { closeTab(current); if (tabs.isNotEmpty()) exitOverview() }
                "navback" -> if (web.canGoBack()) web.goBack()
                "navforward" -> if (web.canGoForward()) web.goForward()
            }
        }

        @android.webkit.JavascriptInterface
        fun tabSwipe(direction: String?) = runOnUiThread {
            if (tabs.size < 2) return@runOnUiThread
            val next = if (direction == "next") (current + 1) % tabs.size else (current - 1 + tabs.size) % tabs.size
            switchTo(next)
        }

        @android.webkit.JavascriptInterface
        fun tool(name: String?) = runOnUiThread {
            when (name) {
                "voiceSearch" -> launchVoiceSearch()
                "translate" -> translatePage()
                "eraser" -> js("window.ulaaEraser && window.ulaaEraser()")
                "summarise" -> js("window.ulaaSummarise && window.ulaaSummarise()")
                "copy" -> {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("url", web.url ?: ""))
                    toast("Link copied")
                }
                "home" -> { web.loadUrl(START_URL); toolbarJs("window.ulaaFold && window.ulaaFold(false)") }
                "hidebar" -> hideBar()
            }
        }
    }

    private val voiceRequestCode = 7041

    /** Uses Android's system speech UI; no direct microphone permission is requested by Valley. */
    private fun launchVoiceSearch() {
        try {
            if (!packageManager.hasSystemFeature("android.hardware.microphone")) {
                toast("Voice search is unavailable on this device")
                return
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your search")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            startActivityForResult(intent, voiceRequestCode)
        } catch (e: Exception) {
            toast("Voice search service is unavailable")
        }
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with the current Activity shell")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != voiceRequestCode || resultCode != RESULT_OK) return
        val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim().orEmpty()
        if (spoken.isNotEmpty()) {
            if (!active.isPrivate) recordSearchQuery(spoken)
            web.loadUrl(routeSearch(spoken, prefs().getBoolean("smart_search", true)))
        }
    }

    /** the bar only needs 78dp; the orb and its tools need room above it */
    private fun resizeToolbarWeb(expanded: Boolean) {
        try {
            val tw = findViewById<WebView>(R.id.toolbarWeb)
            val lp = tw.layoutParams
            lp.height = dp(if (expanded) 360 else 78)
            tw.layoutParams = lp
        } catch (e: Exception) {}
    }

    private fun toolbarJs(code: String) {
        try { findViewById<WebView>(R.id.toolbarWeb).evaluateJavascript(code, null) } catch (e: Exception) {}
    }

    private fun setUpToolbarWeb() {
        val tw = findViewById<WebView>(R.id.toolbarWeb)
        tw.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        tw.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        tw.settings.javaScriptEnabled = true
        tw.settings.domStorageEnabled = true
        tw.settings.allowFileAccess = false
        tw.isVerticalScrollBarEnabled = false
        tw.isHorizontalScrollBarEnabled = false
        tw.overScrollMode = View.OVER_SCROLL_NEVER
        tw.addJavascriptInterface(ToolbarBridge(), "ValleyNative")
        tw.webViewClient = object : android.webkit.WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                assetLoader.shouldInterceptRequest(request.url)?.let { return it }
                return null
            }
        }
        tw.loadUrl("https://appassets.androidplatform.net/assets/toolbar.html")
    }

    // ---------------------------------------------------------------- overview pages

    private fun overview(): FrameLayout = findViewById(R.id.overview)

    private fun enterOverview(kind: Mode, group: String? = null) {
        mode = kind
        filterGroup = group
        val box = overview()
        box.visibility = View.VISIBLE
        box.removeAllViews()
        box.addView(when (kind) {
            Mode.TABS -> buildTabsPage(group)
            Mode.MANAGE_GROUPS -> buildManageTabGroupsPage()
            else -> buildBookmarksPage()
        })
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try {
                web.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(
                    22f, 22f, android.graphics.Shader.TileMode.CLAMP))
            } catch (e: Exception) {}
        }
        box.alpha = 0f
        box.translationY = dp(18).toFloat()
        box.animate().alpha(1f).translationY(0f).setDuration(280)
            .setInterpolator(Motion.ease).start()
        applyModeChrome()
    }

    private fun exitOverview() {
        if (mode == Mode.BROWSING) return
        mode = Mode.BROWSING
        filterGroup = null
        val box = overview()
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try { web.setRenderEffect(null) } catch (e: Exception) {}
        }
        box.animate().alpha(0f).translationY(dp(14).toFloat()).setDuration(180)
            .withEndAction { box.visibility = View.GONE; box.removeAllViews() }.start()
        applyModeChrome()
    }

    /** In overview, the compact count pill stays centered between the left + and right … controls. */
    private fun shrinkPill(shrink: Boolean) {
        try {
            val pill = findViewById<View>(R.id.pill)
            val lp = pill.layoutParams as LinearLayout.LayoutParams
            if (shrink) {
                // Overview: keep the count as a compact, independent pill centered
                // between equal-sized edge controls (+ on the left, … on the right).
                lp.weight = 0f
                lp.width = LinearLayout.LayoutParams.WRAP_CONTENT
                lp.gravity = android.view.Gravity.CENTER_VERTICAL
                pill.minimumWidth = dp(76)
            } else {
                lp.weight = 1f
                lp.width = 0
            }
            pill.layoutParams = lp

            // the label itself had weight 1, which measures to nothing inside a wrapping pill
            val label = findViewById<TextView>(R.id.overviewLabel)
            val llp = label.layoutParams as LinearLayout.LayoutParams
            if (shrink) {
                llp.weight = 0f
                llp.width = LinearLayout.LayoutParams.WRAP_CONTENT
                llp.setMargins(dp(16), 0, dp(16), 0)
                label.gravity = android.view.Gravity.CENTER
                label.setPadding(dp(4), 0, dp(4), 0)
            } else {
                llp.weight = 1f
                llp.width = 0
                llp.setMargins(0, 0, 0, 0)
                label.setPadding(0, 0, 0, 0)
                pill.minimumWidth = 0
            }
            label.layoutParams = llp
        } catch (e: Exception) {}
    }

    private fun applyModeChrome() {
        val label = findViewById<TextView>(R.id.overviewLabel)
        val reader = findViewById<View>(R.id.reader)
        val reload = findViewById<View>(R.id.reload)
        val nav = findViewById<ImageButton>(R.id.back)
        val inOverview = mode != Mode.BROWSING
        findViewById<WebView>(R.id.toolbarWeb).visibility =
            if (inOverview) View.GONE else View.VISIBLE

        urlView.visibility = if (inOverview) View.GONE else View.VISIBLE
        reader.visibility = if (inOverview) View.GONE else View.VISIBLE
        reload.visibility = if (inOverview) View.GONE else View.VISIBLE
        label.visibility = if (inOverview) View.VISIBLE else View.GONE

        shrinkPill(inOverview)
        if (inOverview) {
            toolbarJs("window.ulaaCount && window.ulaaCount(" +
                org.json.JSONObject.quote(if (mode == Mode.TABS) tabs.size.toString() + (if (tabs.size == 1) " tab" else " tabs") else "Bookmarks") + ")")
        } else {
            toolbarJs("window.ulaaCount && window.ulaaCount(null)")
        }
        if (inOverview) {
            label.text = if (mode == Mode.TABS) tabs.size.toString() + (if (tabs.size == 1) " tab" else " tabs")
                         else "Bookmarks"
            nav.setImageResource(R.drawable.ic_plus)
            nav.alpha = 1f
        } else {
            applyNavMode()
            refreshBack()
        }
    }

    private fun pageHeader(title: String): LinearLayout {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(12))
        }
        head.addView(TextView(this).apply {
            text = title
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 24f
            setTypeface(Typeface.create("serif", Typeface.ITALIC))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        head.addView(TextView(this).apply {
            text = "Done"
            setTextColor(0xFFE8622A.toInt())
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), dp(6), 0, dp(6))
            isClickable = true
            setOnClickListener { exitOverview() }
            pressable(this)
        })
        return head
    }

    private fun buildTabsPage(group: String?): View {
        val root = FrameLayout(this)

        val scroll = android.widget.ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            isFillViewport = true
            clipToPadding = false
            setPadding(0, 0, 0, dp(88))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        scroll.addView(col)
        root.addView(scroll)

        val isPrivateGroup = group == "__PRIVATE__"
        val visibleTabs = tabs.filter { t ->
            when {
                isPrivateGroup -> t.isPrivate
                group != null -> groups.firstOrNull { it.first == group }?.second?.contains(t.web.url ?: "") == true
                else -> !t.isPrivate
            }
        }
        val currentGroupName = when {
            isPrivateGroup -> "Private"
            group != null -> group
            else -> "Personal"
        }

        // Search header. Settings has its own fixed-width hit target and cannot overlap search.
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(10))
        }
        val settingsPill = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_settings)
            scaleType = android.widget.ImageView.ScaleType.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(22).toFloat()
                setColor(0xFF343438.toInt())
                setStroke(dp(1), 0x33FFFFFF)
            }
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(50)).also {
                it.marginEnd = dp(10)
            }
            isClickable = true
            contentDescription = "Tab settings"
            setOnClickListener { showTabActions() }
            pressable(this)
        }
        val searchField = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(0xFF343438.toInt())
                setStroke(dp(1), 0x22FFFFFF)
            }
            setPadding(dp(14), 0, dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(0, dp(50), 1f)
        }
        val searchIcon = TextView(this).apply {
            text = "⌕"
            textSize = 25f
            setTextColor(0xFFF4F4F6.toInt())
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(30), dp(48))
        }
        val tabsSearch = EditText(this).apply {
            hint = "Search tabs"
            setHintTextColor(0xFFB5B5BB.toInt())
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 16f
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            background = null
            setPadding(dp(8), 0, dp(4), 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        val cancelSearch = TextView(this).apply {
            text = "Cancel"
            textSize = 15f
            setTextColor(0xFF0A84FF.toInt())
            gravity = android.view.Gravity.CENTER
            visibility = View.GONE
            setPadding(dp(12), 0, 0, 0)
            setOnClickListener {
                tabsSearch.setText("")
                tabsSearch.clearFocus()
                val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.hideSoftInputFromWindow(tabsSearch.windowToken, 0)
                visibility = View.GONE
            }
        }
        searchField.addView(searchIcon)
        searchField.addView(tabsSearch)
        searchRow.addView(settingsPill)
        searchRow.addView(searchField)
        searchRow.addView(cancelSearch)
        searchRow.visibility = if (selectingTabs) View.GONE else View.VISIBLE
        col.addView(searchRow)

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
        }
        col.addView(grid)

        var row: LinearLayout? = null
        var count = 0
        tabs.withIndex().sortedWith(compareByDescending<IndexedValue<Tab>> { it.value.isPinned }.thenBy { it.index }).forEach { entry ->
            val i = entry.index
            val t = entry.value
            val belongs = when {
                isPrivateGroup -> t.isPrivate
                group != null -> groups.firstOrNull { it.first == group }?.second?.contains(t.web.url ?: "") == true
                else -> !t.isPrivate
            }
            if (!belongs) return@forEach
            if (count % 2 == 0) {
                val fresh = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                grid.addView(fresh)
                row = fresh
            }
            val card = tabCard(t, i == current)
            val target = row
            if (target != null) {
                target.addView(card, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .also { it.setMargins(dp(6), 0, dp(6), 0) })
            }
            count++
        }

        tabsSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString()?.trim()?.lowercase().orEmpty()
                cancelSearch.visibility = if (q.isNotEmpty() || tabsSearch.hasFocus()) View.VISIBLE else View.GONE
                for (r in 0 until grid.childCount) {
                    val rowView = grid.getChildAt(r) as? LinearLayout ?: continue
                    var anyVisible = false
                    for (c in 0 until rowView.childCount) {
                        val cardView = rowView.getChildAt(c)
                        val match = q.isEmpty() || (cardView.tag as? String)?.contains(q) == true
                        cardView.visibility = if (match) View.VISIBLE else View.GONE
                        if (match) anyVisible = true
                    }
                    rowView.visibility = if (anyVisible) View.VISIBLE else View.GONE
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        tabsSearch.setOnFocusChangeListener { _, focused ->
            cancelSearch.visibility = if (focused || tabsSearch.text.isNotEmpty()) View.VISIBLE else View.GONE
        }
        tabsSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {
                val q = tabsSearch.text.toString().trim()
                if (q.isNotEmpty()) { exitOverview(); newTab(routeSearch(q, prefs().getBoolean("smart_search", true))) }
                true
            } else false
        }
        if (count == 0) {
            col.addView(TextView(this).apply {
                text = "No tabs here yet."
                setTextColor(0xFF877E74.toInt())
                textSize = 13.5f
                setPadding(dp(20), dp(10), dp(20), dp(10))
            })
        }

        // Bottom overview dock: left actions, true-centred count, current group name, done.
        val dock = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadii = floatArrayOf(dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat(), dp(28).toFloat(),
                    0f, 0f, 0f, 0f)
                setColor(0xEE171719.toInt())
                setStroke(dp(1), 0x22FFFFFF)
            }
            elevation = dp(12).toFloat()
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val dockLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dp(58), android.view.Gravity.BOTTOM)
        dockLp.setMargins(dp(12), 0, dp(12), dp(20))
        root.addView(dock, dockLp)

        fun dockText(label: String, selected: Boolean = false): TextView =
            TextView(this).apply {
                text = label
                gravity = android.view.Gravity.CENTER
                textSize = 13.5f
                setTextColor(if (selected) 0xFFFFFFFF.toInt() else 0xFFB8B8BE.toInt())
                setPadding(dp(10), 0, dp(10), 0)
                background = GradientDrawable().apply {
                    cornerRadius = dp(22).toFloat()
                    setColor(if (selected) 0x333B82F6 else 0x00000000)
                    if (selected) setStroke(dp(1), 0x554A9EFF)
                }
            }

        val leftActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val plus = dockText("+", false).apply {
            textSize = 25f
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
            setOnClickListener { exitOverview(); newTab(START_URL) }
            isClickable = true
            contentDescription = "New tab"
            pressable(this)
        }
        val privateChip = dockText("Private", isPrivateGroup).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(38)).also { it.marginStart = dp(4) }
            setOnClickListener { enterOverview(Mode.TABS, if (isPrivateGroup) null else "__PRIVATE__") }
            isClickable = true
            pressable(this)
        }
        leftActions.addView(plus)
        leftActions.addView(privateChip)
        dock.addView(leftActions, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.MATCH_PARENT, android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL))

        val countChip = dockText(if (selectingTabs) "${selectedTabs.size} Selected" else "${visibleTabs.size} ${if (visibleTabs.size == 1) "Tab" else "Tabs"}", false).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, dp(40), android.view.Gravity.CENTER)
            setOnClickListener { if (selectingTabs) showSelectedTabsMenu() }
        }
        dock.addView(countChip)

        val groupNames = (listOf("Personal") + groups.map { it.first }).distinct()
            .filter { it != "Personal" || !isPrivateGroup }
        val groupStrip = android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = false
            isHorizontalFadingEdgeEnabled = true
            setFadingEdgeLength(dp(18))
            setPadding(dp(3), 0, dp(3), 0)
            clipToPadding = false
        }
        val groupItems = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        groupNames.forEach { name ->
            val item = dockText(name, false).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(38)).also {
                    it.marginStart = dp(3); it.marginEnd = dp(3)
                }
                isClickable = name != currentGroupName
                if (name != currentGroupName) setOnClickListener { enterOverview(Mode.TABS, if (name == "Personal") null else name) }
            }
            groupItems.addView(item)
        }
        groupStrip.addView(groupItems)
        val groupLp = FrameLayout.LayoutParams(dp(92), FrameLayout.LayoutParams.MATCH_PARENT,
            android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.END)
        groupLp.setMargins(0, 0, dp(48), 0)
        dock.addView(groupStrip, groupLp)

        val done = dockText("✓", true).apply {
            textSize = 22f
            layoutParams = FrameLayout.LayoutParams(dp(42), dp(42), android.view.Gravity.END or android.view.Gravity.CENTER_VERTICAL)
            setOnClickListener { exitOverview() }
            isClickable = true
            contentDescription = "Done"
            pressable(this)
        }
        dock.addView(done)

        if (selectingTabs) {
            // iOS-style selection controls: compact action capsule at top-left and a blue Done check at top-right.
            val selectionBar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    cornerRadius = dp(24).toFloat()
                    setColor(0xCC5B1830.toInt())
                    setStroke(dp(1), 0x44FFFFFF)
                }
                elevation = dp(14).toFloat()
                setPadding(dp(5), dp(3), dp(5), dp(3))
            }
            fun selectionAction(label: String, action: () -> Unit): TextView =
                TextView(this).apply {
                    text = label
                    gravity = android.view.Gravity.CENTER
                    textSize = 12.5f
                    setTextColor(0xFFF8F4F6.toInt())
                    setPadding(dp(10), dp(7), dp(10), dp(7))
                    isClickable = true
                    setOnClickListener { action() }
                    pressable(this)
                }
            selectionBar.addView(selectionAction("Close") {
                val targets = selectedTabs.toList()
                selectedTabs.clear()
                selectingTabs = false
                targets.map { tabs.indexOf(it) }.filter { it >= 0 }.sortedDescending().forEach { closeTab(it) }
                enterOverview(Mode.TABS, filterGroup)
            })
            selectionBar.addView(selectionAction("Move") {
                if (selectedTabs.isNotEmpty()) showMoveSelectedTabs()
            })
            selectionBar.addView(selectionAction("•••") {
                showSelectedTabsMenu()
            })
            val topLp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, dp(42),
                android.view.Gravity.TOP or android.view.Gravity.START)
            topLp.setMargins(dp(18), dp(12), 0, 0)
            root.addView(selectionBar, topLp)

            val finish = TextView(this).apply {
                text = "✓"
                gravity = android.view.Gravity.CENTER
                textSize = 21f
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFF279AF2.toInt())
                    setStroke(dp(1), 0x66FFFFFF)
                }
                elevation = dp(14).toFloat()
                layoutParams = FrameLayout.LayoutParams(dp(38), dp(38),
                    android.view.Gravity.TOP or android.view.Gravity.END)
                setOnClickListener {
                    selectedTabs.clear()
                    selectingTabs = false
                    enterOverview(Mode.TABS, filterGroup)
                }
                contentDescription = "Done selecting tabs"
                isClickable = true
                pressable(this)
            }
            val finishLp = FrameLayout.LayoutParams(dp(38), dp(38),
                android.view.Gravity.TOP or android.view.Gravity.END)
            finishLp.setMargins(0, dp(14), dp(18), 0)
            root.addView(finish, finishLp)
        }

        return root
    }

    private fun tabCard(t: Tab, active: Boolean): LinearLayout {
        var pressX = dp(72).toFloat()
        var pressY = dp(42).toFloat()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            tag = (t.title + " " + (t.web.url ?: "")).lowercase()
            setPadding(dp(8), dp(8), dp(8), dp(10))
            background = getDrawable(if (selectedTabs.contains(t) || active) R.drawable.card_glass_active else R.drawable.card_glass)
            isClickable = true
            setOnClickListener {
                if (selectingTabs) {
                    if (selectedTabs.contains(t)) selectedTabs.remove(t) else selectedTabs.add(t)
                    enterOverview(Mode.TABS, filterGroup)
                } else {
                    val idx = tabs.indexOf(t)
                    if (idx >= 0) switchTo(idx)
                    exitOverview()
                }
            }
            pressable(this)
        }
        card.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_DOWN) {
                pressX = event.x - dp(8)
                pressY = event.y - dp(8)
            }
            false
        }
        val preview = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xFF20232A.toInt())
            }
            clipToOutline = true
        }
        card.setOnLongClickListener {
            val glow = View(this).apply {
                setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                val cx = pressX.coerceIn(0f, preview.width.toFloat().coerceAtLeast(1f))
                val cy = (pressY - dp(8)).coerceIn(0f, preview.height.toFloat().coerceAtLeast(1f))
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                paint.shader = android.graphics.RadialGradient(
                    cx, cy, dp(105).toFloat(),
                    intArrayOf(0x99FFFFFF.toInt(), 0x4478B7FF, 0x0078B7FF),
                    floatArrayOf(0f, .42f, 1f), android.graphics.Shader.TileMode.CLAMP)
                background = object : android.graphics.drawable.Drawable() {
                    override fun draw(canvas: android.graphics.Canvas) { canvas.drawCircle(cx, cy, dp(105).toFloat(), paint) }
                    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
                    override fun setColorFilter(filter: android.graphics.ColorFilter?) { paint.colorFilter = filter }
                    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
                }
            }
            preview.addView(glow, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            glow.alpha = 0f
            glow.animate().alpha(1f).setDuration(100).withEndAction {
                glow.animate().alpha(0f).setDuration(230).withEndAction { preview.removeView(glow) }.start()
            }.start()
            showTabContextMenu(t)
            true
        }
        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Preview of ${t.title}"
        }
        val w = dp(145); val h = dp(92)
        try {
            if (t.web.width > 0 && t.web.height > 0) {
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bmp)
                canvas.drawColor(0xFF20232A.toInt())
                // Preserve the webpage's aspect ratio: fit the whole visible page into
                // the thumbnail instead of stretching it into a narrow, distorted preview.
                val scale = minOf(w.toFloat() / t.web.width, h.toFloat() / t.web.height)
                val drawW = t.web.width * scale
                val drawH = t.web.height * scale
                val left = (w - drawW) / 2f
                val top = (h - drawH) / 2f
                canvas.save()
                canvas.translate(left, top)
                canvas.scale(scale, scale)
                t.web.draw(canvas)
                canvas.restore()
                thumb.setImageBitmap(bmp)
            }
        } catch (_: Exception) {}
        preview.addView(thumb, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(92)))
        if (selectedTabs.contains(t)) {
            if (selectedTabs.firstOrNull() === t) {
                val countBadge = TextView(this).apply {
                    text = "${selectedTabs.size} selected"
                    gravity = android.view.Gravity.CENTER
                    textSize = 9.5f
                    setTextColor(Color.WHITE)
                    setPadding(dp(7), dp(3), dp(7), dp(3))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor(0xAA243B58.toInt())
                        setStroke(dp(1), 0x5578B7FF)
                    }
                    elevation = dp(4).toFloat()
                }
                val countLp = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, dp(20),
                    android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL)
                countLp.topMargin = dp(3)
                preview.addView(countBadge, countLp)
            }
            preview.foreground = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), 0xFF399BFF.toInt())
            }
            val selectedBadge = TextView(this).apply {
                text = "✓"
                gravity = android.view.Gravity.CENTER
                textSize = 12f
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFF299AF2.toInt())
                }
                elevation = dp(4).toFloat()
            }
            val badgeLp = FrameLayout.LayoutParams(dp(22), dp(22),
                android.view.Gravity.TOP or android.view.Gravity.END)
            badgeLp.setMargins(0, dp(4), dp(4), 0)
            preview.addView(selectedBadge, badgeLp)
        }
        val close = TextView(this).apply {
            text = "×"
            gravity = android.view.Gravity.CENTER
            textSize = 20f
            setTextColor(0xFFFF3B30.toInt())
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xAA171719.toInt()) }
            contentDescription = "Close tab"
            setPadding(0, 0, 0, dp(2))
            setOnClickListener { closeTab(tabs.indexOf(t)); if (mode != Mode.BROWSING) enterOverview(Mode.TABS) }
            pressable(this)
        }
        val closeLp = FrameLayout.LayoutParams(dp(28), dp(28), android.view.Gravity.TOP or android.view.Gravity.END)
        closeLp.setMargins(0, dp(5), dp(5), 0)
        preview.addView(close, closeLp)
        card.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(92)))
        card.addView(TextView(this).apply {
            text = (if (t.isPinned) "📌 " else "") + (if (t.isPrivate) "◐ " else "") + t.title.take(28)
            setTextColor(if (t.isPrivate) 0xFFCBA8FF.toInt() else 0xFFF6F0E8.toInt())
            textSize = 13f
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(3), dp(8), dp(3), 0)
        })
        card.addView(TextView(this).apply {
            text = prettyUrl(t.web.url ?: "")
            setTextColor(0xFFB6B0A8.toInt())
            textSize = 11f
            setPadding(dp(3), dp(4), dp(3), 0)
            maxLines = 1
            ellipsize = null
            isSingleLine = true
            // Text remains centered and readable; fade edges rather than adding dots.
            setFadingEdgeLength(dp(18))
            setHorizontalFadingEdgeEnabled(true)
        })
        return card
    }

    private fun showTabContextMenu(tab: Tab) {
        val card = menuCard()
        val url = tab.web.url ?: START_URL
        val idx = tabs.indexOf(tab)
        card.addView(menuRow(R.drawable.ic_copy, "Copy Link") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("link", url))
            dismissLater()
            toast("Link copied")
        })
        card.addView(menuRow(R.drawable.ic_star, if (tab.isPinned) "Unpin Tab" else "Pin Tab") {
            tab.isPinned = !tab.isPinned
            dismissLater()
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuRow(R.drawable.ic_tabs, "Duplicate Tab") {
            dismissLater()
            newTab(url, tab.isPrivate)
        })
        card.addView(menuRow(R.drawable.ic_tabs, "Select Tabs") {
            dismissLater()
            selectingTabs = true
            selectedTabs.clear()
            selectedTabs.add(tab)
            enterOverview(Mode.TABS, filterGroup)
            showSelectedTabsMenu()
        })
        card.addView(menuRow(R.drawable.ic_group, "Move Tab", chevron = true) {
            dismissLater()
            showMoveSingleTab(tab)
        })
        card.addView(menuRow(R.drawable.ic_chevron_left, "Close Tab", destructive = true) {
            dismissLater()
            closeTab(idx)
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_chevron_left, "Close Other Tabs", destructive = true) {
            dismissLater()
            closeOtherTabs(tab)
        })
        showCard(card, Align.RIGHT)
    }

    private fun showMoveSingleTab(tab: Tab) {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_group, "Personal") {
            groups.forEach { it.second.remove(tab.web.url ?: "") }
            dismissLater()
            enterOverview(Mode.TABS, null)
        })
        groups.forEach { group ->
            card.addView(menuRow(R.drawable.ic_group, group.first) {
                val url = tab.web.url ?: START_URL
                groups.forEach { it.second.remove(url) }
                if (!group.second.contains(url)) group.second.add(url)
                dismissLater()
                enterOverview(Mode.TABS, group.first)
            })
        }
        card.addView(menuRow(R.drawable.ic_plus, "New Tab Group") {
            dismissLater()
            newGroupPrompt()
        })
        showCard(card, Align.RIGHT)
    }

    private fun showSelectedTabsMenu() {
        if (selectedTabs.isEmpty()) {
            selectingTabs = false
            return
        }
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_group, "Move ${selectedTabs.size} Tabs", chevron = true) {
            dismissLater()
            showMoveSelectedTabs()
        })
        card.addView(menuRow(R.drawable.ic_star, "Pin ${selectedTabs.size} Tabs") {
            selectedTabs.forEach { it.isPinned = true }
            selectedTabs.clear()
            selectingTabs = false
            dismissLater()
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuRow(R.drawable.ic_chevron_left, "Close ${selectedTabs.size} Tabs", destructive = true) {
            val targets = selectedTabs.toList()
            selectedTabs.clear()
            selectingTabs = false
            dismissLater()
            targets.map { tabs.indexOf(it) }.filter { it >= 0 }.sortedDescending().forEach { closeTab(it) }
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuRow(R.drawable.ic_chevron_left, "Cancel Selection") {
            selectedTabs.clear()
            selectingTabs = false
            dismissLater()
            enterOverview(Mode.TABS, filterGroup)
        })
        showCard(card, Align.TOP_LEFT, blurBehind = false)
    }

    private fun showMoveSelectedTabs() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_group, "Personal") {
            selectedTabs.forEach { tab -> groups.forEach { it.second.remove(tab.web.url ?: "") } }
            selectedTabs.clear()
            selectingTabs = false
            dismissLater()
            enterOverview(Mode.TABS, null)
        })
        groups.forEach { group ->
            card.addView(menuRow(R.drawable.ic_group, group.first) {
                selectedTabs.forEach { tab ->
                    val url = tab.web.url ?: START_URL
                    groups.forEach { it.second.remove(url) }
                    if (!group.second.contains(url)) group.second.add(url)
                }
                selectedTabs.clear()
                selectingTabs = false
                dismissLater()
                enterOverview(Mode.TABS, group.first)
            })
        }
        card.addView(menuRow(R.drawable.ic_plus, "New Tab Group") {
            dismissLater()
            newGroupPrompt()
        })
        showCard(card, Align.RIGHT)
    }

    private fun closeOtherTabs(keep: Tab) {
        val closing = tabs.filter { it !== keep }
        closing.forEach { tab ->
            val idx = tabs.indexOf(tab)
            if (idx >= 0) {
                tabs.removeAt(idx)
                if (tab.isPrivate) privateCount = (privateCount - 1).coerceAtLeast(0)
                try { tab.web.destroy() } catch (_: Exception) {}
            }
        }
        current = tabs.indexOf(keep).coerceAtLeast(0)
        if (tabs.isEmpty()) newTab(START_URL) else attach()
        selectedTabs.clear()
        selectingTabs = false
        enterOverview(Mode.TABS, filterGroup)
    }

    private fun buildBookmarksPage(): View {
        val scroll = android.widget.ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(96))
        }
        scroll.addView(col)
        col.addView(pageHeader("Bookmarks"))

        val favs = (prefs().getString("list_favs", "") ?: "").split("\n").filter { it.isNotBlank() }
        val marks = (prefs().getString("list_bookmarks", "") ?: "").split("\n").filter { it.isNotBlank() }

        if (favs.isEmpty() && marks.isEmpty()) {
            col.addView(TextView(this).apply {
                text = "Nothing saved yet. Long-press \u22EF on a page and choose Add to Favourites."
                setTextColor(0xFF877E74.toInt())
                textSize = 13.5f
                setLineSpacing(dp(3).toFloat(), 1f)
                setPadding(dp(20), dp(10), dp(20), dp(10))
            })
            return scroll
        }
        if (favs.isNotEmpty()) {
            col.addView(sectionLabel("Favourites"))
            favs.forEach { col.addView(bookmarkRow(it, "\u2605")) }
        }
        if (marks.isNotEmpty()) {
            col.addView(sectionLabel("Bookmarks"))
            marks.forEach { col.addView(bookmarkRow(it, "\u25C6")) }
        }
        return scroll
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text.uppercase()
        setTextColor(0xFF877E74.toInt())
        textSize = 10f
        letterSpacing = 0.18f
        setPadding(dp(22), dp(18), dp(20), dp(6))
    }

    private fun bookmarkRow(url: String, mark: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(14), dp(14))
            background = getDrawable(R.drawable.card_glass)
            isClickable = true
            setOnClickListener { exitOverview(); newTab(url) }
            pressable(this)
        }
        row.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .also { it.setMargins(dp(16), dp(5), dp(16), dp(5)) }
        row.addView(TextView(this).apply {
            text = mark
            setTextColor(0xFFE8622A.toInt())
            textSize = 12f
            setPadding(0, 0, dp(12), 0)
        })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = prettyUrl(url)
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 14.5f
            maxLines = 1
        })
        col.addView(TextView(this).apply {
            text = url
            setTextColor(0xFF877E74.toInt())
            textSize = 11f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(3), 0, 0)
        })
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = "\u00d7"
            setTextColor(0xFF877E74.toInt())
            textSize = 17f
            setPadding(dp(12), 0, dp(4), 0)
            isClickable = true
            setOnClickListener {
                val bucket = if (mark == "\u2605") "list_favs" else "list_bookmarks"
                val all = (prefs().getString(bucket, "") ?: "").split("\n").filter { it.isNotBlank() && it != url }
                prefs().edit().putString(bucket, all.joinToString("\n")).apply()
                enterOverview(Mode.BOOKMARKS)
            }
            pressable(this)
        })
        return row
    }

    // ---------------------------------------------------------------- url bar

    private fun editUrl() {
        val card = menuCard()
        val input = EditText(this).apply {
            setText(if (web.url == null || web.url!!.contains(HOST)) "" else web.url)
            setSingleLine(true)
            setTextColor(0xFFF6F0E8.toInt())
            setHintTextColor(0xFF877E74.toInt())
            hint = getString(R.string.url_hint)
            textSize = 15f
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = getDrawable(R.drawable.field_glass)
            setSelection(text.length)
        }
        card.addView(input, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val go = TextView(this).apply {
            text = "Go"
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFF150C07.toInt())
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(13), 0, dp(13))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(0xFFE8622A.toInt())
            }
            isClickable = true
            setOnClickListener {
                val typed = input.text.toString().trim()
                if (typed.isNotEmpty()) web.loadUrl(toUrl(typed))
                dismissLater()
            }
            pressable(this)
        }
        card.addView(go, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also {
            it.setMargins(0, dp(10), 0, 0)
        })

        showCard(card, Align.FULL)
        input.requestFocus()
        input.postDelayed({
            try {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            } catch (e: Exception) {}
        }, 260)
    }

    /**
     * The floating pill has its own search box, so it must use the same smart-routing rules
     * as Valley's homepage rather than treating every non-host query as a plain Brave search.
     * URLs and explicit navigation commands always remain navigation, even with smart search off.
     */
    private fun routeSearch(input: String, smart: Boolean): String {
        val q = input.trim()
        if (q.isEmpty()) return START_URL
        if (Regex("^[a-z][a-z0-9+.-]*://", RegexOption.IGNORE_CASE).containsMatchIn(q)) return q
        val bareHost = Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE)
        if (!q.contains(Regex("\\s")) && bareHost.matches(q)) return "https://$q"

        val sites = linkedMapOf(
            "flipkart" to "https://www.flipkart.com/search?q=",
            "amazon" to "https://www.amazon.in/s?k=",
            "myntra" to "https://www.myntra.com/search?q=",
            "ajio" to "https://www.ajio.com/search/?text=",
            "croma" to "https://www.croma.com/searchB?q=",
            "snapdeal" to "https://www.snapdeal.com/search?keyword=",
            "meesho" to "https://www.meesho.com/search?q=",
            "nykaa" to "https://www.nykaa.com/search/result/?q=",
            "tatacliq" to "https://www.tatacliq.com/search/?searchCategory=all&text=",
            "reliancedigital" to "https://www.reliancedigital.in/search?q=",
            "swiggy" to "https://www.swiggy.com/search?query=",
            "zomato" to "https://www.zomato.com/search?q=",
            "bookmyshow" to "https://in.bookmyshow.com/explore/movies?q=",
            "paytm" to "https://paytm.com/",
            "github" to "https://github.com/search?q=",
            "wikipedia" to "https://en.wikipedia.org/w/index.php?search=",
            "youtube" to "https://www.youtube.com/results?search_query=",
            "reddit" to "https://www.reddit.com/search/?q=",
            "stackoverflow" to "https://stackoverflow.com/search?q=",
            "quora" to "https://www.quora.com/search?q=",
            "imdb" to "https://www.imdb.com/find?q=",
            "cricbuzz" to "https://www.cricbuzz.com/search?q=",
            "ndtv" to "https://www.ndtv.com/search?searchtext="
        )
        val known = listOf(
            "google.com","youtube.com","facebook.com","instagram.com","whatsapp.com","x.com","twitter.com",
            "reddit.com","wikipedia.org","linkedin.com","pinterest.com","quora.com","medium.com","github.com",
            "gitlab.com","stackoverflow.com","npmjs.com","vercel.com","netlify.com","amazon.in","amazon.com",
            "flipkart.com","myntra.com","ajio.com","meesho.com","snapdeal.com","nykaa.com","croma.com",
            "reliancedigital.in","tatacliq.com","paytm.com","phonepe.com","swiggy.com","zomato.com","zepto.com",
            "blinkit.com","bigbasket.com","bookmyshow.com","makemytrip.com","irctc.co.in","redbus.in","uber.com",
            "ndtv.com","thehindu.com","hindustantimes.com","indianexpress.com","bbc.com","cnn.com","reuters.com",
            "theguardian.com","nytimes.com","netflix.com","primevideo.com","hotstar.com","spotify.com","soundcloud.com",
            "imdb.com","cricbuzz.com","espn.com","apple.com","microsoft.com","samsung.com","oneplus.in","mi.com",
            "realme.com","vivo.com","adobe.com","figma.com","canva.com","notion.so","slack.com","discord.com",
            "telegram.org","chatgpt.com","claude.ai","perplexity.ai","sarvam.ai","accuweather.com","timeanddate.com",
            "britannica.com","dictionary.com","archive.org","wordpress.com","substack.com"
        )
        fun distance(a: String, b: String): Int {
            var prev = IntArray(b.length + 1) { it }
            for (i in a.indices) {
                val cur = IntArray(b.length + 1)
                cur[0] = i + 1
                for (j in b.indices) cur[j + 1] = minOf(
                    prev[j + 1] + 1, cur[j] + 1,
                    prev[j] + if (a[i] == b[j]) 0 else 1
                )
                prev = cur
            }
            return prev[b.length]
        }
        fun nearestSite(word: String): String? {
            val w = word.lowercase().replace(Regex("[^a-z0-9]"), "")
            if (w.length < 3) return null
            var best: String? = null
            var bestDistance = Int.MAX_VALUE
            for (host in known) {
                val base = host.substringBefore('.').replace(Regex("[^a-z0-9]"), "")
                var d = distance(w, base)
                if (base.startsWith(w)) d = minOf(d, 1)
                if (d < bestDistance) { bestDistance = d; best = host }
            }
            val limit = if (w.length <= 4) 1 else if (w.length <= 7) 2 else 3
            return if (best != null && bestDistance <= limit) "https://$best" else null
        }
        fun navTarget(raw: String): String? {
            val target = raw.trim().trimEnd('.', '。', ',', '\'', '"').trim()
            if (target.isEmpty()) return null
            val key = target.lowercase().replace(Regex("\\s+"), "")
            sites[key]?.let { value ->
                return try { val uri = java.net.URI(value); "${uri.scheme}://${uri.authority}" } catch (_: Exception) { null }
            }
            if (Regex("^[a-z0-9-]+$", RegexOption.IGNORE_CASE).matches(target)) {
                return nearestSite(target) ?: "https://${target.lowercase()}.com"
            }
            if (Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE).matches(target)) {
                return "https://$target"
            }
            return null
        }

        val nav = Regex("^(?:open|go\\s+to|goto|visit|launch)\\s+(.+)$", RegexOption.IGNORE_CASE).matchEntire(q)
        if (nav != null) navTarget(nav.groupValues[1])?.let { return it }
        val brave = "https://search.brave.com/search?q="
        if (!smart) return brave + android.net.Uri.encode(q)
        if (Regex("^(what|who|whom|whose|why|how|when|where|which|is|are|was|were|am|do|does|did|can|could|should|would|will|has|have|had)\\b", RegexOption.IGNORE_CASE)
                .containsMatchIn(q) || q.endsWith("?")) return brave + android.net.Uri.encode(q)

        for ((name, endpoint) in sites) {
            if (Regex("\\b${Regex.escape(name)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(q)) {
                val terms = q.replace(Regex("\\b${Regex.escape(name)}\\b", RegexOption.IGNORE_CASE), " ")
                    .replace(Regex("^\\s*(price of|prices|price|cost of|cost|buy|buying|best|where to buy|order)\\s+", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("\\s+\\b(on|from|at|in)\\s*$", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("\\s+"), " ").trim()
                return if (endpoint.endsWith("/" ) && name == "paytm") endpoint else endpoint + android.net.Uri.encode(terms.ifEmpty { q })
            }
        }
        return brave + android.net.Uri.encode(q)
    }

    private fun toUrl(input: String): String {
        val t = input.trim()
        if (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("file://")) return t
        val looksLikeHost = !t.contains(" ") &&
                Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE).containsMatchIn(t)
        return if (looksLikeHost) "https://$t"
        else "https://search.brave.com/search?q=" + URLEncoder.encode(t, "UTF-8")
    }

    // ---------------------------------------------------------------- menus

    private fun showPageMenu() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_share, "Share") { shareCurrent() })
        card.addView(menuRow(R.drawable.ic_star, "Add to Favourites") { saveLink("favs") })
        card.addView(menuRow(R.drawable.ic_bookmark, "Add Bookmark to\u2026") { saveLink("bookmarks") })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { newTab(START_URL) })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { privateTab() })
        card.addView(twoUpRow())
        showCard(card, Align.RIGHT)
    }

    private fun showPageTools() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_translate, "Translate page") { js("window.ulaaTranslate && window.ulaaTranslate()") })
        card.addView(menuRow(R.drawable.ic_eraser, "Eraser") { js("window.ulaaEraser && window.ulaaEraser()") })
        card.addView(menuRow(R.drawable.ic_summary, "Summarise page") { js("window.ulaaSummarise && window.ulaaSummarise()") })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_smart, "Smart search") { showSmartSearch() })
        card.addView(menuRow(R.drawable.ic_copy, "Copy link") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("link", web.url ?: ""))
            toast("Link copied")
        })
        card.addView(menuRow(R.drawable.ic_home, "Home") { web.loadUrl(START_URL) })
        showCard(card, Align.RIGHT)
    }

    private fun showBackForward() {
        val card = menuCard()

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2), dp(10), dp(2), dp(4))
        }
        row.addView(arrowCell(R.drawable.ic_chevron_left, "Back", !navForward) {
            navForward = false
            applyNavMode()
            dismissLater()
        }, weight())
        row.addView(arrowCell(R.drawable.ic_chevron_right, "Forward", navForward) {
            navForward = true
            applyNavMode()
            dismissLater()
        }, weight())
        card.addView(row)

        // one wide button underneath, showing whichever direction the circle is set to
        val wide = TextView(this).apply {
            text = if (navForward) "Forward" else "Back"
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(999).toFloat()
                setColor(0x3DFFFFFF)
            }
            isClickable = true
            setOnClickListener {
                navForward = !navForward
                applyNavMode()
                dismissLater()
            }
            pressable(this)
        }
        card.addView(wide, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .also { it.setMargins(dp(10), dp(6), dp(10), dp(12)) })

        showCard(card, Align.LEFT)
    }

    private fun arrowCell(icon: Int, label: String, selected: Boolean, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            isClickable = true
            setPadding(0, dp(10), 0, dp(8))
            setOnClickListener { onClick() }
            pressable(this)
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
        })
        // the label sits directly under its arrow, full brightness either way
        box.addView(TextView(this).apply {
            text = label
            setTextColor(if (selected) 0xFFF6F0E8.toInt() else 0xFFB3A89C.toInt())
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    /** the left circle shows only the direction that is currently selected */
    private fun applyNavMode() {
        val navBtn = findViewById<ImageButton>(R.id.back)
        navBtn.setImageResource(if (navForward) R.drawable.ic_chevron_right else R.drawable.ic_back)
        navBtn.contentDescription = if (navForward) "Forward" else "Back"
        toolbarJs("window.ulaaForward && window.ulaaForward(" + navForward + ")")
        toolbarJs("window.ulaaNavLabel && window.ulaaNavLabel(" + org.json.JSONObject.quote(if (navForward) "Forward" else "Back") + ")")
        refreshBack()
    }

    private fun privateTab() {
        val card = menuCard()
        card.addView(titleBlock("New Private Tab",
            "No site storage, no cache, third-party cookies off. When you close the last private " +
            "tab, every cookie is wiped \u2014 which also signs you out of your normal tabs, because " +
            "Android shares one cookie jar."))
        card.addView(primaryButton("Open private tab", 0xFF7B3FF2.toInt()) {
            dismissLater(); newTab(START_URL, true)
        })
        showCard(card, Align.RIGHT)
    }

    private fun titleBlock(title: String, body: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(6))
        }
        box.addView(TextView(this).apply {
            text = title
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 16.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, dp(8))
        })
        box.addView(TextView(this).apply {
            text = body
            setTextColor(0xFFB3A89C.toInt())
            textSize = 13f
            setLineSpacing(dp(3).toFloat(), 1f)
        })
        return box
    }

    private fun primaryButton(label: String, colour: Int, onClick: () -> Unit): TextView {
        val b = TextView(this).apply {
            text = label
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFF150C07.toInt())
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(13), 0, dp(13))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat(); setColor(colour)
            }
            isClickable = true
            setOnClickListener { onClick() }
            pressable(this)
        }
        b.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .also { it.setMargins(dp(10), dp(10), dp(10), dp(8)) }
        return b
    }

    private fun showAddTabMenu() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { dismissLater(); exitOverview(); newTab(START_URL) })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { dismissLater(); exitOverview(); newTab(START_URL, true) })
        showCard(card, Align.LEFT)
    }


    // Tab groups are stored as names plus their member URLs. Tabs not assigned to a
    // named group remain in Personal; private tabs are always kept separate.
    private fun saveTabGroups() {
        val array = org.json.JSONArray()
        groups.forEach { group ->
            val item = org.json.JSONObject()
            item.put("name", group.first)
            val urls = org.json.JSONArray()
            group.second.forEach { urls.put(it) }
            item.put("urls", urls)
            array.put(item)
        }
        prefs().edit().putString("valley_tab_groups_v1", array.toString()).apply()
    }

    private fun loadTabGroups() {
        groups.clear()
        val raw = prefs().getString("valley_tab_groups_v1", null) ?: return
        try {
            val array = org.json.JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val name = item.optString("name").trim()
                if (name.isEmpty() || name == "Personal" || name == "Private") continue
                val urls = mutableListOf<String>()
                val members = item.optJSONArray("urls") ?: org.json.JSONArray()
                for (j in 0 until members.length()) {
                    val url = members.optString(j)
                    if (url.isNotBlank() && !urls.contains(url)) urls.add(url)
                }
                if (groups.none { it.first.equals(name, true) }) groups.add(name to urls)
            }
        } catch (_: Exception) { groups.clear() }
    }

    private fun groupOrphanTabs(): List<Tab> {
        return tabs.filter { tab ->
            !tab.isPrivate && groups.none { g -> g.second.contains(tab.web.url ?: "") }
        }
    }

    private fun showGroupNameDialog(title: String, initial: String = "", onCreate: (String) -> Unit) {
        val input = EditText(this).apply {
            hint = "Name"
            setText(initial)
            setSingleLine(true)
            textSize = 16f
            setTextColor(0xFFF5F5F7.toInt())
            setHintTextColor(0xFF9A9AA2.toInt())
            setPadding(dp(16), dp(13), dp(16), dp(13))
            background = getDrawable(R.drawable.field_glass)
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(4), dp(22), 0)
            addView(input, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrap)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setTextColor(0xFF0A84FF.toInt())
            dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(0xFFFF453A.toInt())
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    input.error = "Enter a name"
                    return@setOnClickListener
                }
                if (name.equals("Personal", true) || name.equals("Private", true)) {
                    input.error = "That name is reserved"
                    return@setOnClickListener
                }
                if (groups.any { it.first.equals(name, true) && !it.first.equals(initial, true) }) {
                    input.error = "A group with this name already exists"
                    return@setOnClickListener
                }
                onCreate(name)
                dialog.dismiss()
            }
            input.requestFocus()
        }
        dialog.show()
    }

    private fun buildManageTabGroupsPage(): View {
        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF101014.toInt())
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(14), dp(18), dp(14), dp(24))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll)

        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(0xCC24242B.toInt())
                setStroke(dp(1), 0x24FFFFFF)
            }
            elevation = dp(5).toFloat()
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        fun divider(parent: LinearLayout) {
            parent.addView(View(this).apply {
                setBackgroundColor(0x20FFFFFF)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).also {
                    it.setMargins(dp(34), dp(2), dp(4), dp(2))
                }
            })
        }
        fun actionText(label: String, color: Int, click: () -> Unit): TextView =
            TextView(this).apply {
                text = label
                textSize = 12.5f
                setTextColor(color)
                gravity = android.view.Gravity.CENTER
                setPadding(dp(9), dp(8), dp(9), dp(8))
                isClickable = true
                setOnClickListener { click() }
            }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(14))
        }
        val edit = actionText(if (editingTabGroups) "Done" else "Edit", 0xFFF5F5F7.toInt()) {
            editingTabGroups = !editingTabGroups
            enterOverview(Mode.MANAGE_GROUPS)
        }
        header.addView(edit)
        header.addView(TextView(this).apply {
            text = "Personal Tab Groups"
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFF5F5F7.toInt())
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
        })
        header.addView(actionText("✓", 0xFFFFFFFF.toInt()) { exitOverview() }.apply {
            textSize = 21f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF0A84FF.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))
        })
        content.addView(header)

        val groupsCard = card()
        val personalCount = groupOrphanTabs().size
        val personalRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            minimumHeight = dp(42)
            addView(TextView(this@MainActivity).apply {
                text = "▯"
                textSize = 18f
                setTextColor(0xFF4A9EFF.toInt())
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(40))
            })
            addView(TextView(this@MainActivity).apply {
                text = "Personal  —  $personalCount ${if (personalCount == 1) "Tab" else "Tabs"}"
                textSize = 13.5f
                setTextColor(0xFFF0F0F3.toInt())
                gravity = android.view.Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            })
            addView(TextView(this@MainActivity).apply {
                text = "✓"
                textSize = 16f
                setTextColor(0xFF4A9EFF.toInt())
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(40))
            })
            isClickable = true
            setOnClickListener { enterOverview(Mode.TABS) }
        }
        groupsCard.addView(personalRow)
        if (groups.isNotEmpty()) divider(groupsCard)
        groups.forEachIndexed { index, group ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                minimumHeight = dp(42)
            }
            row.addView(TextView(this).apply {
                text = "▢"
                textSize = 19f
                setTextColor(0xFF4A9EFF.toInt())
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(40))
            })
            val count = group.second.count { url -> tabs.any { !it.isPrivate && it.web.url == url } }
            row.addView(TextView(this).apply {
                text = group.first + if (count > 0) "  —  $count Tabs" else ""
                textSize = 13.5f
                setTextColor(0xFFF0F0F3.toInt())
                gravity = android.view.Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            })
            if (editingTabGroups) {
                row.addView(actionText("Rename", 0xFF0A84FF.toInt()) {
                    showGroupNameDialog("Name", group.first) { newName ->
                        groups[index] = newName to group.second
                        saveTabGroups()
                        enterOverview(Mode.MANAGE_GROUPS)
                    }
                })
                row.addView(actionText("Delete", 0xFFFF453A.toInt()) {
                    groups.removeAt(index)
                    saveTabGroups()
                    enterOverview(Mode.MANAGE_GROUPS)
                })
            } else {
                row.isClickable = true
                row.setOnClickListener { enterOverview(Mode.TABS, group.first) }
            }
            groupsCard.addView(row)
            if (index != groups.lastIndex) divider(groupsCard)
        }
        content.addView(groupsCard)

        // Private is deliberately isolated from regular tab groups.
        val privateCard = card()
        val privateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            minimumHeight = dp(44)
            addView(TextView(this@MainActivity).apply {
                text = "♧"
                textSize = 18f
                setTextColor(0xFF4A9EFF.toInt())
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(42))
            })
            addView(TextView(this@MainActivity).apply {
                text = "Private"
                textSize = 13.5f
                setTextColor(0xFFF0F0F3.toInt())
                gravity = android.view.Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            })
            addView(TextView(this@MainActivity).apply {
                text = "${tabs.count { it.isPrivate }} Tabs"
                textSize = 12f
                setTextColor(0xFFB7B7BF.toInt())
                gravity = android.view.Gravity.CENTER
            })
            isClickable = true
            setOnClickListener { enterOverview(Mode.TABS, "__PRIVATE__") }
        }
        privateCard.addView(privateRow)
        content.addView(privateCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(12)
        })

        val createCard = card()
        val emptyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            minimumHeight = dp(44)
            addView(TextView(this@MainActivity).apply {
                text = "+"
                textSize = 21f
                setTextColor(0xFF0A84FF.toInt())
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(42))
            })
            addView(TextView(this@MainActivity).apply {
                text = "New Empty Tab Group"
                textSize = 13.5f
                setTextColor(0xFFF0F0F3.toInt())
                gravity = android.view.Gravity.CENTER_VERTICAL
            })
            isClickable = true
            setOnClickListener {
                showGroupNameDialog("Name") { name ->
                    if (groups.none { it.first.equals(name, true) }) {
                        groups.add(name to mutableListOf())
                        saveTabGroups()
                        enterOverview(Mode.MANAGE_GROUPS)
                    }
                }
            }
        }
        createCard.addView(emptyRow)
        divider(createCard)
        val orphanCount = groupOrphanTabs().size
        val moveRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            minimumHeight = dp(44)
            addView(TextView(this@MainActivity).apply {
                text = "+"
                textSize = 21f
                setTextColor(0xFF0A84FF.toInt())
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(42))
            })
            addView(TextView(this@MainActivity).apply {
                text = "New Tab Group with $orphanCount ${if (orphanCount == 1) "Tab" else "Tabs"}"
                textSize = 13.5f
                setTextColor(0xFFF0F0F3.toInt())
                gravity = android.view.Gravity.CENTER_VERTICAL
            })
            isClickable = true
            setOnClickListener {
                showGroupNameDialog("Name") { name ->
                    if (groups.none { it.first.equals(name, true) }) {
                        val orphanUrls = groupOrphanTabs().mapNotNull { it.web.url }.distinct().toMutableList()
                        groups.add(name to orphanUrls)
                        saveTabGroups()
                        enterOverview(Mode.MANAGE_GROUPS)
                    }
                }
            }
        }
        createCard.addView(moveRow)
        content.addView(createCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(12)
        })
        return root
    }

    private fun showTabActions() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_group, "Manage Tab Groups") {
            dismissLater()
            enterOverview(Mode.MANAGE_GROUPS)
        })
        card.addView(menuDivider())
        val shownGroups = groups.map { it.first }.toMutableList()
        if (shownGroups.isEmpty()) shownGroups.addAll(listOf("Tab Group 1", "Tab Group 2"))
        shownGroups.forEach { groupName ->
            card.addView(menuRow(R.drawable.ic_group, groupName) {
                dismissLater()
                if (groups.none { it.first == groupName }) { groups.add(groupName to mutableListOf()); saveTabGroups() }
                enterOverview(Mode.TABS, groupName)
            })
        }
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_chevron_left, "Close This Tab", destructive = true) {
            dismissLater()
            closeTab(current)
            if (tabs.isNotEmpty()) enterOverview(Mode.TABS) else exitOverview()
        })
        card.addView(menuRow(R.drawable.ic_chevron_left, "Close All ${tabs.size} tabs", destructive = true) {
            dismissLater(); closeAllTabs()
        })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_group, "New Tab Group") { dismissLater(); newGroupPrompt() })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_tabs, "${tabs.size} ${if (tabs.size == 1) "Tab" else "Tabs"}  ·  View All") {
            dismissLater(); enterOverview(Mode.TABS)
        })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { dismissLater(); exitOverview(); newTab(START_URL, true) })
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { dismissLater(); exitOverview(); newTab(START_URL) })
        showCard(card, Align.RIGHT)
    }

    private fun closeAllTabs() {
        for (i in tabs.indices.reversed()) {
            val t = tabs.removeAt(i)
            if (t.isPrivate) privateCount = (privateCount - 1).coerceAtLeast(0)
            try { t.web.destroy() } catch (e: Exception) {}
        }
        newTab(START_URL)
        enterOverview(Mode.TABS)
    }

    private fun showMoveToGroup() {
        val card = menuCard()
        val url = web.url ?: START_URL
        if (groups.isEmpty()) {
            card.addView(menuRow(R.drawable.ic_group, "No groups yet \u2014 create one") { dismissLater(); newGroupPrompt() })
        } else {
            groups.forEach { g ->
                card.addView(menuRow(R.drawable.ic_group, g.first) {
                    dismissLater()
                    if (!g.second.contains(url)) g.second.add(url)
                    saveTabGroups()
                    toast("Moved to " + g.first)
                })
            }
        }
        showCard(card, Align.RIGHT)
    }

    private fun newGroupPrompt() {
        val card = menuCard()
        val input = EditText(this).apply {
            hint = "Group name"
            setHintTextColor(0xFF877E74.toInt())
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 16.5f
            setSingleLine(true)
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = getDrawable(R.drawable.field_glass)
        }
        card.addView(input)
        card.addView(primaryButton("Create group", 0xFFE8622A.toInt()) {
            val name = input.text.toString().trim()
            if (name.isNotEmpty()) {
                val existing = groups.firstOrNull { it.first == name }
                val urls = existing?.second ?: mutableListOf<String>().also { groups.add(name to it) }
                val url = web.url
                if (url != null && !urls.contains(url)) urls.add(url)
                saveTabGroups()
                toast("Created " + name)
                dismissLater()
                enterOverview(Mode.TABS)
            } else {
                toast("Give the group a name")
            }
        })
        showCard(card, Align.RIGHT)
        input.requestFocus()
        input.postDelayed({
            try {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            } catch (e: Exception) {}
        }, 260)
    }

    private fun showTabs() {
        val card = menuCard()

        tabs.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(9), dp(9), dp(7), dp(9))
                isClickable = true
                setOnClickListener {
                    switchTo(i)
                    dismissLater()
                }
                pressable(this)
            }
            val dot = TextView(this).apply {
                text = if (i == current) "\u25CF" else "\u25CB"
                setTextColor(if (i == current) 0xFFE8622A.toInt() else 0x88FFFFFF.toInt())
                textSize = 12f
                setPadding(0, 0, dp(10), 0)
            }
            val label = TextView(this).apply {
                text = (if (t.isPrivate) "\u25D0  " else "") + t.title
                setTextColor(if (t.isPrivate) 0xFFCBA8FF.toInt() else 0xFFF6F0E8.toInt())
                textSize = 14.5f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val close = TextView(this).apply {
                text = "\u00d7"
                setTextColor(0x99FFFFFF.toInt())
                textSize = 18f
                setPadding(dp(10), 0, dp(6), 0)
                isClickable = true
                setOnClickListener {
                    // Compress the selected card before removing it, matching the pill's spring.
                    isEnabled = false
                    animate().alpha(0f).scaleX(0.94f).scaleY(0.94f)
                        .translationY(-dp(5).toFloat()).setDuration(190)
                        .setInterpolator(Motion.collapse)
                        .withEndAction { dismissLater(); closeTab(i) }.start()
                }
                pressable(this)
            }
            row.addView(dot); row.addView(label); row.addView(close)
            row.alpha = 0f
            row.translationY = dp(12).toFloat()
            row.scaleX = 0.97f
            row.scaleY = 0.97f
            card.addView(row)
            row.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay((i * 32L).coerceAtMost(192L))
                .setDuration(Motion.D_EXPAND).setInterpolator(Motion.spring).start()
        }

        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { dismissLater(); newTab(START_URL) })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { dismissLater(); newTab(START_URL, true) })
        showCard(card, Align.LEFT)
    }

    private fun showBookmarks() {
        val favs = (prefs().getString("list_favs", "") ?: "").split("\n").filter { it.isNotBlank() }
        val marks = (prefs().getString("list_bookmarks", "") ?: "").split("\n").filter { it.isNotBlank() }
        val card = menuCard()
        if (favs.isEmpty() && marks.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Nothing saved yet. Long-press \u22EF and choose Add to Favourites."
                setTextColor(0xFF877E74.toInt())
                textSize = 13.5f
                setPadding(dp(14), dp(16), dp(14), dp(16))
            }
            card.addView(empty)
            showCard(card, Align.RIGHT)
            return
        }
        favs.forEach { url -> card.addView(linkRow("\u2605", url)) }
        marks.forEach { url -> card.addView(linkRow("\u25C6", url)) }
        showCard(card, Align.RIGHT)
    }

    private fun linkRow(mark: String, url: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(9), dp(9), dp(8), dp(9))
            isClickable = true
            setOnClickListener { dismissLater(); newTab(url) }
            pressable(this)
        }
        row.addView(TextView(this).apply {
            text = mark
            setTextColor(0xFFE8622A.toInt())
            textSize = 13f
            setPadding(0, 0, dp(12), 0)
        })
        row.addView(TextView(this).apply {
            text = prettyUrl(url)
            setTextColor(0xFFF6F0E8.toInt())
            textSize = 14.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        return row
    }

    private fun showSmartSearch() {
        val card = menuCard()
        card.addView(titleBlock("Smart search",
            "When on, a query that names a site opens that site's own search \u2014 " +
            "\u201cprice of oneplus nord ce6 on Flipkart\u201d lands on Flipkart's results. " +
            "When off, everything goes to Brave exactly as typed."))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), 0, dp(10), dp(10))
        }
        row.addView(primaryButton("Turn on", 0xFFE8622A.toInt()) {
            prefs().edit().putBoolean("smart_search", true).apply()
            js("window.ulaaSmartSet && window.ulaaSmartSet(true)")
            toast("Smart search on")
            dismissLater()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(primaryButton("Turn off", 0xFF3A332D.toInt()) {
            prefs().edit().putBoolean("smart_search", false).apply()
            js("window.ulaaSmartSet && window.ulaaSmartSet(false)")
            toast("Smart search off")
            dismissLater()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(row)
        showCard(card, Align.RIGHT)
    }

    // ---------------------------------------------------------------- menu pieces

    private fun twoUpRow(): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(bigTile(R.drawable.ic_bookmarks, "Bookmarks") { dismissLater(); enterOverview(Mode.BOOKMARKS) }, weight())
        row.addView(bigTile(R.drawable.ic_tabs, "All Tabs") { dismissLater(); enterOverview(Mode.TABS) }, weight())
        return row
    }

    private fun weight() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    private fun bigTile(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(10), 0, dp(12))
            isClickable = true
            setOnClickListener { onClick() }
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFEDE7E0.toInt())
            textSize = 11.5f
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun dirTile(icon: Int, label: String, enabled: Boolean, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            isClickable = true
            alpha = if (enabled) 1f else 0.35f
            setOnClickListener { onClick() }
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFEDE7E0.toInt())
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun segment(label: String, active: Boolean, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.gravity = android.view.Gravity.CENTER
        tv.textSize = 13f
        tv.setPadding(0, dp(9), 0, dp(9))
        tv.setTextColor(if (active) 0xFFF6F0E8.toInt() else 0x99FFFFFF.toInt())
        if (active) {
            tv.background = GradientDrawable().apply {
                cornerRadius = dp(999).toFloat(); setColor(0x33FFFFFF)
            }
        }
        tv.isClickable = true
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---- motion: the app should feel like the pill, not like a settings screen ----

    /** press feedback: squash on touch down, spring back on release */
    private fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.92f).scaleY(0.92f)
                        .setDuration(90).setInterpolator(null).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f)
                        .setDuration(240).setInterpolator(Motion.spring).start()
            }
            false
        }
    }

    /** the toolbar rises into place on launch */
    private fun enterToolbar() {
        val bar = findViewById<View>(R.id.toolbar)
        bar.translationY = dp(56).toFloat()
        bar.alpha = 0f
        bar.animate().translationY(0f).alpha(1f)
            .setStartDelay(120).setDuration(Motion.D_EXPAND)
            .setInterpolator(Motion.spring).start()
    }

    /** the left circle does one thing at a time: back, or forward, whichever you picked */
    private var navForward = false

    private enum class Mode { BROWSING, TABS, BOOKMARKS, MANAGE_GROUPS }

    private var mode = Mode.BROWSING
    private var filterGroup: String? = null

    /** tab groups: a name and the pages that belong to it */
    private val groups = ArrayList<Pair<String, MutableList<String>>>()

    /** scrolling down tucks the toolbar to its minimum, scrolling up brings it back */
    private fun watchScroll(w: WebView) {
        w.setOnScrollChangeListener { _, _, y, _, oldY ->
            val dy = y - oldY
            if (dy > 12) minimiseBar(true) else if (dy < -12) minimiseBar(false)
            // Do not capture and blur the whole page while the user is scrolling.
            // The page-backed frost is refreshed after navigation settles instead.
        }
    }

    private var barHidden = false

    /** scrolling down shrinks the pill to its essentials; scrolling up brings it back */
    private fun minimiseBar(min: Boolean) {
        if (barHidden == min) return
        barHidden = min
        val bar = findViewById<ViewGroup>(R.id.toolbar)

        val t = android.transition.AutoTransition()
        t.duration = if (min) Motion.D_COLLAPSE else Motion.D_EXPAND
        t.interpolator = if (min) Motion.ease
                         else Motion.spring
        try { android.transition.TransitionManager.beginDelayedTransition(bar, t) } catch (e: Exception) {}

        findViewById<View>(R.id.reader).visibility = if (min) View.GONE else View.VISIBLE
        findViewById<View>(R.id.reload).visibility = if (min) View.GONE else View.VISIBLE

        try {
            val pill = findViewById<View>(R.id.pill)
            val lp = pill.layoutParams as LinearLayout.LayoutParams
            if (min) { lp.weight = 0f; lp.width = dp(132) } else { lp.weight = 1f; lp.width = 0 }
            pill.layoutParams = lp
        } catch (e: Exception) {}

        toolbarJs("window.ulaaBig && window.ulaaBig(" + !min + ")")
        // the side pills go away entirely when minimised, the way the spark drops them
        listOf(R.id.back, R.id.settings).forEach { id ->
            findViewById<View>(id).visibility = if (min) View.GONE else View.VISIBLE
        }

        // the address never truncates: it shrinks a little and fades out at both edges,
        // staying scrollable sideways
        try {
            urlView.textSize = if (min) 11.5f else 14f
            urlView.maxWidth = Int.MAX_VALUE
            urlView.ellipsize = null
            urlView.isSingleLine = true
            val scroll = findViewById<View>(R.id.urlScroll) as android.widget.HorizontalScrollView
            scroll.isHorizontalFadingEdgeEnabled = true
            scroll.isFillViewport = true
            scroll.scrollTo(0, 0)
        } catch (e: Exception) {}

        // motion blur across the move, plus a slight dim, exactly like the collapse on the web
        val pill = findViewById<View>(R.id.pill)
        pill.alpha = if (min) 0.88f else 1f
        pill.animate().alpha(1f).setDuration(if (min) Motion.D_COLLAPSE else Motion.D_EXPAND).start()
        motionBlur(pill, if (min) Motion.D_COLLAPSE else Motion.D_EXPAND)

        if (!min) {
            pill.animate().scaleX(1.04f).scaleY(1.04f).setDuration(140)
                .withEndAction {
                    pill.animate().scaleX(1f).scaleY(1f).setDuration(340)
                        .setInterpolator(Motion.spring).start()
                }.start()
            scheduleFrost()
        }
    }

    /**
     * The spark blurs its own text while the pill collapses. Android can do the same on 12+ with
     * a RenderEffect: ramp the blur up and back down across the animation, then clear it.
     */
    private fun motionBlur(view: View, duration: Long) {
        if (android.os.Build.VERSION.SDK_INT < 31) return
        try {
            val anim = android.animation.ValueAnimator.ofFloat(0f, 1f)
            anim.duration = duration
            anim.interpolator = Motion.collapse
            anim.addUpdateListener { va ->
                val t = (va.animatedValue as Float) * Math.PI
                val r = (Math.sin(t).toFloat().coerceAtLeast(0f)) * 6f
                try {
                    view.setRenderEffect(
                        android.graphics.RenderEffect.createBlurEffect(
                            r.coerceAtLeast(0.01f), r.coerceAtLeast(0.01f),
                            android.graphics.Shader.TileMode.CLAMP))
                } catch (e: Exception) {}
            }
            anim.addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    try { view.setRenderEffect(null) } catch (e: Exception) {}
                }
            })
            anim.start()
        } catch (e: Exception) {}
    }

    private fun hideBar() = minimiseBar(true)
    private fun showBar() = minimiseBar(false)

    /** sheets rise from the bottom with a spring, the way the pill's menus do */
    private fun animateSheetIn(card: View) {
        card.alpha = 0f
        card.translationY = dp(22).toFloat()
        card.scaleX = 0.94f
        card.scaleY = 0.94f
        card.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(360).setInterpolator(Motion.ease).start()
    }

    /** rows fade up one after another */
    private fun staggerRows(card: LinearLayout) {
        for (i in 0 until card.childCount) {
            val child = card.getChildAt(i)
            child.alpha = 0f
            child.translationY = dp(10).toFloat()
            child.animate().alpha(1f).translationY(0f)
                .setStartDelay((60L + i * 34L))
                .setDuration(260)
                .setInterpolator(Motion.ease).start()
        }
    }

    private fun menuCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(6), dp(6), dp(6), dp(6))
        background = getDrawable(R.drawable.sheet_glass)
        clipToOutline = false
    }

    private fun menuDivider(): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).also { it.setMargins(dp(49), dp(6), dp(14), dp(6)) }
        setBackgroundColor(0x24FFFFFF)
    }

    private fun menuRow(
        icon: Int,
        label: String,
        chevron: Boolean = false,
        destructive: Boolean = false,
        onClick: () -> Unit
    ): LinearLayout {
        val tint = if (destructive) 0xFFFF3B30.toInt() else 0xFFF6F0E8.toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            minimumHeight = dp(38)
            isClickable = true
            setOnClickListener { onClick() }
        }
        row.addView(ImageView(this).apply {
            setImageResource(icon)
            if (destructive) setColorFilter(0xFFFF3B30.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(18))
        })
        row.addView(TextView(this).apply {
            text = label
            setTextColor(tint)
            textSize = 14f
            setPadding(dp(13), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        if (chevron) {
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_chevron_right)
                alpha = 0.45f
                layoutParams = LinearLayout.LayoutParams(dp(15), dp(15))
            })
        }
        // press highlight, the way iOS dims a row under the finger
        row.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.setBackgroundResource(R.drawable.row_press)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.background = null
            }
            false
        }
        return row
    }

    private var lastDialog: Dialog? = null

    enum class Align { LEFT, RIGHT, FULL, TOP_LEFT }

    private fun showCard(card: LinearLayout, align: Align = Align.RIGHT, blurBehind: Boolean = true) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val wrap = FrameLayout(this)
        val sidePad = dp(12)
        // Compact popup anchored above the toolbar, leaving the page visible.
        if (align == Align.TOP_LEFT) wrap.setPadding(sidePad, dp(64), sidePad, dp(10))
        else wrap.setPadding(sidePad, dp(10), sidePad, dp(76))

        val screen = resources.displayMetrics.widthPixels
        // Measure the actual menu content so the sheet fits its longest option,
        // with a small breathing margin, instead of clipping long labels at 204dp.
        card.measure(
            View.MeasureSpec.makeMeasureSpec(screen - dp(32), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val contentWidth = card.measuredWidth + dp(14)
        val narrow = Math.min(contentWidth.coerceAtLeast(dp(204)), screen - dp(32))
        val scroller = object : android.widget.ScrollView(this) {
            private val maxPanelHeight = dp(7 * 42 + 28)
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(widthMeasureSpec,
                    View.MeasureSpec.makeMeasureSpec(maxPanelHeight, View.MeasureSpec.AT_MOST))
            }
        }.apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = false
            isVerticalFadingEdgeEnabled = true
            setFadingEdgeLength(dp(14))
            clipToOutline = true
        }
        scroller.addView(card, android.view.ViewGroup.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT))
        val cardParams = FrameLayout.LayoutParams(
            if (align == Align.FULL) FrameLayout.LayoutParams.MATCH_PARENT else narrow,
            FrameLayout.LayoutParams.WRAP_CONTENT)
        cardParams.gravity = when (align) {
            Align.LEFT -> android.view.Gravity.START or android.view.Gravity.BOTTOM
            Align.RIGHT -> android.view.Gravity.END or android.view.Gravity.BOTTOM
            Align.FULL -> android.view.Gravity.CENTER_HORIZONTAL or android.view.Gravity.BOTTOM
            Align.TOP_LEFT -> android.view.Gravity.TOP or android.view.Gravity.START
        }
        wrap.addView(scroller, cardParams)
        dialog.setContentView(wrap)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            if (blurBehind) {
                addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                setDimAmount(0.22f)
            } else {
                clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                setDimAmount(0f)
            }
            if (blurBehind && android.os.Build.VERSION.SDK_INT >= 31) {
                try {
                    addFlags(android.view.WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                    attributes = attributes.apply { blurBehindRadius = dp(18) }
                } catch (_: Exception) {}
            }
            val lp = attributes
            lp.width = android.view.WindowManager.LayoutParams.MATCH_PARENT
            lp.height = android.view.WindowManager.LayoutParams.MATCH_PARENT
            lp.gravity = android.view.Gravity.BOTTOM
            attributes = lp
        }
        // Ignore the release that opened a long-press menu.
        dialog.setCanceledOnTouchOutside(false)
        lastDialog = dialog
        dialog.setOnShowListener {
            animateSheetIn(card)
            staggerRows(card)
            Handler(Looper.getMainLooper()).postDelayed({
                try { dialog.setCanceledOnTouchOutside(true) } catch (e: Exception) {}
            }, 380)
        }
        dialog.show()
    }

    private fun dismissLater() {
        val d = lastDialog
        lastDialog = null
        try { d?.dismiss() } catch (e: Exception) {}
    }

    // ---------------------------------------------------------------- misc

    private fun isNavigationVerb(q: String): Boolean =
        Regex("^(open|go to|goto|visit|launch)\\b", RegexOption.IGNORE_CASE).containsMatchIn(q.trim())

    private fun isQuestion(q: String): Boolean {
        val t = q.trim().lowercase()
        return t.endsWith("?") || Regex("^(what|who|why|how|is|are|when|where|which|can|does|do)\\b").containsMatchIn(t)
    }

    private fun addToList(key: String) {
        val url = web.url ?: return
        val all = (prefs().getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
        if (!all.contains(url)) all.add(0, url)
        prefs().edit().putString(key, all.joinToString("\n")).apply()
        toast("Saved")
    }

    private fun shareCurrent() {
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, web.url ?: "")
        }
        startActivity(android.content.Intent.createChooser(intent, "Share"))
    }

    private fun prefs(): SharedPreferences = getSharedPreferences("valley", MODE_PRIVATE)

    private fun readHistoryArray(key: String): org.json.JSONArray {
        return try { org.json.JSONArray(prefs().getString(key, "[]") ?: "[]") }
        catch (_: Exception) { org.json.JSONArray() }
    }

    private fun recordSearchQuery(query: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val old = readHistoryArray("history_searches")
        val next = org.json.JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (!item.optString("q").equals(q, ignoreCase = true)) next.put(item)
        }
        next.put(org.json.JSONObject().put("q", q).put("t", System.currentTimeMillis()))
        val capped = org.json.JSONArray()
        for (i in 0 until minOf(next.length(), 200)) capped.put(next.get(i))
        prefs().edit().putString("history_searches", capped.toString()).apply()
    }

    private fun removeSearchQuery(query: String) {
        val old = readHistoryArray("history_searches")
        val next = org.json.JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (!item.optString("q").equals(query, ignoreCase = true)) next.put(item)
        }
        prefs().edit().putString("history_searches", next.toString()).apply()
    }

    private fun removeOpenedPage(rawUrl: String) {
        val target = canonicalSavedUrl(rawUrl)
        val old = readHistoryArray("history_opened")
        val next = org.json.JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (canonicalSavedUrl(item.optString("u")) != target) next.put(item)
        }
        prefs().edit().putString("history_opened", next.toString()).apply()
    }

    private fun recordOpenedPage(rawUrl: String, title: String?) {
        val url = rawUrl.trim()
        if (url.isBlank() || url.startsWith("about:") || url.startsWith("data:") ||
            url.contains("appassets.androidplatform.net/assets/index.html")) return
        val old = readHistoryArray("history_opened")
        val next = org.json.JSONArray()
        val canonical = canonicalSavedUrl(url)
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (canonicalSavedUrl(item.optString("u")) != canonical) next.put(item)
        }
        next.put(org.json.JSONObject()
            .put("u", url)
            .put("n", title?.takeIf { it.isNotBlank() } ?: prettyUrl(url))
            .put("t", System.currentTimeMillis()))
        val capped = org.json.JSONArray()
        for (i in 0 until minOf(next.length(), 200)) capped.put(next.get(i))
        prefs().edit().putString("history_opened", capped.toString()).apply()
    }

    private fun syncHistoryWithHomepage() {
        val searches = readHistoryArray("history_searches")
        val opened = readHistoryArray("history_opened")
        val searchJson = searches.toString()
        val openedJson = opened.toString()
        val code = "(function(){try{" +
            "function merge(a,b,key){var map={};(a||[]).concat(b||[]).forEach(function(x){if(!x)return;var k=key(x);if(!k)return;if(!map[k]||(x.t||0)>(map[k].t||0))map[k]=x;});var out=Object.keys(map).map(function(k){return map[k];});out.sort(function(x,y){return (y.t||0)-(x.t||0);});return out.slice(0,200);}" +
            "var s=JSON.parse(localStorage.getItem('hp.searches')||'[]');var ns=" + searchJson + ";" +
            "s=merge(s,ns,function(x){return String((typeof x==='string'?x:(x.q||'')).toLowerCase());});localStorage.setItem('hp.searches',JSON.stringify(s));" +
            "var o=JSON.parse(localStorage.getItem('hp.opened')||'[]');var no=" + openedJson + ";" +
            "o=merge(o,no,function(x){return String(x.u||'').replace(/#.*$/,'').replace(new RegExp('/$'),'');});localStorage.setItem('hp.opened',JSON.stringify(o));" +
            "if(window.ulaaRefresh)window.ulaaRefresh();return true;}catch(e){return false;}})()"
        web.evaluateJavascript(code, null)
    }

    private fun canonicalSavedUrl(raw: String): String {
        return try {
            val uri = android.net.Uri.parse(raw.trim())
            val scheme = (uri.scheme ?: "https").lowercase()
            val host = (uri.host ?: "").lowercase().removePrefix("www.")
            val port = uri.port
            val defaultPort = (scheme == "https" && port == 443) || (scheme == "http" && port == 80)
            val path = (uri.encodedPath ?: "").let { p ->
                if (p.isBlank() || p == "/") "" else p.trimEnd('/')
            }
            buildString {
                append(scheme).append("://").append(host)
                if (port >= 0 && !defaultPort) append(":").append(port)
                append(path)
                if (!uri.encodedQuery.isNullOrBlank()) append("?").append(uri.encodedQuery)
            }
        } catch (_: Exception) { raw.trim().substringBefore('#').trimEnd('/') }
    }

    private fun saveLink(bucket: String) {
        val url = web.url?.trim()?.takeIf { it.isNotBlank() } ?: return
        val favKey = "list_favs"
        val bookmarkKey = "list_bookmarks"
        val currentFavs = (prefs().getString(favKey, "") ?: "").split("\n").filter { it.isNotBlank() }
        val currentBookmarks = (prefs().getString(bookmarkKey, "") ?: "").split("\n").filter { it.isNotBlank() }
        val canonical = canonicalSavedUrl(url)
        if ((currentFavs + currentBookmarks).any { canonicalSavedUrl(it) == canonical }) {
            toast(if (currentFavs.any { canonicalSavedUrl(it) == canonical }) "Already in Favourites" else "Already bookmarked")
            return
        }
        val key = "list_$bucket"
        val all = (prefs().getString(key, "") ?: "").split("\n")
            .filter { it.isNotBlank() }
            .distinctBy { canonicalSavedUrl(it) }
            .toMutableList()
        all.add(0, url)
        prefs().edit().putString(key, all.joinToString("\n")).apply()
        toast(if (bucket == "favs") "Added to Favourites" else "Added to Bookmarks")
    }

    private fun translatePage() {
        val target = active.web
        val code = "(function(){try{" +
            "if(window.ulaaTranslate && window.ulaaTranslate())return true;" +
            "var sels=['[title=\"Translate page\"]','[title=\"Show original\"]','[aria-label*=\"Translate\" i]'];" +
            "for(var i=0;i<sels.length;i++){var e=document.querySelector(sels[i]);if(e){e.click();return true;}}" +
            "return false;}catch(e){return false;}})()"
        target.evaluateJavascript(code) { result ->
            if (result != "true") runOnUiThread { toast("Translation is unavailable on this page.") }
        }
    }

    private fun js(code: String) {
        try { web.evaluateJavascript(code, null) } catch (e: Exception) {}
    }

    /**
     * The app saves bookmarks in Android storage; the homepage keeps its own list in the page's
     * localStorage. On the start page the two are merged, so everything you saved shows up in
     * Favourites there, and anything you delete there comes back to the app.
     */
    private fun syncWithHomepage() {
        val favs = (prefs().getString("list_favs", "") ?: "").split("\n").filter { it.isNotBlank() }
        val marks = (prefs().getString("list_bookmarks", "") ?: "").split("\n").filter { it.isNotBlank() }
        val all = (favs + marks).distinct()
        if (all.isEmpty()) {
            web.evaluateJavascript("window.ulaaRefresh && window.ulaaRefresh()", null)
            return
        }
        val arr = org.json.JSONArray(all).toString()
        val code = "(function(){try{" +
                "var add=" + arr + ";" +
                "var cur=[];try{cur=JSON.parse(localStorage.getItem('hp.favs')||'[]');}catch(e){cur=[];}" +
                "function canon(u){try{var a=new URL(u);a.hash='';a.hostname=a.hostname.toLowerCase().replace(/^www\\./,'');if((a.protocol==='https:'&&a.port==='443')||(a.protocol==='http:'&&a.port==='80'))a.port='';a.pathname=a.pathname==='/'?'':a.pathname.replace(/\\/$/,'');return a.protocol+'//'+a.host+a.pathname+a.search;}catch(e){return String(u||'').split('#')[0].replace(/\\/$/,'');}}" +
                "var have={};cur.forEach(function(x){if(x&&x.u){var k=canon(x.u);if(!have[k])have[k]=1;else x.__duplicate=1;}});cur=cur.filter(function(x){return x&&!x.__duplicate;});" +
                "add.forEach(function(u){var k=canon(u);if(!have[k]){cur.push({u:u,n:''});have[k]=1;}});" +
                "localStorage.setItem('hp.favs',JSON.stringify(cur));" +
                "return cur.map(function(x){return (x&&x.u)||'';}).filter(Boolean).join('\\n');" +
                "}catch(e){return '';}})()"

        web.evaluateJavascript(code) { res ->
            try {
                val merged = org.json.JSONTokener(res).nextValue() as? String
                if (!merged.isNullOrBlank()) {
                    // the page is now the single list: everything is a favourite there
                    prefs().edit()
                        .putString("list_favs", merged)
                        .putString("list_bookmarks", "")
                        .apply()
                }
            } catch (e: Exception) {}
            web.evaluateJavascript("window.ulaaRefresh && window.ulaaRefresh()", null)
        }
    }

    private fun injectSpark(view: WebView, url: String?) {
        val code = sparkJs ?: return
        if (url == null || url.contains(HOST)) return
        try {
            view.evaluateJavascript(code) {
                try { view.evaluateJavascript("window.ulaaHidePill && window.ulaaHidePill()", null) } catch (e: Exception) {}
            }
        } catch (e: Exception) {}
    }

    private fun readAsset(name: String): String? = try {
        assets.open(name).bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        null
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (this::container.isInitialized && tabs.isNotEmpty() && web.canGoBack()) web.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        for (t in tabs) { try { t.web.destroy() } catch (e: Exception) {} }
        tabs.clear()
        super.onDestroy()
    }
}
