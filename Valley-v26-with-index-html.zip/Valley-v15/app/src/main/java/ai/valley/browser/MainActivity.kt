package ai.valley.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.SharedPreferences
import android.content.Intent
import android.speech.RecognizerIntent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.Bitmap
import android.graphics.Outline
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.net.Uri
import android.webkit.JsResult
import android.webkit.JsPromptResult
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.HorizontalScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import java.io.ByteArrayInputStream
import java.net.URLEncoder
import android.webkit.URLUtil
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private inner class Tab(val web: WebView) {
        /** stable id: names this tab's saved preview picture and site icon on disk */
        var id: String = java.util.UUID.randomUUID().toString().replace("-", "")
        /** last picture of the page, sized for the tabs-page card */
        var thumb: Bitmap? = null
        /** the website's icon, when known */
        var icon: Bitmap? = null
        var iconLoaded = false
        var iconHost: String? = null
        var title: String = "New Tab"
        var isPrivate: Boolean = false
        var isPinned: Boolean = false
        var desktopMode: Boolean = false
        var groupName: String? = null
        /** set for a restored tab that has not been loaded yet; it loads the first time the tab is shown */
        var pendingUrl: String? = null
        /** the tab's address, even before a restored tab has loaded */
        val url: String? get() = pendingUrl ?: web.url
    }

    private val pal by lazy { Pal(this) }
    private lateinit var container: FrameLayout
    private lateinit var urlView: TextView
    private lateinit var glow: PillGlowView
    private lateinit var assetLoader: WebViewAssetLoader
    private var sparkJs: String? = null
    private var pageCleanupJs: String? = null
    private var readerJs: String? = null
    private val downloadManager by lazy { getSystemService(DOWNLOAD_SERVICE) as DownloadManager }
    private var downloadToast: View? = null
    private val downloadToastHide = Runnable { hideDownloadStatus() }
    private var downloadReceiverRegistered = false
    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id < 0) return
            val rec = syncDownloadRecords().firstOrNull { it.optLong("id") == id } ?: return
            val title = rec.optString("title", "file")
            when (rec.optString("status")) {
                "Downloaded" -> showDownloadStatus("Downloaded", title, DownloadStatusKind.DONE, id)
                "Failed" -> showDownloadStatus("Download failed", title, DownloadStatusKind.FAILED, id)
            }
            refreshDownloadsPage()
        }
    }

    private val tabs = ArrayList<Tab>()
    private val selectedTabs = linkedSetOf<Tab>()
    private var selectingTabs = false
    private var editingTabGroups = false
    private var overviewActiveCard: View? = null
    private var current = 0
    private var privateCount = 0
    private val privacyBlockedCount = java.util.concurrent.atomic.AtomicInteger(0)

    // protection is always on - there is nothing to switch off

    /** hosts that serve ads and trackers; a request to one of these is answered with nothing */
    private val blocked: HashSet<String> by lazy {
        RAW_BLOCKLIST.trim().lines().map { it.trim() }.filter { it.isNotEmpty() }.toHashSet()
    }
    private val active: Tab get() = tabs[current]
    private val web: WebView get() = active.web

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val START_URL = "https://$HOST/assets/index.html"

        private val RAW_BLOCKLIST = """
            doubleclick.net
            googlesyndication.com
            googleadservices.com
            google-analytics.com
            googletagmanager.com
            googletagservices.com
            adservice.google.com
            pagead2.googlesyndication.com
            facebook.net
            connect.facebook.net
            scorecardresearch.com
            quantserve.com
            quantcount.com
            moatads.com
            adsafeprotected.com
            adnxs.com
            adsrvr.org
            rubiconproject.com
            pubmatic.com
            casalemedia.com
            openx.net
            appnexus.com
            criteo.com
            criteo.net
            taboola.com
            outbrain.com
            revcontent.com
            mgid.com
            zergnet.com
            popads.net
            propellerads.com
            adcash.com
            exoclick.com
            juicyads.com
            trafficjunky.net
            media.net
            smartadserver.com
            teads.tv
            spotxchange.com
            tremorhub.com
            amazon-adsystem.com
            ads.yahoo.com
            adtech.de
            adform.net
            serving-sys.com
            flashtalking.com
            mathtag.com
            turn.com
            tapad.com
            bidswitch.net
            sharethrough.com
            triplelift.com
            indexexchange.com
            sovrn.com
            gumgum.com
            districtm.io
            yieldmo.com
            sonobi.com
            lijit.com
            krxd.net
            bluekai.com
            demdex.net
            omtrdc.net
            2o7.net
            everesttech.net
            adsymptotic.com
            agkn.com
            rlcdn.com
            tapfiliate.com
            branch.io
            appsflyer.com
            adjust.com
            kochava.com
            amplitude.com
            mixpanel.com
            segment.com
            segment.io
            heap.io
            hotjar.com
            hotjar.io
            fullstory.com
            clarity.ms
            inspectlet.com
            mouseflow.com
            smartlook.com
            luckyorange.com
            crazyegg.com
            optimizely.com
            vwo.com
            newrelic.com
            nr-data.net
            bugsnag.com
            rollbar.com
            sentry.io
            loggly.com
            chartbeat.com
            chartbeat.net
            parsely.com
            nr-data.net
            clicktale.net
            userreport.com
            mc.yandex.ru
            top-fwz1.mail.ru
            hb.wrating.com
            ctnsnet.com
            creativecdn.com
            adroll.com
            perfectaudience.com
            rebound.net
            retargeter.com
            steelhousemedia.com
            simpli.fi
            audienceproject.com
            narrative.io
            permutive.com
            id5-sync.com
            liadm.com
            pippio.com
            ads.linkedin.com
            analytics.tiktok.com
            business-api.tiktok.com
            ads.tiktok.com
            analytics.twitter.com
            static.ads-twitter.com
            ads.pinterest.com
            ads.reddit.com
            ads.snapchat.com
            sc-static.net
            tr.snapchat.com
        """
    }

    private fun isBlocked(host: String?): Boolean {
        if (host == null || !prefs().getBoolean("privacy_tracking_protection", true)) return false
        val h = host.lowercase().trimEnd('.')
        val exceptions = (prefs().getString("privacy_allowed_domains", "") ?: "")
            .split("\n").map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toHashSet()
        if (exceptions.any { h == it || h.endsWith(".$it") }) return false
        if (blocked.contains(h)) return true
        var i = h.indexOf('.')
        while (i != -1) {
            if (blocked.contains(h.substring(i + 1))) return true
            i = h.indexOf('.', i + 1)
        }
        return false
    }

    private fun noteBlockedRequest() {
        val count = privacyBlockedCount.incrementAndGet()
        if (count % 10 == 0) prefs().edit().putInt("privacy_blocked_count", count).apply()
    }

    private fun privacyDomain(): String? = try {
        val host = android.net.Uri.parse(web.url ?: "").host?.lowercase()?.removePrefix("www.")
        host?.takeIf { it.isNotBlank() && !it.contains(HOST) }
    } catch (_: Exception) { null }

    private fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        applySystemTheme()
        val filter = android.content.IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(downloadReceiver, filter)
        }
        downloadReceiverRegistered = true
        loadTabGroups()
        privacyBlockedCount.set(prefs().getInt("privacy_blocked_count", 0))

        container = findViewById(R.id.web_container)
        urlView = findViewById(R.id.url)
        glow = findViewById(R.id.glow)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        sparkJs = readAsset("spark.js")
        pageCleanupJs = readAsset("page_cleanup.js")
        readerJs = readAsset("reader.js")


        val navBtn = findViewById<ImageButton>(R.id.back)
        navBtn.setOnClickListener {
            if (mode != Mode.BROWSING) {
                exitOverview()
                newTab(START_URL)
                return@setOnClickListener
            }
            if (navForward) {
                if (web.canGoForward()) web.goForward() else toast("No page to go forward to")
            } else {
                if (web.canGoBack()) web.goBack() else toast("No page to go back to")
            }
        }
        navBtn.setOnLongClickListener { showBackForward(); true }

        findViewById<ImageButton>(R.id.reload).setOnClickListener { reloadActivePage() }
        urlView.setOnClickListener { editUrl() }
        findViewById<View>(R.id.urlScroll).setOnClickListener { editUrl() }
        try {
            (findViewById<View>(R.id.urlScroll) as android.widget.HorizontalScrollView)
                .isHorizontalFadingEdgeEnabled = true
        } catch (e: Exception) {}
        findViewById<ImageButton>(R.id.reader).setOnClickListener { toggleReader() }

        val settingsBtn = findViewById<ImageButton>(R.id.settings)
        settingsBtn.setOnClickListener {
            if (mode != Mode.BROWSING) showTabActions() else showPageMenu()
        }
        settingsBtn.setOnLongClickListener {
            if (mode != Mode.BROWSING) showTabActions() else showPageMenu()
            true
        }
        // The HTML toolbar pill owns the long-press for special page tools.

        listOf(R.id.back, R.id.reader, R.id.reload, R.id.settings).forEach { id ->
            pressable(findViewById(id))
        }
        pressable(findViewById(R.id.pill))

        // clip the frost layer to the pill's rounded shape
        val pillView = findViewById<View>(R.id.pill)
        pillView.clipToOutline = true
        pillView.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.height / 2f)
            }
        }
        setUpToolbarWeb()
        findViewById<View>(R.id.toolbar).visibility = View.GONE

        val incomingUrl = webUrlFromIntent(intent)
        if (incomingUrl != null) {
            newTab(incomingUrl)
        } else if (!restoreTabs()) {
            newTab(START_URL)
        }
    }

    /**
     * Accepts only ordinary HTTP(S) links from Android intents.
     * This prevents unrelated intents from being treated as browser navigation.
     */
    private fun webUrlFromIntent(source: Intent?): String? {
        if (source?.action != Intent.ACTION_VIEW) return null
        val uri = source.data ?: return null
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return null
        return uri.toString()
    }

    // ---------------------------------------------------------------- light / dark

    /** Colours the window, system bars and root to match the phone's light or dark setting. */
    private fun applySystemTheme() {
        val dark = pal.dark
        try {
            window.statusBarColor = pal.bg
            window.navigationBarColor = pal.bg
            findViewById<View>(R.id.root).setBackgroundColor(pal.bg)
            findViewById<View>(R.id.overview).setBackgroundResource(R.drawable.overview_bg)
            var flags = window.decorView.systemUiVisibility
            val lightStatus = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            val lightNav = if (android.os.Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0
            flags = if (dark) flags and (lightStatus or lightNav).inv() else flags or lightStatus or lightNav
            window.decorView.systemUiVisibility = flags
        } catch (_: Exception) {}
    }

    /** Tells the toolbar and every start page which theme is active. */
    private fun pushThemeToPages() {
        val dark = pal.dark
        toolbarJs("window.ulaaSetTheme && window.ulaaSetTheme($dark)")
        for (t in tabs) {
            if (isStartUrl(t.web.url)) {
                try { t.web.evaluateJavascript("window.ulaaSetTheme && window.ulaaSetTheme($dark)", null) } catch (_: Exception) {}
            }
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applySystemTheme()
        pushThemeToPages()
        // screens built from code take their colours when they are built, so rebuild the open one
        if (mode != Mode.BROWSING) enterOverview(mode, filterGroup)
        else try { urlView.setTextColor(if (active.isPrivate) pal.priv else pal.ink) } catch (_: Exception) {}
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent == null) return
        setIntent(intent)
        val incomingUrl = webUrlFromIntent(intent) ?: return
        if (this::container.isInitialized) {
            newTab(incomingUrl)
        }
    }

    // ---------------------------------------------------------------- tab restore

    private fun isRestorableUrl(url: String?): Boolean =
        !url.isNullOrBlank() && (url.startsWith("https://") || url.startsWith("http://")) && !url.contains(HOST)

    /**
     * Saves the open tabs (never private ones) so the next launch can bring them back.
     * Only addresses, titles, pin state and group are stored. Page contents are not.
     */
    private fun saveTabs() {
        if (!this::container.isInitialized || tabs.isEmpty()) return
        try {
            val array = org.json.JSONArray()
            var activeSaved = false
            tabs.forEachIndexed { index, tab ->
                if (tab.isPrivate) return@forEachIndexed
                val url = tab.url
                if (!isRestorableUrl(url)) return@forEachIndexed
                val item = org.json.JSONObject().put("u", url).put("t", tab.title).put("p", tab.isPinned).put("i", tab.id)
                tab.groupName?.let { item.put("g", it) }
                if (index == current) { item.put("a", true); activeSaved = true }
                array.put(item)
            }
            val root = org.json.JSONObject().put("tabs", array).put("home", !activeSaved)
            prefs().edit().putString("valley_tabs_v1", root.toString()).apply()
            pruneTabImages(tabs.filter { !it.isPrivate }.map { it.id }.toSet())
        } catch (_: Exception) {}
    }

    /**
     * Brings back the tabs saved by saveTabs(). Only the active tab loads now; the rest load when opened.
     * If the tab you left on was the start page (or a private tab), you land on a fresh start page as before.
     * Returns false when there is nothing to restore, so the caller opens the usual start page.
     */
    private fun restoreTabs(): Boolean {
        val raw = prefs().getString("valley_tabs_v1", null) ?: return false
        try {
            val root = org.json.JSONObject(raw)
            val array = root.optJSONArray("tabs") ?: return false
            var activeIndex = -1
            for (i in 0 until minOf(array.length(), 20)) {
                val item = array.optJSONObject(i) ?: continue
                val url = item.optString("u")
                if (!isRestorableUrl(url)) continue
                val tab = Tab(buildWeb(false))
                tab.title = item.optString("t").ifBlank { prettyUrl(url) }
                item.optString("i").takeIf { it.length >= 8 }?.let { tab.id = it }
                tab.isPinned = item.optBoolean("p", false)
                val group = item.optString("g")
                // a tab only keeps its group if that group still exists; otherwise it would be hidden
                tab.groupName = groups.firstOrNull { it.first.equals(group, true) }?.first
                tab.pendingUrl = url
                tabs.add(tab)
                if (item.optBoolean("a", false)) activeIndex = tabs.size - 1
            }
            if (tabs.isEmpty()) return false
            if (root.optBoolean("home", false) || activeIndex < 0) {
                newTab(START_URL)
            } else {
                current = activeIndex
                attach()
            }
            return true
        } catch (_: Exception) {
            // Anything unexpected: drop the half-restored tabs and start clean.
            for (t in tabs) { try { t.web.destroy() } catch (_: Exception) {} }
            tabs.clear()
            current = 0
            return false
        }
    }

    override fun onPause() {
        super.onPause()
        // take a fresh picture of the page you are leaving so the tabs page still has it after a restart
        tabs.getOrNull(current)?.let { if (mode == Mode.BROWSING) captureThumb(it) }
        saveTabs()
        // Make sure cookies (your logins) reach disk before Android can end the app.
        try { CookieManager.getInstance().flush() } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- tabs

    // ---------------------------------------------------------------- tab pictures and site icons

    private fun tabImageDir(): java.io.File = java.io.File(filesDir, "tab_images").also { it.mkdirs() }

    /** size of the picture shown on a tabs-page card */
    private fun thumbSize(): Pair<Int, Int> {
        val w = (resources.displayMetrics.widthPixels - dp(52)) / 2
        val h = (w * 1.24f).toInt().coerceAtLeast(dp(190))
        return w to h
    }

    /** a page is drawable when it is attached, laid out and finished loading */
    private fun canDraw(t: Tab): Boolean =
        t.pendingUrl == null && t.web.parent != null && t.web.width > 0 && t.web.height > 0 && t.web.progress >= 100

    /** takes a picture of the tab's page, keeps it in memory and writes it to disk for the next launch */
    private fun captureThumb(t: Tab) {
        if (t.isPrivate || !canDraw(t) || isStartUrl(t.url)) return
        try {
            val (w, h) = thumbSize()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bmp)
            canvas.drawColor(pal.thumbBg)
            val scale = maxOf(w.toFloat() / t.web.width, h.toFloat() / t.web.height)
            canvas.translate((w - t.web.width * scale) / 2f, (h - t.web.height * scale) / 2f)
            canvas.scale(scale, scale)
            t.web.draw(canvas)
            t.thumb = bmp
            val file = java.io.File(tabImageDir(), t.id + ".jpg")
            Thread {
                try { java.io.FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) } } catch (_: Exception) {}
            }.start()
        } catch (_: Exception) {}
    }

    /** the picture to show for a tab: the live page when it is ready, otherwise the saved one */
    private fun thumbFor(t: Tab): Bitmap? {
        if (canDraw(t) && !isStartUrl(t.url)) captureThumb(t)
        t.thumb?.let { return it }
        if (t.isPrivate) return null
        val file = java.io.File(tabImageDir(), t.id + ".jpg")
        if (!file.exists()) return null
        return try { android.graphics.BitmapFactory.decodeFile(file.path)?.also { t.thumb = it } } catch (_: Exception) { null }
    }

    private fun setTabIcon(t: Tab, icon: Bitmap?) {
        if (icon == null || icon.width < 2 || icon.height < 2) return
        try {
            val size = dp(40)
            val scaled = Bitmap.createScaledBitmap(icon, size, size, true)
            t.icon = scaled
            t.iconLoaded = true
            t.iconHost = try { android.net.Uri.parse(t.url ?: "").host } catch (_: Exception) { null }
            if (t.isPrivate) return
            val file = java.io.File(tabImageDir(), t.id + "_icon.png")
            Thread {
                try { java.io.FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) } } catch (_: Exception) {}
            }.start()
        } catch (_: Exception) {}
    }

    private fun iconFor(t: Tab): Bitmap? {
        t.icon?.let { return it }
        if (t.isPrivate) return null
        val file = java.io.File(tabImageDir(), t.id + "_icon.png")
        if (!file.exists()) return null
        return try { android.graphics.BitmapFactory.decodeFile(file.path)?.also {
            t.icon = it; t.iconLoaded = true
            t.iconHost = try { android.net.Uri.parse(t.url ?: "").host } catch (_: Exception) { null }
        } } catch (_: Exception) { null }
    }

    /**
     * Some pages never hand the browser an icon. Ask the page which icon it declares and fetch it,
     * once per page load, in the background.
     */
    private fun fetchIconFromPage(view: WebView, t: Tab) {
        if (t.isPrivate || t.iconLoaded) return
        view.evaluateJavascript(
            "(function(){try{var l=document.querySelectorAll('link[rel~=\"icon\"],link[rel=\"apple-touch-icon\"]');" +
            "var best=null;for(var i=0;i<l.length;i++){if(l[i].href){best=l[i].href;if(/apple-touch/.test(l[i].rel))break;}}" +
            "return best||(location.origin+'/favicon.ico')}catch(e){return ''}})()"
        ) { raw ->
            val url = raw?.trim()?.trim('"')?.replace("\\/", "/") ?: return@evaluateJavascript
            if (!url.startsWith("https://") || url.contains(HOST)) return@evaluateJavascript
            Thread {
                try {
                    val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 4000; conn.readTimeout = 4000
                    conn.setRequestProperty("User-Agent", view.settings.userAgentString)
                    val bmp = conn.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
                    if (bmp != null) runOnUiThread { if (!t.iconLoaded) setTabIcon(t, bmp) }
                } catch (_: Exception) {}
            }.start()
        }
    }

    private fun pruneTabImages(keep: Set<String>) {
        try {
            tabImageDir().listFiles()?.forEach { f ->
                val id = f.name.substringBefore('.').removeSuffix("_icon")
                if (id !in keep) f.delete()
            }
        } catch (_: Exception) {}
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWeb(private: Boolean = false): WebView {
        val w = WebView(this)
        // let the system autofill service (Google, Bitwarden, ...) fill and offer to save logins
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            w.importantForAutofill = if (private) View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
                else View.IMPORTANT_FOR_AUTOFILL_YES
        }
        w.settings.apply {
            javaScriptEnabled = true
            // a private tab writes no site storage at all
            domStorageEnabled = !private
            databaseEnabled = !private
            // hardening: no local file access, no popups, no saved form data
            allowFileAccess = false
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            setBuiltInZoomControls(true)
            setDisplayZoomControls(false)
            setSupportZoom(true)
            saveFormData = false
            if (android.os.Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            // nothing is read from or written to the disk cache
            cacheMode = if (private) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            userAgentString = userAgentString.replace("; wv", "")
        }
        // Native WebView pinch zoom is enabled in WebSettings above.
        // The floating panel is shown from onScaleChanged, only after the page actually scales.

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            // third-party cookies are blocked per-WebView, so this really is per-tab
            // third-party cookies are blocked everywhere except where a site needs them
            setAcceptThirdPartyCookies(w, prefs().getBoolean("privacy_third_party_cookies", false))
        }

        // Registered once, before any page loads. Attaching these in onPageFinished meant the
        // already-loaded start page never saw them, so deletes on the History page only touched
        // the page's localStorage and the next native sync brought the items back.
        // Every method checks trustedHomeViews, so only the Valley start page can use them.
        if (!private) {
            w.addJavascriptInterface(HistoryBridge(w), "ValleyHistory")
            w.addJavascriptInterface(DownloadsBridge(w), "ValleyDownloads")
        }

        w.webViewClient = object : WebViewClientCompat() {
            override fun onReceivedSslError(view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
                handleSslError(view, handler, error)
            }

            override fun onReceivedHttpAuthRequest(view: WebView, handler: android.webkit.HttpAuthHandler, host: String?, realm: String?) {
                handleHttpAuth(handler, host, realm)
            }

            override fun onScaleChanged(view: WebView, oldScale: Float, newScale: Float) {
                super.onScaleChanged(view, oldScale, newScale)
                if (view == web && kotlin.math.abs(newScale - oldScale) > 0.001f) {
                    val percent = (newScale * 100f).toInt().coerceAtLeast(25)
                    toolbarJs("window.ulaaShowZoom && window.ulaaShowZoom($percent)")
                    view.removeCallbacks(hideZoomPanelRunnable)
                    view.postDelayed(hideZoomPanelRunnable, 2200)
                }
            }

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                assetLoader.shouldInterceptRequest(request.url)?.let { return it }
                // never block the page itself, only what it pulls in
                if (!request.isForMainFrame && isBlocked(request.url.host)) {
                    noteBlockedRequest()
                    return emptyResponse()
                }
                return null
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val u = request.url
                // HTTPS only: upgrade plain http, refuse it if the host has no https
                if (u.scheme == "http") {
                    val secure = u.toString().replaceFirst("http://", "https://")
                    view.loadUrl(secure)
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                // The bridges stay registered, but only the Valley start page may call them.
                val startTab = tabs.firstOrNull { it.web === view }
                if (startTab != null && url != null) {
                    val newHost = try { android.net.Uri.parse(url).host } catch (_: Exception) { null }
                    if (startTab.iconHost != null && startTab.iconHost != newHost) {
                        startTab.icon = null; startTab.iconLoaded = false; startTab.iconHost = null
                        try { java.io.File(tabImageDir(), startTab.id + "_icon.png").delete() } catch (_: Exception) {}
                    }
                }
                if (isStartUrl(url) && startTab?.isPrivate != true) trustedHomeViews.add(view)
                else trustedHomeViews.remove(view)
                if (view == web) setLoading(true)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                val tab = tabs.firstOrNull { it.web === view }
                if (url != null && tab != null && (tab.title == "New Tab" || tab.title.isBlank())) {
                    tab.title = prettyUrl(url)
                }
                if (tab != null && url != null && !isStartUrl(url) && !tab.iconLoaded) {
                    view.postDelayed({ if (!tab.iconLoaded) fetchIconFromPage(view, tab) }, 1500)
                }
                if (url != null && tab != null && !tab.isPrivate) {
                    recordOpenedPage(url, view.title?.takeIf { it.isNotBlank() } ?: tab.title)
                }
                if (url != null && url.contains(HOST) && url.contains("index.html")) {
                    view.isLongClickable = false
                    view.setOnLongClickListener { true }
                } else {
                    view.isLongClickable = true
                    view.setOnLongClickListener(null)
                }
                if (view == web) {
                    setLoading(false)
                    if (url != null) {
                        showAddress(url)
                        if (url.contains("translate.goog") || url.contains("translate.google.")) {
                            view.evaluateJavascript("(function(){try{var s=document.getElementById('valley-hide-translate-ui');if(!s){s=document.createElement('style');s.id='valley-hide-translate-ui';s.textContent='.goog-te-banner-frame,#goog-gt-tt,.goog-te-balloon-frame,.VIpgJd-ZVi9od-ORHb-OEVmcd,.VIpgJd-ZVi9od-l4eHX-hSRGPd{display:none!important}html,body{top:0!important;margin-top:0!important}body{padding-top:0!important}';document.documentElement.appendChild(s)}document.querySelectorAll('iframe.goog-te-banner-frame,iframe.goog-te-balloon-frame').forEach(function(x){x.style.display='none'})}catch(e){}})()", null)
                        }
                        val isHome = isStartUrl(url)
                        toolbarJs("window.ulaaHomeMode && window.ulaaHomeMode(" + isHome + ")")
                        urlView.alpha = 0.35f
                        urlView.animate().alpha(1f).setDuration(260).start()
                        pulsePill()
                        
                    }
                    refreshBack()
                }
                if (url != null && !url.contains(HOST)) {
                    // Keep desktop mode's wide layout viewport. The previous unconditional
                    // width=device-width override forced responsive sites (including Google)
                    // straight back into their mobile layout after every page load.
                    val desktopViewport = tab?.desktopMode == true
                    val viewportWidth = if (desktopViewport) "980" else "device-width"
                    view.evaluateJavascript(
                        "(function(){try{var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m)}m.content='width=" + viewportWidth + ",initial-scale=1,minimum-scale=0.5,maximum-scale=5,user-scalable=yes';window.dispatchEvent(new Event('resize'))}catch(e){}})()",
                        null
                    )
                    injectPageCleanup(view)
                }
                injectSpark(view, url)
                if (isStartUrl(url)) {
                    view.evaluateJavascript("window.ulaaSetTheme && window.ulaaSetTheme(" + pal.dark + ")", null)
                }
                if (isStartUrl(url) && tab?.isPrivate != true) {
                    view.postDelayed({ if (view == web) { syncWithHomepage(); syncHistoryWithHomepage(); refreshDownloadsPage() } }, 220)
                }
            }
        }

        w.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startBrowserDownload(url, userAgent, contentDisposition, mimeType)
        }

        watchScroll(w)
        setupFileDrop(w)

        w.webChromeClient = object : WebChromeClient() {
            // Open target=_blank / window.open links in a Valley tab instead of dropping them.
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                if (resultMsg == null || isFinishing || isDestroyed) return false
                return try {
                    val newTabWeb = buildWeb(private)
                    val newTabRecord = Tab(newTabWeb).apply {
                        isPrivate = private
                        if (private) title = "Private"
                    }
                    tabs.add(newTabRecord)
                    current = tabs.lastIndex
                    val transport = resultMsg.obj as? WebView.WebViewTransport
                        ?: run {
                            tabs.remove(newTabRecord)
                            newTabWeb.destroy()
                            return false
                        }
                    transport.webView = newTabWeb
                    resultMsg.sendToTarget()
                    mode = Mode.BROWSING
                    attach()
                    applyModeChrome()
                    true
                } catch (_: Exception) {
                    false
                }
            }

            // Bridge HTML file inputs to Android's native document picker.
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null) return false

                // Only one chooser can be active. Cancel an older request safely.
                pendingFileChooserCallback?.onReceiveValue(null)
                pendingFileChooserCallback = filePathCallback

                return try {
                    val multiple = fileChooserParams?.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE
                    val accept = fileChooserParams?.acceptTypes
                        ?.flatMap { it.split(",") }?.map { it.trim() }
                        ?.filter { it.contains("/") && !it.startsWith(".") } ?: emptyList()
                    val pickerIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        type = if (accept.size == 1) accept[0] else "*/*"
                        if (accept.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, accept.toTypedArray())
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
                    }
                    startActivityForResult(pickerIntent, fileChooserRequestCode)
                    true
                } catch (_: Exception) {
                    pendingFileChooserCallback = null
                    filePathCallback.onReceiveValue(null)
                    toast("No file picker is available")
                    false
                }
            }

            // WebView does not display JavaScript confirm() dialogs unless the host handles them.
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                if (isFinishing || isDestroyed) { result?.cancel(); return true }
                runOnUiThread {
                    if (isFinishing || isDestroyed) { result?.cancel(); return@runOnUiThread }
                    val dialog = AlertDialog.Builder(this@MainActivity)
                        .setMessage(message.orEmpty())
                        .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                        .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                        .create()
                    dialog.setOnCancelListener { result?.cancel() }
                    dialog.show()
                }
                return true
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (view == web) setLoading(newProgress in 1..99)
            }

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                val tab = tabs.firstOrNull { it.web === view } ?: return
                setTabIcon(tab, icon)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                val tab = tabs.firstOrNull { it.web === view }
                if (tab != null && !title.isNullOrBlank()) tab.title = title
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                if (callback == null) return
                if (origin != null && origin.contains(HOST)) { callback.invoke(origin, true, false); return }
                runOnUiThread { askGeolocation(origin ?: "This site", callback) }
            }

            override fun onPermissionRequest(request: android.webkit.PermissionRequest?) {
                if (request == null) return
                runOnUiThread { handleWebPermission(request) }
            }

            override fun onPermissionRequestCanceled(request: android.webkit.PermissionRequest?) {
                if (request != null && request === pendingPermRequest) { pendingPermRequest = null }
            }

            override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                if (view == null || customViewFrame != null) { callback?.onCustomViewHidden(); return }
                showFullscreenView(view, callback)
            }

            override fun onHideCustomView() { hideFullscreenView() }
        }
        return w
    }

    private fun setDesktopMode(enabled: Boolean) {
        val tab = tabs.getOrNull(current) ?: return
        if (tab.desktopMode == enabled) return
        tab.desktopMode = enabled
        val mobileUa = WebSettings.getDefaultUserAgent(this).replace("; wv", "")
        val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        tab.web.settings.userAgentString = if (enabled) desktopUa else mobileUa
        tab.web.settings.useWideViewPort = true
        // Desktop sites need a desktop-width layout viewport; onPageFinished applies
        // width=980 to the page's viewport meta tag. Overview mode fits that layout onscreen.
        tab.web.settings.loadWithOverviewMode = true
        toolbarJs("window.ulaaSetDesktopMode && window.ulaaSetDesktopMode($enabled)")
        val currentUrl = tab.web.url
        if (!currentUrl.isNullOrBlank()) tab.web.reload()
        toast(if (enabled) "Desktop site enabled" else "Mobile site enabled")
    }

    private val hideZoomPanelRunnable = Runnable { toolbarJs("window.ulaaHideZoom && window.ulaaHideZoom()") }

    private fun updateZoomPanel() {
        val percent = (web.scale * 100f).toInt().coerceAtLeast(25)
        toolbarJs("window.ulaaUpdateZoom && window.ulaaUpdateZoom($percent)")
        toolbarJs("window.ulaaShowZoom && window.ulaaShowZoom($percent)")
        web.removeCallbacks(hideZoomPanelRunnable)
        web.postDelayed(hideZoomPanelRunnable, 2200)
    }

    private fun adjustPageZoom(delta: Int) {
        if (delta > 0) {
            if (!web.zoomIn()) toast("Maximum zoom reached")
        } else {
            if (!web.zoomOut()) toast("Minimum zoom reached")
        }
        updateZoomPanel()
    }

    private fun resetPageZoom() {
        val currentScale = web.scale
        if (currentScale > 0f) web.zoomBy(1f / currentScale)
        web.settings.textZoom = 100
        updateZoomPanel()
    }

    /** a new tab gets its own WebView, so scroll position and form state survive switching */
    private fun newTab(url: String, private: Boolean = false) {
        val w = buildWeb(private)
        val tab = Tab(w)
        tab.isPrivate = private
        if (private) tab.title = "Private"
        privateCount += if (private) 1 else 0
        tabs.add(tab)
        current = tabs.size - 1
        val wasOverview = mode != Mode.BROWSING
        if (wasOverview) {
            mode = Mode.BROWSING
            filterGroup = null
            val overviewView = overview()
            overviewView.animate().cancel()
            overviewView.alpha = 1f
            overviewView.translationY = 0f
            overviewView.visibility = View.GONE
            overviewView.removeAllViews()
        }
        attach()
        w.loadUrl(url)
        showAddress(url)
        refreshBack()
        if (wasOverview) applyModeChrome()
    }

    // --- tab switching: the next/previous page slides in over the current one
    private var slideOld: View? = null
    private var slideNew: View? = null
    private var slideOverlay: View? = null

    /** ends a running slide at once, leaving exactly one page in the container */
    private fun finishSlide() {
        slideNew?.let { it.animate().cancel(); it.translationX = 0f }
        slideOverlay?.let { it.animate().cancel(); try { container.removeView(it) } catch (_: Exception) {} }
        slideOld?.let {
            it.animate().cancel(); it.translationX = 0f; it.alpha = 1f
            try { container.removeView(it) } catch (_: Exception) {}
        }
        slideOld = null; slideNew = null; slideOverlay = null
    }

    /**
     * @param slideDir 0 = swap instantly; 1 = the next tab slides in from the right;
     *                 -1 = the previous tab slides in from the left. The toolbar pill slides the same way.
     */
    private fun attach(slideDir: Int = 0) {
        finishSlide()
        val outgoing = container.getChildAt(0) as? WebView
        tabs.firstOrNull { it.web === outgoing }?.let { if (it !== active) captureThumb(it) }
        setReaderButtonActive(false)
        showBar()
        val w = active.web
        val sliding = slideDir != 0 && outgoing != null && outgoing !== w && container.width > 0 && w.parent == null
        w.animate().cancel()
        w.translationX = 0f
        w.translationY = 0f
        val lp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        val hadPending = active.pendingUrl != null
        val activeUrl = active.pendingUrl ?: w.url ?: START_URL
        val isHome = isStartUrl(activeUrl)
        if (sliding) {
            val dist = container.width.toFloat()
            w.translationX = slideDir * dist
            container.addView(w, lp)
            slideOld = outgoing; slideNew = w
            // a tab that has not loaded yet slides in with its saved picture, so it is never an empty sheet
            if (hadPending) {
                thumbFor(active)?.let { pic ->
                    val overlay = ImageView(this).apply {
                        setImageBitmap(pic); scaleType = ImageView.ScaleType.CENTER_CROP
                        setBackgroundColor(pal.bg); translationX = slideDir * dist
                    }
                    container.addView(overlay, lp)
                    slideOverlay = overlay
                    overlay.animate().translationX(0f).setDuration(Motion.D_EXPAND).setInterpolator(Motion.ease).start()
                }
            }
            outgoing!!.animate().translationX(-slideDir * dist * 0.28f).alpha(0.82f)
                .setDuration(Motion.D_EXPAND).setInterpolator(Motion.ease).start()
            w.animate().translationX(0f).setDuration(Motion.D_EXPAND).setInterpolator(Motion.ease)
                .withEndAction {
                    outgoing.alpha = 1f; outgoing.translationX = 0f
                    try { container.removeView(outgoing) } catch (_: Exception) {}
                    slideOld = null; slideNew = null
                    slideOverlay?.let { ov ->
                        ov.animate().alpha(0f).setDuration(260).withEndAction {
                            try { container.removeView(ov) } catch (_: Exception) {}
                        }.start()
                        slideOverlay = null
                    }
                }.start()
            showAddress(activeUrl, false)
            toolbarJs("window.ulaaSlidePill && window.ulaaSlidePill(" + slideDir + "," +
                org.json.JSONObject.quote(addressLabel(activeUrl)) + "," + isHome + ")")
        } else {
            container.removeAllViews()
            container.addView(w, lp)
            showAddress(activeUrl)
            toolbarJs("window.ulaaHomeMode && window.ulaaHomeMode(" + isHome + ")")
        }
        refreshBack()
        // A restored tab loads only when it is first shown, so reopening the app does not load every tab at once.
        active.pendingUrl?.let { pending ->
            active.pendingUrl = null
            w.loadUrl(pending)
        }
    }

    private var readerIsActive = false

    private fun setReaderButtonActive(active: Boolean) {
        readerIsActive = active
        // The visible toolbar is toolbar.html inside toolbarWeb, not the hidden native fallback.
        toolbarJs("window.ulaaSetReaderActive && window.ulaaSetReaderActive(" + active + ")")
        val button = findViewById<ImageButton>(R.id.reader) ?: return
        button.backgroundTintList = null
        button.setPadding(0, 0, 0, 0)
        button.minimumWidth = dp(38)
        button.minimumHeight = dp(38)

        button.background = if (active) {
            val halo = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x5018BDF2)
            }
            val circle = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF18BDF2.toInt())
                setStroke(dp(1), 0xFF8BE5FF.toInt())
            }
            android.graphics.drawable.LayerDrawable(arrayOf(halo, circle)).apply {
                setLayerInset(1, dp(3), dp(3), dp(3), dp(3))
            }
        } else {
            GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
            }
        }
        button.imageTintList = android.content.res.ColorStateList.valueOf(
            if (active) 0xFF062235.toInt() else pal.ink
        )
        button.elevation = if (active) dp(5).toFloat() else 0f
        button.stateListAnimator = null
        button.invalidate()
    }

    /**
     * Reload the WebView belonging to the currently selected tab.
     * A missing tab/WebView is handled without crashing the toolbar bridge.
     */
    private fun reloadActivePage() {
        val target = tabs.getOrNull(current)?.web
        if (target == null) {
            toast("No active page to refresh")
            return
        }
        try {
            val url = target.url
            if (url.isNullOrBlank()) {
                target.loadUrl(START_URL)
            } else {
                target.reload()
            }
            setLoading(true)
        } catch (e: Exception) {
            toast("Page could not be refreshed")
        }
    }

    private fun toggleReaderForActiveTab() {
        toggleReaderOn(active.web)
    }

    private fun toggleReader() {
        toggleReaderOn(web)
    }

    private fun toggleReaderOn(target: WebView) {
        val source = readerJs
        if (source.isNullOrBlank()) {
            toast("Reader mode could not be loaded")
            return
        }
        target.post {
            try {
                // Inject and toggle in one evaluation, and report what actually happened:
                // "opened", "closed", "pending" (still extracting) or "failed".
                val invocation = source + "\n; (function(){try{" +
                    "var had=!!document.getElementById('valley-reader-overlay');" +
                    "if(window.ulaaReaderToggle)window.ulaaReaderToggle();else if(window.ulaaReaderOpen)window.ulaaReaderOpen();else return 'failed';" +
                    "if(had)return 'closed';" +
                    "var s=window.ulaaReaderState?window.ulaaReaderState():'none';" +
                    "return s==='open'?'opened':(s==='pending'?'pending':'failed');" +
                    "}catch(e){return 'failed';}})();"
                target.evaluateJavascript(invocation) { raw ->
                    runOnUiThread {
                        when (raw?.trim('"')) {
                            "opened" -> if (target === web) setReaderButtonActive(true)
                            "closed" -> if (target === web) setReaderButtonActive(false)
                            "pending" -> {
                                // Slow extraction is not a failure. Check back a few times before giving up.
                                if (target === web) setReaderButtonActive(true)
                                waitForReader(target, 8)
                            }
                            else -> {
                                if (target === web) setReaderButtonActive(false)
                                toast("Reader couldn't extract this page. Try an article page.")
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (target === web) setReaderButtonActive(false)
                    toast("Reader mode failed to run")
                }
            }
        }
    }

    /** Polls a page whose Reader is still extracting; only reports failure once it is really over. */
    private fun waitForReader(target: WebView, triesLeft: Int) {
        target.postDelayed({
            try {
                target.evaluateJavascript(
                    "(function(){try{return window.ulaaReaderState?window.ulaaReaderState():'none'}catch(e){return 'none'}})()"
                ) { raw ->
                    runOnUiThread {
                        when (raw?.trim('"')) {
                            "open" -> if (target === web) setReaderButtonActive(true)
                            "pending" -> if (triesLeft > 0) waitForReader(target, triesLeft - 1) else {
                                if (target === web) setReaderButtonActive(false)
                                toast("Reader couldn't extract this page. Try an article page.")
                            }
                            else -> {
                                if (target === web) setReaderButtonActive(false)
                                toast("Reader couldn't extract this page. Try an article page.")
                            }
                        }
                    }
                }
            } catch (e: Exception) {}
        }, 500)
    }

    private fun readerUnavailable() {
        val card = menuCard()
        val msg = TextView(this).apply {
            text = "Reader mode is not available for this page."
            setTextColor(pal.ink)
            textSize = 14f
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        card.addView(msg)
        showCard(card, Align.LEFT)
    }

    private fun setLoading(loading: Boolean) {
        try { if (loading) glow.start() else glow.stop() } catch (e: Exception) {}
    }

    // Toolbar glass is a fixed theme-aware tint, independent of webpage colors.

    private fun pulsePill() {
        val pill = findViewById<View>(R.id.pill)
        pill.animate().scaleX(1.035f).scaleY(1.035f).setDuration(130)
            .withEndAction {
                pill.animate().scaleX(1f).scaleY(1f).setDuration(340)
                    .setInterpolator(Motion.spring).start()
            }.start()
    }

    private fun showAddress(url: String, updateToolbar: Boolean = true) {
        val label = addressLabel(url)
        if (active.isPrivate) {
            urlView.text = "\u25D0  " + label
            urlView.setTextColor(pal.priv)
        } else {
            urlView.text = label
            urlView.setTextColor(pal.ink)
        }
        if (updateToolbar) toolbarJs("window.ulaaSetAddr && window.ulaaSetAddr(" + org.json.JSONObject.quote(label) + ")")
        try { findViewById<android.widget.HorizontalScrollView>(R.id.urlScroll).scrollTo(0, 0) } catch (e: Exception) {}
    }

    private fun switchTo(index: Int, slideDir: Int = 0) {
        if (index !in tabs.indices) return
        current = index
        attach(slideDir)
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val gone = tabs.removeAt(index)
        selectedTabs.remove(gone)
        try {
            java.io.File(tabImageDir(), gone.id + ".jpg").delete()
            java.io.File(tabImageDir(), gone.id + "_icon.png").delete()
        } catch (_: Exception) {}
        if (gone.isPrivate) privateCount = (privateCount - 1).coerceAtLeast(0)
        val needWipe = gone.isPrivate && privateCount == 0
        try { gone.web.destroy() } catch (e: Exception) {}
        if (tabs.isEmpty()) {
            newTab(START_URL)
        } else {
            current = index.coerceAtMost(tabs.size - 1)
            attach()
        }
        if (needWipe) wipePrivateSession()
        if (mode != Mode.BROWSING) applyModeChrome()
    }

    /**
     * Android gives the whole app one cookie jar, so a private tab cannot have a separate one.
     * What we can do: while private tabs are open nothing is written to site storage or the
     * disk cache, and when the last one closes the cookies and cache are destroyed.
     */
    private fun wipePrivateSession() {
        try {
            val cm = CookieManager.getInstance()
            cm.removeAllCookies(null)
            cm.flush()
        } catch (e: Exception) {}
        try { web.clearCache(true) } catch (e: Exception) {}
        try { web.clearFormData() } catch (e: Exception) {}
        try { web.clearHistory() } catch (e: Exception) {}
    }

    private fun refreshBack() {
        if (mode != Mode.BROWSING) { findViewById<ImageButton>(R.id.back).alpha = 1f; toolbarJs("window.ulaaDim && window.ulaaDim(false)"); return }
        val can = if (navForward) web.canGoForward() else web.canGoBack()
        findViewById<ImageButton>(R.id.back).alpha = if (can) 1f else 0.35f
        toolbarJs("window.ulaaDim && window.ulaaDim(" + (!can) + ")")
    }

    private fun addressLabel(url: String): String =
        if (url.contains(HOST) && url.contains("index.html")) "Search or enter website"
        else prettyUrl(url)

    private fun prettyUrl(url: String): String = try {
        if (url.contains(HOST)) "Valley" else java.net.URL(url).host.replace("^www\\.".toRegex(), "")
    } catch (e: Exception) {
        url
    }

    // ---------------------------------------------------------------- html toolbar

    private val historyLock = Any()

    /** WebViews currently showing the Valley start page (the only pages allowed to use the bridges) */
    private val trustedHomeViews: MutableSet<WebView> = java.util.Collections.synchronizedSet(
        java.util.Collections.newSetFromMap(java.util.WeakHashMap<WebView, Boolean>()))

    inner class HistoryBridge(private val owner: WebView) {
        private fun ok() = trustedHomeViews.contains(owner)

        @android.webkit.JavascriptInterface
        fun recordSearch(query: String?) {
            if (!ok()) return
            synchronized(historyLock) {
                if (!active.isPrivate) recordSearchQuery(query.orEmpty())
            }
        }

        @android.webkit.JavascriptInterface
        fun removeSearch(query: String?) {
            if (!ok()) return
            // synchronous: the page may pull a snapshot right after, so storage must already be updated
            synchronized(historyLock) { removeSearchQuery(query.orEmpty()) }
        }

        @android.webkit.JavascriptInterface
        fun clearSearches() {
            if (!ok()) return
            synchronized(historyLock) { prefs().edit().putString("history_searches", "[]").commit() }
        }

        @android.webkit.JavascriptInterface
        fun recordOpened(url: String?, title: String?) {
            if (!ok()) return
            synchronized(historyLock) {
                if (!active.isPrivate) recordOpenedPage(url.orEmpty(), title)
            }
        }

        @android.webkit.JavascriptInterface
        fun removeOpened(url: String?) {
            if (!ok()) return
            synchronized(historyLock) { removeOpenedPage(url.orEmpty()) }
        }

        /** native storage is the single source of truth; the page pulls this whenever a view opens */
        @android.webkit.JavascriptInterface
        fun snapshot(): String = if (!ok()) "{}" else synchronized(historyLock) {
            JSONObject().put("s", readHistoryArray("history_searches")).put("o", readHistoryArray("history_opened")).toString()
        }

        @android.webkit.JavascriptInterface
        fun clearOpened() {
            if (!ok()) return
            synchronized(historyLock) { prefs().edit().putString("history_opened", "[]").commit() }
        }
    }

    inner class DownloadsBridge(private val owner: WebView) {
        private fun ok() = trustedHomeViews.contains(owner)

        @android.webkit.JavascriptInterface
        fun list(): String = if (ok()) buildDownloadsJson() else "[]"

        @android.webkit.JavascriptInterface
        fun open(id: Long) { if (ok()) runOnUiThread { openDownloadedFile(id) } }

        @android.webkit.JavascriptInterface
        fun refresh() { if (ok()) runOnUiThread { refreshDownloadsPage() } }

        /** removes one entry from Valley's list; the file itself stays on the device */
        @android.webkit.JavascriptInterface
        fun remove(id: Long) { if (ok()) runOnUiThread { removeDownloadRecord(id) } }

        private fun removeDownloadRecord(id: Long) {
            val keep = JSONArray()
            val all = readDownloadRecords()
            for (i in 0 until all.length()) { val o = all.optJSONObject(i) ?: continue; if (o.optLong("id") != id) keep.put(o) }
            writeDownloadRecords(keep)
            refreshDownloadsPage()
        }

        /** clears the list; downloaded files are never deleted, only in-progress ones are cancelled */
        @android.webkit.JavascriptInterface
        fun clearAll() { if (ok()) runOnUiThread { clearAllDownloadRecords() } }

        private fun clearAllDownloadRecords() {
            val all = readDownloadRecords()
            for (i in 0 until all.length()) {
                val o = all.optJSONObject(i) ?: continue
                val st = o.optString("status")
                if (st != "Downloaded" && st != "Failed") { try { downloadManager.remove(o.optLong("id")) } catch (_: Exception) {} }
            }
            writeDownloadRecords(JSONArray())
            refreshDownloadsPage()
        }
    }

    inner class ToolbarBridge {
        @android.webkit.JavascriptInterface
        fun nav() = runOnUiThread {
            val target = web
            if (navForward) {
                if (target.canGoForward()) target.goForward() else toast("No page to go forward to")
            } else {
                if (target.canGoBack()) target.goBack() else toast("No page to go back to")
            }
            refreshBack()
        }

        @android.webkit.JavascriptInterface
        fun addtabmenu() = runOnUiThread { showAddTabMenu() }

        @android.webkit.JavascriptInterface
        fun tabactions() = runOnUiThread { showTabActions() }

        @android.webkit.JavascriptInterface
        fun menu() = runOnUiThread { showPageMenu() }

        @android.webkit.JavascriptInterface
        fun reader() = runOnUiThread { toggleReaderForActiveTab() }

        @android.webkit.JavascriptInterface
        fun zoomIn() = runOnUiThread { adjustPageZoom(1) }

        @android.webkit.JavascriptInterface
        fun zoomOut() = runOnUiThread { adjustPageZoom(-1) }

        @android.webkit.JavascriptInterface
        fun zoomReset() = runOnUiThread { resetPageZoom() }


        @android.webkit.JavascriptInterface
        fun eraserMenu() = runOnUiThread {
            val target = active.web
            val url = target.url.orEmpty()
            if (url.isBlank() || url.contains(HOST)) {
                toast("Hide Distracting Items is available on webpages")
                return@runOnUiThread
            }
            target.evaluateJavascript(
                "(function(){return window.ValleyPageCleanup ? window.ValleyPageCleanup.count() : 0})()"
            ) { value ->
                val count = value?.trim()?.toIntOrNull() ?: 0
                toolbarJs("window.ulaaSetEraserCount && window.ulaaSetEraserCount($count)")
            }
        }

        @android.webkit.JavascriptInterface
        fun eraserErase() = runOnUiThread { startEraser() }

        @android.webkit.JavascriptInterface
        fun eraserRestore() = runOnUiThread {
            val target = tabs.getOrNull(current)?.web
            if (target == null) {
                toast("No active page")
                return@runOnUiThread
            }
            try {
                target.evaluateJavascript(
                    "(function(){try{return window.ValleyPageCleanup ? window.ValleyPageCleanup.restore() : 0}catch(e){return 0}})()"
                ) { value ->
                    val count = value?.trim()?.toIntOrNull() ?: 0
                    if (count > 0) toast("Showing $count hidden item" + if (count == 1) "" else "s")
                    else toast("No hidden items on this page")
                    target.evaluateJavascript(
                        "(function(){return window.ValleyPageCleanup ? window.ValleyPageCleanup.count() : 0})()"
                    ) { remaining ->
                        val n = remaining?.trim()?.toIntOrNull() ?: 0
                        toolbarJs("window.ulaaSetEraserCount && window.ulaaSetEraserCount($n)")
                    }
                }
            } catch (e: Exception) {
                toast("Could not restore page items")
            }
        }

        @android.webkit.JavascriptInterface
        fun reload() = runOnUiThread {
            reloadActivePage()
        }

        @android.webkit.JavascriptInterface
        fun voiceSearch() = runOnUiThread { launchVoiceSearch() }

        @android.webkit.JavascriptInterface
        fun findInPage() = runOnUiThread { showFindInPage() }

        @android.webkit.JavascriptInterface
        fun address() = runOnUiThread { editUrl() }

        @android.webkit.JavascriptInterface
        fun folded(on: Boolean) = runOnUiThread { resizeToolbarWeb(on) }

        @android.webkit.JavascriptInterface
        fun hidebar() = runOnUiThread { hideBar() }

        @android.webkit.JavascriptInterface
        fun surface(open: Boolean) = runOnUiThread { resizeToolbarWeb(open) }

        @android.webkit.JavascriptInterface
        fun smartsetting(enabled: Boolean) = runOnUiThread {
            prefs().edit().putBoolean("smart_search", enabled).apply()
            val value = if (enabled) "1" else "0"
            web.evaluateJavascript("(function(){try{localStorage.setItem('hp.smart','$value');localStorage.setItem('ulaa-smart','$value')}catch(e){}})()", null)
        }

        @android.webkit.JavascriptInterface
        fun smartstate() = runOnUiThread {
            val enabled = prefs().getBoolean("smart_search", true)
            toolbarJs("window.ulaaSetSmart && window.ulaaSetSmart($enabled)")
        }

        @android.webkit.JavascriptInterface
        fun search(query: String?) = runOnUiThread {
            val q = query?.trim().orEmpty()
            if (q.isEmpty()) return@runOnUiThread
            if (!active.isPrivate) recordSearchQuery(q)
            // Respect the setting from Valley's homepage (hp.smart) or the page pill (ulaa-smart).
            // The native preference is the fallback for pages that have never set either value.
            val readSetting = "(function(){try{var s=localStorage.getItem('hp.smart');" +
                "if(s===null)s=localStorage.getItem('ulaa-smart');return s;}catch(e){return null;}})()"
            web.evaluateJavascript(readSetting) { raw ->
                val smart = when (raw?.trim('"')) {
                    "0" -> false
                    "1" -> true
                    else -> prefs().getBoolean("smart_search", true)
                }
                prefs().edit().putBoolean("smart_search", smart).apply()
                web.loadUrl(routeSearch(q, smart))
            }
        }

        @android.webkit.JavascriptInterface
        fun navmode(name: String?) = runOnUiThread {
            navForward = name == "Forward"
            applyNavMode()
        }

        @android.webkit.JavascriptInterface
        fun action(name: String?) = runOnUiThread {
            when (name) {
                "share" -> shareCurrent()
                "favourite" -> addToList("list_favs")
                "bookmark" -> addToList("list_bookmarks")
                "desktop" -> setDesktopMode(!active.desktopMode)
                "downloads" -> openHomeView("downloads")
                "home" -> web.loadUrl(START_URL)
                "newtab" -> newTab(START_URL)
                "reader" -> toggleReader()
                "privatetab" -> newTab(START_URL, true)
                "bookmarks" -> enterOverview(Mode.BOOKMARKS)
                "privacy" -> enterOverview(Mode.PRIVACY)
                "alltabs" -> enterOverview(
                Mode.TABS,
                if (active.isPrivate) "__PRIVATE__" else active.groupName
            )
                "closetab" -> { closeTab(current); if (tabs.isNotEmpty()) exitOverview() }
                "navback" -> if (web.canGoBack()) web.goBack()
                "navforward" -> if (web.canGoForward()) web.goForward()
            }
        }

        @android.webkit.JavascriptInterface
        fun tabSwipe(direction: String?) = runOnUiThread {
            if (tabs.size < 2) return@runOnUiThread
            val next = if (direction == "next") (current + 1) % tabs.size else (current - 1 + tabs.size) % tabs.size
            switchTo(next, if (direction == "next") 1 else -1)
        }

        @android.webkit.JavascriptInterface
        fun tool(name: String?) = runOnUiThread {
            when (name) {
                "voiceSearch" -> launchVoiceSearch()
                "findInPage" -> showFindInPage()
                "translate" -> translatePage()
                "eraser" -> startEraser()
                "summarise" -> js("window.ulaaSummarise && window.ulaaSummarise()")
                "copy" -> {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("url", web.url ?: ""))
                    toast("Link copied")
                }
                "home" -> { web.loadUrl(START_URL); toolbarJs("window.ulaaFold && window.ulaaFold(false)") }
                "hidebar" -> hideBar()
            }
        }
    }

    private val voiceRequestCode = 7041
    private val fileChooserRequestCode = 7042
    private var pendingFileChooserCallback: ValueCallback<Array<Uri>>? = null

    /** Uses Android's system speech UI; no direct microphone permission is requested by Valley. */
    private fun showFindInPage() {
        val field = android.widget.EditText(this).apply {
            hint = "Find on this page"
            setSingleLine(true)
            setTextColor(pal.ink)
            setHintTextColor(pal.ink3)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val target = active.web
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Find in Page")
            .setView(field)
            .setNegativeButton("Close") { _, _ -> target.clearMatches() }
            .setNeutralButton("Previous", null)
            .setPositiveButton("Next", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                target.findAllAsync(field.text?.toString().orEmpty())
                target.findNext(true)
            }
            dialog.getButton(android.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                target.findAllAsync(field.text?.toString().orEmpty())
                target.findNext(false)
            }
        }
        dialog.show()
        field.requestFocus()
    }

    private fun launchVoiceSearch() {
        try {
            if (!packageManager.hasSystemFeature("android.hardware.microphone")) {
                toast("Voice search is unavailable on this device")
                return
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your search")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            startActivityForResult(intent, voiceRequestCode)
        } catch (e: Exception) {
            toast("Voice search service is unavailable")
        }
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with the current Activity shell")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == fileChooserRequestCode) {
            val callback = pendingFileChooserCallback
            pendingFileChooserCallback = null
            if (callback != null) {
                val results: Array<Uri>? = if (resultCode == RESULT_OK && data != null) {
                    val list = ArrayList<Uri>()
                    val clip = data.clipData
                    if (clip != null) {
                        for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { list.add(it) }
                    }
                    if (list.isEmpty()) data.data?.let { list.add(it) }
                    if (list.isEmpty()) null else list.toTypedArray()
                } else null
                callback.onReceiveValue(results)
            }
            return
        }

        if (requestCode != voiceRequestCode || resultCode != RESULT_OK) return
        val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim().orEmpty()
        if (spoken.isNotEmpty()) {
            if (!active.isPrivate) recordSearchQuery(spoken)
            web.loadUrl(routeSearch(spoken, prefs().getBoolean("smart_search", true)))
        }
    }

    /** the bar only needs 78dp; the orb and its tools need room above it */
    private fun resizeToolbarWeb(expanded: Boolean) {
        try {
            val tw = findViewById<WebView>(R.id.toolbarWeb)
            val lp = tw.layoutParams
            lp.height = dp(if (expanded) 360 else 78)
            tw.layoutParams = lp
        } catch (e: Exception) {}
    }

    private fun toolbarJs(code: String) {
        try { findViewById<WebView>(R.id.toolbarWeb).evaluateJavascript(code, null) } catch (e: Exception) {}
    }

    private fun setUpToolbarWeb() {
        val tw = findViewById<WebView>(R.id.toolbarWeb)
        tw.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        tw.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        tw.settings.javaScriptEnabled = true
        tw.settings.domStorageEnabled = true
        tw.settings.allowFileAccess = false
        tw.isVerticalScrollBarEnabled = false
        tw.isHorizontalScrollBarEnabled = false
        tw.overScrollMode = View.OVER_SCROLL_NEVER
        tw.addJavascriptInterface(ToolbarBridge(), "ValleyNative")
        tw.webViewClient = object : android.webkit.WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                assetLoader.shouldInterceptRequest(request.url)?.let { return it }
                return null
            }
            override fun onPageFinished(view: WebView, url: String?) {
                super.onPageFinished(view, url)
                pushThemeToPages()
            }
        }
        tw.loadUrl("https://appassets.androidplatform.net/assets/toolbar.html")
    }

    // ---------------------------------------------------------------- overview pages

    private fun overview(): FrameLayout = findViewById(R.id.overview)

    private fun enterOverview(kind: Mode, group: String? = null) {
        val sourceWeb = web
        val pageSnapshot = if (kind == Mode.TABS && sourceWeb.width > 0 && sourceWeb.height > 0) {
            try {
                android.graphics.Bitmap.createBitmap(
                    sourceWeb.width, sourceWeb.height, android.graphics.Bitmap.Config.RGB_565
                ).also { bitmap -> sourceWeb.draw(android.graphics.Canvas(bitmap)) }
            } catch (e: Exception) { null }
        } else null

        mode = kind
        filterGroup = group
        val box = overview()
        box.visibility = View.VISIBLE
        box.removeAllViews()
        box.addView(when (kind) {
            Mode.TABS -> buildTabsPage(group)
            Mode.MANAGE_GROUPS -> buildManageTabGroupsPage()
            Mode.PRIVACY -> buildPrivacyPage()
            else -> buildBookmarksPage()
        })
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try {
                web.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(
                    33f, 33f, android.graphics.Shader.TileMode.CLAMP))
            } catch (e: Exception) {}
        }
        box.alpha = 1f
        box.translationY = 0f
        applyModeChrome()

        if (pageSnapshot != null && kind == Mode.TABS) {
            box.post {
                val destination = overviewActiveCard
                if (destination == null || destination.width <= 0 || destination.height <= 0) {
                    pageSnapshot.recycle()
                    return@post
                }
                val boxPos = IntArray(2)
                val webPos = IntArray(2)
                val cardPos = IntArray(2)
                box.getLocationOnScreen(boxPos)
                sourceWeb.getLocationOnScreen(webPos)
                destination.getLocationOnScreen(cardPos)
                val startX = (webPos[0] - boxPos[0]).toFloat()
                val startY = (webPos[1] - boxPos[1]).toFloat()
                val endX = (cardPos[0] - boxPos[0]).toFloat()
                val endY = (cardPos[1] - boxPos[1]).toFloat()
                val startW = sourceWeb.width.toFloat().coerceAtLeast(1f)
                val startH = sourceWeb.height.toFloat().coerceAtLeast(1f)
                val image = ImageView(this).apply {
                    setImageBitmap(pageSnapshot)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    clipToOutline = true
                    background = GradientDrawable().apply {
                        cornerRadius = dp(18).toFloat()
                        setColor(Color.BLACK)
                    }
                    elevation = dp(24).toFloat()
                    pivotX = 0f
                    pivotY = 0f
                    x = startX
                    y = startY
                    layoutParams = FrameLayout.LayoutParams(sourceWeb.width, sourceWeb.height)
                }
                destination.alpha = 0f
                box.addView(image)
                image.animate()
                    .x(endX).y(endY)
                    .scaleX(destination.width / startW)
                    .scaleY(destination.height / startH)
                    .setDuration(420)
                    .setInterpolator(Motion.spring)
                    .withEndAction {
                        destination.animate().alpha(1f).setDuration(90).start()
                        box.removeView(image)
                        pageSnapshot.recycle()
                    }.start()
            }
        } else {
            box.alpha = 0f
            box.translationY = dp(12).toFloat()
            box.animate().alpha(1f).translationY(0f).setDuration(220)
                .setInterpolator(Motion.ease).start()
        }
    }

    private fun exitOverview() {
        if (mode == Mode.BROWSING) return
        mode = Mode.BROWSING
        filterGroup = null
        val box = overview()
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try { web.setRenderEffect(null) } catch (e: Exception) {}
        }
        box.animate().alpha(0f).translationY(dp(14).toFloat()).setDuration(180)
            .withEndAction { box.visibility = View.GONE; box.removeAllViews() }.start()
        applyModeChrome()
    }

    /** In overview, the compact count pill stays centered between the left + and right … controls. */
    private fun shrinkPill(shrink: Boolean) {
        try {
            val pill = findViewById<View>(R.id.pill)
            val lp = pill.layoutParams as LinearLayout.LayoutParams
            if (shrink) {
                // Overview: keep the count as a compact, independent pill centered
                // between equal-sized edge controls (+ on the left, … on the right).
                lp.weight = 0f
                lp.width = LinearLayout.LayoutParams.WRAP_CONTENT
                lp.gravity = android.view.Gravity.CENTER_VERTICAL
                pill.minimumWidth = dp(76)
            } else {
                lp.weight = 1f
                lp.width = 0
            }
            pill.layoutParams = lp

            // the label itself had weight 1, which measures to nothing inside a wrapping pill
            val label = findViewById<TextView>(R.id.overviewLabel)
            val llp = label.layoutParams as LinearLayout.LayoutParams
            if (shrink) {
                llp.weight = 0f
                llp.width = LinearLayout.LayoutParams.WRAP_CONTENT
                llp.setMargins(dp(16), 0, dp(16), 0)
                label.gravity = android.view.Gravity.CENTER
                label.setPadding(dp(4), 0, dp(4), 0)
            } else {
                llp.weight = 1f
                llp.width = 0
                llp.setMargins(0, 0, 0, 0)
                label.setPadding(0, 0, 0, 0)
                pill.minimumWidth = 0
            }
            label.layoutParams = llp
        } catch (e: Exception) {}
    }

    private fun applyModeChrome() {
        val label = findViewById<TextView>(R.id.overviewLabel)
        val reader = findViewById<View>(R.id.reader)
        val reload = findViewById<View>(R.id.reload)
        val nav = findViewById<ImageButton>(R.id.back)
        val inOverview = mode != Mode.BROWSING
        findViewById<WebView>(R.id.toolbarWeb).visibility =
            if (inOverview) View.GONE else View.VISIBLE

        urlView.visibility = if (inOverview) View.GONE else View.VISIBLE
        reader.visibility = if (inOverview) View.GONE else View.VISIBLE
        reload.visibility = if (inOverview) View.GONE else View.VISIBLE
        label.visibility = if (inOverview) View.VISIBLE else View.GONE

        shrinkPill(inOverview)
        if (inOverview) {
            toolbarJs("window.ulaaCount && window.ulaaCount(" +
                org.json.JSONObject.quote(if (mode == Mode.TABS) tabs.size.toString() + (if (tabs.size == 1) " tab" else " tabs") else "Bookmarks") + ")")
        } else {
            toolbarJs("window.ulaaCount && window.ulaaCount(null)")
        }
        if (inOverview) {
            label.text = if (mode == Mode.TABS) tabs.size.toString() + (if (tabs.size == 1) " tab" else " tabs")
                         else "Bookmarks"
            nav.setImageResource(R.drawable.ic_plus)
            nav.alpha = 1f
        } else {
            applyNavMode()
            refreshBack()
        }
    }

    /** Inter Bold when assets/fonts/Inter-Bold.ttf is bundled, otherwise the system bold sans. */
    private val interBold: Typeface? by lazy {
        listOf("Inter_28pt-Bold.ttf", "Inter-Bold.ttf", "Inter_24pt-Bold.ttf", "Inter_18pt-Bold.ttf").firstNotNullOfOrNull { name ->
            try { Typeface.createFromAsset(assets, "fonts/$name") } catch (_: Exception) { null }
        }
    }
    private fun headingTypeface(): Typeface = interBold ?: Typeface.create("sans-serif", Typeface.BOLD)

    private fun pageHeader(title: String): LinearLayout {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(12))
        }
        head.addView(TextView(this).apply {
            text = title
            setTextColor(pal.ink)
            if (title == "Bookmarks" || title == "Privacy" || title == "Tab Groups") {
                // same look as the History and Downloads headings: Inter Bold, upright, 32
                textSize = 32f
                setTypeface(headingTypeface())
                letterSpacing = -0.03f
            } else {
                textSize = 24f
                setTypeface(Typeface.create("serif", Typeface.ITALIC))
            }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        head.addView(TextView(this).apply {
            text = "Done"
            setTextColor(0xFFE8622A.toInt())
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), dp(6), 0, dp(6))
            isClickable = true
            setOnClickListener { exitOverview() }
            pressable(this)
        })
        return head
    }

    private fun buildTabsPage(group: String?): View {
        overviewActiveCard = null
        val root = FrameLayout(this)

        val scroll = android.widget.ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            isFillViewport = true
            clipToPadding = false
            setPadding(0, 0, 0, dp(88))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        scroll.addView(col)
        root.addView(scroll)

        val isPrivateGroup = group == "__PRIVATE__"
        val visibleTabs = tabs.filter { t ->
            when {
                isPrivateGroup -> t.isPrivate
                group != null -> !t.isPrivate && t.groupName == group
                else -> !t.isPrivate && t.groupName == null
            }
        }
        val currentGroupName = when {
            isPrivateGroup -> "Private"
            group != null -> group
            else -> ""
        }
        val orphanTabCount = tabs.count { !it.isPrivate && it.groupName == null }

        // Centered floating group/status pill, positioned below the search row.
        val groupLabel = TextView(this).apply {
            text = if (selectingTabs) "${selectedTabs.size} Tabs selected" else currentGroupName
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(pal.ink)
            gravity = android.view.Gravity.CENTER
            setPadding(dp(14), 0, 0, 0)
            isSingleLine = true
        }
        val groupChevron = ImageView(this).apply {
            setImageResource(R.drawable.ic_chevron_down)
            imageTintList = android.content.res.ColorStateList.valueOf(pal.ink)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            scaleY = 1f
            setPadding(0, 0, dp(10), dp(3))
            contentDescription = "Choose tab group"
        }
        val groupHeading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(22).toFloat()
                setColor(pal.pop)
                setStroke(dp(1), pal.line)
            }
            elevation = dp(8).toFloat()
            addView(groupLabel, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT))
            addView(groupChevron, LinearLayout.LayoutParams(dp(22), LinearLayout.LayoutParams.MATCH_PARENT))
            isClickable = !selectingTabs
            isFocusable = !selectingTabs
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(38)).also {
                it.gravity = android.view.Gravity.CENTER_HORIZONTAL
                it.topMargin = dp(2)
                it.bottomMargin = dp(8)
            }
        }
        var groupPickerOverlay: FrameLayout? = null
        var groupPickerAnchor: View = groupHeading
        fun closeGroupPicker() {
            val overlay = groupPickerOverlay ?: return
            groupChevron.animate().scaleY(1f).setDuration(180).start()
            overlay.animate().alpha(0f).setDuration(150).withEndAction {
                if (overlay.parent === root) root.removeView(overlay)
                if (groupPickerOverlay === overlay) groupPickerOverlay = null
            }.start()
        }
        groupHeading.setOnClickListener {
            if (selectingTabs || groupPickerOverlay != null) return@setOnClickListener
            val overlay = FrameLayout(this).apply {
                setBackgroundColor(Color.TRANSPARENT)
                alpha = 0f
                isClickable = true
                setOnClickListener { closeGroupPicker() }
            }
            val picker = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(28).toFloat()
                    setColor(pal.pop)
                    setStroke(dp(1), pal.lineStrong)
                }
                elevation = dp(14).toFloat()
                isClickable = true
                setOnClickListener { }
            }
            fun addGroupOption(icon: Int, label: String, key: String?) {
                val option = menuRow(icon, label) {
                    closeGroupPicker()
                    root.postDelayed({ enterOverview(Mode.TABS, key) }, 170)
                }
                picker.addView(option)
            }
            addGroupOption(R.drawable.ic_group, "$orphanTabCount ${if (orphanTabCount == 1) "Tab" else "Tabs"}", null)
            addGroupOption(R.drawable.ic_mask, "Private", "__PRIVATE__")
            groups.map { it.first }.distinct().forEach { name ->
                addGroupOption(R.drawable.ic_group, name, name)
            }
            overlay.addView(picker, FrameLayout.LayoutParams(
                minOf(dp(212), root.width - dp(40)).coerceAtLeast(dp(176)),
                FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL))
            root.addView(overlay, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            groupPickerOverlay = overlay
            overlay.post {
                val anchor = IntArray(2)
                val rootLoc = IntArray(2)
                groupPickerAnchor.getLocationOnScreen(anchor)
                root.getLocationOnScreen(rootLoc)
                val lp = picker.layoutParams as FrameLayout.LayoutParams
                lp.topMargin = (anchor[1] - rootLoc[1]) + groupPickerAnchor.height + dp(7)
                picker.layoutParams = lp
                picker.pivotX = picker.width / 2f
                picker.pivotY = 0f
                picker.scaleX = 0.82f
                picker.scaleY = 0.12f
                picker.alpha = 0f
                overlay.animate().alpha(1f).setDuration(120).start()
                picker.animate().scaleX(1f).scaleY(1f).alpha(1f)
                    .setDuration(280).setInterpolator(Motion.ease).start()
                groupChevron.animate().scaleY(-1f).setDuration(220).start()
            }
        }

        // Search header. Settings has its own fixed-width hit target and cannot overlap search.
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(76), dp(12), dp(16), dp(10))
        }
        val settingsPill = TextView(this).apply {
            text = "•••"
            textSize = 22f
            setTextColor(pal.popInk)
            gravity = android.view.Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(22).toFloat()
                setColor(pal.popSolid)
                setStroke(dp(1), pal.line)
            }
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).also {
                it.marginEnd = dp(10)
            }
            isClickable = true
            contentDescription = "More tab options"
            setOnClickListener { showTabActions() }
            pressable(this)
        }
        val searchField = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(pal.popSolid)
                setStroke(dp(1), pal.lineSoft)
            }
            setPadding(dp(14), 0, dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
        }
        val searchIcon = TextView(this).apply {
            text = "⌕"
            textSize = 25f
            setTextColor(pal.popInk)
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(30), dp(48))
        }
        val tabsSearch = EditText(this).apply {
            hint = "Search tabs"
            setHintTextColor(pal.popHint)
            setTextColor(pal.ink)
            textSize = 16f
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            background = null
            setPadding(dp(8), 0, dp(4), 0)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        val cancelSearch = TextView(this).apply {
            text = "Cancel"
            textSize = 15f
            setTextColor(0xFF0A84FF.toInt())
            gravity = android.view.Gravity.CENTER
            visibility = View.GONE
            setPadding(dp(12), 0, 0, 0)
            setOnClickListener {
                tabsSearch.setText("")
                tabsSearch.clearFocus()
                val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.hideSoftInputFromWindow(tabsSearch.windowToken, 0)
                visibility = View.GONE
            }
        }
        searchField.addView(searchIcon)
        searchField.addView(tabsSearch)
        searchRow.addView(searchField)
        searchRow.addView(cancelSearch)
        searchRow.visibility = if (selectingTabs) View.INVISIBLE else View.VISIBLE
        col.addView(searchRow)
        if (selectingTabs) col.addView(groupHeading)

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
        }
        col.addView(grid)

        var row: LinearLayout? = null
        var count = 0
        tabs.withIndex().sortedWith(compareByDescending<IndexedValue<Tab>> { it.value.isPinned }.thenBy { it.index }).forEach { entry ->
            val i = entry.index
            val t = entry.value
            val belongs = when {
                isPrivateGroup -> t.isPrivate
                group != null -> !t.isPrivate && t.groupName == group
                else -> !t.isPrivate && t.groupName == null
            }
            if (!belongs) return@forEach
            if (count % 2 == 0) {
                val fresh = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(6), 0, dp(6))
                }
                grid.addView(fresh)
                row = fresh
            }
            val card = tabCard(t, i == current)
            if (i == current) overviewActiveCard = card
            val target = row
            if (target != null) {
                target.addView(card, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .also { it.setMargins(dp(6), 0, dp(6), 0) })
            }
            count++
        }

        tabsSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString()?.trim()?.lowercase().orEmpty()
                cancelSearch.visibility = if (q.isNotEmpty() || tabsSearch.hasFocus()) View.VISIBLE else View.GONE
                for (r in 0 until grid.childCount) {
                    val rowView = grid.getChildAt(r) as? LinearLayout ?: continue
                    var anyVisible = false
                    for (c in 0 until rowView.childCount) {
                        val cardView = rowView.getChildAt(c)
                        val match = q.isEmpty() || (cardView.tag as? String)?.contains(q) == true
                        cardView.visibility = if (match) View.VISIBLE else View.GONE
                        if (match) anyVisible = true
                    }
                    rowView.visibility = if (anyVisible) View.VISIBLE else View.GONE
                }
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        tabsSearch.setOnFocusChangeListener { _, focused ->
            cancelSearch.visibility = if (focused || tabsSearch.text.isNotEmpty()) View.VISIBLE else View.GONE
        }
        tabsSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {
                val q = tabsSearch.text.toString().trim()
                if (q.isNotEmpty()) { exitOverview(); newTab(routeSearch(q, prefs().getBoolean("smart_search", true))) }
                true
            } else false
        }
        if (count == 0) {
            col.addView(TextView(this).apply {
                text = "No tabs here yet."
                setTextColor(pal.ink3)
                textSize = 13.5f
                setPadding(dp(20), dp(10), dp(20), dp(10))
            })
        }

        // Three independent floating controls: new tab, centered group slider, and done.
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 0)
        }
        val dockLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dp(42), android.view.Gravity.BOTTOM)
        dockLp.setMargins(dp(20), 0, dp(20), dp(24))
        root.addView(dock, dockLp)

        fun floatingBackground(color: Int) = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(28).toFloat()
            setColor(color)
            setStroke(dp(1), pal.line)
        }
        val plus = TextView(this).apply {
            text = "+"
            gravity = android.view.Gravity.CENTER
            textSize = 27f
            setTextColor(pal.popInk)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).also { it.marginEnd = dp(15) }
            background = floatingBackground(pal.pop)
            setOnClickListener { exitOverview(); newTab(START_URL, isPrivateGroup) }
            contentDescription = if (isPrivateGroup) "New private tab" else "New tab"
            isClickable = true
            pressable(this)
        }
        dock.addView(plus)

        run {
            val selectorScroll = android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = false
                overScrollMode = View.OVER_SCROLL_NEVER
                clipToPadding = false
                isFocusable = false
                descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).also {
                    it.marginStart = dp(8)
                    it.marginEnd = dp(8)
                }
            }
            val selectorRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                clipChildren = false
                clipToPadding = false
            }
            selectorScroll.addView(selectorRow)

            data class GroupChoice(val label: String, val key: String?, val selected: Boolean)
            val choices = mutableListOf<GroupChoice>()
            // Keep Private immediately to the left of the ungrouped "N Tabs" chip.
            if (tabs.any { it.isPrivate }) {
                choices.add(GroupChoice("Private", "__PRIVATE__", isPrivateGroup))
            }
            choices.add(GroupChoice(
                "$orphanTabCount ${if (orphanTabCount == 1) "Tab" else "Tabs"}",
                null, group == null && !isPrivateGroup))
            groups.map { it.first }.distinct().forEach { name ->
                choices.add(GroupChoice(name, name, group == name && !isPrivateGroup))
            }

            val choiceViews = mutableListOf<View>()
            choices.forEachIndexed { index, choice ->
                val chip = TextView(this).apply {
                    text = choice.label
                    gravity = android.view.Gravity.CENTER
                    textSize = if (choice.selected) 14.5f else 13.5f
                    setTypeface(typeface, if (choice.selected) Typeface.BOLD else Typeface.NORMAL)
                    setTextColor(if (choice.selected) pal.popInk else pal.popInk2)
                    setPadding(dp(15), 0, dp(15), 0)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(24).toFloat()
                        if (choice.selected) {
                            setColor(pal.popSelected)
                            setStroke(dp(1), pal.lineSelected)
                        } else {
                            setColor(pal.popSelectedFill)
                        }
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT, dp(38)).also {
                        if (index > 0) it.marginStart = dp(7)
                    }
                    isClickable = true
                    contentDescription = "Show ${choice.label}"
                    setOnClickListener {
                        val target = this.left + this.width / 2 - selectorScroll.width / 2
                        selectorScroll.smoothScrollTo(target.coerceAtLeast(0), 0)
                        root.postDelayed({ enterOverview(Mode.TABS, choice.key) }, 230)
                    }
                    pressable(this)
                }
                selectorRow.addView(chip)
                choiceViews.add(chip)
            }

            fun updateGroupSliderDepth() {
                val center = selectorScroll.scrollX + selectorScroll.width / 2f
                val half = (selectorScroll.width * 0.62f).coerceAtLeast(1f)
                choiceViews.forEach { view ->
                    val distance = kotlin.math.abs((view.left + view.right) / 2f - center)
                    val proximity = (1f - distance / half).coerceIn(0f, 1f)
                    val scale = 0.88f + proximity * 0.12f
                    view.scaleX = scale
                    view.scaleY = scale
                    view.alpha = 0.48f + proximity * 0.52f
                }
            }

            var switchingBySwipe = false
            var lastSwipeTarget: String? = null

            fun detectGroupEnteringCenter() {
                if (!selectorScroll.isAttachedToWindow || switchingBySwipe) return
                val centerLeft = selectorScroll.scrollX + selectorScroll.width * 0.10f
                val centerRight = selectorScroll.scrollX + selectorScroll.width * 0.90f
                val candidate = choiceViews.mapIndexedNotNull { index, view ->
                    val visibleLeft = maxOf(view.left.toFloat(), centerLeft)
                    val visibleRight = minOf(view.right.toFloat(), centerRight)
                    val overlap = (visibleRight - visibleLeft).coerceAtLeast(0f)
                    val fraction = overlap / view.width.coerceAtLeast(1)
                    if (fraction >= 0.20f) {
                        val distance = kotlin.math.abs((view.left + view.right) / 2f -
                            (selectorScroll.scrollX + selectorScroll.width / 2f))
                        Triple(index, fraction, distance)
                    } else null
                }.minByOrNull { it.third }

                if (candidate != null) {
                    val choice = choices.getOrNull(candidate.first) ?: return
                    val targetKey = choice.key ?: "__UNGROUPED__"
                    if (!choice.selected && targetKey != lastSwipeTarget) {
                        // Switch on the first meaningful entry into the slider's active area.
                        switchingBySwipe = true
                        lastSwipeTarget = targetKey
                        enterOverview(Mode.TABS, choice.key)
                    }
                }
            }

            selectorScroll.setOnScrollChangeListener { _, _, _, _, _ ->
                updateGroupSliderDepth()
                detectGroupEnteringCenter()
            }
            dock.addView(selectorScroll)
            val selectedIndex = choices.indexOfFirst { it.selected }.coerceAtLeast(0)
            selectorScroll.post {
                val selected = choiceViews.getOrNull(selectedIndex) ?: return@post
                val sideInset = selectorScroll.width / 2
                selectorRow.setPadding(sideInset, 0, sideInset, 0)
                selectorRow.requestLayout()
                selectorRow.post {
                    val target = selected.left + selected.width / 2 - selectorScroll.width / 2
                    selectorScroll.scrollTo(target.coerceAtLeast(0), 0)
                    updateGroupSliderDepth()
                }
            }
        }

        val done = TextView(this).apply {
            text = "✓"
            gravity = android.view.Gravity.CENTER
            textSize = 22f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF279AF2.toInt())
                setStroke(dp(1), 0x66FFFFFF)
            }
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            setOnClickListener { exitOverview() }
            contentDescription = "Done"
            isClickable = true
            pressable(this)
        }
        dock.addView(done)

        // Settings remains fixed to the overview, independent of the scrolling tab grid.
        settingsPill.visibility = View.GONE
        val floatingSettings = TextView(this).apply {
            text = "•••"
            textSize = 22f
            gravity = android.view.Gravity.CENTER
            setTextColor(pal.popInk)
            background = floatingBackground(pal.popStrong)
            elevation = dp(14).toFloat()
            layoutParams = FrameLayout.LayoutParams(dp(40), dp(40),
                android.view.Gravity.TOP or android.view.Gravity.START).also {
                it.setMargins(dp(18), dp(14), 0, 0)
            }
            contentDescription = "More tab options"
            isClickable = true
            setOnClickListener {
                if (selectingTabs) showSelectedTabsMenu() else showTabActions()
            }
            pressable(this)
        }
        floatingSettings.visibility = View.VISIBLE
        root.addView(floatingSettings)

        if (selectingTabs) {
            val closeSelection = TextView(this).apply {
                text = "Close"
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                gravity = android.view.Gravity.CENTER
                setTextColor(pal.popInk)
                background = floatingBackground(pal.popStrong)
                elevation = dp(14).toFloat()
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, dp(40),
                    android.view.Gravity.TOP or android.view.Gravity.START).also {
                    it.setMargins(dp(66), dp(14), 0, 0)
                }
                setPadding(dp(14), 0, dp(14), 0)
                isClickable = true
                contentDescription = "Exit tab selection"
                setOnClickListener {
                    selectedTabs.clear()
                    selectingTabs = false
                    enterOverview(Mode.TABS, filterGroup)
                }
                pressable(this)
            }
            root.addView(closeSelection)
        }

        // Selection count is shown in the centered floating group pill above.
        // The bottom dock checkmark is the sole Done control during selection.

        return root
    }

    private fun tabCard(t: Tab, active: Boolean): LinearLayout {
        var pressX = dp(72).toFloat()
        var pressY = dp(42).toFloat()
        var pressTouchSize = dp(18).toFloat()
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            tag = (t.title + " " + (t.url ?: "")).lowercase()
            setPadding(dp(8), dp(8), dp(8), dp(10))
            background = getDrawable(if (selectedTabs.contains(t) || active) R.drawable.card_glass_active else R.drawable.card_glass)
            isClickable = true
            setOnClickListener {
                if (selectingTabs) {
                    if (selectedTabs.contains(t)) selectedTabs.remove(t) else selectedTabs.add(t)
                    enterOverview(Mode.TABS, filterGroup)
                } else {
                    val idx = tabs.indexOf(t)
                    if (idx >= 0) switchTo(idx)
                    exitOverview()
                }
            }
            pressable(this)
        }
        card.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_DOWN) {
                pressX = event.x - dp(8)
                pressY = event.y - dp(8)
                pressTouchSize = maxOf(event.touchMajor, event.touchMinor, dp(18).toFloat())
            }
            false
        }
        val preview = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(pal.thumbBg)
            }
            clipToOutline = true
        }
        card.setOnLongClickListener {
            val glow = View(this).apply {
                setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                val cx = pressX.coerceIn(0f, preview.width.toFloat().coerceAtLeast(1f))
                val cy = (pressY - dp(8)).coerceIn(0f, preview.height.toFloat().coerceAtLeast(1f))
                val touchDiameter = pressTouchSize
                val maxRadius = minOf(preview.width * 0.28f, preview.height * 0.48f).coerceAtLeast(dp(24).toFloat())
                val radius = minOf(maxOf(touchDiameter, dp(44).toFloat()), maxRadius)
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                paint.shader = android.graphics.RadialGradient(
                    cx, cy, radius,
                    intArrayOf(0xCCFFFFFF.toInt(), 0x66FFFFFF, 0x00FFFFFF),
                    floatArrayOf(0f, .48f, 1f), android.graphics.Shader.TileMode.CLAMP)
                background = object : android.graphics.drawable.Drawable() {
                    override fun draw(canvas: android.graphics.Canvas) { canvas.drawCircle(cx, cy, radius, paint) }
                    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
                    override fun setColorFilter(filter: android.graphics.ColorFilter?) { paint.colorFilter = filter }
                    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
                }
            }
            preview.addView(glow, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            glow.alpha = 0f
            glow.animate().alpha(1f).setDuration(100).withEndAction {
                glow.animate().alpha(0f).setDuration(230).withEndAction { preview.removeView(glow) }.start()
            }.start()
            showTabContextMenu(t)
            true
        }
        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Preview of ${t.title}"
        }
        val w = (resources.displayMetrics.widthPixels - dp(52)) / 2
        val h = (w * 1.24f).toInt().coerceAtLeast(dp(190))
        try {
            val picture = thumbFor(t)
            if (picture != null) {
                thumb.setImageBitmap(picture)
            } else if (t.web.parent != null && t.web.width > 0 && t.web.height > 0) {
                // nothing saved yet (a brand-new tab): draw whatever the page shows right now
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bmp)
                canvas.drawColor(pal.thumbBg)
                val scale = maxOf(w.toFloat() / t.web.width, h.toFloat() / t.web.height)
                canvas.translate((w - t.web.width * scale) / 2f, (h - t.web.height * scale) / 2f)
                canvas.scale(scale, scale)
                t.web.draw(canvas)
                thumb.setImageBitmap(bmp)
            }
        } catch (_: Exception) {}
        preview.addView(thumb, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, h))
        if (selectedTabs.contains(t)) {
            preview.foreground = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), 0xFF399BFF.toInt())
            }
            val selectedBadge = TextView(this).apply {
                text = "✓"
                gravity = android.view.Gravity.CENTER
                textSize = 12f
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFF299AF2.toInt())
                }
                elevation = dp(4).toFloat()
            }
            val badgeLp = FrameLayout.LayoutParams(dp(22), dp(22),
                android.view.Gravity.TOP or android.view.Gravity.END)
            badgeLp.setMargins(0, dp(4), dp(4), 0)
            preview.addView(selectedBadge, badgeLp)
        }
        val close = TextView(this).apply {
            text = "×"
            gravity = android.view.Gravity.CENTER
            textSize = 20f
            setTextColor(0xFFFF3B30.toInt())
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(pal.closeBadge) }
            contentDescription = "Close tab"
            setPadding(0, 0, 0, dp(2))
            setOnClickListener { closeTab(tabs.indexOf(t)); if (mode != Mode.BROWSING) enterOverview(Mode.TABS) }
            pressable(this)
        }
        val closeLp = FrameLayout.LayoutParams(dp(28), dp(28), android.view.Gravity.TOP or android.view.Gravity.END)
        closeLp.setMargins(0, dp(5), dp(5), 0)
        preview.addView(close, closeLp)
        card.setPadding(0, 0, 0, dp(5))
        card.background = null
        card.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h))
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(7), dp(2), 0)
        }
        val iconBitmap = if (t.isPrivate) null else iconFor(t)
        val favicon: View = if (iconBitmap != null) {
            ImageView(this).apply {
                setImageBitmap(iconBitmap)
                scaleType = ImageView.ScaleType.CENTER_CROP
                contentDescription = null
                background = GradientDrawable().apply { cornerRadius = dp(5).toFloat(); setColor(pal.fillSoft) }
                clipToOutline = true
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, dp(5).toFloat()) }
                }
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).also { it.marginEnd = dp(7); it.marginStart = dp(1) }
            }
        } else {
            // no icon known yet: a small tile with the site's first letter
            val host = try { android.net.Uri.parse(t.url ?: "").host.orEmpty().removePrefix("www.") } catch (_: Exception) { "" }
            TextView(this).apply {
                text = if (t.isPrivate) "◐" else (host.firstOrNull()?.uppercaseChar()?.toString() ?: "•")
                textSize = if (t.isPrivate) 13f else 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (t.isPrivate) pal.priv else pal.ink2)
                gravity = android.view.Gravity.CENTER
                if (!t.isPrivate) background = GradientDrawable().apply { cornerRadius = dp(5).toFloat(); setColor(pal.fillMid) }
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).also { it.marginEnd = dp(7); it.marginStart = dp(1) }
            }
        }
        titleRow.addView(favicon)
        titleRow.addView(TextView(this).apply {
            text = (if (t.isPinned) "📌 " else "") + t.title
            setTextColor(pal.ink)
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        card.addView(titleRow)
        return card
    }

    private fun showTabContextMenu(tab: Tab) {
        val card = menuCard()
        val url = tab.url ?: START_URL
        val idx = tabs.indexOf(tab)
        card.addView(menuRow(R.drawable.ic_copy, "Copy Link") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("link", url))
            dismissLater()
            toast("Link copied")
        })
        card.addView(menuRow(R.drawable.ic_pin, if (tab.isPinned) "Unpin Tab" else "Pin Tab") {
            tab.isPinned = !tab.isPinned
            dismissLater()
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuRow(R.drawable.ic_duplicate, "Duplicate Tab") {
            dismissLater()
            newTab(url, tab.isPrivate)
        })
        card.addView(menuRow(R.drawable.ic_select, "Select Tabs") {
            dismissLater()
            selectingTabs = true
            selectedTabs.clear()
            selectedTabs.add(tab)
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuRow(R.drawable.ic_move, "Move Tab", chevron = true) {
            dismissLater()
            showMoveSingleTab(tab)
        })
        card.addView(menuRow(R.drawable.ic_close, "Close Tab", destructive = true) {
            dismissLater()
            closeTab(idx)
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_close_others, "Close Other Tabs", destructive = true) {
            dismissLater()
            closeOtherTabs(tab)
        })
        showCard(card, Align.RIGHT)
    }

    private fun showMoveSingleTab(tab: Tab) {
        val card = menuCard()
        if (tab.isPrivate) {
            card.addView(menuRow(R.drawable.ic_mask, "Private") {
                tab.groupName = null
                dismissLater()
                enterOverview(Mode.TABS, "__PRIVATE__")
            })
        } else {
            card.addView(menuRow(R.drawable.ic_group, "Ungrouped") {
                tab.groupName = null
                saveTabGroups()
                dismissLater()
                enterOverview(Mode.TABS, null)
            })
            groups.forEach { group ->
                card.addView(menuRow(R.drawable.ic_group, group.first) {
                    tab.groupName = group.first
                    saveTabGroups()
                    dismissLater()
                    enterOverview(Mode.TABS, group.first)
                })
            }
            card.addView(menuRow(R.drawable.ic_new_group, "New Tab Group") {
                dismissLater()
                newGroupPrompt(listOf(tab))
            })
        }
        showCard(card, Align.RIGHT)
    }

    private fun showSelectedTabsMenu() {
        if (selectedTabs.isEmpty()) {
            selectingTabs = false
            enterOverview(Mode.TABS, filterGroup)
            return
        }
        val targets = selectedTabs.toList()
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_copy, "Copy Link(s)") {
            val links = targets.mapNotNull { it.url?.takeIf { url -> url.isNotBlank() } }
            if (links.isNotEmpty()) {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Selected tab links", links.joinToString("\\n")))
                toast("Links copied")
            } else toast("No links to copy")
            dismissLater()
        })
        card.addView(menuRow(R.drawable.ic_pin, "Pin Tabs") {
            targets.forEach { it.isPinned = true }
            selectedTabs.clear()
            selectingTabs = false
            dismissLater()
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuRow(R.drawable.ic_duplicate, "Duplicate Tabs") {
            val copies = targets.map { it.url?.takeIf { url -> url.isNotBlank() } to it.isPrivate }
            selectedTabs.clear()
            selectingTabs = false
            dismissLater()
            copies.forEach { (url, privateTab) -> newTab(url ?: START_URL, privateTab) }
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuRow(R.drawable.ic_move, "Move Tabs", chevron = true) {
            dismissLater()
            showMoveSelectedTabs()
        })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_close, "Close Tabs", destructive = true) {
            selectedTabs.clear()
            selectingTabs = false
            dismissLater()
            targets.map { tabs.indexOf(it) }.filter { it >= 0 }.sortedDescending().forEach { closeTab(it) }
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuRow(R.drawable.ic_close_others, "Close Other Tabs", destructive = true) {
            val keep = targets.toSet()
            val others = tabs.filter { it !in keep }.toList()
            selectedTabs.clear()
            selectingTabs = false
            dismissLater()
            others.map { tabs.indexOf(it) }.filter { it >= 0 }.sortedDescending().forEach { closeTab(it) }
            enterOverview(Mode.TABS, filterGroup)
        })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_new_group, "Move To New Tab Group") {
            dismissLater()
            newGroupPrompt(targets)
        })
        showCard(card, Align.TOP_LEFT, blurBehind = false)
    }

    private fun showMoveSelectedTabs() {
        val card = menuCard()
        val movingPrivate = selectedTabs.all { it.isPrivate }
        if (movingPrivate) {
            card.addView(menuRow(R.drawable.ic_mask, "Private") {
                selectedTabs.forEach { it.groupName = null }
                selectedTabs.clear()
                selectingTabs = false
                dismissLater()
                enterOverview(Mode.TABS, "__PRIVATE__")
            })
        } else {
            card.addView(menuRow(R.drawable.ic_group, "Ungrouped") {
                selectedTabs.filter { !it.isPrivate }.forEach { it.groupName = null }
                selectedTabs.clear()
                selectingTabs = false
                saveTabGroups()
                dismissLater()
                enterOverview(Mode.TABS, null)
            })
            groups.forEach { group ->
                card.addView(menuRow(R.drawable.ic_group, group.first) {
                    selectedTabs.filter { !it.isPrivate }.forEach { it.groupName = group.first }
                    selectedTabs.clear()
                    selectingTabs = false
                    saveTabGroups()
                    dismissLater()
                    enterOverview(Mode.TABS, group.first)
                })
            }
            card.addView(menuRow(R.drawable.ic_new_group, "New Tab Group") {
                dismissLater()
                newGroupPrompt(selectedTabs.toList())
            })
        }
        showCard(card, Align.RIGHT)
    }

    private fun closeOtherTabs(keep: Tab) {
        val closing = tabs.filter { it !== keep }
        closing.forEach { tab ->
            val idx = tabs.indexOf(tab)
            if (idx >= 0) {
                tabs.removeAt(idx)
                if (tab.isPrivate) privateCount = (privateCount - 1).coerceAtLeast(0)
                try { tab.web.destroy() } catch (_: Exception) {}
            }
        }
        current = tabs.indexOf(keep).coerceAtLeast(0)
        if (tabs.isEmpty()) newTab(START_URL) else attach()
        selectedTabs.clear()
        selectingTabs = false
        enterOverview(Mode.TABS, filterGroup)
    }

    private fun buildBookmarksPage(): View {
        val root = FrameLayout(this)
        val scroll = android.widget.ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            isFillViewport = true
            clipToPadding = false
            setPadding(0, 0, 0, dp(88))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, dp(14), dp(16))
        }
        scroll.addView(col)
        root.addView(scroll)
        col.addView(pageHeader("Bookmarks"))

        val search = EditText(this).apply {
            hint = "Search bookmarks and favourites"
            setSingleLine(true)
            textSize = 14f
            setTextColor(pal.ink)
            setHintTextColor(pal.ink3)
            setPadding(dp(16), 0, dp(16), 0)
            background = getDrawable(R.drawable.field_glass)
            compoundDrawablePadding = dp(8)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).also {
                it.setMargins(dp(4), dp(8), dp(4), dp(14))
            }
        }
        col.addView(search)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(content)

        fun readBucket(key: String): List<String> =
            (prefs().getString(key, "") ?: "").split("\n")
                .filter { it.isNotBlank() }.distinctBy { canonicalSavedUrl(it) }

        lateinit var render: (String) -> Unit

        fun removeSaved(url: String, key: String) {
            val next = readBucket(key).filter { canonicalSavedUrl(it) != canonicalSavedUrl(url) }
            prefs().edit().putString(key, next.joinToString("\n")).apply()
            render(search.text?.toString().orEmpty())
        }

        fun makeBookmarkCard(url: String, favourite: Boolean): View {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = getDrawable(R.drawable.card_glass)
                isClickable = true
                isFocusable = true
                setOnClickListener { exitOverview(); newTab(url) }
                pressable(this)
            }
            val preview = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(pal.bookmarkTile)
                }
                clipToOutline = true
            }
            val host = try { android.net.Uri.parse(url).host?.removePrefix("www.") ?: url } catch (_: Exception) { url }
            val initial = (host.substringBefore(".").firstOrNull()?.uppercaseChar() ?: '•').toString()
            val mark = TextView(this).apply {
                text = initial
                gravity = android.view.Gravity.CENTER
                textSize = 36f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(pal.ink)
                background = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(pal.bookmarkMark)
                }
            }
            preview.addView(mark, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(112)))
            val type = TextView(this).apply {
                text = if (favourite) "★ FAVOURITE" else "◆ BOOKMARK"
                textSize = 9f
                letterSpacing = .12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFFE8622A.toInt())
                setPadding(dp(2), dp(9), dp(2), dp(5))
            }
            val title = TextView(this).apply {
                text = prettyUrl(url)
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(pal.ink)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(dp(2), dp(2), dp(2), 0)
            }
            val address = TextView(this).apply {
                text = host
                textSize = 10.5f
                setTextColor(pal.ink3)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(dp(2), dp(3), dp(2), 0)
            }
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.END or android.view.Gravity.CENTER_VERTICAL
            }
            val open = TextView(this).apply {
                text = "Open"
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFFE8622A.toInt())
                setPadding(dp(8), dp(8), dp(12), dp(4))
                setOnClickListener { exitOverview(); newTab(url) }
                isClickable = true
                pressable(this)
            }
            val delete = TextView(this).apply {
                text = "Remove"
                textSize = 11f
                setTextColor(pal.ink2)
                setPadding(dp(8), dp(8), dp(4), dp(4))
                setOnClickListener {
                    removeSaved(url, if (favourite) "list_favs" else "list_bookmarks")
                }
                isClickable = true
                pressable(this)
            }
            actions.addView(open)
            actions.addView(delete)
            card.addView(preview)
            card.addView(type)
            card.addView(title)
            card.addView(address)
            card.addView(actions)
            card.setOnLongClickListener {
                android.app.AlertDialog.Builder(this)
                    .setTitle(prettyUrl(url))
                    .setItems(arrayOf("Open in new tab", "Remove")) { _, which ->
                        if (which == 0) { exitOverview(); newTab(url) }
                        else removeSaved(url, if (favourite) "list_favs" else "list_bookmarks")
                    }.show()
                true
            }
            return card
        }

        fun addGridSection(label: String, entries: List<String>, favourite: Boolean, query: String) {
            val filtered = entries.filter {
                query.isBlank() || (prettyUrl(it) + " " + it).contains(query, ignoreCase = true)
            }
            if (filtered.isEmpty()) return
            content.addView(TextView(this).apply {
                text = "$label · ${filtered.size}"
                textSize = 10f
                letterSpacing = .16f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(pal.ink2)
                setPadding(dp(7), dp(13), dp(7), dp(7))
            })
            var row: LinearLayout? = null
            filtered.forEachIndexed { index, url ->
                if (index % 2 == 0) {
                    row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = android.view.Gravity.TOP
                    }
                    content.addView(row, LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                }
                val card = makeBookmarkCard(url, favourite)
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(dp(4), dp(4), dp(4), dp(8))
                row?.addView(card, lp)
                if (index % 2 == 1) row?.let { it.addView(View(this), LinearLayout.LayoutParams(0, 1, 0f)) }
            }
            if (filtered.size % 2 == 1) {
                row?.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
        }

        render = { queryRaw ->
            content.removeAllViews()
            val query = queryRaw.trim()
            val favs = readBucket("list_favs")
            val marks = readBucket("list_bookmarks")
            addGridSection("Favourites", favs, true, query)
            addGridSection("Bookmarks", marks, false, query)
            if (content.childCount == 0) {
                content.addView(TextView(this).apply {
                    text = if (query.isBlank()) "Nothing saved yet. Save a page from the browser menu and it will appear here."
                    else "No saved pages match “$query”."
                    setTextColor(pal.ink3)
                    textSize = 13.5f
                    setLineSpacing(dp(3).toFloat(), 1f)
                    setPadding(dp(12), dp(18), dp(12), dp(10))
                })
            }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                render(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        render("")
        return root
    }

    private fun buildPrivacyPage(): View {
        val root = FrameLayout(this)
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(14), dp(4), dp(14), dp(24))
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll)
        content.addView(pageHeader("Privacy"))

        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = getDrawable(R.drawable.card_glass)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(3), dp(6), dp(3), dp(8))
            layoutParams = lp
        }
        fun heading(text: String): TextView = TextView(this).apply {
            this.text = text
            textSize = 10f
            letterSpacing = .13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFE8622A.toInt())
            setPadding(0, 0, 0, dp(8))
        }
        fun body(text: String): TextView = TextView(this).apply {
            this.text = text
            textSize = 12.5f
            setTextColor(pal.ink2)
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        fun toggleRow(title: String, description: String, key: String, default: Boolean, onChanged: ((Boolean) -> Unit)? = null) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            texts.addView(TextView(this).apply {
                text = title
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(pal.ink)
            })
            texts.addView(body(description))
            val sw = android.widget.Switch(this).apply {
                isChecked = prefs().getBoolean(key, default)
                setOnCheckedChangeListener { _, checked ->
                    prefs().edit().putBoolean(key, checked).apply()
                    onChanged?.invoke(checked)
                }
            }
            row.addView(texts)
            row.addView(sw)
            (content.getChildAt(content.childCount - 1) as? LinearLayout)?.addView(row)
        }

        val status = card()
        status.addView(heading("PROTECTION STATUS"))
        status.addView(TextView(this).apply {
            text = String.format(java.util.Locale.US, "%,d", privacyBlockedCount.get())
            textSize = 34f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(pal.ink)
        })
        status.addView(body("Known tracker and advertising requests blocked since this counter was last reset. This is a request count, not a count of unique trackers."))
        content.addView(status)

        val protection = card()
        protection.addView(heading("TRACKING PROTECTION"))
        content.addView(protection)
        toggleRow("Block known trackers", "Blocks requests to Valley's built-in list of known advertising and tracking domains.", "privacy_tracking_protection", true)

        val cookies = card()
        cookies.addView(heading("COOKIES"))
        content.addView(cookies)
        toggleRow("Allow third-party cookies", "Off by default. Some websites may need this enabled to work correctly.", "privacy_third_party_cookies", false) { enabled ->
            tabs.forEach { tab ->
                try { CookieManager.getInstance().setAcceptThirdPartyCookies(tab.web, enabled) } catch (_: Exception) {}
            }
            toast(if (enabled) "Third-party cookies allowed" else "Third-party cookies blocked")
        }

        val site = card()
        site.addView(heading("CURRENT WEBSITE"))
        val domain = privacyDomain()
        site.addView(body(domain ?: "Open a website to manage its tracker exception."))
        if (domain != null) {
            val exceptions = (prefs().getString("privacy_allowed_domains", "") ?: "")
                .split("\n").map { it.trim() }.filter { it.isNotEmpty() }.toMutableSet()
            val isAllowed = exceptions.contains(domain)
            site.addView(TextView(this).apply {
                text = if (isAllowed) "Remove tracker exception" else "Allow trackers on this website"
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFFE8622A.toInt())
                setPadding(0, dp(14), 0, dp(2))
                isClickable = true
                setOnClickListener {
                    val latest = (prefs().getString("privacy_allowed_domains", "") ?: "")
                        .split("\n").map { it.trim() }.filter { it.isNotEmpty() }.toMutableSet()
                    if (latest.contains(domain)) latest.remove(domain) else latest.add(domain)
                    prefs().edit().putString("privacy_allowed_domains", latest.joinToString("\n")).apply()
                    enterOverview(Mode.PRIVACY)
                }
                pressable(this)
            })
        }
        content.addView(site)

        val data = card()
        data.addView(heading("BROWSING DATA"))
        data.addView(body("Clear cookies and cached website files stored by Android WebView. This signs you out of websites and may reset site preferences."))
        data.addView(TextView(this).apply {
            text = "Clear cookies and cache"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFE8622A.toInt())
            setPadding(0, dp(14), 0, dp(2))
            isClickable = true
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Clear website data?")
                    .setMessage("This removes cookies and cached website files for Valley. You may be signed out of websites.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Clear") { _, _ ->
                        try {
                            CookieManager.getInstance().removeAllCookies {
                                CookieManager.getInstance().flush()
                            }
                            tabs.forEach { try { it.web.clearCache(true) } catch (_: Exception) {} }
                            toast("Cookies and cache cleared")
                        } catch (_: Exception) { toast("Could not clear all website data") }
                    }.show()
            }
            pressable(this)
        })
        data.addView(TextView(this).apply {
            text = "Reset blocked-request counter"
            textSize = 12f
            setTextColor(pal.ink2)
            setPadding(0, dp(12), 0, 0)
            isClickable = true
            setOnClickListener {
                privacyBlockedCount.set(0)
                prefs().edit().putInt("privacy_blocked_count", 0).apply()
                enterOverview(Mode.PRIVACY)
            }
            pressable(this)
        })
        content.addView(data)
        content.addView(body("Valley uses a built-in domain blocklist and Android WebView cookie controls. This is not a complete anonymity system: websites can still identify visitors through first-party storage and fingerprinting."))
        return root
    }

    // ---------------------------------------------------------------- url bar

    private fun editUrl() {
        val card = menuCard()
        val input = EditText(this).apply {
            setText(if (web.url == null || web.url!!.contains(HOST)) "" else web.url)
            setSingleLine(true)
            setTextColor(pal.ink)
            setHintTextColor(pal.ink3)
            hint = getString(R.string.url_hint)
            textSize = 15f
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = getDrawable(R.drawable.field_glass)
            setSelection(text.length)
        }
        card.addView(input, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val go = TextView(this).apply {
            text = "Go"
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFF150C07.toInt())
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(13), 0, dp(13))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(0xFFE8622A.toInt())
            }
            isClickable = true
            setOnClickListener {
                val typed = input.text.toString().trim()
                if (typed.isNotEmpty()) web.loadUrl(toUrl(typed))
                dismissLater()
            }
            pressable(this)
        }
        card.addView(go, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also {
            it.setMargins(0, dp(10), 0, 0)
        })

        showCard(card, Align.FULL)
        input.requestFocus()
        input.postDelayed({
            try {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            } catch (e: Exception) {}
        }, 260)
    }

    /**
     * The floating pill has its own search box, so it must use the same smart-routing rules
     * as Valley's homepage rather than treating every non-host query as a plain Brave search.
     * URLs and explicit navigation commands always remain navigation, even with smart search off.
     */
    private fun routeSearch(input: String, smart: Boolean): String {
        val q = input.trim()
        if (q.isEmpty()) return START_URL
        if (Regex("^[a-z][a-z0-9+.-]*://", RegexOption.IGNORE_CASE).containsMatchIn(q)) return q
        val bareHost = Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE)
        if (!q.contains(Regex("\\s")) && bareHost.matches(q)) return "https://$q"

        val sites = linkedMapOf(
            "flipkart" to "https://www.flipkart.com/search?q=",
            "amazon" to "https://www.amazon.in/s?k=",
            "myntra" to "https://www.myntra.com/search?q=",
            "ajio" to "https://www.ajio.com/search/?text=",
            "croma" to "https://www.croma.com/searchB?q=",
            "snapdeal" to "https://www.snapdeal.com/search?keyword=",
            "meesho" to "https://www.meesho.com/search?q=",
            "nykaa" to "https://www.nykaa.com/search/result/?q=",
            "tatacliq" to "https://www.tatacliq.com/search/?searchCategory=all&text=",
            "reliancedigital" to "https://www.reliancedigital.in/search?q=",
            "swiggy" to "https://www.swiggy.com/search?query=",
            "zomato" to "https://www.zomato.com/search?q=",
            "bookmyshow" to "https://in.bookmyshow.com/explore/movies?q=",
            "paytm" to "https://paytm.com/",
            "github" to "https://github.com/search?q=",
            "wikipedia" to "https://en.wikipedia.org/w/index.php?search=",
            "youtube" to "https://www.youtube.com/results?search_query=",
            "reddit" to "https://www.reddit.com/search/?q=",
            "stackoverflow" to "https://stackoverflow.com/search?q=",
            "quora" to "https://www.quora.com/search?q=",
            "imdb" to "https://www.imdb.com/find?q=",
            "cricbuzz" to "https://www.cricbuzz.com/search?q=",
            "ndtv" to "https://www.ndtv.com/search?searchtext="
        )
        val known = listOf(
            "google.com","youtube.com","facebook.com","instagram.com","whatsapp.com","x.com","twitter.com",
            "reddit.com","wikipedia.org","linkedin.com","pinterest.com","quora.com","medium.com","github.com",
            "gitlab.com","stackoverflow.com","npmjs.com","vercel.com","netlify.com","amazon.in","amazon.com",
            "flipkart.com","myntra.com","ajio.com","meesho.com","snapdeal.com","nykaa.com","croma.com",
            "reliancedigital.in","tatacliq.com","paytm.com","phonepe.com","swiggy.com","zomato.com","zepto.com",
            "blinkit.com","bigbasket.com","bookmyshow.com","makemytrip.com","irctc.co.in","redbus.in","uber.com",
            "ndtv.com","thehindu.com","hindustantimes.com","indianexpress.com","bbc.com","cnn.com","reuters.com",
            "theguardian.com","nytimes.com","netflix.com","primevideo.com","hotstar.com","spotify.com","soundcloud.com",
            "imdb.com","cricbuzz.com","espn.com","apple.com","microsoft.com","samsung.com","oneplus.in","mi.com",
            "realme.com","vivo.com","adobe.com","figma.com","canva.com","notion.so","slack.com","discord.com",
            "telegram.org","chatgpt.com","claude.ai","perplexity.ai","sarvam.ai","accuweather.com","timeanddate.com",
            "britannica.com","dictionary.com","archive.org","wordpress.com","substack.com"
        )
        fun distance(a: String, b: String): Int {
            var prev = IntArray(b.length + 1) { it }
            for (i in a.indices) {
                val cur = IntArray(b.length + 1)
                cur[0] = i + 1
                for (j in b.indices) cur[j + 1] = minOf(
                    prev[j + 1] + 1, cur[j] + 1,
                    prev[j] + if (a[i] == b[j]) 0 else 1
                )
                prev = cur
            }
            return prev[b.length]
        }
        fun nearestSite(word: String): String? {
            val w = word.lowercase().replace(Regex("[^a-z0-9]"), "")
            if (w.length < 3) return null
            var best: String? = null
            var bestDistance = Int.MAX_VALUE
            for (host in known) {
                val base = host.substringBefore('.').replace(Regex("[^a-z0-9]"), "")
                var d = distance(w, base)
                if (base.startsWith(w)) d = minOf(d, 1)
                if (d < bestDistance) { bestDistance = d; best = host }
            }
            val limit = if (w.length <= 4) 1 else if (w.length <= 7) 2 else 3
            return if (best != null && bestDistance <= limit) "https://$best" else null
        }
        fun navTarget(raw: String): String? {
            val target = raw.trim().trimEnd('.', '。', ',', '\'', '"').trim()
            if (target.isEmpty()) return null
            val key = target.lowercase().replace(Regex("\\s+"), "")
            sites[key]?.let { value ->
                return try { val uri = java.net.URI(value); "${uri.scheme}://${uri.authority}" } catch (_: Exception) { null }
            }
            if (Regex("^[a-z0-9-]+$", RegexOption.IGNORE_CASE).matches(target)) {
                return nearestSite(target) ?: "https://${target.lowercase()}.com"
            }
            if (Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE).matches(target)) {
                return "https://$target"
            }
            return null
        }

        val nav = Regex("^(?:open|go\\s+to|goto|visit|launch)\\s+(.+)$", RegexOption.IGNORE_CASE).matchEntire(q)
        if (nav != null) navTarget(nav.groupValues[1])?.let { return it }
        val brave = "https://search.brave.com/search?q="
        if (!smart) return brave + android.net.Uri.encode(q)
        if (Regex("^(what|who|whom|whose|why|how|when|where|which|is|are|was|were|am|do|does|did|can|could|should|would|will|has|have|had)\\b", RegexOption.IGNORE_CASE)
                .containsMatchIn(q) || q.endsWith("?")) return brave + android.net.Uri.encode(q)

        for ((name, endpoint) in sites) {
            if (Regex("\\b${Regex.escape(name)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(q)) {
                val terms = q.replace(Regex("\\b${Regex.escape(name)}\\b", RegexOption.IGNORE_CASE), " ")
                    .replace(Regex("^\\s*(price of|prices|price|cost of|cost|buy|buying|best|where to buy|order)\\s+", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("\\s+\\b(on|from|at|in)\\s*$", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("\\s+"), " ").trim()
                return if (endpoint.endsWith("/" ) && name == "paytm") endpoint else endpoint + android.net.Uri.encode(terms.ifEmpty { q })
            }
        }
        return brave + android.net.Uri.encode(q)
    }

    private fun toUrl(input: String): String {
        val t = input.trim()
        if (t.startsWith("http://") || t.startsWith("https://") || t.startsWith("file://")) return t
        val looksLikeHost = !t.contains(" ") &&
                Regex("^[^\\s/?#]+\\.[a-z]{2,}([/?#].*)?$", RegexOption.IGNORE_CASE).containsMatchIn(t)
        return if (looksLikeHost) "https://$t"
        else "https://search.brave.com/search?q=" + URLEncoder.encode(t, "UTF-8")
    }

    private fun startBrowserDownload(url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
        runOnUiThread {
            try {
                val uri = android.net.Uri.parse(url)
                if (uri.scheme != "https" && uri.scheme != "http") {
                    toast("This download type is not supported")
                    return@runOnUiThread
                }
                val filename = URLUtil.guessFileName(url, contentDisposition, mimeType).replace(Regex("[\\/:*?\"<>|]"), "_")
                val request = DownloadManager.Request(uri).apply {
                    setTitle(filename)
                    setDescription("Downloading with Valley")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setAllowedOverMetered(true)
                    setAllowedOverRoaming(false)
                    if (!userAgent.isNullOrBlank()) addRequestHeader("User-Agent", userAgent)
                    val cookies = CookieManager.getInstance().getCookie(url)
                    if (!cookies.isNullOrBlank()) addRequestHeader("Cookie", cookies)
                    if (!mimeType.isNullOrBlank()) setMimeType(mimeType)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                }
                val id = downloadManager.enqueue(request)
                val all = readDownloadRecords()
                all.put(JSONObject().put("id", id).put("title", filename).put("url", url).put("mime", mimeType ?: "")
                    .put("status", "Downloading").put("total", 0L).put("done", 0L).put("time", System.currentTimeMillis()))
                writeDownloadRecords(all)
                showDownloadStatus("Downloading", filename, DownloadStatusKind.PROGRESS, id)
                refreshDownloadsPage()
                scheduleDownloadPolling()
            } catch (e: Exception) {
                toast("Couldn't start download: ${e.message ?: "unknown error"}")
            }
        }
    }

    // ---- permanent downloads list -------------------------------------------------
    // Valley keeps its own record of every download (SharedPreferences), so the list survives
    // restarts, cleared notifications and DownloadManager housekeeping. Entries only disappear
    // when the person removes them.

    private fun readDownloadRecords(): JSONArray =
        try { JSONArray(prefs().getString("valley_downloads", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    private fun writeDownloadRecords(arr: JSONArray) {
        prefs().edit().putString("valley_downloads", arr.toString()).apply()
    }

    private fun downloadFileExists(rec: JSONObject): Boolean {
        val path = rec.optString("path")
        if (path.isBlank()) return true
        return try { java.io.File(path).exists() } catch (_: Exception) { true }
    }

    /** refreshes every stored record from DownloadManager, persists it, and returns the list (newest first) */
    private fun syncDownloadRecords(): List<JSONObject> {
        val all = readDownloadRecords()
        val recs = ArrayList<JSONObject>()
        for (i in 0 until all.length()) all.optJSONObject(i)?.let { recs.add(it) }
        var changed = false
        for (rec in recs) {
            val st0 = rec.optString("status")
            if (st0 == "Downloaded" || st0 == "Failed") continue
            val id = rec.optLong("id")
            var found = false
            try {
                downloadManager.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                    if (c.moveToFirst()) {
                        found = true
                        val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        val state = when (status) {
                            DownloadManager.STATUS_SUCCESSFUL -> "Downloaded"
                            DownloadManager.STATUS_FAILED -> "Failed"
                            DownloadManager.STATUS_PAUSED -> "Paused"
                            DownloadManager.STATUS_PENDING -> "Queued"
                            else -> "Downloading"
                        }
                        val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        rec.put("status", state).put("total", total).put("done", done)
                        if (state == "Downloaded") {
                            rec.put("done", if (total > 0) total else done)
                            val local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                            if (!local.isNullOrBlank()) {
                                rec.put("path", android.net.Uri.parse(local).path ?: "")
                            }
                            val mt = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE))
                            if (!mt.isNullOrBlank()) rec.put("mime", mt)
                            rec.put("time", System.currentTimeMillis())
                        }
                        changed = true
                    }
                }
            } catch (_: Exception) {}
            if (!found) { rec.put("status", "Failed"); changed = true }   // cancelled or purged before it finished
        }
        if (changed) {
            val out = JSONArray(); for (r in recs) out.put(r); writeDownloadRecords(out)
        }
        return recs.sortedByDescending { it.optLong("time") }
    }

    private fun buildDownloadsJson(): String {
        val array = JSONArray()
        for (rec in syncDownloadRecords()) {
            val copy = JSONObject(rec.toString())
            copy.put("missing", rec.optString("status") == "Downloaded" && !downloadFileExists(rec))
            array.put(copy)
        }
        return array.toString()
    }

    private var downloadPolling = false
    private fun scheduleDownloadPolling() {
        if (downloadPolling) return
        downloadPolling = true
        val tick = object : Runnable {
            override fun run() {
                val live = syncDownloadRecords().filter {
                    val st = it.optString("status"); st == "Downloading" || st == "Queued" || st == "Paused"
                }
                refreshDownloadsPage()
                if (live.isNotEmpty()) updateDownloadProgress(live.first())
                if (live.isEmpty() || isDestroyed) downloadPolling = false else handler().postDelayed(this, 900)
            }
        }
        handler().postDelayed(tick, 700)
    }

    private fun handler(): Handler = uiHandler
    private val uiHandler = Handler(Looper.getMainLooper())

    private fun refreshDownloadsPage() {
        try {
            val payload = JSONObject.quote(buildDownloadsJson())
            web.evaluateJavascript("window.valleyRenderDownloads && window.valleyRenderDownloads($payload)", null)
        } catch (_: Exception) {}
    }

    private fun openDownloadedFile(id: Long) {
        try {
            val rec = readDownloadRecords().let { a ->
                (0 until a.length()).mapNotNull { a.optJSONObject(it) }.firstOrNull { it.optLong("id") == id }
            }
            if (rec == null || rec.optString("status") != "Downloaded") { toast("This download isn't complete yet"); return }
            var uri: android.net.Uri? = try { downloadManager.getUriForDownloadedFile(id) } catch (_: Exception) { null }
            if (uri == null && android.os.Build.VERSION.SDK_INT >= 29) {
                // DownloadManager forgot it (e.g. cleared elsewhere): find the file in the public Downloads collection
                val coll = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI
                contentResolver.query(coll, arrayOf(android.provider.MediaStore.Downloads._ID),
                    android.provider.MediaStore.Downloads.DISPLAY_NAME + "=?", arrayOf(rec.optString("title")), null)?.use { c ->
                    if (c.moveToFirst()) uri = android.content.ContentUris.withAppendedId(coll, c.getLong(0))
                }
            }
            val target = uri
            if (target == null) { toast("This file is no longer on the device"); return }
            val mime = rec.optString("mime").ifBlank { contentResolver.getType(target) ?: "*/*" }
            val intent = Intent(Intent.ACTION_VIEW).setDataAndType(target, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val isApk = mime == "application/vnd.android.package-archive" ||
                rec.optString("title").lowercase().endsWith(".apk")
            if (isApk) {
                AlertDialog.Builder(this)
                    .setTitle(rec.optString("title").ifBlank { "APK" })
                    .setItems(arrayOf("Install", "Show in Files Manager")) { d, which ->
                        d.dismiss()
                        try {
                            if (which == 0) startActivity(intent) else showDownloadsInFileManager()
                        } catch (_: Exception) { toast("No app can open this file") }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                return
            }
            startActivity(Intent.createChooser(intent, "Open downloaded file"))
        } catch (_: Exception) {
            toast("No app can open this file")
        }
    }

    /** opens the device's Downloads folder in the file manager */
    private fun showDownloadsInFileManager() {
        try {
            val dir = Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload")
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(dir, "vnd.android.document/directory")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) { toast("No file manager is available") }
        }
    }

    private fun isStartUrl(url: String?): Boolean {
        val u = url ?: return false
        val base = u.substringBefore('#')
        return base == START_URL || base.startsWith(START_URL + "?")
    }

    /** opens one of the Valley start-page views (history, downloads...) in the current tab */
    private fun openHomeView(view: String) {
        if (active.isPrivate) { newTab("$START_URL#$view"); return }
        val cur = web.url
        if (isStartUrl(cur)) {
            web.evaluateJavascript(
                "(function(){try{history.replaceState(null,'','#$view');}catch(e){}" +
                "window.ulaaShowView&&window.ulaaShowView('$view');})()", null)
            if (view == "downloads") refreshDownloadsPage()
        } else {
            web.loadUrl("$START_URL#$view")
        }
    }

    // ---- download status pill ---------------------------------------------------------
    private enum class DownloadStatusKind { PROGRESS, DONE, FAILED }

    private fun hideDownloadStatus() {
        val v = downloadToast ?: return
        downloadToast = null
        handler().removeCallbacks(downloadToastHide)
        v.animate().alpha(0f).translationY(dp(24).toFloat()).scaleX(.94f).scaleY(.94f).setDuration(220)
            .withEndAction { (v.parent as? ViewGroup)?.removeView(v) }.start()
    }

    private fun updateDownloadProgress(rec: JSONObject) {
        val v = downloadToast ?: return
        if (v.tag != "progress") return
        val bar = v.findViewWithTag<View>("bar") ?: return
        val track = v.findViewWithTag<View>("track") ?: return
        val total = rec.optLong("total"); val done = rec.optLong("done")
        val frac = if (total > 0) (done.toFloat() / total).coerceIn(0.03f, 1f) else 0.08f
        val lp = bar.layoutParams
        lp.width = (track.width * frac).toInt().coerceAtLeast(dp(6))
        bar.layoutParams = lp
    }

    /** A glass pill that slides up above the toolbar: spinner + progress while downloading, a tick + Open when done. */
    private fun showDownloadStatus(headline: String, filename: String, kind: DownloadStatusKind, id: Long) {
        runOnUiThread {
            val root = findViewById<ViewGroup>(android.R.id.content)
            (downloadToast?.parent as? ViewGroup)?.removeView(downloadToast)
            handler().removeCallbacks(downloadToastHide)

            val accent = when (kind) {
                DownloadStatusKind.DONE -> 0xFF4ADE80.toInt()
                DownloadStatusKind.FAILED -> 0xFFFF6B5E.toInt()
                else -> 0xFFFF9B62.toInt()
            }
            val pill = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(16), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(30).toFloat()
                    setColor(pal.toast)
                    setStroke(dp(1), pal.line)
                }
                elevation = dp(14).toFloat()
                tag = if (kind == DownloadStatusKind.PROGRESS) "progress" else "status"
            }
            val badge = FrameLayout(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor((accent and 0x00FFFFFF) or 0x2E000000) }
            }
            if (kind == DownloadStatusKind.PROGRESS) {
                badge.addView(android.widget.ProgressBar(this).apply {
                    isIndeterminate = true
                    indeterminateTintList = android.content.res.ColorStateList.valueOf(accent)
                }, FrameLayout.LayoutParams(dp(22), dp(22), android.view.Gravity.CENTER))
            } else {
                badge.addView(TextView(this).apply {
                    text = if (kind == DownloadStatusKind.DONE) "\u2713" else "!"
                    setTextColor(accent); textSize = 18f; gravity = android.view.Gravity.CENTER
                    setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
                }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            }
            pill.addView(badge, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(12) })

            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply {
                text = headline; setTextColor(pal.ink); textSize = 13.5f
                setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
            })
            col.addView(TextView(this).apply {
                text = filename; setTextColor(pal.ink2); textSize = 12f
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            })
            if (kind == DownloadStatusKind.PROGRESS) {
                val track = FrameLayout(this).apply {
                    tag = "track"
                    background = GradientDrawable().apply { cornerRadius = dp(2).toFloat(); setColor(pal.fillTrack) }
                }
                track.addView(View(this).apply {
                    tag = "bar"
                    background = GradientDrawable().apply { cornerRadius = dp(2).toFloat(); setColor(accent) }
                }, FrameLayout.LayoutParams(dp(8), dp(3)))
                col.addView(track, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)).apply { topMargin = dp(6) })
            }
            pill.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            if (kind == DownloadStatusKind.DONE) {
                pill.addView(TextView(this).apply {
                    text = "Open"; setTextColor(pal.onInk); textSize = 12.5f
                    setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
                    setPadding(dp(14), dp(7), dp(14), dp(7))
                    background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(pal.ink) }
                    setOnClickListener { hideDownloadStatus(); openDownloadedFile(id) }
                }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(12) })
            }
            pill.setOnClickListener { hideDownloadStatus() }

            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(84); leftMargin = dp(16); rightMargin = dp(16)
            }
            pill.minimumWidth = dp(240)
            pill.alpha = 0f; pill.translationY = dp(28).toFloat(); pill.scaleX = .94f; pill.scaleY = .94f
            root.addView(pill, lp)
            pill.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(320)
                .setInterpolator(Motion.spring).start()
            downloadToast = pill
            if (kind != DownloadStatusKind.PROGRESS) handler().postDelayed(downloadToastHide, 4500)
            else handler().postDelayed(downloadToastHide, 3500)
        }
    }

    // ---------------------------------------------------------------- menus

    private fun showPageMenu() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_share, "Share") { shareCurrent() })
        card.addView(menuRow(R.drawable.ic_star, "Add to Favourites") { saveLink("favs") })
        card.addView(menuRow(R.drawable.ic_download, "Downloads") {
            dismissLater()
            openHomeView("downloads")
        })
        card.addView(menuRow(R.drawable.ic_bookmark, "Add Bookmark to\u2026") { saveLink("bookmarks") })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { newTab(START_URL) })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { privateTab() })
        card.addView(twoUpRow())
        showCard(card, Align.RIGHT)
    }

    private fun showPageTools() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_translate, "Translate page") { js("window.ulaaTranslate && window.ulaaTranslate()") })
        card.addView(menuRow(R.drawable.ic_eraser, "Hide Distracting Items") { startEraser() })
        card.addView(menuRow(R.drawable.ic_summary, "Summarise page") { js("window.ulaaSummarise && window.ulaaSummarise()") })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_smart, "Smart search") { showSmartSearch() })
        card.addView(menuRow(R.drawable.ic_copy, "Copy link") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("link", web.url ?: ""))
            toast("Link copied")
        })
        card.addView(menuRow(R.drawable.ic_home, "Home") { web.loadUrl(START_URL) })
        card.addView(menuDivider())
        val desktopEnabled = tabs.getOrNull(current)?.desktopMode == true
        card.addView(menuRow(if (desktopEnabled) R.drawable.ic_mobile else R.drawable.ic_desktop, if (desktopEnabled) "Use mobile site" else "Desktop site") {
            setDesktopMode(!desktopEnabled)
        })
        card.addView(menuRow(R.drawable.ic_zoom_in, "Zoom in") { adjustPageZoom(1) })
        card.addView(menuRow(R.drawable.ic_zoom_out, "Zoom out") { adjustPageZoom(-1) })
        card.addView(menuRow(R.drawable.ic_zoom_reset, "Reset zoom") { resetPageZoom() })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_print, "Print / Save as PDF") { printCurrentPage() })
        showCard(card, Align.RIGHT)
    }

    private fun showBackForward() {
        val card = menuCard()

        // Keep the two direction selectors on the first row.
        val directions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(2))
        }
        directions.addView(arrowCell(R.drawable.ic_chevron_left, "Back", !navForward) {
            navForward = false
            applyNavMode()
            dismissLater()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        directions.addView(arrowCell(R.drawable.ic_chevron_right, "Forward", navForward) {
            navForward = true
            applyNavMode()
            dismissLater()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(directions)

        // Bottom row: shorter selected-direction action, with a separate circular Home control
        // immediately to its right (matching the requested screenshot layout).
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val primaryAction = TextView(this).apply {
            text = if (navForward) "Forward" else "Back"
            gravity = android.view.Gravity.CENTER
            textSize = 14f
            setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
            setTextColor(pal.ink)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(pal.button)
            }
            isClickable = true
            setOnClickListener {
                val target = web
                if (navForward) {
                    if (target.canGoForward()) target.goForward() else toast("No page to go forward to")
                } else {
                    if (target.canGoBack()) target.goBack() else toast("No page to go back to")
                }
                dismissLater()
                refreshBack()
            }
            pressable(this)
        }
        actionRow.addView(primaryAction, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            marginEnd = dp(10)
        })

        val homeButton = ImageView(this).apply {
            setImageResource(R.drawable.ic_home)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(pal.button)
                setStroke(dp(1), pal.line)
            }
            contentDescription = "Home"
            isClickable = true
            isFocusable = true
            setOnClickListener {
                dismissLater()
                web.loadUrl(START_URL)
            }
            pressable(this)
        }
        actionRow.addView(homeButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        card.addView(actionRow)
        showCard(card, Align.LEFT, panelWidthDp = 280)
    }

    private fun arrowCell(icon: Int, label: String, selected: Boolean, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            isClickable = true
            setPadding(0, dp(10), 0, dp(8))
            setOnClickListener { onClick() }
            pressable(this)
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
        })
        // the label sits directly under its arrow, full brightness either way
        box.addView(TextView(this).apply {
            text = label
            setTextColor(if (selected) pal.ink else pal.ink2)
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    /** the left circle shows only the direction that is currently selected */
    private fun applyNavMode() {
        val navBtn = findViewById<ImageButton>(R.id.back)
        navBtn.setImageResource(if (navForward) R.drawable.ic_chevron_right else R.drawable.ic_back)
        navBtn.contentDescription = if (navForward) "Forward" else "Back"
        toolbarJs("window.ulaaForward && window.ulaaForward(" + navForward + ")")
        toolbarJs("window.ulaaNavLabel && window.ulaaNavLabel(" + org.json.JSONObject.quote(if (navForward) "Forward" else "Back") + ")")
        refreshBack()
    }

    private fun privateTab() {
        val card = menuCard()
        card.addView(titleBlock("New Private Tab",
            "No site storage, no cache, third-party cookies off. When you close the last private " +
            "tab, every cookie is wiped \u2014 which also signs you out of your normal tabs, because " +
            "Android shares one cookie jar."))
        card.addView(primaryButton("Open private tab", 0xFF7B3FF2.toInt()) {
            dismissLater(); newTab(START_URL, true)
        })
        showCard(card, Align.RIGHT)
    }

    private fun titleBlock(title: String, body: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(6))
        }
        box.addView(TextView(this).apply {
            text = title
            setTextColor(pal.ink)
            textSize = 16.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, dp(8))
        })
        box.addView(TextView(this).apply {
            text = body
            setTextColor(pal.ink2)
            textSize = 13f
            setLineSpacing(dp(3).toFloat(), 1f)
        })
        return box
    }

    private fun primaryButton(label: String, colour: Int, onClick: () -> Unit): TextView {
        val b = TextView(this).apply {
            text = label
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFF150C07.toInt())
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(13), 0, dp(13))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat(); setColor(colour)
            }
            isClickable = true
            setOnClickListener { onClick() }
            pressable(this)
        }
        b.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .also { it.setMargins(dp(10), dp(10), dp(10), dp(8)) }
        return b
    }

    private fun showAddTabMenu() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { dismissLater(); exitOverview(); newTab(START_URL, filterGroup == "__PRIVATE__") })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { dismissLater(); exitOverview(); newTab(START_URL, true) })
        showCard(card, Align.LEFT)
    }


    // Tab groups are stored as names plus their member URLs. Tabs not assigned to a
    // named group remain in Personal; private tabs are always kept separate.
    private fun saveTabGroups() {
        val array = org.json.JSONArray()
        groups.forEach { group ->
            val item = org.json.JSONObject()
            item.put("name", group.first)
            val urls = org.json.JSONArray()
            tabs.filter { !it.isPrivate && it.groupName == group.first }
                .mapNotNull { it.url }
                .distinct()
                .forEach { urls.put(it) }
            item.put("urls", urls)
            array.put(item)
        }
        prefs().edit().putString("valley_tab_groups_v1", array.toString()).apply()
    }

    private fun loadTabGroups() {
        groups.clear()
        val raw = prefs().getString("valley_tab_groups_v1", null) ?: return
        try {
            val array = org.json.JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val name = item.optString("name").trim()
                if (name.isEmpty() || name == "Personal" || name == "Private") continue
                val urls = mutableListOf<String>()
                val members = item.optJSONArray("urls") ?: org.json.JSONArray()
                for (j in 0 until members.length()) {
                    val url = members.optString(j)
                    if (url.isNotBlank() && !urls.contains(url)) urls.add(url)
                }
                if (groups.none { it.first.equals(name, true) }) groups.add(name to urls)
            }
        } catch (_: Exception) { groups.clear() }
    }

    private fun groupOrphanTabs(): List<Tab> {
        return tabs.filter { tab -> !tab.isPrivate && tab.groupName == null }
    }

    private fun showGroupNameDialog(title: String, initial: String = "", onCreate: (String) -> Unit) {
        val input = EditText(this).apply {
            hint = "Name"
            setText(initial)
            setSingleLine(true)
            textSize = 16f
            setTextColor(pal.popInk)
            setHintTextColor(pal.popHint)
            setPadding(dp(16), dp(13), dp(16), dp(13))
            background = getDrawable(R.drawable.field_glass)
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(4), dp(22), 0)
            addView(input, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrap)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setTextColor(0xFF0A84FF.toInt())
            dialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(0xFFFF453A.toInt())
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    input.error = "Enter a name"
                    return@setOnClickListener
                }
                if (name.equals("Personal", true) || name.equals("Private", true)) {
                    input.error = "That name is reserved"
                    return@setOnClickListener
                }
                if (groups.any { it.first.equals(name, true) && !it.first.equals(initial, true) }) {
                    input.error = "A group with this name already exists"
                    return@setOnClickListener
                }
                onCreate(name)
                dialog.dismiss()
            }
            input.requestFocus()
        }
        dialog.show()
    }

    private fun buildManageTabGroupsPage(): View {
        val root = FrameLayout(this)
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(14), dp(4), dp(14), dp(24))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll)

        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.card_glass)
            setPadding(dp(16), dp(6), dp(16), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.setMargins(dp(3), dp(6), dp(3), dp(8)) }
        }
        fun icon(res: Int): ImageView = ImageView(this).apply {
            setImageResource(res)
            imageTintList = android.content.res.ColorStateList.valueOf(0xFFE8622A.toInt())
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(5), dp(9), dp(5), dp(9))
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(42)).also { it.marginEnd = dp(8) }
        }
        fun divider(parent: LinearLayout) {
            parent.addView(View(this).apply {
                setBackgroundColor(pal.fillFaint)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).also {
                    it.setMargins(dp(42), dp(2), dp(0), dp(2))
                }
            })
        }
        fun actionText(label: String, color: Int, click: () -> Unit): TextView =
            TextView(this).apply {
                text = label
                textSize = 12.5f
                setTextColor(color)
                gravity = android.view.Gravity.CENTER
                setPadding(dp(9), dp(8), dp(9), dp(8))
                isClickable = true
                setOnClickListener { click() }
            }

        val header = pageHeader("Tab Groups")
        val edit = actionText(if (editingTabGroups) "Finish" else "Edit", 0xFFE8622A.toInt()) {
            editingTabGroups = !editingTabGroups
            enterOverview(Mode.MANAGE_GROUPS)
        }.apply { setTypeface(typeface, Typeface.BOLD); textSize = 13f }
        header.addView(edit, 1)
        content.addView(header)

        val groupsCard = card()
        val personalCount = groupOrphanTabs().size
        val personalRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            minimumHeight = dp(42)
            addView(icon(R.drawable.ic_tabs))
            addView(TextView(this@MainActivity).apply {
                text = "Personal  —  $personalCount ${if (personalCount == 1) "Tab" else "Tabs"}"
                textSize = 14.5f
                setTextColor(pal.ink)
                gravity = android.view.Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            })
            addView(TextView(this@MainActivity).apply {
                text = "✓"
                textSize = 16f
                setTextColor(0xFFE8622A.toInt())
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(30), dp(40))
            })
            isClickable = true
            setOnClickListener { enterOverview(Mode.TABS) }
        }
        groupsCard.addView(personalRow)
        if (groups.isNotEmpty()) divider(groupsCard)
        groups.forEachIndexed { index, group ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                minimumHeight = dp(42)
            }
            row.addView(icon(R.drawable.ic_group))
            val count = tabs.count { !it.isPrivate && it.groupName == group.first }
            row.addView(TextView(this).apply {
                text = group.first + if (count > 0) "  —  $count Tabs" else ""
                textSize = 14.5f
                setTextColor(pal.ink)
                gravity = android.view.Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            })
            if (editingTabGroups) {
                row.addView(actionText("Rename", 0xFFE8622A.toInt()) {
                    showGroupNameDialog("Name", group.first) { newName ->
                        val oldName = group.first
                        groups[index] = newName to group.second
                        tabs.filter { !it.isPrivate && it.groupName == oldName }.forEach { it.groupName = newName }
                        saveTabGroups()
                        enterOverview(Mode.MANAGE_GROUPS)
                    }
                })
                row.addView(actionText("Delete", 0xFFFF453A.toInt()) {
                    val deletedName = group.first
                    tabs.filter { !it.isPrivate && it.groupName == deletedName }.forEach { it.groupName = null }
                    groups.removeAt(index)
                    saveTabGroups()
                    enterOverview(Mode.MANAGE_GROUPS)
                })
            } else {
                row.isClickable = true
                row.setOnClickListener { enterOverview(Mode.TABS, group.first) }
            }
            groupsCard.addView(row)
            if (index != groups.lastIndex) divider(groupsCard)
        }
        content.addView(groupsCard)

        // Private is deliberately isolated from regular tab groups.
        val privateCard = card()
        val privateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            minimumHeight = dp(44)
            addView(icon(R.drawable.ic_mask))
            addView(TextView(this@MainActivity).apply {
                text = "Private"
                textSize = 14.5f
                setTextColor(pal.ink)
                gravity = android.view.Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
            })
            addView(TextView(this@MainActivity).apply {
                text = "${tabs.count { it.isPrivate }} Tabs"
                textSize = 12f
                setTextColor(pal.ink2)
                gravity = android.view.Gravity.CENTER
            })
            isClickable = true
            setOnClickListener { enterOverview(Mode.TABS, "__PRIVATE__") }
        }
        privateCard.addView(privateRow)
        content.addView(privateCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(12)
        })

        val createCard = card()
        val emptyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            minimumHeight = dp(44)
            addView(icon(R.drawable.ic_plus))
            addView(TextView(this@MainActivity).apply {
                text = "New Empty Tab Group"
                textSize = 14.5f
                setTextColor(pal.ink)
                gravity = android.view.Gravity.CENTER_VERTICAL
            })
            isClickable = true
            setOnClickListener {
                showGroupNameDialog("Name") { name ->
                    if (groups.none { it.first.equals(name, true) }) {
                        groups.add(name to mutableListOf())
                        saveTabGroups()
                        enterOverview(Mode.MANAGE_GROUPS)
                    }
                }
            }
        }
        createCard.addView(emptyRow)
        divider(createCard)
        val orphanCount = groupOrphanTabs().size
        val moveRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            minimumHeight = dp(44)
            addView(icon(R.drawable.ic_plus))
            addView(TextView(this@MainActivity).apply {
                text = "New Tab Group with $orphanCount ${if (orphanCount == 1) "Tab" else "Tabs"}"
                textSize = 14.5f
                setTextColor(pal.ink)
                gravity = android.view.Gravity.CENTER_VERTICAL
            })
            isClickable = true
            setOnClickListener {
                showGroupNameDialog("Name") { name ->
                    if (groups.none { it.first.equals(name, true) }) {
                        val orphanTabs = groupOrphanTabs()
                        groups.add(name to mutableListOf())
                        orphanTabs.forEach { it.groupName = name }
                        saveTabGroups()
                        enterOverview(Mode.MANAGE_GROUPS)
                    }
                }
            }
        }
        createCard.addView(moveRow)
        content.addView(createCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also {
            it.topMargin = dp(12)
        })
        return root
    }

    private fun showTabActions() {
        val card = menuCard()
        card.addView(menuRow(R.drawable.ic_group, "Manage Tab Groups") {
            dismissLater()
            enterOverview(Mode.MANAGE_GROUPS)
        })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_mask, "Private") {
            dismissLater()
            enterOverview(Mode.TABS, "__PRIVATE__")
        })
        // Show only groups the user has actually created. Never synthesize placeholders.
        groups.map { it.first }.forEach { groupName ->
            card.addView(menuRow(R.drawable.ic_group, groupName) {
                dismissLater()
                enterOverview(Mode.TABS, groupName)
            })
        }
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_close, "Close This Tab", destructive = true) {
            dismissLater()
            closeTab(current)
            if (tabs.isNotEmpty()) enterOverview(Mode.TABS) else exitOverview()
        })
        card.addView(menuRow(R.drawable.ic_close, "Close All ${tabs.size} tabs", destructive = true) {
            dismissLater(); closeAllTabs()
        })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_new_group, "New Tab Group") { dismissLater(); newGroupPrompt() })
        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_tabs, "${tabs.size} ${if (tabs.size == 1) "Tab" else "Tabs"}  ·  View All") {
            dismissLater(); enterOverview(Mode.TABS)
        })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { dismissLater(); exitOverview(); newTab(START_URL, true) })
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { dismissLater(); exitOverview(); newTab(START_URL) })
        showCard(card, Align.RIGHT)
    }

    private fun closeAllTabs() {
        for (i in tabs.indices.reversed()) {
            val t = tabs.removeAt(i)
            if (t.isPrivate) privateCount = (privateCount - 1).coerceAtLeast(0)
            try { t.web.destroy() } catch (e: Exception) {}
        }
        newTab(START_URL)
        enterOverview(Mode.TABS)
    }

    private fun showMoveToGroup() {
        val card = menuCard()
        val url = web.url ?: START_URL
        if (groups.isEmpty()) {
            card.addView(menuRow(R.drawable.ic_new_group, "No groups yet \u2014 create one") { dismissLater(); newGroupPrompt() })
        } else {
            groups.forEach { g ->
                card.addView(menuRow(R.drawable.ic_group, g.first) {
                    if (!active.isPrivate) active.groupName = g.first
                    dismissLater()
                    saveTabGroups()
                    toast("Moved to " + g.first)
                })
            }
        }
        showCard(card, Align.RIGHT)
    }

    private fun newGroupPrompt(tabsToAssign: List<Tab> = listOf(active)) {
        val card = menuCard()
        val input = EditText(this).apply {
            hint = "Group name"
            setHintTextColor(pal.ink3)
            setTextColor(pal.ink)
            textSize = 16.5f
            setSingleLine(true)
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = getDrawable(R.drawable.field_glass)
        }
        card.addView(input)
        card.addView(primaryButton("Create group", 0xFFE8622A.toInt()) {
            val name = input.text.toString().trim()
            if (name.isNotEmpty()) {
                if (groups.none { it.first.equals(name, true) }) groups.add(name to mutableListOf())
                tabsToAssign.filter { !it.isPrivate }.forEach { it.groupName = name }
                selectedTabs.clear()
                selectingTabs = false
                saveTabGroups()
                toast("Created " + name)
                dismissLater()
                enterOverview(Mode.TABS, name)
            } else {
                toast("Give the group a name")
            }
        })
        showCard(card, Align.RIGHT)
        input.requestFocus()
        input.postDelayed({
            try {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            } catch (e: Exception) {}
        }, 260)
    }

    private fun showTabs() {
        val card = menuCard()

        tabs.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(9), dp(9), dp(7), dp(9))
                isClickable = true
                setOnClickListener {
                    switchTo(i)
                    dismissLater()
                }
                pressable(this)
            }
            val dot = TextView(this).apply {
                text = if (i == current) "\u25CF" else "\u25CB"
                setTextColor(if (i == current) 0xFFE8622A.toInt() else pal.textDimmer)
                textSize = 12f
                setPadding(0, 0, dp(10), 0)
            }
            val label = TextView(this).apply {
                text = (if (t.isPrivate) "\u25D0  " else "") + t.title
                setTextColor(if (t.isPrivate) pal.priv else pal.ink)
                textSize = 14.5f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val close = TextView(this).apply {
                text = "\u00d7"
                setTextColor(pal.lineSelected)
                textSize = 18f
                setPadding(dp(10), 0, dp(6), 0)
                isClickable = true
                setOnClickListener {
                    // Compress the selected card before removing it, matching the pill's spring.
                    isEnabled = false
                    animate().alpha(0f).scaleX(0.94f).scaleY(0.94f)
                        .translationY(-dp(5).toFloat()).setDuration(190)
                        .setInterpolator(Motion.collapse)
                        .withEndAction { dismissLater(); closeTab(i) }.start()
                }
                pressable(this)
            }
            row.addView(dot); row.addView(label); row.addView(close)
            row.alpha = 0f
            row.translationY = dp(12).toFloat()
            row.scaleX = 0.97f
            row.scaleY = 0.97f
            card.addView(row)
            row.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay((i * 32L).coerceAtMost(192L))
                .setDuration(Motion.D_EXPAND).setInterpolator(Motion.spring).start()
        }

        card.addView(menuDivider())
        card.addView(menuRow(R.drawable.ic_plus, "New Tab") { dismissLater(); newTab(START_URL) })
        card.addView(menuRow(R.drawable.ic_mask, "New Private Tab") { dismissLater(); newTab(START_URL, true) })
        showCard(card, Align.LEFT)
    }

    private fun showBookmarks() {
        val favs = (prefs().getString("list_favs", "") ?: "").split("\n").filter { it.isNotBlank() }
        val marks = (prefs().getString("list_bookmarks", "") ?: "").split("\n").filter { it.isNotBlank() }
        val card = menuCard()
        if (favs.isEmpty() && marks.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Nothing saved yet. Long-press \u22EF and choose Add to Favourites."
                setTextColor(pal.ink3)
                textSize = 13.5f
                setPadding(dp(14), dp(16), dp(14), dp(16))
            }
            card.addView(empty)
            showCard(card, Align.RIGHT)
            return
        }
        favs.forEach { url -> card.addView(linkRow("\u2605", url)) }
        marks.forEach { url -> card.addView(linkRow("\u25C6", url)) }
        showCard(card, Align.RIGHT)
    }

    private fun linkRow(mark: String, url: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(9), dp(9), dp(8), dp(9))
            isClickable = true
            setOnClickListener { dismissLater(); newTab(url) }
            pressable(this)
        }
        row.addView(TextView(this).apply {
            text = mark
            setTextColor(0xFFE8622A.toInt())
            textSize = 13f
            setPadding(0, 0, dp(12), 0)
        })
        row.addView(TextView(this).apply {
            text = prettyUrl(url)
            setTextColor(pal.ink)
            textSize = 14.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        return row
    }

    private fun showSmartSearch() {
        val card = menuCard()
        card.addView(titleBlock("Smart search",
            "When on, a query that names a site opens that site's own search \u2014 " +
            "\u201cprice of oneplus nord ce6 on Flipkart\u201d lands on Flipkart's results. " +
            "When off, everything goes to Brave exactly as typed."))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), 0, dp(10), dp(10))
        }
        row.addView(primaryButton("Turn on", 0xFFE8622A.toInt()) {
            prefs().edit().putBoolean("smart_search", true).apply()
            js("window.ulaaSmartSet && window.ulaaSmartSet(true)")
            toast("Smart search on")
            dismissLater()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(primaryButton("Turn off", pal.offButton) {
            prefs().edit().putBoolean("smart_search", false).apply()
            js("window.ulaaSmartSet && window.ulaaSmartSet(false)")
            toast("Smart search off")
            dismissLater()
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(row)
        showCard(card, Align.RIGHT)
    }

    // ---------------------------------------------------------------- menu pieces

    private fun twoUpRow(): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(dp(166), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        row.addView(bigTile(R.drawable.ic_bookmarks, "Bookmarks") {
            dismissLater(); enterOverview(Mode.BOOKMARKS)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(bigTile(R.drawable.ic_tabs, "All Tabs") {
            dismissLater(); enterOverview(Mode.TABS)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    private fun weight() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    private fun bigTile(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(10), 0, dp(12))
            isClickable = true
            setOnClickListener { onClick() }
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(pal.ink)
            textSize = 11.5f
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun dirTile(icon: Int, label: String, enabled: Boolean, onClick: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            isClickable = true
            alpha = if (enabled) 1f else 0.35f
            setOnClickListener { onClick() }
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(pal.ink)
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun segment(label: String, active: Boolean, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.gravity = android.view.Gravity.CENTER
        tv.textSize = 13f
        tv.setPadding(0, dp(9), 0, dp(9))
        tv.setTextColor(if (active) pal.ink else pal.lineSelected)
        if (active) {
            tv.background = GradientDrawable().apply {
                cornerRadius = dp(999).toFloat(); setColor(pal.fillMid)
            }
        }
        tv.isClickable = true
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---- motion: the app should feel like the pill, not like a settings screen ----

    /**
     * White touch feedback. Short controls get a bounded ripple whose radius
     * reaches the element's top and bottom. Large surfaces get a circular
     * ripple based on the finger contact size, capped before it can span the width.
     */
    private fun applyWhiteTouchGlow(view: View, event: MotionEvent) {
        val w = view.width.coerceAtLeast(1)
        val h = view.height.coerceAtLeast(1)
        val smallElement = h <= dp(64) && w <= dp(360)
        val fingerDiameter = maxOf(event.touchMajor, event.touchMinor, dp(18).toFloat())
        val radius = if (smallElement) {
            h / 2
        } else {
            minOf(fingerDiameter, minOf(w * 0.28f, h * 0.48f).coerceAtLeast(dp(20).toFloat())).toInt()
        }
        val mask = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = (view.background as? android.graphics.drawable.GradientDrawable)
                ?.let { minOf(w, h) / 2f } ?: dp(18).toFloat()
            setColor(android.graphics.Color.WHITE)
        }
        val ripple = android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(pal.rippleGlow),
            null,
            mask
        )
        ripple.radius = radius.coerceAtLeast(dp(12))
        view.foreground = ripple
        ripple.setHotspot(event.x, event.y)
        ripple.state = intArrayOf(android.R.attr.state_pressed, android.R.attr.state_enabled)
    }

    /** press feedback: white bounded glow plus squash on touch down, spring back on release */
    private fun pressable(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    applyWhiteTouchGlow(view, e)
                    view.animate().scaleX(0.92f).scaleY(0.92f)
                        .setDuration(90).setInterpolator(null).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    (view.foreground as? android.graphics.drawable.RippleDrawable)
                        ?.setHotspot(e.x, e.y)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    (view.foreground as? android.graphics.drawable.RippleDrawable)?.state = intArrayOf()
                    view.animate().scaleX(1f).scaleY(1f)
                        .setDuration(240).setInterpolator(Motion.spring)
                        .withEndAction { view.foreground = null }.start()
                }
            }
            false
        }
    }

    /** the toolbar rises into place on launch */
    private fun enterToolbar() {
        val bar = findViewById<View>(R.id.toolbar)
        bar.translationY = dp(56).toFloat()
        bar.alpha = 0f
        bar.animate().translationY(0f).alpha(1f)
            .setStartDelay(120).setDuration(Motion.D_EXPAND)
            .setInterpolator(Motion.spring).start()
    }

    /** the left circle does one thing at a time: back, or forward, whichever you picked */
    private var navForward = false

    private enum class Mode { BROWSING, TABS, BOOKMARKS, MANAGE_GROUPS, PRIVACY }

    private var mode = Mode.BROWSING
    private var filterGroup: String? = null

    /** tab groups: a name and the pages that belong to it */
    private val groups = ArrayList<Pair<String, MutableList<String>>>()

    /** scrolling down tucks the toolbar to its minimum, scrolling up brings it back */
    private fun watchScroll(w: WebView) {
        w.setOnScrollChangeListener { _, _, y, _, oldY ->
            val dy = y - oldY
            if (toolbarGone) { if (dy < -12) showBar() }
            else if (dy > 12) minimiseBar(true) else if (dy < -12) minimiseBar(false)
            // Do not capture and blur the whole page while the user is scrolling.
            // The page-backed frost is refreshed after navigation settles instead.
        }
    }

    private var barHidden = false

    /** scrolling down shrinks the pill to its essentials; scrolling up brings it back */
    private fun minimiseBar(min: Boolean) {
        if (barHidden == min) return
        barHidden = min
        val bar = findViewById<ViewGroup>(R.id.toolbar)

        val t = android.transition.AutoTransition()
        t.duration = if (min) Motion.D_COLLAPSE else Motion.D_EXPAND
        t.interpolator = if (min) Motion.ease
                         else Motion.spring
        try { android.transition.TransitionManager.beginDelayedTransition(bar, t) } catch (e: Exception) {}

        findViewById<View>(R.id.reader).visibility = if (min) View.GONE else View.VISIBLE
        findViewById<View>(R.id.reload).visibility = if (min) View.GONE else View.VISIBLE

        try {
            val pill = findViewById<View>(R.id.pill)
            val lp = pill.layoutParams as LinearLayout.LayoutParams
            if (min) { lp.weight = 0f; lp.width = dp(132) } else { lp.weight = 1f; lp.width = 0 }
            pill.layoutParams = lp
        } catch (e: Exception) {}

        toolbarJs("window.ulaaBig && window.ulaaBig(" + !min + ")")
        // the side pills go away entirely when minimised, the way the spark drops them
        listOf(R.id.back, R.id.settings).forEach { id ->
            findViewById<View>(id).visibility = if (min) View.GONE else View.VISIBLE
        }

        // the address never truncates: it shrinks a little and fades out at both edges,
        // staying scrollable sideways
        try {
            urlView.textSize = if (min) 11.5f else 14f
            urlView.maxWidth = Int.MAX_VALUE
            urlView.ellipsize = null
            urlView.isSingleLine = true
            val scroll = findViewById<View>(R.id.urlScroll) as android.widget.HorizontalScrollView
            scroll.isHorizontalFadingEdgeEnabled = true
            scroll.isFillViewport = true
            scroll.scrollTo(0, 0)
        } catch (e: Exception) {}

        // motion blur across the move, plus a slight dim, exactly like the collapse on the web
        val pill = findViewById<View>(R.id.pill)
        pill.alpha = if (min) 0.88f else 1f
        pill.animate().alpha(1f).setDuration(if (min) Motion.D_COLLAPSE else Motion.D_EXPAND).start()
        motionBlur(pill, if (min) Motion.D_COLLAPSE else Motion.D_EXPAND)

        if (!min) {
            pill.animate().scaleX(1.04f).scaleY(1.04f).setDuration(140)
                .withEndAction {
                    pill.animate().scaleX(1f).scaleY(1f).setDuration(340)
                        .setInterpolator(Motion.spring).start()
                }.start()
            
        }
    }

    /**
     * The spark blurs its own text while the pill collapses. Android can do the same on 12+ with
     * a RenderEffect: ramp the blur up and back down across the animation, then clear it.
     */
    private fun motionBlur(view: View, duration: Long) {
        if (android.os.Build.VERSION.SDK_INT < 31) return
        try {
            val anim = android.animation.ValueAnimator.ofFloat(0f, 1f)
            anim.duration = duration
            anim.interpolator = Motion.collapse
            anim.addUpdateListener { va ->
                val t = (va.animatedValue as Float) * Math.PI
                val r = (Math.sin(t).toFloat().coerceAtLeast(0f)) * 6f
                try {
                    view.setRenderEffect(
                        android.graphics.RenderEffect.createBlurEffect(
                            r.coerceAtLeast(0.01f), r.coerceAtLeast(0.01f),
                            android.graphics.Shader.TileMode.CLAMP))
                } catch (e: Exception) {}
            }
            anim.addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    try { view.setRenderEffect(null) } catch (e: Exception) {}
                }
            })
            anim.start()
        } catch (e: Exception) {}
    }

    /** true while the whole toolbar is slid off screen ("Hide Address Bar") */
    private var toolbarGone = false
    private var barHandle: View? = null

    /** slides the real toolbar (the toolbar WebView) off the bottom and leaves a small handle to bring it back */
    private fun hideBar() {
        if (toolbarGone) return
        toolbarGone = true
        val tw = findViewById<WebView>(R.id.toolbarWeb)
        tw.animate().cancel()
        tw.animate().translationY((tw.height + dp(24)).toFloat()).alpha(0f)
            .setDuration(Motion.D_COLLAPSE).setInterpolator(Motion.ease)
            .withEndAction { if (toolbarGone) tw.visibility = View.INVISIBLE }
            .start()
        showBarHandle(true)
    }

    private fun showBar() {
        if (!toolbarGone) { minimiseBar(false); return }
        toolbarGone = false
        val tw = findViewById<WebView>(R.id.toolbarWeb)
        tw.animate().cancel()
        tw.visibility = View.VISIBLE
        tw.animate().translationY(0f).alpha(1f)
            .setDuration(Motion.D_EXPAND).setInterpolator(Motion.spring).start()
        showBarHandle(false)
    }

    private fun showBarHandle(show: Boolean) {
        val root = findViewById<ViewGroup>(R.id.root)
        var h = barHandle
        if (h == null) {
            val grip = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(3).toFloat()
                    setColor((pal.ink and 0x00FFFFFF) or 0x99000000.toInt())
                }
            }
            h = FrameLayout(this).apply {
                isClickable = true
                elevation = dp(12).toFloat()
                setOnClickListener { showBar() }
                addView(grip, FrameLayout.LayoutParams(dp(44), dp(5),
                    android.view.Gravity.CENTER))
            }
            root.addView(h, FrameLayout.LayoutParams(dp(140), dp(34),
                android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL))
            barHandle = h
        }
        h.animate().cancel()
        if (show) {
            h.visibility = View.VISIBLE
            h.alpha = 0f
            h.animate().alpha(1f).setStartDelay(160).setDuration(220).start()
        } else {
            h.animate().alpha(0f).setStartDelay(0).setDuration(140)
                .withEndAction { if (!toolbarGone) h.visibility = View.GONE }.start()
        }
    }

    /** sheets rise from the bottom with a spring, the way the pill's menus do */
    private fun animateSheetIn(card: View) {
        card.alpha = 0f
        card.translationY = dp(22).toFloat()
        card.scaleX = 0.94f
        card.scaleY = 0.94f
        card.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(360).setInterpolator(Motion.ease).start()
    }

    /** rows fade up one after another */
    private fun staggerRows(card: LinearLayout) {
        for (i in 0 until card.childCount) {
            val child = card.getChildAt(i)
            child.alpha = 0f
            child.translationY = dp(10).toFloat()
            child.animate().alpha(1f).translationY(0f)
                .setStartDelay((60L + i * 34L))
                .setDuration(260)
                .setInterpolator(Motion.ease).start()
        }
    }

    private fun menuCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(6), dp(6), dp(6), dp(6))
        background = getDrawable(R.drawable.sheet_glass)
        clipToOutline = false
    }

    private fun menuDivider(): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            dp(120), dp(1)).also { it.setMargins(dp(49), dp(6), dp(4), dp(6)) }
        setBackgroundColor(pal.fillSoft)
    }

    private fun menuRow(
        icon: Int,
        label: String,
        chevron: Boolean = false,
        destructive: Boolean = false,
        onClick: () -> Unit
    ): LinearLayout {
        val tint = if (destructive) 0xFFFF3B30.toInt() else pal.ink
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            minimumHeight = dp(38)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            isClickable = true
            setOnClickListener { onClick() }
        }
        row.addView(ImageView(this).apply {
            setImageResource(icon)
            if (destructive) setColorFilter(0xFFFF3B30.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(18))
        })
        row.addView(TextView(this).apply {
            text = label
            setTextColor(tint)
            textSize = 14f
            setPadding(dp(13), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        })
        if (chevron) {
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_chevron_right)
                alpha = 0.45f
                layoutParams = LinearLayout.LayoutParams(dp(15), dp(15))
            })
        }
        // press highlight, the way iOS dims a row under the finger
        row.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> applyWhiteTouchGlow(view, e)
                MotionEvent.ACTION_MOVE ->
                    (view.foreground as? android.graphics.drawable.RippleDrawable)?.setHotspot(e.x, e.y)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    (view.foreground as? android.graphics.drawable.RippleDrawable)?.state = intArrayOf()
            }
            false
        }
        return row
    }

    private var lastDialog: Dialog? = null

    enum class Align { LEFT, RIGHT, FULL, TOP_LEFT }

    private fun showCard(card: LinearLayout, align: Align = Align.RIGHT, blurBehind: Boolean = true, panelWidthDp: Int? = null) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val wrap = FrameLayout(this)
        val sidePad = dp(12)
        // Compact popup anchored above the toolbar, leaving the page visible.
        if (align == Align.TOP_LEFT) wrap.setPadding(sidePad, dp(64), sidePad, dp(10))
        else wrap.setPadding(sidePad, dp(10), sidePad, dp(76))

        val screen = resources.displayMetrics.widthPixels
        // Measure the actual menu content so the sheet fits its longest option,
        // with a small breathing margin, instead of clipping long labels at 204dp.
        card.measure(
            View.MeasureSpec.makeMeasureSpec(screen - dp(32), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val contentWidth = card.measuredWidth + dp(12)
        val narrow = Math.min(panelWidthDp?.let { dp(it) } ?: contentWidth.coerceAtLeast(dp(184)), screen - dp(32))
        val scroller = object : android.widget.ScrollView(this) {
            private val maxPanelHeight = dp(7 * 42 + 28)
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(widthMeasureSpec,
                    View.MeasureSpec.makeMeasureSpec(maxPanelHeight, View.MeasureSpec.AT_MOST))
            }
        }.apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = false
            isVerticalFadingEdgeEnabled = true
            setFadingEdgeLength(dp(14))
            clipToOutline = true
        }
        scroller.addView(card, android.view.ViewGroup.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT))
        val cardParams = FrameLayout.LayoutParams(
            if (align == Align.FULL) FrameLayout.LayoutParams.MATCH_PARENT else narrow,
            FrameLayout.LayoutParams.WRAP_CONTENT)
        cardParams.gravity = when (align) {
            Align.LEFT -> android.view.Gravity.START or android.view.Gravity.BOTTOM
            Align.RIGHT -> android.view.Gravity.END or android.view.Gravity.BOTTOM
            Align.FULL -> android.view.Gravity.CENTER_HORIZONTAL or android.view.Gravity.BOTTOM
            Align.TOP_LEFT -> android.view.Gravity.TOP or android.view.Gravity.START
        }
        wrap.addView(scroller, cardParams)
        wrap.setOnClickListener { dismissLater() }
        scroller.setOnClickListener { /* consume taps inside the panel */ }
        dialog.setContentView(wrap)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            if (blurBehind) {
                addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                setDimAmount(0.22f)
            } else {
                clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                setDimAmount(0f)
            }
            if (blurBehind && android.os.Build.VERSION.SDK_INT >= 31) {
                try {
                    addFlags(android.view.WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                    attributes = attributes.apply { blurBehindRadius = dp(18) }
                } catch (_: Exception) {}
            }
            val lp = attributes
            lp.width = android.view.WindowManager.LayoutParams.MATCH_PARENT
            lp.height = android.view.WindowManager.LayoutParams.MATCH_PARENT
            lp.gravity = android.view.Gravity.BOTTOM
            attributes = lp
        }
        // Ignore the release that opened a long-press menu.
        dialog.setCancelable(true)
        dialog.setCanceledOnTouchOutside(true)
        lastDialog = dialog
        dialog.setOnShowListener {
            animateSheetIn(card)
            staggerRows(card)
        }
        dialog.show()
    }

    private fun dismissLater() {
        val d = lastDialog
        lastDialog = null
        try { d?.dismiss() } catch (e: Exception) {}
    }

    // ---------------------------------------------------------------- misc

    private fun isNavigationVerb(q: String): Boolean =
        Regex("^(open|go to|goto|visit|launch)\\b", RegexOption.IGNORE_CASE).containsMatchIn(q.trim())

    private fun isQuestion(q: String): Boolean {
        val t = q.trim().lowercase()
        return t.endsWith("?") || Regex("^(what|who|why|how|is|are|when|where|which|can|does|do)\\b").containsMatchIn(t)
    }

    private fun addToList(key: String) {
        val url = web.url ?: return
        val all = (prefs().getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
        if (!all.contains(url)) all.add(0, url)
        prefs().edit().putString(key, all.joinToString("\n")).apply()
        toast("Saved")
    }

    private fun shareCurrent() {
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, web.url ?: "")
        }
        startActivity(android.content.Intent.createChooser(intent, "Share"))
    }

    private fun prefs(): SharedPreferences = getSharedPreferences("valley", MODE_PRIVATE)

    private fun readHistoryArray(key: String): org.json.JSONArray {
        return try { org.json.JSONArray(prefs().getString(key, "[]") ?: "[]") }
        catch (_: Exception) { org.json.JSONArray() }
    }

    private fun recordSearchQuery(query: String) {
        synchronized(historyLock) {
        val q = query.trim()
        if (q.isEmpty()) return
        val old = readHistoryArray("history_searches")
        val next = org.json.JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (!item.optString("q").equals(q, ignoreCase = true)) next.put(item)
        }
        next.put(org.json.JSONObject().put("q", q).put("t", System.currentTimeMillis()))
        val capped = org.json.JSONArray()
        for (i in 0 until minOf(next.length(), 200)) capped.put(next.get(i))
        prefs().edit().putString("history_searches", capped.toString()).commit()
        }
    }

    private fun removeSearchQuery(query: String) {
        synchronized(historyLock) {
        val old = readHistoryArray("history_searches")
        val next = org.json.JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (!item.optString("q").equals(query, ignoreCase = true)) next.put(item)
        }
        prefs().edit().putString("history_searches", next.toString()).commit()
        }
    }

    private fun removeOpenedPage(rawUrl: String) {
        synchronized(historyLock) {
        val target = canonicalSavedUrl(rawUrl)
        val old = readHistoryArray("history_opened")
        val next = org.json.JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (canonicalSavedUrl(item.optString("u")) != target) next.put(item)
        }
        prefs().edit().putString("history_opened", next.toString()).commit()
        }
    }

    private fun recordOpenedPage(rawUrl: String, title: String?) {
        synchronized(historyLock) {
        val url = rawUrl.trim()
        if (url.isBlank() || url.startsWith("about:") || url.startsWith("data:") ||
            url.contains("appassets.androidplatform.net/assets/index.html") ||
            url.substringBefore("#").trimEnd('/') == START_URL.trimEnd('/')) return
        val old = readHistoryArray("history_opened")
        val next = org.json.JSONArray()
        val canonical = canonicalSavedUrl(url)
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (canonicalSavedUrl(item.optString("u")) != canonical) next.put(item)
        }
        next.put(org.json.JSONObject()
            .put("u", url)
            .put("n", title?.takeIf { it.isNotBlank() } ?: prettyUrl(url))
            .put("t", System.currentTimeMillis()))
        val capped = org.json.JSONArray()
        for (i in 0 until minOf(next.length(), 200)) capped.put(next.get(i))
        prefs().edit().putString("history_opened", capped.toString()).commit()
        }
    }

    private fun syncHistoryWithHomepage() {
        // The page pulls the native snapshot itself (ValleyHistory.snapshot) on every render.
        // Pushing a copy into localStorage from here could land after a delete and bring it back.
        web.evaluateJavascript("window.ulaaRefresh && window.ulaaRefresh()", null)
    }

    private fun canonicalSavedUrl(raw: String): String {
        return try {
            val uri = android.net.Uri.parse(raw.trim())
            val scheme = (uri.scheme ?: "https").lowercase()
            val host = (uri.host ?: "").lowercase().removePrefix("www.")
            val port = uri.port
            val defaultPort = (scheme == "https" && port == 443) || (scheme == "http" && port == 80)
            val path = (uri.encodedPath ?: "").let { p ->
                if (p.isBlank() || p == "/") "" else p.trimEnd('/')
            }
            buildString {
                append(scheme).append("://").append(host)
                if (port >= 0 && !defaultPort) append(":").append(port)
                append(path)
                if (!uri.encodedQuery.isNullOrBlank()) append("?").append(uri.encodedQuery)
            }
        } catch (_: Exception) { raw.trim().substringBefore('#').trimEnd('/') }
    }

    private fun saveLink(bucket: String) {
        val url = web.url?.trim()?.takeIf { it.isNotBlank() } ?: return
        val favKey = "list_favs"
        val bookmarkKey = "list_bookmarks"
        val currentFavs = (prefs().getString(favKey, "") ?: "").split("\n").filter { it.isNotBlank() }
        val currentBookmarks = (prefs().getString(bookmarkKey, "") ?: "").split("\n").filter { it.isNotBlank() }
        val canonical = canonicalSavedUrl(url)
        if ((currentFavs + currentBookmarks).any { canonicalSavedUrl(it) == canonical }) {
            toast(if (currentFavs.any { canonicalSavedUrl(it) == canonical }) "Already in Favourites" else "Already bookmarked")
            return
        }
        val key = "list_$bucket"
        val all = (prefs().getString(key, "") ?: "").split("\n")
            .filter { it.isNotBlank() }
            .distinctBy { canonicalSavedUrl(it) }
            .toMutableList()
        all.add(0, url)
        prefs().edit().putString(key, all.joinToString("\n")).apply()
        toast(if (bucket == "favs") "Added to Favourites" else "Added to Bookmarks")
    }

    private fun translatePage() {
        val target = active.web
        val currentUrl = target.url
        if (currentUrl.isNullOrBlank() || currentUrl == "about:blank") {
            toast("Open a webpage before translating.")
            return
        }
        try {
            val encoded = java.net.URLEncoder.encode(currentUrl, "UTF-8")
            target.loadUrl("https://translate.google.com/translate?sl=auto&tl=en&u=" + encoded)
        } catch (e: Exception) {
            toast("Couldn't open the translation service.")
        }
    }

    private fun js(code: String) {
        try { web.evaluateJavascript(code, null) } catch (e: Exception) {}
    }

    /** Starts the page eraser (page_cleanup.js) on the active tab. Single entry point for every Eraser button. */
    private fun startEraser() {
        val target = tabs.getOrNull(current)?.web
        if (target == null) { toast("No active page"); return }
        val url = target.url.orEmpty()
        if (url.isBlank() || url.contains(HOST)) { toast("Hide Distracting Items is available on webpages"); return }
        val source = pageCleanupJs
        if (source.isNullOrBlank()) { toast("Page cleanup could not be loaded"); return }
        try {
            // Install and start in one evaluation so there is no timing gap between the two.
            val script = source + "\n;(function(){try{return !!(window.ValleyPageCleanup && window.ValleyPageCleanup.start({dark:" + pal.dark + "}))}catch(e){return false}})()"
            target.evaluateJavascript(script) { result ->
                if (result != "true") toast("Hide Distracting Items could not start on this page. Try reloading it.")
                else watchEraser(target)
            }
        } catch (e: Exception) {
            toast("Hide Distracting Items could not start")
        }
    }

    /**
     * While the page's own picker bar is on screen it takes the place of the toolbar, like Safari's does.
     * The toolbar returns as soon as the picker is finished (or the page / tab changes).
     */
    private fun watchEraser(target: WebView) {
        val tw = findViewById<WebView>(R.id.toolbarWeb)
        tw.visibility = View.INVISIBLE
        val check = object : Runnable {
            override fun run() {
                if (isFinishing || isDestroyed) return
                if (target !== web || mode != Mode.BROWSING) {
                    try { target.evaluateJavascript("(function(){try{window.ValleyPageCleanup&&window.ValleyPageCleanup.stop()}catch(e){}})()", null) } catch (_: Exception) {}
                    if (mode == Mode.BROWSING) tw.visibility = View.VISIBLE
                    return
                }
                target.evaluateJavascript(
                    "(function(){try{return !!(window.ValleyPageCleanup&&window.ValleyPageCleanup.isActive&&window.ValleyPageCleanup.isActive())}catch(e){return false}})()"
                ) { value ->
                    if (value == "true") uiHandler.postDelayed(this, 300)
                    else if (mode == Mode.BROWSING) tw.visibility = View.VISIBLE
                }
            }
        }
        uiHandler.postDelayed(check, 500)
    }

    private fun runPageSparkAction(action: String) {
        val target = active.web
        val allowed = setOf("ulaaEraser", "ulaaTranslate", "ulaaSummarise")
        if (action !in allowed) return
        val url = target.url.orEmpty()
        if (url.contains(HOST)) {
            toast("This tool is available on webpages")
            return
        }
        val source = sparkJs
        if (source.isNullOrBlank()) {
            toast("Page tools could not be loaded")
            return
        }
        target.post {
            try {
                target.evaluateJavascript(source) {
                    target.evaluateJavascript(
                        "(function(){try{return typeof window.$action==='function' ? !!window.$action() : false;}catch(e){return false;}})()"
                    ) { result ->
                        if (result != "true") runOnUiThread {
                            toast(if (action == "ulaaEraser") "Hide Distracting Items could not be started on this page" else "Page tool unavailable")
                        }
                    }
                }
            } catch (e: Exception) {
                toast("Page tool failed to run")
            }
        }
    }

    /**
     * The app saves bookmarks in Android storage; the homepage keeps its own list in the page's
     * localStorage. On the start page the two are merged, so everything you saved shows up in
     * Favourites there, and anything you delete there comes back to the app.
     */
    private fun syncWithHomepage() {
        val favs = (prefs().getString("list_favs", "") ?: "").split("\n").filter { it.isNotBlank() }
        val marks = (prefs().getString("list_bookmarks", "") ?: "").split("\n").filter { it.isNotBlank() }
        val all = (favs + marks).distinct()
        if (all.isEmpty()) {
            web.evaluateJavascript("window.ulaaRefresh && window.ulaaRefresh()", null)
            return
        }
        val arr = org.json.JSONArray(all).toString()
        val code = "(function(){try{" +
                "var add=" + arr + ";" +
                "var cur=[];try{cur=JSON.parse(localStorage.getItem('hp.favs')||'[]');}catch(e){cur=[];}" +
                "function canon(u){try{var a=new URL(u);a.hash='';a.hostname=a.hostname.toLowerCase().replace(/^www\\./,'');if((a.protocol==='https:'&&a.port==='443')||(a.protocol==='http:'&&a.port==='80'))a.port='';a.pathname=a.pathname==='/'?'':a.pathname.replace(/\\/$/,'');return a.protocol+'//'+a.host+a.pathname+a.search;}catch(e){return String(u||'').split('#')[0].replace(/\\/$/,'');}}" +
                "var have={};cur.forEach(function(x){if(x&&x.u){var k=canon(x.u);if(!have[k])have[k]=1;else x.__duplicate=1;}});cur=cur.filter(function(x){return x&&!x.__duplicate;});" +
                "add.forEach(function(u){var k=canon(u);if(!have[k]){cur.push({u:u,n:''});have[k]=1;}});" +
                "localStorage.setItem('hp.favs',JSON.stringify(cur));" +
                "return cur.map(function(x){return (x&&x.u)||'';}).filter(Boolean).join('\\n');" +
                "}catch(e){return '';}})()"

        web.evaluateJavascript(code) { res ->
            try {
                val merged = org.json.JSONTokener(res).nextValue() as? String
                if (!merged.isNullOrBlank()) {
                    // the page is now the single list: everything is a favourite there
                    prefs().edit()
                        .putString("list_favs", merged)
                        .putString("list_bookmarks", "")
                        .apply()
                }
            } catch (e: Exception) {}
            web.evaluateJavascript("window.ulaaRefresh && window.ulaaRefresh()", null)
        }
    }

    private fun injectPageCleanup(view: WebView) {
        val source = pageCleanupJs ?: return
        try {
            view.evaluateJavascript(source, null)
        } catch (e: Exception) {
            // The page can navigate away while injection is queued; the next page load retries.
        }
    }

    private fun injectSpark(view: WebView, url: String?) {
        val code = sparkJs ?: return
        if (url == null || url.contains(HOST)) return
        try {
            view.evaluateJavascript(code) {
                try { view.evaluateJavascript("window.ulaaHidePill && window.ulaaHidePill()", null) } catch (e: Exception) {}
            }
        } catch (e: Exception) {}
    }

    private fun readAsset(name: String): String? = try {
        assets.open(name).bufferedReader().use { it.readText() }
    } catch (e: Exception) {
        null
    }

    // ---- drag and drop files onto a page (split-screen / other apps) ----
    private fun setupFileDrop(w: WebView) {
        w.setOnDragListener { v, event ->
            when (event.action) {
                android.view.DragEvent.ACTION_DRAG_STARTED ->
                    event.clipDescription != null
                android.view.DragEvent.ACTION_DROP -> {
                    val clip = event.clipData
                    if (clip == null || clip.itemCount == 0) return@setOnDragListener false
                    val perms = if (android.os.Build.VERSION.SDK_INT >= 24) requestDragAndDropPermissions(event) else null
                    val uris = ArrayList<Uri>()
                    for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris.add(it) }
                    if (uris.isEmpty()) { perms?.release(); return@setOnDragListener false }
                    val density = resources.displayMetrics.density
                    val cx = event.x / density
                    val cy = event.y / density
                    Thread {
                        try { deliverDroppedFiles(w, uris, cx, cy) }
                        finally { try { perms?.release() } catch (_: Exception) {} }
                    }.start()
                    true
                }
                else -> true
            }
        }
    }

    private fun deliverDroppedFiles(w: WebView, uris: List<Uri>, x: Float, y: Float) {
        val maxTotal = 40L * 1024 * 1024
        var total = 0L
        val id = "vd" + System.nanoTime()
        runOnUiThread { w.evaluateJavascript("window['$id']=[];", null) }
        var count = 0
        for (u in uris) {
            try {
                var name = "file"; var mime = contentResolver.getType(u) ?: "application/octet-stream"
                contentResolver.query(u, null, null, null, null)?.use { c ->
                    val ix = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && ix >= 0) name = c.getString(ix) ?: name
                }
                val input = contentResolver.openInputStream(u) ?: continue
                val bytes = input.use { it.readBytes() }
                total += bytes.size
                if (total > maxTotal) { runOnUiThread { toast("Dropped files are too large") }; break }
                val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                val q = JSONObject.quote(name); val m = JSONObject.quote(mime)
                // push in chunks so one huge string is never a single JS call
                val parts = b64.chunked(400_000)
                runOnUiThread { w.evaluateJavascript("window['$id'].push({n:$q,t:$m,d:[]});", null) }
                for (part in parts) {
                    runOnUiThread { w.evaluateJavascript("window['$id'][$count].d.push('$part');", null) }
                }
                count++
            } catch (_: Exception) { }
        }
        if (count == 0) return
        val js = """(function(){try{
var raw=window['$id'];delete window['$id'];
var files=raw.map(function(f){var s=atob(f.d.join(''));var a=new Uint8Array(s.length);
for(var i=0;i<s.length;i++)a[i]=s.charCodeAt(i);return new File([a],f.n,{type:f.t})});
var dt=new DataTransfer();files.forEach(function(f){dt.items.add(f)});
var el=document.elementFromPoint($x,$y)||document.body;
function fire(t){var e=new DragEvent(t,{bubbles:true,cancelable:true,dataTransfer:dt,clientX:$x,clientY:$y});
 el.dispatchEvent(e);return e.defaultPrevented}
fire('dragenter');fire('dragover');
var handled=fire('drop');
if(!handled){
 var inp=null,n=el;
 while(n&&!inp){inp=n.querySelector&&n.querySelector('input[type=file]');n=n.parentElement}
 if(!inp){var all=document.querySelectorAll('input[type=file]');if(all.length)inp=all[all.length-1]}
 if(inp){var d2=new DataTransfer();var list=inp.multiple?files:files.slice(0,1);
  list.forEach(function(f){d2.items.add(f)});inp.files=d2.files;
  inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}))}
}
}catch(e){}})();"""
        runOnUiThread { w.evaluateJavascript(js, null) }
    }

    // ---- website permissions: camera, microphone, location ----
    private val allowedPermOrigins = HashSet<String>()
    private var pendingPermRequest: android.webkit.PermissionRequest? = null
    private var pendingPermResources: List<String> = emptyList()
    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private val mediaPermRequestCode = 7043
    private val geoPermRequestCode = 7044

    private fun hostOf(origin: String): String =
        try { Uri.parse(origin).host ?: origin } catch (_: Exception) { origin }

    private fun handleWebPermission(request: android.webkit.PermissionRequest) {
        val origin = request.origin?.toString() ?: ""
        val res = request.resources.toList()
        val wantsCam = res.contains(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE)
        val wantsMic = res.contains(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE)
        if (!wantsCam && !wantsMic) {
            // DRM playback needs no prompt; anything else is refused
            if (res.contains(android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID))
                request.grant(arrayOf(android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID))
            else request.deny()
            return
        }
        val granted = res.filter {
            it == android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
            it == android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
            it == android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID
        }
        pendingPermRequest?.let { try { it.deny() } catch (_: Exception) {} }
        val key = origin + "|" + granted.sorted().joinToString(",")
        if (allowedPermOrigins.contains(key)) { grantWebPermission(request, granted); return }
        val what = when {
            wantsCam && wantsMic -> "camera and microphone"
            wantsCam -> "camera"
            else -> "microphone"
        }
        AlertDialog.Builder(this)
            .setTitle("Allow ${hostOf(origin)} to use your $what?")
            .setPositiveButton("Allow") { _, _ ->
                allowedPermOrigins.add(key)
                grantWebPermission(request, granted)
            }
            .setNegativeButton("Don't allow") { _, _ -> request.deny() }
            .setOnCancelListener { request.deny() }
            .show()
    }

    private fun grantWebPermission(request: android.webkit.PermissionRequest, resources: List<String>) {
        val need = ArrayList<String>()
        if (resources.contains(android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE) &&
            checkSelfPermission(android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            need.add(android.Manifest.permission.CAMERA)
        if (resources.contains(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE) &&
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            need.add(android.Manifest.permission.RECORD_AUDIO)
        if (need.isEmpty()) {
            try { request.grant(resources.toTypedArray()) } catch (_: Exception) {}
            return
        }
        pendingPermRequest = request
        pendingPermResources = resources
        requestPermissions(need.toTypedArray(), mediaPermRequestCode)
    }

    private fun askGeolocation(origin: String, callback: GeolocationPermissions.Callback) {
        val key = "geo|$origin"
        val proceed = {
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                callback.invoke(origin, true, false)
            } else {
                pendingGeoCallback?.invoke(pendingGeoOrigin, false, false)
                pendingGeoOrigin = origin
                pendingGeoCallback = callback
                requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION), geoPermRequestCode)
            }
        }
        if (allowedPermOrigins.contains(key)) { proceed(); return }
        AlertDialog.Builder(this)
            .setTitle("Allow ${hostOf(origin)} to use your location?")
            .setPositiveButton("Allow") { _, _ -> allowedPermOrigins.add(key); proceed() }
            .setNegativeButton("Don't allow") { _, _ -> callback.invoke(origin, false, false) }
            .setOnCancelListener { callback.invoke(origin, false, false) }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == mediaPermRequestCode) {
            val req = pendingPermRequest ?: return
            pendingPermRequest = null
            val ok = ArrayList<String>()
            for (r in pendingPermResources) {
                when (r) {
                    android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                        if (checkSelfPermission(android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) ok.add(r)
                    android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) ok.add(r)
                    else -> ok.add(r)
                }
            }
            try {
                if (ok.isEmpty()) { req.deny(); toast("Permission denied in Android settings") }
                else req.grant(ok.toTypedArray())
            } catch (_: Exception) {}
        } else if (requestCode == geoPermRequestCode) {
            val cb = pendingGeoCallback ?: return
            val origin = pendingGeoOrigin
            pendingGeoCallback = null; pendingGeoOrigin = null
            val ok = grantResults.any { it == android.content.pm.PackageManager.PERMISSION_GRANTED }
            cb.invoke(origin, ok, false)
        }
    }

    // ---- certificate errors and HTTP logins ----
    private val sslExceptions = HashSet<String>()
    private var sslDialogHost: String? = null

    private fun handleSslError(view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
        val host = hostOf(error.url ?: "")
        val mainFrame = (error.url ?: "") == (view.url ?: "")
        // images, scripts and frames on a bad certificate are simply refused
        if (!mainFrame && !sslExceptions.contains(host)) { handler.cancel(); return }
        if (sslExceptions.contains(host)) { handler.proceed(); return }
        if (sslDialogHost == host) { handler.cancel(); return }
        sslDialogHost = host
        val why = when (error.primaryError) {
            android.net.http.SslError.SSL_EXPIRED -> "its security certificate has expired."
            android.net.http.SslError.SSL_IDMISMATCH -> "its certificate belongs to a different site."
            android.net.http.SslError.SSL_UNTRUSTED -> "its certificate isn't from a trusted authority."
            android.net.http.SslError.SSL_NOTYETVALID -> "its certificate isn't valid yet."
            else -> "its certificate couldn't be verified."
        }
        if (isFinishing || isDestroyed) { handler.cancel(); return }
        AlertDialog.Builder(this)
            .setTitle("This connection isn't private")
            .setMessage("$host can't be trusted because $why\n\nAttackers might be trying to steal your information.")
            .setPositiveButton("Go back") { _, _ ->
                handler.cancel(); sslDialogHost = null
                if (view.canGoBack()) view.goBack()
            }
            .setNegativeButton("Continue anyway") { _, _ ->
                sslExceptions.add(host); sslDialogHost = null; handler.proceed()
            }
            .setOnCancelListener { handler.cancel(); sslDialogHost = null }
            .show()
    }

    private fun handleHttpAuth(handler: android.webkit.HttpAuthHandler, host: String?, realm: String?) {
        if (isFinishing || isDestroyed) { handler.cancel(); return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val user = EditText(this).apply { hint = "Username"; setSingleLine(true) }
        val pass = EditText(this).apply {
            hint = "Password"; setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(user); box.addView(pass)
        AlertDialog.Builder(this)
            .setTitle("Sign in to ${host ?: "this site"}")
            .setMessage(realm?.takeIf { it.isNotBlank() })
            .setView(box)
            .setPositiveButton("Sign in") { _, _ -> handler.proceed(user.text.toString(), pass.text.toString()) }
            .setNegativeButton("Cancel") { _, _ -> handler.cancel() }
            .setOnCancelListener { handler.cancel() }
            .show()
    }

    // ---- fullscreen video ----
    private var customViewFrame: FrameLayout? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var prevOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    private var prevSystemUi = 0

    @Suppress("DEPRECATION")
    private fun showFullscreenView(view: View, callback: WebChromeClient.CustomViewCallback?) {
        val decor = window.decorView as ViewGroup
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        decor.addView(frame, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        customViewFrame = frame
        customViewCallback = callback
        prevOrientation = requestedOrientation
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        prevSystemUi = decor.systemUiVisibility
        decor.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    @Suppress("DEPRECATION")
    private fun hideFullscreenView() {
        val frame = customViewFrame ?: return
        val decor = window.decorView as ViewGroup
        customViewFrame = null
        frame.removeAllViews()
        decor.removeView(frame)
        decor.systemUiVisibility = prevSystemUi
        requestedOrientation = prevOrientation
        try { customViewCallback?.onCustomViewHidden() } catch (_: Exception) {}
        customViewCallback = null
    }

    // ---- print / save as PDF ----
    private fun printCurrentPage() {
        try {
            val pm = getSystemService(PRINT_SERVICE) as android.print.PrintManager
            val title = (web.title?.takeIf { it.isNotBlank() } ?: "Valley page")
            pm.print(title, web.createPrintDocumentAdapter(title), android.print.PrintAttributes.Builder().build())
        } catch (_: Exception) {
            toast("Couldn't start printing")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (customViewFrame != null) { hideFullscreenView(); return }
        if (this::container.isInitialized && tabs.isNotEmpty() && web.canGoBack()) web.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        hideFullscreenView()
        pendingFileChooserCallback?.onReceiveValue(null)
        pendingFileChooserCallback = null
        if (downloadReceiverRegistered) { try { unregisterReceiver(downloadReceiver) } catch (_: Exception) {} }
        handler().removeCallbacks(downloadToastHide)
        for (t in tabs) { try { t.web.destroy() } catch (e: Exception) {} }
        tabs.clear()
        super.onDestroy()
    }
}
