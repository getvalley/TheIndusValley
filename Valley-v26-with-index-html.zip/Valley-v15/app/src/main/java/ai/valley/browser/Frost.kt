package ai.valley.browser

import android.graphics.Bitmap

/**
 * A cheap, convincing blur for the frosted toolbar.
 *
 * Android has no backdrop-filter: a native view cannot sample what is behind it. So we capture the
 * pixels under the pill (PixelCopy), shrink them, blur the small copy, and let the pill paint the
 * result — which is exactly what the browser's own pill does with CSS, done by hand.
 */
object Frost {

    /** three box passes on a downscaled bitmap reads as a gaussian at this size */
    fun blur(src: Bitmap, radius: Int = 2, scale: Int = 8): Bitmap {
        if (src.width <= 0 || src.height <= 0) return src
        val w = (src.width / scale).coerceAtLeast(1)
        val h = (src.height / scale).coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)

        repeat(3) { boxPass(px, w, h, radius) }

        small.setPixels(px, 0, w, 0, 0, w, h)
        return small
    }

    private fun boxPass(px: IntArray, w: Int, h: Int, r: Int) {
        if (r <= 0) return
        val tmp = IntArray(px.size)
        // horizontal
        for (y in 0 until h) {
            val row = y * w
            var sumA = 0; var sumR = 0; var sumG = 0; var sumB = 0
            var count = 0
            for (x in -r..r) {
                val xx = x.coerceIn(0, w - 1)
                val c = px[row + xx]
                sumA += c ushr 24 and 0xFF; sumR += c shr 16 and 0xFF
                sumG += c shr 8 and 0xFF; sumB += c and 0xFF
                count++
            }
            for (x in 0 until w) {
                tmp[row + x] = (sumA / count shl 24) or (sumR / count shl 16) or
                        (sumG / count shl 8) or (sumB / count)
                val addX = (x + r + 1).coerceAtMost(w - 1)
                val remX = (x - r).coerceAtLeast(0)
                val add = px[row + addX]
                val rem = px[row + remX]
                sumA += (add ushr 24 and 0xFF) - (rem ushr 24 and 0xFF)
                sumR += (add shr 16 and 0xFF) - (rem shr 16 and 0xFF)
                sumG += (add shr 8 and 0xFF) - (rem shr 8 and 0xFF)
                sumB += (add and 0xFF) - (rem and 0xFF)
            }
        }
        // vertical
        for (x in 0 until w) {
            var sumA = 0; var sumR = 0; var sumG = 0; var sumB = 0
            var count = 0
            for (y in -r..r) {
                val yy = y.coerceIn(0, h - 1)
                val c = tmp[yy * w + x]
                sumA += c ushr 24 and 0xFF; sumR += c shr 16 and 0xFF
                sumG += c shr 8 and 0xFF; sumB += c and 0xFF
                count++
            }
            for (y in 0 until h) {
                px[y * w + x] = (sumA / count shl 24) or (sumR / count shl 16) or
                        (sumG / count shl 8) or (sumB / count)
                val addY = (y + r + 1).coerceAtMost(h - 1)
                val remY = (y - r).coerceAtLeast(0)
                val add = tmp[addY * w + x]
                val rem = tmp[remY * w + x]
                sumA += (add ushr 24 and 0xFF) - (rem ushr 24 and 0xFF)
                sumR += (add shr 16 and 0xFF) - (rem shr 16 and 0xFF)
                sumG += (add shr 8 and 0xFF) - (rem shr 8 and 0xFF)
                sumB += (add and 0xFF) - (rem and 0xFF)
            }
        }
    }
}
