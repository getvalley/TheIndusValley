package ai.valley.browser

import android.content.Context
import android.content.res.Configuration

/**
 * One place for every colour the Kotlin-built screens use, so the whole app follows the
 * system light / dark setting. Values are read on access, so a rebuilt screen always matches
 * the theme that is active right now.
 */
class Pal(private val ctx: Context) {
    val dark: Boolean
        get() = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun pick(d: Long, l: Long): Int = (if (dark) d else l).toInt()

    /** main text */
    val ink get() = pick(0xFFF6F0E8, 0xFF1B1815)
    /** text sitting on an `ink` coloured button */
    val onInk get() = pick(0xFF1A1A1E, 0xFFFFFFFF)
    /** secondary text */
    val ink2 get() = pick(0xFFB3A89C, 0xFF3F3832)
    /** hints and muted text */
    val ink3 get() = pick(0xFF877E74, 0xFF554C44)
    /** text on a floating popover */
    val popInk get() = pick(0xFFF4F4F6, 0xFF1C1C20)
    val popInk2 get() = pick(0xFFB9B9C0, 0xFF45454D)
    val popHint get() = pick(0xFFB5B5BB, 0xFF5A5A62)
    /** private-tab purple */
    val priv get() = pick(0xFFCBA8FF, 0xFF6C3DD0)
    /** screen background */
    val bg get() = pick(0xFF0A0807, 0xFFF5F2EC)

    /** floating popover surfaces */
    val pop get() = pick(0xEE29292D, 0xF2F4F4F8)
    val popStrong get() = pick(0xEE343438, 0xF2EDEDF2)
    val popSolid get() = pick(0xFF343438, 0xFFEDEDF2)
    val popSelected get() = pick(0xEE303036, 0xF2E3E3EA)
    val popSelectedFill get() = pick(0x33202024, 0x14000000)
    val button get() = pick(0xFF4A4A4D, 0xFFDCDCE2)
    val toast get() = pick(0xE61A1A1E, 0xF2F7F7FA)
    val thumbBg get() = pick(0xFF20232A, 0xFFE4E6EC)
    val bookmarkTile get() = pick(0xFF24262C, 0xFFE9E7E2)
    val bookmarkMark get() = pick(0xFF30343D, 0xFFDAD8D3)
    val offButton get() = pick(0xFF3A332D, 0xFFD9D2CA)
    val closeBadge get() = pick(0xAA171719, 0xCCFFFFFF)

    /** hairlines and translucent fills (white on dark, black on light) */
    val line get() = pick(0x33FFFFFF, 0x24000000)
    val lineSoft get() = pick(0x22FFFFFF, 0x1A000000)
    val lineStrong get() = pick(0x55FFFFFF, 0x38000000)
    val lineSelected get() = pick(0x99FFFFFF, 0x66000000)
    val fillFaint get() = pick(0x20FFFFFF, 0x12000000)
    val fillSoft get() = pick(0x24FFFFFF, 0x14000000)
    val fillTrack get() = pick(0x26FFFFFF, 0x1F000000)
    val fillMid get() = pick(0x33FFFFFF, 0x1F000000)
    val textDim get() = pick(0x99FFFFFF, 0xB3000000)
    val textDimmer get() = pick(0x88FFFFFF, 0x99000000)
    val rippleGlow get() = pick(0x88FFFFFF, 0x66FF7A33)
}
