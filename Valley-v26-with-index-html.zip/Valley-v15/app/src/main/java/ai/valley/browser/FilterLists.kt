package ai.valley.browser

import android.content.Context
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * The same lists uBlock Origin ships enabled by default, fetched straight from their publishers,
 * plus a small bundled seed list (assets/ubo-filters.txt) so filtering works before the first download.
 */
object FilterLists {
    class Source(val id: String, val title: String, val url: String)

    val sources = listOf(
        Source("ublock-filters", "uBlock filters", "https://ublockorigin.github.io/uAssets/filters/filters.min.txt"),
        Source("ublock-badware", "uBlock filters - Badware risks", "https://ublockorigin.github.io/uAssets/filters/badware.min.txt"),
        Source("ublock-privacy", "uBlock filters - Privacy", "https://ublockorigin.github.io/uAssets/filters/privacy.min.txt"),
        Source("ublock-unbreak", "uBlock filters - Unbreak", "https://ublockorigin.github.io/uAssets/filters/unbreak.min.txt"),
        Source("ublock-quick-fixes", "uBlock filters - Quick fixes", "https://ublockorigin.github.io/uAssets/filters/quick-fixes.min.txt"),
        Source("easylist", "EasyList", "https://easylist.to/easylist/easylist.txt"),
        Source("easyprivacy", "EasyPrivacy", "https://easylist.to/easylist/easyprivacy.txt"),
        Source("peterlowe", "Peter Lowe's Ad and tracking server list", "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext")
    )

    private fun dir(ctx: Context): File = File(ctx.filesDir, "ubo").apply { mkdirs() }

    /** Builds an engine from the bundled seed, every downloaded list, and the user's own filters. */
    fun load(ctx: Context, customFilters: String): FilterEngine {
        val b = FilterEngine.Builder()
        try {
            ctx.assets.open("ubo-filters.txt").use { b.addReader(BufferedReader(InputStreamReader(it, Charsets.UTF_8))) }
        } catch (_: Exception) {}
        for (s in sources) {
            val f = File(dir(ctx), s.id + ".txt")
            if (!f.isFile) continue
            try { f.bufferedReader(Charsets.UTF_8).use { b.addReader(it) } } catch (_: Exception) {}
        }
        if (customFilters.isNotBlank()) b.addText(customFilters)
        return b.build()
    }

    fun lastUpdated(ctx: Context): Long = try {
        dir(ctx).listFiles()?.filter { it.isFile && it.name.endsWith(".txt") }?.maxOfOrNull { it.lastModified() } ?: 0L
    } catch (_: Exception) { 0L }

    fun downloadedCount(ctx: Context): Int =
        dir(ctx).listFiles()?.count { it.isFile && it.name.endsWith(".txt") } ?: 0

    /** Downloads every list. Blocking: call from a background thread. Returns how many lists were refreshed. */
    fun update(ctx: Context): Int {
        var ok = 0
        for (s in sources) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(s.url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 30000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "Valley-Browser filter updater")
                }
                if (conn.responseCode != 200) continue
                val tmp = File(dir(ctx), s.id + ".tmp")
                conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
                // refuse error pages and truncated downloads so a bad fetch never replaces a good list
                val head = tmp.bufferedReader(Charsets.UTF_8).use { r -> CharArray(512).let { buf -> String(buf, 0, maxOf(0, r.read(buf))) } }
                if (tmp.length() < 2000 || head.trimStart().startsWith("<")) { tmp.delete(); continue }
                val target = File(dir(ctx), s.id + ".txt")
                if (target.exists()) target.delete()
                if (tmp.renameTo(target)) ok++ else tmp.delete()
            } catch (_: Exception) {
            } finally {
                try { conn?.disconnect() } catch (_: Exception) {}
            }
        }
        return ok
    }
}
