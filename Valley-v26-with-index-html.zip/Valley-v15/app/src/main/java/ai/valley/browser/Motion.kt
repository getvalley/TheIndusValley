package ai.valley.browser

import android.view.animation.Interpolator
import android.view.animation.PathInterpolator

/**
 * The pill's own motion curves, lifted from its CSS:
 *
 *   spring   cubic-bezier(.34,1.4,.64,1)    the overshoot on expand
 *   ease     cubic-bezier(.22,.61,.36,1)    the settle
 *   collapse cubic-bezier(.55,0,.9,.4)      the shrink
 *   sheet    cubic-bezier(.10,.86,.18,1)    panels rising from the bottom
 *
 * Same control points, so the app moves like the pill rather than near it.
 */
object Motion {
    val spring: Interpolator = PathInterpolator(0.34f, 1.4f, 0.64f, 1f)
    val ease: Interpolator = PathInterpolator(0.22f, 0.61f, 0.36f, 1f)
    val collapse: Interpolator = PathInterpolator(0.55f, 0f, 0.9f, 0.4f)
    val sheet: Interpolator = PathInterpolator(0.10f, 0.86f, 0.18f, 1f)

    // durations in ms, straight from the CSS
    const val D_EXPAND = 380L
    const val D_COLLAPSE = 340L
    const val D_SHEET = 460L
    const val D_PANEL = 400L
    const val D_ORB = 180L
    const val D_FADE = 220L
}
