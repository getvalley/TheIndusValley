(function () {
  'use strict';
  if (window.__valleyReaderInstalled) return;
  window.__valleyReaderInstalled = true;
  var overlayId = 'valley-reader-overlay';

  function textOf(node) {
    return (node && (node.innerText || node.textContent) || '')
      .replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function isVisible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect();
    var s = window.getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.display !== 'none' &&
      s.visibility !== 'hidden' && Number(s.opacity || 1) > 0;
  }
  function chooseArticle() {
    var selectors = [
      '[itemprop="articleBody"]', 'article', 'main', '[role="main"]',
      '.article-body', '.post-content', '.entry-content', '.story-body',
      '.article-content', '.article', '#article-body', '#content'
    ];
    var best = null, bestScore = 0;
    selectors.forEach(function (selector) {
      var nodes;
      try { nodes = document.querySelectorAll(selector); } catch (_) { return; }
      for (var i = 0; i < nodes.length; i++) {
        var el = nodes[i];
        if (!isVisible(el) || el.closest('#' + overlayId)) continue;
        var txt = textOf(el);
        if (txt.length < 120) continue;
        var paragraphs = el.querySelectorAll('p').length;
        var headings = el.querySelectorAll('h1,h2,h3,h4').length;
        var links = el.querySelectorAll('a').length;
        var score = txt.length + paragraphs * 100 + headings * 35 - links * 8;
        if (score > bestScore) { best = el; bestScore = score; }
      }
    });
    return best || document.body;
  }
  function collectBlocks(root) {
    var nodes = root.querySelectorAll('h1,h2,h3,h4,p,li,blockquote,figcaption,dt,dd,pre');
    var result = [], seen = Object.create(null);
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!isVisible(el) || el.closest('nav,header,footer,aside,[aria-hidden="true"],script,style,button,[role="navigation"]')) continue;
      var value = textOf(el);
      var min = /^H[1-4]$/.test(el.tagName) ? 4 : 28;
      if (value.length < min || seen[value]) continue;
      seen[value] = true;
      result.push({ tag: el.tagName.toLowerCase(), text: value });
    }
    return result;
  }
  function escapeHtml(value) {
    return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function makeReader() {
    var existing = document.getElementById(overlayId);
    if (existing) { existing.remove(); return true; }

    var article = chooseArticle();
    var blocks = collectBlocks(article);
    var total = blocks.reduce(function (sum, block) { return sum + block.text.length; }, 0);

    if (total < 180) {
      blocks = collectBlocks(document.body);
      total = blocks.reduce(function (sum, block) { return sum + block.text.length; }, 0);
    }
    if (total < 180) {
      var body = textOf(document.body);
      if (body.length >= 180) {
        blocks = body.split(/[.!?।]\s+/).filter(function (part) { return part.length > 30; })
          .map(function (part) { return { tag: 'p', text: part }; });
        total = blocks.reduce(function (sum, block) { return sum + block.text.length; }, 0);
      }
    }
    if (total < 120 || !blocks.length) return false;

    var titleNode = article.querySelector && article.querySelector('h1');
    var title = textOf(titleNode) || textOf(document.querySelector('h1')) ||
      document.title || 'Article';
    var content = blocks.map(function (block) {
      var tag = /^(h1|h2|h3|h4|blockquote|li|pre)$/.test(block.tag) ? block.tag : 'p';
      return '<' + tag + '>' + escapeHtml(block.text) + '</' + tag + '>';
    }).join('');

    var overlay = document.createElement('div');
    overlay.id = overlayId;
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-label', 'Reader mode');
    overlay.style.cssText = [
      'position:fixed', 'inset:0', 'z-index:2147483647', 'overflow:auto',
      'overscroll-behavior:contain', 'box-sizing:border-box',
      'padding:calc(18px + env(safe-area-inset-top)) 22px calc(36px + env(safe-area-inset-bottom))',
      'background:#ffffff', 'color:#202124', 'font:18px/1.72 Inter,Arial,sans-serif',
      '-webkit-overflow-scrolling:touch'
    ].join(';');

    overlay.innerHTML =
      '<div id="valley-reader-content" style="max-width:720px;margin:0 auto;padding-top:30vh;box-sizing:border-box">' +
        '<div style="font:600 10px/1.2 Inter,Arial,sans-serif;letter-spacing:.2em;text-transform:uppercase;color:#777;margin:0 0 14px">VALLEY READER</div>' +
        '<h1 style="font:700 30px/1.18 Inter,Arial,sans-serif;letter-spacing:-.02em;margin:0 0 25px">' + escapeHtml(title) + '</h1>' +
        '<div id="valley-reader-article">' + content + '</div>' +
        '<div style="margin-top:36px;padding-top:14px;border-top:1px solid #d8dadd;font:500 11px Inter,Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#777">End of article</div>' +
      '</div>' +
      '<div id="valley-reader-controls" style="position:fixed;top:25vh;left:50%;transform:translateX(-50%);z-index:2;display:flex;align-items:center;gap:8px;white-space:nowrap;font:14px Inter,Arial,sans-serif">' +
        '<div id="valley-reader-fonts" style="display:flex;align-items:center;gap:5px;padding:7px 9px;border:1px solid rgba(0,0,0,.16);border-radius:24px;background:rgba(245,246,248,.97);box-shadow:0 8px 24px rgba(0,0,0,.14)">' +
          '<button data-font="Inter" style="font:600 14px Inter,Arial,sans-serif;background:rgba(21,158,232,.18)">Inter</button>' +
          '<button data-font="Consolas" style="font:600 14px Consolas,monospace">Consolas</button>' +
          '<button data-font="Garamond" style="font:600 14px Garamond,serif">Garamond</button>' +
        '</div>' +
        '<button id="valley-reader-theme" aria-label="Toggle reader background" style="width:42px;height:42px;border:1px solid rgba(0,0,0,.16);border-radius:50%;background:rgba(245,246,248,.97);box-shadow:0 8px 24px rgba(0,0,0,.14);color:#202124;font-size:18px">☾</button>' +
      '</div>';

    var style = document.createElement('style');
    style.id = 'valley-reader-style';
    style.textContent =
      '#' + overlayId + ' *{box-sizing:border-box}' +
      '#' + overlayId + ' button{border:0;background:transparent;color:inherit;padding:8px 5px;border-radius:15px;cursor:pointer}' +
      '#' + overlayId + ' button:focus{outline:2px solid #159ee8}' +
      '#' + overlayId + ' #valley-reader-article p{margin:0 0 1.1em}' +
      '#' + overlayId + ' #valley-reader-article h2{font-size:1.45em;line-height:1.25;margin:1.5em 0 .55em}' +
      '#' + overlayId + ' #valley-reader-article h3{font-size:1.2em;margin:1.3em 0 .5em}' +
      '#' + overlayId + ' #valley-reader-article li{margin:.35em 0}' +
      '#' + overlayId + ' #valley-reader-article blockquote{margin:1em 0;padding-left:1em;border-left:3px solid #159ee8;color:inherit}' +
      '#' + overlayId + ' #valley-reader-article pre{white-space:pre-wrap;overflow-wrap:anywhere}' +
      '@media(max-width:420px){#' + overlayId + ' #valley-reader-controls{gap:6px}#' + overlayId + ' #valley-reader-fonts{gap:2px;padding:5px 6px}#' + overlayId + ' #valley-reader-fonts button{font-size:12px;padding:7px 3px}#' + overlayId + ' #valley-reader-theme{width:38px;height:38px}}';
    overlay.appendChild(style);
    document.body.appendChild(overlay);

    var articleBox = overlay.querySelector('#valley-reader-article');
    var fontButtons = overlay.querySelectorAll('[data-font]');
    Array.prototype.forEach.call(fontButtons, function (button) {
      button.addEventListener('click', function () {
        var family = button.getAttribute('data-font');
        articleBox.style.fontFamily = family === 'Consolas' ? 'Consolas,monospace' :
          family === 'Garamond' ? 'Garamond,serif' : 'Inter,Arial,sans-serif';
        Array.prototype.forEach.call(fontButtons, function (item) {
          item.style.background = item === button ? 'rgba(21,158,232,.18)' : 'transparent';
        });
      });
    });
    var dark = false;
    overlay.querySelector('#valley-reader-theme').addEventListener('click', function () {
      dark = !dark;
      overlay.style.background = dark ? '#17191d' : '#ffffff';
      overlay.style.color = dark ? '#f1f3f5' : '#202124';
      var fontPill = overlay.querySelector('#valley-reader-fonts');
      fontPill.style.background = dark ? 'rgba(38,41,47,.98)' : 'rgba(245,246,248,.97)';
      fontPill.style.color = dark ? '#f1f3f5' : '#202124';
      fontPill.style.borderColor = dark ? 'rgba(255,255,255,.2)' : 'rgba(0,0,0,.16)';
      this.style.background = dark ? 'rgba(38,41,47,.98)' : 'rgba(245,246,248,.97)';
      this.style.color = dark ? '#ffffff' : '#202124';
      this.style.borderColor = dark ? 'rgba(255,255,255,.2)' : 'rgba(0,0,0,.16)';
      this.textContent = dark ? '☀' : '☾';
      this.style.background = dark ? '#454a53' : '#e5e7eb';
      this.style.color = dark ? '#ffffff' : '#202124';
      var end = overlay.querySelector('#valley-reader-content > div:last-child');
      if (end) end.style.borderColor = dark ? '#454a53' : '#d8dadd';
    });
    overlay.scrollTop = 0;
    return true;
  }

  window.ulaaReaderToggle = makeReader;
  window.ulaaReaderOpen = function () {
    if (document.getElementById(overlayId)) return true;
    return makeReader();
  };
})();