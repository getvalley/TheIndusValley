(function () {
  'use strict';
  if (window.__valleyReaderInstalled) return;
  window.__valleyReaderInstalled = true;
  var overlayId = 'valley-reader-overlay';

  function cleanText(node) {
    return (node && (node.innerText || node.textContent) || '').replace(/\s+/g, ' ').trim();
  }
  function visible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    var r = node.getBoundingClientRect();
    var s = window.getComputedStyle(node);
    return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
  }
  function chooseArticle() {
    var selectors = [
      '[itemprop="articleBody"]', 'article', 'main', '[role="main"]',
      '.article-body', '.post-content', '.entry-content', '.story-body',
      '.article-content', '.article', '#article-body', '#content'
    ];
    var best = null, bestScore = 0;
    selectors.forEach(function (selector) {
      var list;
      try { list = document.querySelectorAll(selector); } catch (_) { return; }
      for (var i = 0; i < list.length; i++) {
        var el = list[i];
        if (!visible(el) || el.closest('#' + overlayId)) continue;
        var text = cleanText(el);
        if (text.length < 180) continue;
        var links = el.querySelectorAll('a').length;
        var paras = el.querySelectorAll('p').length;
        var score = text.length + paras * 90 - links * 18;
        if (score > bestScore) { best = el; bestScore = score; }
      }
    });
    return best;
  }
  function collectBlocks(root) {
    var source = root || document.body;
    var nodes = source.querySelectorAll('h1,h2,h3,p,li,blockquote,figcaption');
    var out = [], seen = Object.create(null);
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!visible(el) || el.closest('nav,header,footer,aside,[aria-hidden="true"]')) continue;
      var text = cleanText(el);
      if (text.length < (el.tagName === 'P' ? 35 : 12)) continue;
      if (seen[text]) continue;
      seen[text] = true;
      out.push({ tag: el.tagName.toLowerCase(), text: text });
    }
    return out;
  }
  function escapeHtml(value) {
    return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function makeReader() {
    var existing = document.getElementById(overlayId);
    if (existing) { existing.remove(); return true; }

    var article = chooseArticle();
    var blocks = collectBlocks(article);
    var total = blocks.reduce(function (n, b) { return n + b.text.length; }, 0);

    // Some news sites render article copy as generic divs rather than paragraphs.
    if (total < 220) {
      blocks = collectBlocks(document.body);
      total = blocks.reduce(function (n, b) { return n + b.text.length; }, 0);
    }
    // Last-resort extraction: retain readable body text instead of silently doing nothing.
    if (total < 220) {
      var bodyText = cleanText(document.body);
      if (bodyText.length >= 220) {
        blocks = bodyText.split(/(?<=[.!?।])\s+/).filter(function (s) { return s.length > 35; })
          .map(function (s) { return { tag: 'p', text: s }; });
        total = blocks.reduce(function (n, b) { return n + b.text.length; }, 0);
      }
    }
    if (total < 180 || !blocks.length) return false;

    var title = cleanText(document.querySelector('h1')) || document.title || 'Article';
    var content = blocks.map(function (b) {
      var tag = /^(h1|h2|h3|blockquote|li)$/.test(b.tag) ? b.tag : 'p';
      return '<' + tag + '>' + escapeHtml(b.text) + '</' + tag + '>';
    }).join('');

    var overlay = document.createElement('div');
    overlay.id = overlayId;
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-label', 'Reader mode');
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;overflow:auto;overscroll-behavior:contain;' +
      'background:#f6f1e9;color:#191410;padding:calc(28px + env(safe-area-inset-top)) 22px calc(34px + env(safe-area-inset-bottom));' +
      'font:17px/1.75 Georgia,"Iowan Old Style",serif;-webkit-overflow-scrolling:touch;box-sizing:border-box;';
    overlay.innerHTML = '<div style="max-width:680px;margin:0 auto">' +
      '<div style="font:600 10px/1.2 -apple-system,sans-serif;letter-spacing:.2em;text-transform:uppercase;color:#a2978b;margin-bottom:16px">VALLEY READER</div>' +
      '<h1 style="font:600 30px/1.18 Georgia,serif;letter-spacing:-.02em;margin:0 0 25px">' + escapeHtml(title) + '</h1>' +
      content +
      '<div style="margin-top:36px;padding-top:14px;border-top:1px solid #e4dbcd;font:500 11px -apple-system,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#a2978b">End of article</div>' +
      '</div>';
    document.body.appendChild(overlay);
    overlay.scrollTop = 0;
    return true;
  }

  window.ulaaReaderToggle = makeReader;
  window.ulaaReaderOpen = function () {
    if (document.getElementById(overlayId)) return true;
    return makeReader();
  };
})();
