(function () {
  'use strict';
  if (window.__valleyReaderInstalled) return;
  window.__valleyReaderInstalled = true;
  var overlayId = 'valley-reader-overlay';

  function cleanText(node) {
    return (node && (node.innerText || node.textContent) || '').replace(/\s+/g, ' ').trim();
  }
  function visible(node) {
    if (!node || !node.getBoundingClientRect) return false;
    var r = node.getBoundingClientRect();
    var s = window.getComputedStyle(node);
    return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
  }
  function chooseArticle() {
    var selectors = [
      '[itemprop="articleBody"]', '#mw-content-text .mw-parser-output',
      '#mw-content-text', '.mw-parser-output', 'article', 'main', '[role="main"]',
      '.article-body', '.post-content', '.entry-content', '.story-body',
      '.article-content', '.article', '#article-body', '#content',
      '[class*="article-body"]', '[class*="article-content"]',
      '[class*="story-content"]', '[data-testid*="article"]'
    ];
    var best = null, bestScore = 0;
    selectors.forEach(function (selector) {
      var list;
      try { list = document.querySelectorAll(selector); } catch (_) { return; }
      for (var i = 0; i < list.length; i++) {
        var el = list[i];
        if (!visible(el) || el.closest('#' + overlayId)) continue;
        var text = cleanText(el);
        if (text.length < 120) continue;
        var links = el.querySelectorAll('a').length;
        var paras = el.querySelectorAll('p').length;
        var score = text.length + paras * 90 - links * 18;
        if (score > bestScore) { best = el; bestScore = score; }
      }
    });
    return best;
  }
  function collectBlocks(root) {
    var source = root || document.body;
    var nodes = source.querySelectorAll('h1,h2,h3,p,li,blockquote,figcaption');
    var out = [], seen = Object.create(null);
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!visible(el) || el.closest('nav,header,footer,aside,[aria-hidden="true"],figure,picture,svg,video,audio,.mw-editsection,.toc,.navbox,.metadata,.reflist,.references,.reference')) continue;
      // Reader mode is text-first: media and image-only blocks are deliberately omitted.
      var text;
      if (el.querySelector('img,picture,svg,video,canvas')) {
        var clone = el.cloneNode(true);
        Array.prototype.forEach.call(clone.querySelectorAll('img,picture,svg,video,canvas'), function (media) { media.remove(); });
        text = cleanText(clone);
        if (!text) continue;
      } else {
        text = cleanText(el);
      }
      if (text.length < (el.tagName === 'P' ? 35 : 12)) continue;
      if (seen[text]) continue;
      seen[text] = true;
      out.push({ tag: el.tagName.toLowerCase(), text: text });
    }
    return out;
  }
  function escapeHtml(value) {
    return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // Mozilla Readability is loaded on demand. The existing local extractor remains
  // available as an offline/failure fallback, so Reader does not become network-dependent.
  var readabilityLoadPromise = null;
  function ensureReadability() {
    if (typeof window.Readability === 'function') return Promise.resolve(true);
    if (readabilityLoadPromise) return readabilityLoadPromise;
    readabilityLoadPromise = new Promise(function (resolve) {
      var script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/@mozilla/readability@0.6.0/Readability.js';
      script.async = true;
      script.onload = function () { resolve(typeof window.Readability === 'function'); };
      script.onerror = function () { resolve(false); };
      (document.head || document.documentElement).appendChild(script);
    });
    return readabilityLoadPromise;
  }

  function safeArticleMarkup(html) {
    var parsed;
    try { parsed = new DOMParser().parseFromString(String(html || ''), 'text/html'); }
    catch (_) { return ''; }
    var allowed = { P:1, H1:1, H2:1, H3:1, H4:1, UL:1, OL:1, LI:1,
      BLOCKQUOTE:1, PRE:1, CODE:1, STRONG:1, B:1, EM:1, I:1, BR:1, HR:1,
      FIGURE:1, FIGCAPTION:1 };
    var blocked = { SCRIPT:1, STYLE:1, NOSCRIPT:1, IFRAME:1, OBJECT:1, EMBED:1,
      VIDEO:1, AUDIO:1, SOURCE:1, SVG:1, CANVAS:1, FORM:1,
      BUTTON:1, INPUT:1, NAV:1, FOOTER:1, HEADER:1, ASIDE:1 };
    function walk(node) {
      if (node.nodeType === 3) return escapeHtml(node.nodeValue || '');
      if (node.nodeType !== 1) return '';
      var tag = node.tagName;
      if (blocked[tag]) return '';
      if (tag === 'IMG') {
        var rawSrc = node.getAttribute('src') || node.getAttribute('data-src') ||
          node.getAttribute('data-lazy-src') || node.getAttribute('data-original') || '';
        if (!rawSrc) return '';
        var safeSrc = '';
        try {
          var parsedUrl = new URL(rawSrc, document.baseURI);
          if (parsedUrl.protocol === 'https:' || parsedUrl.protocol === 'http:') safeSrc = parsedUrl.href;
        } catch (_) {}
        if (!safeSrc) return '';
        var alt = escapeHtml(node.getAttribute('alt') || '');
        return '<img src="' + escapeHtml(safeSrc) + '" alt="' + alt + '" loading="lazy">';
      }
      var inner = '';
      for (var child = node.firstChild; child; child = child.nextSibling) inner += walk(child);
      if (!allowed[tag]) return inner;
      var name = tag.toLowerCase();
      if (name === 'br' || name === 'hr') return '<' + name + '>';
      return '<' + name + '>' + inner + '</' + name + '>';
    }
    var result = '';
    var body = parsed.body;
    for (var child = body.firstChild; child; child = child.nextSibling) result += walk(child);
    return result;
  }

  function readWithMozilla() {
    if (typeof window.Readability !== 'function') return null;
    try {
      var clonedDocument = document.cloneNode(true);
      var article = new window.Readability(clonedDocument, {
        charThreshold: 120,
        keepClasses: false,
        disableJSONLD: false
      }).parse();
      if (!article || !article.content) return null;
      var markup = safeArticleMarkup(article.content);
      var plain = markup.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
      if (plain.length < 100) return null;
      return { title: article.title || document.title || 'Article', markup: markup, length: plain.length };
    } catch (_) { return null; }
  }

  function makeReader() {
    var existing = document.getElementById(overlayId);
    if (existing) { existing.remove(); return true; }

    var mozillaArticle = readWithMozilla();
    var article = chooseArticle();
    var blocks = collectBlocks(article);
    var total = blocks.reduce(function (n, b) { return n + b.text.length; }, 0);
    if (total < 220) {
      blocks = collectBlocks(document.body);
      total = blocks.reduce(function (n, b) { return n + b.text.length; }, 0);
    }
    if (total < 220) {
      // Fallback for news sites whose story text is outside semantic article containers.
      var candidates = Array.prototype.slice.call(document.querySelectorAll('h1,h2,h3,p,blockquote,li'));
      var fallback = [], seenFallback = Object.create(null);
      candidates.forEach(function (el) {
        if (!visible(el) || el.closest('nav,header,footer,aside,[aria-hidden="true"],[role="navigation"],[role="complementary"],[class*="advert"],[id*="advert"],[class*="related"],[class*="recommend"],#' + overlayId)) return;
        var text = cleanText(el);
        if (text.length < (el.tagName === 'P' ? 28 : 14) || seenFallback[text]) return;
        seenFallback[text] = true;
        fallback.push({ tag: el.tagName.toLowerCase(), text: text });
      });
      var fallbackTotal = fallback.reduce(function (n, b) { return n + b.text.length; }, 0);
      if (fallbackTotal > total) { blocks = fallback; total = fallbackTotal; }
    }
    if (!mozillaArticle && (total < 100 || !blocks.length)) return false;

    var title = (mozillaArticle && mozillaArticle.title) ||
      cleanText(document.querySelector('h1')) || document.title || 'Article';
    var content = (mozillaArticle && mozillaArticle.markup) || blocks.map(function (b) {
      var tag = /^(h1|h2|h3|blockquote|li)$/.test(b.tag) ? b.tag : 'p';
      return '<' + tag + '>' + escapeHtml(b.text) + '</' + tag + '>';
    }).join('');

    var overlay = document.createElement('div');
    overlay.id = overlayId;
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-label', 'Reader mode');
    overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;overflow:auto;overscroll-behavior:contain;' +
      'background:#fff;color:#202124;padding:calc(28px + env(safe-area-inset-top)) 22px calc(34px + env(safe-area-inset-bottom));' +
      'font:17px/1.75 Inter,Arial,sans-serif;-webkit-overflow-scrolling:touch;box-sizing:border-box;';

    overlay.innerHTML =
      '<style id="valley-reader-theme-style">' +
        '#valley-reader-overlay[data-theme="dark"]{background:#111318!important;color:#eceef2!important}' +
        '#valley-reader-overlay[data-theme="dark"] #valley-reader-title,' +
        '#valley-reader-overlay[data-theme="dark"] #valley-reader-content{color:#eceef2!important}' +
        '#valley-reader-overlay[data-theme="dark"] #valley-reader-content p,' +
        '#valley-reader-overlay[data-theme="dark"] #valley-reader-content li,' +
        '#valley-reader-overlay[data-theme="dark"] #valley-reader-content blockquote{color:#d9dce3!important}' +
        '#valley-reader-overlay[data-theme="dark"] #valley-reader-content h1,' +
        '#valley-reader-overlay[data-theme="dark"] #valley-reader-content h2,' +
        '#valley-reader-overlay[data-theme="dark"] #valley-reader-content h3{color:#fff!important}' +
        '#valley-reader-overlay[data-theme="dark"] .valley-reader-meta{color:#a5aab5!important}' +
        '#valley-reader-overlay[data-theme="dark"] .valley-reader-end{border-color:#3b404b!important;color:#a5aab5!important}' +
        '#valley-reader-overlay[data-theme="dark"] .valley-reader-control{background:#292d36!important;color:#f2f3f6!important;border-color:#555b68!important}' +
        '#valley-reader-overlay[data-theme="dark"] .valley-reader-control [data-active="true"]{background:#454b58!important;color:#fff!important}' +
        '#valley-reader-overlay[data-theme="light"]{background:#fff!important;color:#202124!important}' +
        '#valley-reader-content img{display:block;max-width:100%;height:auto;margin:22px auto;border-radius:12px;object-fit:contain}' +
        '#valley-reader-content figure{margin:22px 0;padding:0}' +
        '#valley-reader-content figcaption{font-size:.82em;line-height:1.45;color:#777;text-align:center;margin-top:8px}' +
        '#valley-reader-overlay[data-theme="dark"] #valley-reader-content figcaption{color:#a5aab5!important}' +
        '@media(max-width:390px){#valley-reader-controls{gap:6px!important}#valley-reader-font-picker button{padding:7px 7px!important;font-size:12px!important}#valley-reader-theme-toggle{padding:8px 10px!important}}' +
      '</style>' +
      '<div id="valley-reader-controls" style="position:fixed;top:12vh;left:50%;transform:translateX(-50%);z-index:3;display:flex;align-items:center;justify-content:center;gap:9px;max-width:calc(100vw - 24px);white-space:nowrap">' +
        '<div id="valley-reader-font-picker" class="valley-reader-control" role="group" aria-label="Reader font" style="display:flex;align-items:center;gap:0;padding:5px 7px;border:1px solid rgba(80,80,80,.28);border-radius:999px;background:rgba(245,245,245,.97);box-shadow:0 5px 22px rgba(0,0,0,.16);box-sizing:border-box">' +
          '<button type="button" data-font="inter" data-active="true" style="font:500 14px Inter,Arial,sans-serif;color:#202124;background:rgba(30,30,30,.10);border:0;border-radius:999px;padding:8px 10px">Inter</button>' +
          '<span aria-hidden="true" style="color:#999">|</span>' +
          '<button type="button" data-font="consolas" style="font:14px Consolas,monospace;color:#202124;background:transparent;border:0;border-radius:999px;padding:8px 10px">Consolas</button>' +
          '<span aria-hidden="true" style="color:#999">|</span>' +
          '<button type="button" data-font="garamond" style="font:italic 15px Garamond,Georgia,serif;color:#202124;background:transparent;border:0;border-radius:999px;padding:8px 10px">Garamond</button>' +
        '</div>' +
        '<button id="valley-reader-theme-toggle" class="valley-reader-control" type="button" aria-label="Switch to dark reader background" aria-pressed="false" style="display:flex;align-items:center;justify-content:center;min-width:48px;padding:10px 13px;border:1px solid rgba(80,80,80,.28);border-radius:999px;background:rgba(245,245,245,.97);box-shadow:0 5px 22px rgba(0,0,0,.16);color:#202124;font:600 16px Inter,Arial,sans-serif">☾</button>' +
      '</div>' +
      '<main style="max-width:680px;margin:0 auto;padding-top:calc(25vh + 64px)">' +
        '<div class="valley-reader-meta" style="font:600 10px/1.2 Inter,Arial,sans-serif;letter-spacing:.2em;text-transform:uppercase;color:#777;margin-bottom:16px">VALLEY READER</div>' +
        '<h1 id="valley-reader-title" style="font:600 30px/1.18 Inter,Arial,sans-serif;letter-spacing:-.02em;margin:0 0 25px;color:#202124">' + escapeHtml(title) + '</h1>' +
        '<div id="valley-reader-content" style="font:17px/1.75 Inter,Arial,sans-serif;color:#202124">' + content + '</div>' +
        '<div class="valley-reader-end" style="margin-top:36px;padding-top:14px;border-top:1px solid #ddd;font:500 11px Inter,Arial,sans-serif;letter-spacing:.12em;text-transform:uppercase;color:#777">End of article</div>' +
      '</main>';

    var picker = overlay.querySelector('#valley-reader-font-picker');
    picker.addEventListener('click', function (event) {
      var button = event.target.closest('button[data-font]');
      if (!button) return;
      var font = button.getAttribute('data-font');
      var stack = font === 'consolas' ? 'Consolas,monospace' :
        (font === 'garamond' ? 'Garamond,Georgia,serif' : 'Inter,Arial,sans-serif');
      var contentNode = overlay.querySelector('#valley-reader-content');
      var titleNode = overlay.querySelector('#valley-reader-title');
      contentNode.style.fontFamily = stack;
      titleNode.style.fontFamily = stack;
      Array.prototype.forEach.call(picker.querySelectorAll('button[data-font]'), function (item) {
        var active = item === button;
        item.style.background = active ? 'rgba(30,30,30,.10)' : 'transparent';
        item.setAttribute('data-active', active ? 'true' : 'false');
        item.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
    });

    var themeToggle = overlay.querySelector('#valley-reader-theme-toggle');
    themeToggle.addEventListener('click', function () {
      var dark = overlay.getAttribute('data-theme') !== 'dark';
      overlay.setAttribute('data-theme', dark ? 'dark' : 'light');
      themeToggle.textContent = dark ? '☀' : '☾';
      themeToggle.setAttribute('aria-pressed', dark ? 'true' : 'false');
      themeToggle.setAttribute('aria-label', dark ? 'Switch to light reader background' : 'Switch to dark reader background');
    });
    overlay.setAttribute('data-theme', 'light');
    document.body.appendChild(overlay);
    overlay.scrollTop = 0;
    return true;
  }

  var readerLoadPending = false;
  window.ulaaReaderToggle = function () {
    var existing = document.getElementById(overlayId);
    if (existing) {
      existing.remove();
      return true;
    }
    // Render immediately with Valley's local parser. Do not make Reader depend
    // on a third-party CDN being reachable inside the page's WebView.
    if (typeof window.Readability === 'function') return makeReader();
    var opened = makeReader();
    if (opened) {
      ensureReadability(); // cache the engine for a future page where local parsing is weak
      return true;
    }
    if (readerLoadPending) return true;
    readerLoadPending = true;
    window.__valleyReaderPending = true;
    ensureReadability().then(function () {
      readerLoadPending = false;
      try { if (!document.getElementById(overlayId)) makeReader(); } catch (_) {}
      window.__valleyReaderPending = false;
    });
    return true;
  };
  /* 'open' | 'pending' | 'none' : lets the app tell a slow open from a real failure */
  window.ulaaReaderState = function () {
    if (document.getElementById(overlayId)) return 'open';
    return window.__valleyReaderPending ? 'pending' : 'none';
  };
  // Native Reader controls call these functions through the active WebView.
  window.setReaderFont = function (fontType) {
    var overlay = document.getElementById(overlayId);
    if (!overlay) return false;
    var font = String(fontType || 'Inter').toLowerCase();
    var stack = font === 'garamond' ? 'Garamond,Georgia,serif' :
      (font === 'consolas' ? 'Consolas,"Courier New",monospace' : 'Inter,system-ui,-apple-system,sans-serif');
    var content = overlay.querySelector('#valley-reader-content');
    var title = overlay.querySelector('#valley-reader-title');
    if (content) content.style.fontFamily = stack;
    if (title) title.style.fontFamily = stack;
    var buttons = overlay.querySelectorAll('#valley-reader-font-picker button[data-font]');
    Array.prototype.forEach.call(buttons, function (button) {
      var active = button.getAttribute('data-font') === font;
      button.style.background = active ? 'rgba(30,30,30,.10)' : 'transparent';
      button.setAttribute('data-active', active ? 'true' : 'false');
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
    return true;
  };
  window.toggleReaderTheme = function (isDark) {
    var overlay = document.getElementById(overlayId);
    if (!overlay) return false;
    var dark = (typeof isDark === 'boolean') ? isDark : overlay.getAttribute('data-theme') !== 'dark';
    overlay.setAttribute('data-theme', dark ? 'dark' : 'light');
    var button = overlay.querySelector('#valley-reader-theme-toggle');
    if (button) {
      button.textContent = dark ? '☀' : '☾';
      button.setAttribute('aria-pressed', dark ? 'true' : 'false');
      button.setAttribute('aria-label', dark ? 'Switch to light reader background' : 'Switch to dark reader background');
    }
    return true;
  };
  window.ulaaReaderOpen = function () {
    if (document.getElementById(overlayId)) return true;
    return window.ulaaReaderToggle();
  };
})();
