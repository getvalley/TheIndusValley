(function () {
  'use strict';
  if (window.ValleyPageCleanup && window.ValleyPageCleanup.version >= 3) {
    window.ValleyPageCleanup.applySaved();
    return;
  }

  var key = 'valley_cleanup_hidden_' + location.hostname;
  var hiddenAttr = 'data-valley-cleanup-hidden';
  var active = false, selected = null, hovered = null, sheet = null;
  var highlight = null, doneButton = null, observer = null;
  var savedStyleId = 'valley-cleanup-style';

  function selectors() {
    try {
      var value = JSON.parse(localStorage.getItem(key) || '[]');
      return Array.isArray(value) ? value : [];
    } catch (_) { return []; }
  }
  function save(list) {
    try { localStorage.setItem(key, JSON.stringify(list)); return true; }
    catch (_) { return false; }
  }
  function count() { return selectors().length; }

  function hideElement(el) {
    if (!el || el.nodeType !== 1 || el.hasAttribute(hiddenAttr)) return;
    el.setAttribute(hiddenAttr, '1');
    el.setAttribute('data-valley-cleanup-old-display', el.style.getPropertyValue('display'));
    el.setAttribute('data-valley-cleanup-old-priority', el.style.getPropertyPriority('display'));
    el.style.setProperty('display', 'none', 'important');
  }

  function applySaved() {
    selectors().forEach(function (selector) {
      try { document.querySelectorAll(selector).forEach(hideElement); } catch (_) {}
    });
  }

  function addStyles() {
    if (document.getElementById(savedStyleId)) return;
    var style = document.createElement('style');
    style.id = savedStyleId;
    style.textContent = `
      [${hiddenAttr}="1"] { display:none!important; }
      #valley-cleanup-highlight {
        position:fixed!important; z-index:2147483644!important; pointer-events:none!important;
        border:2px solid #0a84ff!important; border-radius:9px!important;
        background:rgba(10,132,255,.12)!important; box-shadow:0 0 0 9999px rgba(0,0,0,.12)!important;
        box-sizing:border-box!important; display:none;
      }
      #valley-cleanup-panel {
        position:fixed!important; z-index:2147483647!important; left:12px!important; right:12px!important;
        bottom:calc(12px + env(safe-area-inset-bottom))!important; padding:16px!important;
        border-radius:20px!important; color:#f7f7f7!important; background:rgba(28,29,33,.97)!important;
        border:1px solid rgba(255,255,255,.16)!important; box-shadow:0 12px 40px rgba(0,0,0,.4)!important;
        font:500 15px/1.4 -apple-system,BlinkMacSystemFont,system-ui,sans-serif!important;
        -webkit-backdrop-filter:blur(22px)!important; backdrop-filter:blur(22px)!important;
      }
      #valley-cleanup-panel .vpc-title { font-size:16px!important; font-weight:700!important; margin:0 0 4px!important; }
      #valley-cleanup-panel .vpc-desc { font-size:12px!important; opacity:.72!important; margin:0 0 10px!important; }
      #valley-cleanup-panel button {
        display:block!important; width:100%!important; min-height:44px!important; border:0!important;
        border-radius:12px!important; margin-top:8px!important; padding:10px!important;
        font:700 15px -apple-system,BlinkMacSystemFont,system-ui,sans-serif!important;
      }
      #valley-cleanup-panel .vpc-hide { background:#0a84ff!important; color:white!important; }
      #valley-cleanup-panel .vpc-cancel { background:rgba(255,255,255,.13)!important; color:white!important; }
      #valley-cleanup-done {
        position:fixed!important; top:calc(14px + env(safe-area-inset-top))!important; right:14px!important;
        z-index:2147483647!important; width:44px!important; height:44px!important; min-width:44px!important;
        min-height:44px!important; padding:0!important; margin:0!important; border-radius:50%!important;
        display:flex!important; align-items:center!important; justify-content:center!important;
        border:1px solid rgba(255,255,255,.45)!important; background:#0a84ff!important; color:#fff!important;
        font:700 23px/1 -apple-system,BlinkMacSystemFont,system-ui,sans-serif!important;
        box-shadow:0 4px 16px rgba(0,0,0,.3)!important; touch-action:manipulation!important;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function isToolElement(el) {
    return !el || !el.closest || !!el.closest(
      '#valley-cleanup-panel,#valley-cleanup-done,#valley-cleanup-highlight,[data-valley-cleanup-hidden]'
    );
  }

  function visible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 24 || r.height < 18) return false;
    var cs;
    try { cs = getComputedStyle(el); } catch (_) { return false; }
    return cs.display !== 'none' && cs.visibility !== 'hidden' && Number(cs.opacity) !== 0;
  }

  function chooseContainer(target) {
    if (!target || target.nodeType !== 1) return null;
    var node = target, candidates = [], vw = Math.max(1, innerWidth), vh = Math.max(1, innerHeight);
    for (var depth = 0; node && node !== document.body && node !== document.documentElement && depth < 8; depth++, node = node.parentElement) {
      if (!visible(node) || isToolElement(node)) continue;
      var r = node.getBoundingClientRect();
      var area = Math.min(r.width, vw) * Math.min(r.height, vh);
      var ratio = area / (vw * vh);
      var text = (node.innerText || node.getAttribute('aria-label') || '').trim();
      var role = (node.getAttribute('role') || '').toLowerCase();
      var tag = node.tagName.toLowerCase();
      var hint = ((node.id || '') + ' ' + (typeof node.className === 'string' ? node.className : '') + ' ' + role).toLowerCase();
      var semantic = /dialog|banner|alertdialog|complementary/.test(role) ||
        /cookie|consent|privacy|modal|popup|newsletter|subscribe|overlay|paywall/.test(hint);
      var fixed = getComputedStyle(node).position === 'fixed' || getComputedStyle(node).position === 'sticky';
      var block = /^(div|section|aside|header|footer|article|form|nav)$/.test(tag);
      if (!text && !semantic) continue;
      var score = Math.log(1 + area) + Math.min(text.length, 300) / 100;
      if (semantic) score += 18;
      if (fixed) score += 12;
      if (block) score += 2;
      if (ratio > .82) score -= 24;
      if (ratio < .015) score -= 10;
      if (depth > 5) score -= depth;
      candidates.push({el:node, score:score, ratio:ratio, depth:depth, semantic:semantic});
    }
    if (!candidates.length) return target;
    candidates.sort(function(a,b){ return b.score-a.score; });
    var best = candidates[0];
    // For ordinary page content avoid selecting a massive page wrapper.
    if (best.ratio > .82 && !best.semantic) {
      candidates = candidates.filter(function(c){ return c.ratio <= .82 || c.semantic; });
      if (candidates.length) best = candidates[0];
    }
    // Prefer a nearby sensible block unless a consent/dialog container is clearly identified.
    var nearby = candidates.filter(function(c){ return c.depth <= 3; });
    if (nearby.length && !best.semantic) {
      nearby.sort(function(a,b){ return b.score-a.score; });
      if (nearby[0].score >= best.score - 5) best = nearby[0];
    }
    return best.el;
  }

  function makeSelector(el) {
    if (!el || !el.tagName) return null;
    function esc(s) {
      return String(s).replace(/[^a-zA-Z0-9_-]/g, function(ch) {
        return '\\' + ch.codePointAt(0).toString(16) + ' ';
      });
    }
    if (el.id && !/^valley-cleanup/.test(el.id)) {
      var byId = '#' + esc(el.id);
      try { if (document.querySelectorAll(byId).length === 1) return byId; } catch (_) {}
    }
    var path = [], node = el;
    while (node && node.nodeType === 1 && node !== document.documentElement && path.length < 7) {
      var part = node.tagName.toLowerCase();
      if (node.id && !/^valley-cleanup/.test(node.id)) {
        part = '#' + esc(node.id);
        path.unshift(part);
        break;
      }
      var classes = Array.prototype.slice.call(node.classList || []).filter(function(c) {
        return c.length < 40 && !/^valley-cleanup/.test(c);
      }).slice(0, 2);
      if (classes.length) part += '.' + classes.map(esc).join('.');
      var parent = node.parentElement;
      if (parent) {
        var same = Array.prototype.filter.call(parent.children, function(x) {
          return x.tagName === node.tagName;
        });
        if (same.length > 1) part += ':nth-of-type(' + (same.indexOf(node) + 1) + ')';
      }
      path.unshift(part);
      var candidate = path.join(' > ');
      try { if (document.querySelectorAll(candidate).length === 1) return candidate; } catch (_) {}
      node = parent;
    }
    return path.join(' > ') || null;
  }

  function updateHighlight(el) {
    hovered = el;
    if (!highlight) return;
    if (!el || !visible(el)) { highlight.style.display = 'none'; return; }
    var r = el.getBoundingClientRect();
    highlight.style.display = 'block';
    highlight.style.left = Math.max(0, r.left) + 'px';
    highlight.style.top = Math.max(0, r.top) + 'px';
    highlight.style.width = Math.max(0, Math.min(innerWidth, r.right) - Math.max(0, r.left)) + 'px';
    highlight.style.height = Math.max(0, Math.min(innerHeight, r.bottom) - Math.max(0, r.top)) + 'px';
  }

  function closePanel() {
    if (sheet) { sheet.remove(); sheet = null; }
    selected = null;
  }

  function stop() {
    active = false;
    document.removeEventListener('click', onPick, true);
    document.removeEventListener('pointermove', onMove, true);
    document.removeEventListener('touchmove', onTouchMove, true);
    document.removeEventListener('keydown', onKeyDown, true);
    if (observer) { observer.disconnect(); observer = null; }
    if (highlight) { highlight.remove(); highlight = null; }
    if (doneButton) { doneButton.remove(); doneButton = null; }
    closePanel();
  }

  function showConfirm(el) {
    closePanel();
    selected = el;
    updateHighlight(el);
    var text = (el.innerText || el.getAttribute('aria-label') || el.tagName).trim().replace(/\s+/g, ' ');
    if (text.length > 100) text = text.slice(0, 97) + '...';
    sheet = document.createElement('div');
    sheet.id = 'valley-cleanup-panel';
    var title = document.createElement('div');
    title.className = 'vpc-title';
    title.textContent = 'Hide this item?';
    var desc = document.createElement('div');
    desc.className = 'vpc-desc';
    desc.textContent = text || 'Selected webpage element';
    var yes = document.createElement('button');
    yes.type = 'button'; yes.className = 'vpc-hide'; yes.textContent = 'Hide Item';
    var no = document.createElement('button');
    no.type = 'button'; no.className = 'vpc-cancel'; no.textContent = 'Cancel';
    yes.addEventListener('click', function(e) {
      e.preventDefault(); e.stopPropagation();
      var selector = makeSelector(selected);
      if (!selector) { closePanel(); return; }
      var list = selectors();
      if (list.indexOf(selector) < 0) list.push(selector);
      if (!save(list)) {
        desc.textContent = 'Could not save this change. This site may block local storage.';
        return;
      }
      hideElement(selected);
      closePanel();
      updateHighlight(null);
    });
    no.addEventListener('click', function(e) {
      e.preventDefault(); e.stopPropagation(); closePanel(); updateHighlight(null);
    });
    sheet.appendChild(title); sheet.appendChild(desc); sheet.appendChild(yes); sheet.appendChild(no);
    document.body.appendChild(sheet);
  }

  function onMove(e) {
    if (!active || sheet) return;
    var el = document.elementFromPoint(e.clientX, e.clientY);
    if (isToolElement(el)) return;
    updateHighlight(chooseContainer(el));
  }
  function onTouchMove(e) {
    if (!active || sheet || !e.touches || !e.touches.length) return;
    var t = e.touches[0], el = document.elementFromPoint(t.clientX, t.clientY);
    if (!isToolElement(el)) updateHighlight(chooseContainer(el));
  }
  function onPick(e) {
    if (!active || sheet || e.button > 0 || isToolElement(e.target)) return;
    var target = document.elementFromPoint(e.clientX, e.clientY) || e.target;
    if (isToolElement(target)) return;
    var candidate = chooseContainer(target);
    if (!candidate) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    showConfirm(candidate);
  }

  function onKeyDown(e) {
    if (active && e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      stop();
    }
  }

  function start() {
    if (active) return true;
    if (!document.body) return false;
    addStyles();
    active = true;
    highlight = document.createElement('div');
    highlight.id = 'valley-cleanup-highlight';
    document.body.appendChild(highlight);
    doneButton = document.createElement('button');
    doneButton.id = 'valley-cleanup-done';
    doneButton.type = 'button';
    doneButton.setAttribute('aria-label', 'Finish hiding items');
    doneButton.textContent = '✓';
    doneButton.addEventListener('click', function(e) {
      e.preventDefault(); e.stopPropagation(); stop();
    });
    document.body.appendChild(doneButton);
    document.addEventListener('click', onPick, true);
    document.addEventListener('pointermove', onMove, true);
    document.addEventListener('touchmove', onTouchMove, {capture:true, passive:true});
    document.addEventListener('keydown', onKeyDown, true);
    if (window.MutationObserver && document.body) {
      observer = new MutationObserver(function() { if (!active) return; applySaved(); });
      observer.observe(document.body, {childList:true, subtree:true});
    }
    return true;
  }

  function restore() {
    var list = selectors();
    try { localStorage.removeItem(key); } catch (_) {}
    document.querySelectorAll('[' + hiddenAttr + ']').forEach(function(el) {
      var old = el.getAttribute('data-valley-cleanup-old-display');
      var priority = el.getAttribute('data-valley-cleanup-old-priority') || '';
      if (old) el.style.setProperty('display', old, priority);
      else el.style.removeProperty('display');
      el.removeAttribute(hiddenAttr);
      el.removeAttribute('data-valley-cleanup-old-display');
      el.removeAttribute('data-valley-cleanup-old-priority');
    });
    stop();
    return list.length;
  }

  applySaved();
  if (window.MutationObserver && document.documentElement) {
    var savedObserver = new MutationObserver(function() { applySaved(); });
    savedObserver.observe(document.documentElement, {childList:true, subtree:true});
  }
  window.ValleyPageCleanup = {
    version: 3,
    start: start,
    toggle: function() { if (active) { stop(); return false; } return start(); },
    restore: restore,
    count: count,
    applySaved: applySaved,
    isReady: true
  };
})();
