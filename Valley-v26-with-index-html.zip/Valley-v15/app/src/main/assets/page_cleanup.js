(function () {
  'use strict';

  var VERSION = 9;
  if (window.ValleyPageCleanup && window.ValleyPageCleanup.version >= VERSION) {
    try { window.ValleyPageCleanup.applySaved(); } catch (_) {}
    return;
  }

  var hostKey = String(location.hostname || 'page').replace(/[^a-z0-9.-]/gi, '_');
  var storageKey = 'valley_cleanup_hidden_' + hostKey;
  var hiddenAttr = 'data-valley-cleanup-hidden';
  var styleId = 'valley-cleanup-style';
  var active = false;
  var selected = null;
  var selectedOriginalFilter = null;
  var hovered = null;
  var panel = null;
  var highlight = null;
  var doneButton = null;
  var hint = null;
  var downX = 0, downY = 0;
  var observer = null;
  var usingPointerEvents = !!window.PointerEvent;

  function readSelectors() {
    var values = [];
    try {
      var stored = JSON.parse(window.localStorage.getItem(storageKey) || '[]');
      if (Array.isArray(stored)) values = stored.filter(function (v) { return typeof v === 'string'; });
    } catch (_) {}
    if (Array.isArray(window.__valleyCleanupFallback)) {
      values = values.concat(window.__valleyCleanupFallback.filter(function (v) { return typeof v === 'string'; }));
    }
    return Array.from(new Set(values));
  }

  function saveSelectors(values) {
    window.__valleyCleanupFallback = values.slice();
    try { window.localStorage.setItem(storageKey, JSON.stringify(values)); } catch (_) {}
  }

  function count() { return readSelectors().length; }

  function isToolNode(node) {
    if (!node || !node.closest) return false;
    return !!node.closest('#valley-cleanup-panel,#valley-cleanup-done,#valley-cleanup-highlight,#valley-cleanup-hint');
  }

  function isVisible(el) {
    if (!el || el.nodeType !== 1 || !el.getBoundingClientRect) return false;
    var rect = el.getBoundingClientRect();
    if (rect.width < 8 || rect.height < 8) return false;
    var css;
    try { css = window.getComputedStyle(el); } catch (_) { return false; }
    return css.display !== 'none' && css.visibility !== 'hidden' && Number(css.opacity) !== 0;
  }

  function chooseElement(target) {
    if (!target || target.nodeType !== 1) return null;
    var node = target;
    // Avoid selecting tiny inline glyphs when the user taps an icon or text fragment.
    for (var i = 0; i < 3 && node.parentElement && node.parentElement !== document.body; i++) {
      var r = node.getBoundingClientRect();
      var p = node.parentElement.getBoundingClientRect();
      if ((r.width < 28 || r.height < 24) &&
          p.width <= window.innerWidth * 0.92 && p.height <= window.innerHeight * 0.92) {
        node = node.parentElement;
      } else break;
    }

    var best = node;
    var bestScore = -Infinity;
    var current = node;
    for (var depth = 0; current && current !== document.body &&
         current !== document.documentElement && depth < 6; depth++, current = current.parentElement) {
      if (!isVisible(current) || isToolNode(current)) continue;
      var rect = current.getBoundingClientRect();
      var area = Math.max(0, rect.width) * Math.max(0, rect.height);
      var ratio = area / Math.max(1, window.innerWidth * window.innerHeight);
      var role = (current.getAttribute('role') || '').toLowerCase();
      var hint = ((current.id || '') + ' ' +
        (typeof current.className === 'string' ? current.className : '') + ' ' + role).toLowerCase();
      var semantic = /dialog|alertdialog|banner|complementary/.test(role) ||
        /cookie|consent|privacy|modal|popup|newsletter|subscribe|paywall|advert/.test(hint);
      var position = window.getComputedStyle(current).position;
      var score = 10 - depth * 2;
      if (semantic) score += 30;
      if (position === 'fixed' || position === 'sticky') score += 8;
      if (ratio > 0.88) score -= 35;
      if (ratio > 0.72) score -= 12;
      if (area < 500) score -= 10;
      if (score > bestScore) { bestScore = score; best = current; }
      if (semantic) break;
    }
    return best;
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
    return String(value).replace(/[^a-zA-Z0-9_-]/g, function (ch) {
      return '\\' + ch.codePointAt(0).toString(16) + ' ';
    });
  }

  function makeSelector(el) {
    if (!el || !el.tagName) return null;
    if (el.id && !/^valley-cleanup/.test(el.id)) {
      var idSelector = '#' + cssEscape(el.id);
      try { if (document.querySelectorAll(idSelector).length === 1) return idSelector; } catch (_) {}
    }

    var parts = [];
    var node = el;
    while (node && node.nodeType === 1 && node !== document.documentElement && parts.length < 9) {
      var part = node.tagName.toLowerCase();
      if (node.id && !/^valley-cleanup/.test(node.id)) {
        part = '#' + cssEscape(node.id);
        parts.unshift(part);
        break;
      }
      var classes = Array.prototype.slice.call(node.classList || [])
        .filter(function (c) { return c.length < 48 && !/^valley-cleanup/.test(c); }).slice(0, 2);
      if (classes.length) part += '.' + classes.map(cssEscape).join('.');
      var parent = node.parentElement;
      if (parent) {
        var sameTag = Array.prototype.filter.call(parent.children, function (child) {
          return child.tagName === node.tagName;
        });
        if (sameTag.length > 1) part += ':nth-of-type(' + (sameTag.indexOf(node) + 1) + ')';
      }
      parts.unshift(part);
      var candidate = parts.join(' > ');
      try { if (document.querySelectorAll(candidate).length === 1) return candidate; } catch (_) {}
      node = parent;
    }
    var result = parts.join(' > ');
    try { return document.querySelectorAll(result).length ? result : null; } catch (_) { return null; }
  }

  function hideElement(el) {
    if (!el || el.nodeType !== 1 || el.hasAttribute(hiddenAttr)) return;
    el.setAttribute('data-valley-cleanup-old-display', el.style.getPropertyValue('display'));
    el.setAttribute('data-valley-cleanup-old-priority', el.style.getPropertyPriority('display'));
    el.setAttribute(hiddenAttr, '1');
    el.style.setProperty('display', 'none', 'important');
  }

  var applyQueued = false;
  function scheduleApply() {
    if (applyQueued) return;
    applyQueued = true;
    (window.requestAnimationFrame || window.setTimeout)(function () { applyQueued = false; applySaved(); });
  }

  function applySaved() {
    readSelectors().forEach(function (selector) {
      try { document.querySelectorAll(selector).forEach(hideElement); } catch (_) {}
    });
  }

  /* Styles are applied through the CSSOM (el.style.setProperty). Unlike a <style> element,
     this is not blocked by a site's Content-Security-Policy, so the picker UI shows on every page. */
  function setStyles(el, props) {
    Object.keys(props).forEach(function (k) { el.style.setProperty(k, props[k], 'important'); });
    return el;
  }

  function make(tag, id, props, text) {
    var el = document.createElement(tag);
    if (id) el.id = id;
    if (text) el.textContent = text;
    return setStyles(el, props);
  }

  var FONT = 'system-ui,-apple-system,Roboto,sans-serif';

  function updateHighlight(el) {
    hovered = el;
    if (!highlight) return;
    if (!el || !isVisible(el)) { setStyles(highlight, { display: 'none' }); return; }
    var rect = el.getBoundingClientRect();
    var left = Math.max(0, rect.left), top = Math.max(0, rect.top);
    setStyles(highlight, {
      display: 'block',
      left: left + 'px',
      top: top + 'px',
      width: Math.max(0, Math.min(window.innerWidth, rect.right) - left) + 'px',
      height: Math.max(0, Math.min(window.innerHeight, rect.bottom) - top) + 'px'
    });
  }

  function restoreSelectedBlur() {
    if (!selected || !selectedOriginalFilter) return;
    try {
      if (selectedOriginalFilter.value) {
        selected.style.setProperty('filter', selectedOriginalFilter.value, selectedOriginalFilter.priority);
      } else {
        selected.style.removeProperty('filter');
      }
      if (selectedOriginalFilter.transition) {
        selected.style.setProperty('transition', selectedOriginalFilter.transition, selectedOriginalFilter.transitionPriority);
      } else {
        selected.style.removeProperty('transition');
      }
    } catch (_) {}
    selectedOriginalFilter = null;
  }

  function closePanel() {
    if (panel) { panel.remove(); panel = null; }
    restoreSelectedBlur();
    selected = null;
  }

  function stop() {
    active = false;
    window.removeEventListener('pointerup', onPointerUp, true);
    window.removeEventListener('touchend', onTouchEnd, true);
    window.removeEventListener('click', onClick, true);
    window.removeEventListener('pointerdown', onDown, true);
    window.removeEventListener('touchstart', onDown, true);
    window.removeEventListener('pointermove', onPointerMove, true);
    window.removeEventListener('touchmove', onTouchMove, true);
    window.removeEventListener('keydown', onKeyDown, true);
    window.removeEventListener('scroll', onViewportChange, true);
    window.removeEventListener('resize', onViewportChange, true);
    if (observer) { observer.disconnect(); observer = null; }
    if (highlight) { highlight.remove(); highlight = null; }
    if (doneButton) { doneButton.remove(); doneButton = null; }
    if (hint) { hint.remove(); hint = null; }
    closePanel();
  }

  function confirmSelection(el) {
    if (!el || !el.isConnected) return;
    closePanel();
    selected = el;
    try {
      selectedOriginalFilter = {
        value: el.style.getPropertyValue('filter'),
        priority: el.style.getPropertyPriority('filter'),
        transition: el.style.getPropertyValue('transition'),
        transitionPriority: el.style.getPropertyPriority('transition')
      };
      el.style.setProperty('filter', 'blur(3px)', 'important');
      el.style.setProperty('transition', 'filter .16s ease', 'important');
    } catch (_) {}

    var label = (el.innerText || el.getAttribute('aria-label') || el.tagName || 'Selected item')
      .trim().replace(/\s+/g, ' ');
    if (label.length > 110) label = label.slice(0, 107) + '...';

    var rect = el.getBoundingClientRect();
    var panelWidth = Math.min(232, Math.max(176, window.innerWidth - 32));
    var centerX = rect.left + rect.width / 2;
    var left = Math.max(8 + panelWidth / 2,
      Math.min(centerX, window.innerWidth - 8 - panelWidth / 2));
    var centerY = rect.top + rect.height / 2;
    var top = Math.max(8, Math.min(centerY - 25, window.innerHeight - 58));

    /* No card or modal: the two glass controls float directly over the blurred target. */
    panel = make('div', 'valley-cleanup-panel', {
      position: 'fixed', 'z-index': '2147483647',
      left: left + 'px', top: top + 'px',
      transform: 'translate(-50%, -50%)',
      display: 'flex', 'align-items': 'center', 'justify-content': 'center',
      gap: '9px', width: panelWidth + 'px',
      padding: '0', margin: '0',
      background: 'transparent', border: '0', 'border-radius': '0',
      'box-shadow': 'none', overflow: 'visible',
      color: '#f5f5f7', font: '600 14px/1 ' + FONT,
      'box-sizing': 'border-box', 'pointer-events': 'none'
    });

    var glassButton = {
      display: 'flex', 'align-items': 'center', 'justify-content': 'center',
      flex: '1 1 0', 'min-width': '0', height: '42px',
      padding: '0 13px', margin: '0',
      border: '1px solid rgba(255,255,255,.22)',
      'border-radius': '999px',
      background: 'rgba(28,31,38,.68)',
      color: '#f5f5f7',
      'box-shadow': '0 3px 14px rgba(0,0,0,.22)',
      'backdrop-filter': 'blur(22px) saturate(155%)',
      '-webkit-backdrop-filter': 'blur(22px) saturate(155%)',
      font: '600 14px/1 ' + FONT,
      'box-sizing': 'border-box',
      'touch-action': 'manipulation',
      'pointer-events': 'auto',
      'white-space': 'nowrap'
    };
    var hide = make('button', '', glassButton, 'Hide Item');
    hide.type = 'button';
    var cancel = make('button', '', glassButton, 'Cancel');
    cancel.type = 'button';

    hide.addEventListener('click', function (event) {
      event.preventDefault(); event.stopPropagation();
      if (!selected || !selected.isConnected) { closePanel(); return; }
      var selector = makeSelector(selected);
      if (!selector) { closePanel(); return; }
      var list = readSelectors();
      if (list.indexOf(selector) === -1) list.push(selector);
      restoreSelectedBlur();
      hideElement(selected);
      saveSelectors(list);
      closePanel();
      updateHighlight(null);
    });
    cancel.addEventListener('click', function (event) {
      event.preventDefault(); event.stopPropagation();
      closePanel(); updateHighlight(null);
    });
    panel.appendChild(hide);
    panel.appendChild(cancel);
    document.body.appendChild(panel);
  }

  function pickAt(x, y, event) {
    if (!active || panel) return;
    var target = document.elementFromPoint(x, y);
    if (!target || isToolNode(target)) return;
    var candidate = chooseElement(target);
    if (!candidate || isToolNode(candidate)) return;
    if (event) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    }
    confirmSelection(candidate);
  }

  function isToolEvent(event) {
    return isToolNode(event.target) && !!event.target.closest('#valley-cleanup-done,#valley-cleanup-panel');
  }

  function onDown(event) {
    var p = (event.touches && event.touches[0]) || event;
    downX = p.clientX; downY = p.clientY;
  }

  function moved(x, y) {
    return Math.abs(x - downX) > 12 || Math.abs(y - downY) > 12;
  }

  function onPointerUp(event) {
    if (!active || event.button !== 0) return;
    if (isToolEvent(event)) return;
    if (moved(event.clientX, event.clientY)) return;
    pickAt(event.clientX, event.clientY, event);
  }

  function onTouchEnd(event) {
    if (!active || !event.changedTouches || !event.changedTouches.length) return;
    if (isToolEvent(event)) return;
    var touch = event.changedTouches[0];
    if (moved(touch.clientX, touch.clientY)) return;
    pickAt(touch.clientX, touch.clientY, event);
  }

  /* While erasing, a tap must never reach the page: otherwise links and buttons would fire. */
  function onClick(event) {
    if (!active || isToolEvent(event)) return;
    event.preventDefault();
    event.stopPropagation();
    if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    if (!usingPointerEvents && !panel) pickAt(event.clientX, event.clientY, null);
  }

  function onPointerMove(event) {
    if (!active || panel) return;
    var target = document.elementFromPoint(event.clientX, event.clientY);
    if (target && !isToolNode(target)) updateHighlight(chooseElement(target));
  }

  function onTouchMove(event) {
    if (!active || panel || !event.touches || !event.touches.length) return;
    var touch = event.touches[0];
    var target = document.elementFromPoint(touch.clientX, touch.clientY);
    if (target && !isToolNode(target)) updateHighlight(chooseElement(target));
  }

  function onViewportChange() {
    if (active && hovered) updateHighlight(hovered);
  }

  function onKeyDown(event) {
    if (active && event.key === 'Escape') {
      event.preventDefault(); event.stopPropagation(); stop();
    }
  }

  function start() {
    if (active) return true;
    if (!document.body) return false;
    active = true;

    highlight = make('div', 'valley-cleanup-highlight', {
      position: 'fixed', 'z-index': '2147483645', 'pointer-events': 'none', 'box-sizing': 'border-box',
      border: '2px solid #19bfff', 'border-radius': '10px', background: 'rgba(25,191,255,.13)',
      'box-shadow': '0 0 0 9999px rgba(0,0,0,.16)', display: 'none', margin: '0', padding: '0'
    });
    document.body.appendChild(highlight);

    doneButton = make('button', 'valley-cleanup-done', {
      position: 'fixed', top: 'calc(14px + env(safe-area-inset-top))', right: '14px', 'z-index': '2147483647',
      width: '46px', height: '46px', 'min-width': '46px', 'min-height': '46px', padding: '0', margin: '0',
      'border-radius': '50%', display: 'flex', 'align-items': 'center', 'justify-content': 'center',
      border: '1px solid rgba(255,255,255,.55)', background: '#68b6df', color: '#102332',
      font: '700 23px/1 ' + FONT, 'box-shadow': '0 4px 16px rgba(0,0,0,.34)', 'touch-action': 'manipulation'
    }, '\u2713');
    doneButton.type = 'button';
    doneButton.setAttribute('aria-label', 'Finish erasing');
    doneButton.addEventListener('click', function (event) {
      event.preventDefault(); event.stopPropagation(); stop();
    });
    document.body.appendChild(doneButton);

    /* Short hint so it is obvious the mode is on. */
    hint = make('div', 'valley-cleanup-hint', {
      position: 'fixed', top: 'calc(22px + env(safe-area-inset-top))', left: '50%', transform: 'translateX(-50%)',
      'z-index': '2147483646', 'max-width': 'calc(100% - 100px)', padding: '9px 14px', 'border-radius': '999px',
      background: 'rgba(19,25,35,.94)', color: '#fff', font: '600 13px/1.2 ' + FONT,
      'pointer-events': 'none', 'box-sizing': 'border-box', 'white-space': 'nowrap', transition: 'opacity .4s'
    }, 'Tap an item to hide it');
    document.body.appendChild(hint);
    setTimeout(function () { if (hint) hint.style.setProperty('opacity', '0', 'important'); }, 2600);

    window.addEventListener('click', onClick, true);
    if (usingPointerEvents) {
      window.addEventListener('pointerdown', onDown, true);
      window.addEventListener('pointerup', onPointerUp, true);
      window.addEventListener('pointermove', onPointerMove, true);
    } else {
      window.addEventListener('touchstart', onDown, { capture: true, passive: true });
      window.addEventListener('touchend', onTouchEnd, true);
      window.addEventListener('touchmove', onTouchMove, { capture: true, passive: true });
    }
    window.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('scroll', onViewportChange, true);
    window.addEventListener('resize', onViewportChange, true);

    if (window.MutationObserver) {
      observer = new MutationObserver(function () {
        if (active) scheduleApply();
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
    return true;
  }

  function restore() {
    var previousCount = count();
    try { window.localStorage.removeItem(storageKey); } catch (_) {}
    window.__valleyCleanupFallback = [];
    document.querySelectorAll('[' + hiddenAttr + ']').forEach(function (el) {
      var oldDisplay = el.getAttribute('data-valley-cleanup-old-display');
      var oldPriority = el.getAttribute('data-valley-cleanup-old-priority') || '';
      if (oldDisplay) el.style.setProperty('display', oldDisplay, oldPriority);
      else el.style.removeProperty('display');
      el.removeAttribute(hiddenAttr);
      el.removeAttribute('data-valley-cleanup-old-display');
      el.removeAttribute('data-valley-cleanup-old-priority');
    });
    stop();
    return previousCount;
  }

  applySaved();
  if (window.MutationObserver && document.documentElement) {
    var savedObserver = new MutationObserver(function () { scheduleApply(); });
    savedObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  window.ValleyPageCleanup = {
    version: VERSION,
    start: start,
    toggle: function () { if (active) { stop(); return false; } return start(); },
    stop: stop,
    restore: restore,
    count: count,
    applySaved: applySaved,
    isReady: true
  };
})();