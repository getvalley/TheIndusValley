
(function () {
  'use strict';
  if (window.ValleyPageCleanup) return;

  var key = 'valley_cleanup_hidden_' + location.hostname;
  var hiddenAttr = 'data-valley-cleanup-hidden';
  var active = false, selected = null, overlay = null, sheet = null;
  var handlers = null;

  function selectors() {
    try { return JSON.parse(localStorage.getItem(key) || '[]') || []; }
    catch (_) { return []; }
  }
  function save(list) {
    try { localStorage.setItem(key, JSON.stringify(list)); } catch (_) {}
  }
  function count() { return selectors().length; }

  function applySaved() {
    var list = selectors();
    list.forEach(function (selector) {
      try {
        document.querySelectorAll(selector).forEach(function (el) {
          if (!el.hasAttribute(hiddenAttr)) {
            el.setAttribute(hiddenAttr, '1');
            el.setAttribute('data-valley-cleanup-display', el.style.display || '');
            el.style.setProperty('display', 'none', 'important');
          }
        });
      } catch (_) {}
    });
  }

  function addStyles() {
    if (document.getElementById('valley-cleanup-style')) return;
    var style = document.createElement('style');
    style.id = 'valley-cleanup-style';
    style.textContent = `
      #valley-cleanup-overlay { position:fixed!important; inset:0!important; z-index:2147483640!important;
        pointer-events:none!important; border:3px solid #0a84ff!important; background:rgba(10,132,255,.07)!important;
        box-shadow:inset 0 0 28px rgba(10,132,255,.12)!important; }
      #valley-cleanup-sheet { position:fixed!important; z-index:2147483647!important; left:12px!important; right:12px!important;
        bottom:calc(12px + env(safe-area-inset-bottom))!important; padding:18px!important; border-radius:20px!important;
        color:var(--vpc-text,#fff)!important; background:var(--vpc-bg,rgba(30,30,32,.94))!important;
        border:1px solid rgba(255,255,255,.15)!important; box-shadow:0 12px 40px rgba(0,0,0,.35)!important;
        font:500 16px -apple-system,BlinkMacSystemFont,system-ui,sans-serif!important; }
      #valley-cleanup-sheet button { display:block!important; width:100%!important; border:0!important; border-radius:12px!important;
        padding:13px!important; margin-top:10px!important; font:600 16px -apple-system,system-ui,sans-serif!important; }
      #valley-cleanup-sheet .yes { background:#0a84ff!important; color:white!important; }
      #valley-cleanup-sheet .no { background:rgba(128,128,128,.2)!important; color:inherit!important; }
      #valley-cleanup-done { position:fixed!important; top:calc(14px + env(safe-area-inset-top))!important;
        right:14px!important; left:auto!important; z-index:2147483647!important; width:40px!important; height:40px!important;
        min-width:40px!important; min-height:40px!important; padding:0!important; margin:0!important; border-radius:50%!important;
        display:flex!important; align-items:center!important; justify-content:center!important; box-sizing:border-box!important;
        border:1px solid rgba(255,255,255,.40)!important; background:#279af2!important; color:#fff!important;
        font:700 23px/1 -apple-system,BlinkMacSystemFont,system-ui,sans-serif!important; text-align:center!important;
        box-shadow:0 4px 16px rgba(0,0,0,.22)!important; -webkit-tap-highlight-color:transparent!important;
        touch-action:manipulation!important; cursor:pointer!important; }
      #valley-cleanup-done:active { transform:scale(.93)!important; }
      .valley-cleanup-highlight { outline:2px solid #0a84ff!important; outline-offset:3px!important; }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function makeSelector(el) {
    if (el.id && !/^valley-cleanup/.test(el.id)) return '#' + CSS.escape(el.id);
    var aria = el.getAttribute('aria-label');
    if (aria) return el.tagName.toLowerCase() + '[aria-label="' + aria.replace(/\\/g,'\\\\').replace(/"/g,'\\"') + '"]';
    var cls = Array.from(el.classList || []).filter(function (c) {
      return c.length < 32 && !/^valley-cleanup/.test(c);
    }).slice(0, 2);
    if (cls.length) {
      var candidate = el.tagName.toLowerCase() + '.' + cls.map(function(c){return CSS.escape(c);}).join('.');
      try { if (document.querySelectorAll(candidate).length <= 3) return candidate; } catch (_) {}
    }
    var path = [], node = el;
    while (node && node !== document.body && path.length < 5) {
      var part = node.tagName.toLowerCase();
      if (node.id && !/^valley-cleanup/.test(node.id)) { path.unshift('#' + CSS.escape(node.id)); break; }
      var siblings = node.parentElement ? Array.from(node.parentElement.children).filter(function(x){return x.tagName===node.tagName;}) : [];
      if (siblings.length > 1) part += ':nth-of-type(' + (siblings.indexOf(node)+1) + ')';
      path.unshift(part); node = node.parentElement;
    }
    return path.length ? path.join(' > ') : null;
  }

  function closeSheet() {
    if (sheet) { sheet.remove(); sheet = null; }
    if (selected) selected.classList.remove('valley-cleanup-highlight');
    selected = null;
  }
  function stop() {
    active = false;
    if (handlers) {
      document.removeEventListener('click', handlers, true);
      document.removeEventListener('touchend', handlers, true);
      handlers = null;
    }
    if (overlay) { overlay.remove(); overlay = null; }
    var doneButton = document.getElementById('valley-cleanup-done');
    if (doneButton) doneButton.remove();
    closeSheet();
  }
  function confirmElement(el) {
    addStyles();
    selected = el;
    el.classList.add('valley-cleanup-highlight');
    sheet = document.createElement('div');
    sheet.id = 'valley-cleanup-sheet';
    var title = document.createElement('div');
    title.textContent = 'Hide this element?';
    var yes = document.createElement('button'); yes.className = 'yes'; yes.textContent = 'Erase';
    var no = document.createElement('button'); no.className = 'no'; no.textContent = 'Cancel';
    yes.addEventListener('click', function () {
      var selector = makeSelector(el);
      if (!selector) { closeSheet(); return; }
      var list = selectors();
      if (list.indexOf(selector) < 0) list.push(selector);
      save(list);
      el.setAttribute(hiddenAttr, '1');
      el.setAttribute('data-valley-cleanup-display', el.style.display || '');
      el.style.setProperty('display', 'none', 'important');
      closeSheet();
      stop();
    });
    no.addEventListener('click', function () { closeSheet(); });
    sheet.appendChild(title); sheet.appendChild(yes); sheet.appendChild(no);
    document.body.appendChild(sheet);
  }
  function start() {
    if (active) { stop(); return true; }
    addStyles();
    active = true;
    overlay = document.createElement('div');
    overlay.id = 'valley-cleanup-overlay';
    document.body.appendChild(overlay);

    var doneButton = document.createElement('button');
    doneButton.id = 'valley-cleanup-done';
    doneButton.type = 'button';
    doneButton.setAttribute('aria-label', 'Finish erasing');
    doneButton.setAttribute('title', 'Finish');
    doneButton.textContent = '✓';
    doneButton.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      stop();
    });
    document.body.appendChild(doneButton);

    handlers = function (e) {
      if (!active || sheet) return;
      var target = e.target;
      if (!target || target.closest('#valley-cleanup-sheet,#valley-cleanup-overlay,#valley-cleanup-done,[data-valley-cleanup-hidden]')) return;
      if (/^(HTML|BODY|MAIN)$/i.test(target.tagName)) return;
      if (target.closest('script,style,noscript,iframe')) return;
      e.preventDefault(); e.stopPropagation();
      confirmElement(target);
    };
    document.addEventListener('click', handlers, true);
    document.addEventListener('touchend', handlers, true);
    return true;
  }
  function restore() {
    var list = selectors();
    try { localStorage.removeItem(key); } catch (_) {}
    document.querySelectorAll('[' + hiddenAttr + ']').forEach(function (el) {
      var old = el.getAttribute('data-valley-cleanup-display');
      el.style.display = old || '';
      el.removeAttribute(hiddenAttr);
      el.removeAttribute('data-valley-cleanup-display');
    });
    stop();
    return list.length;
  }
  applySaved();
  window.ValleyPageCleanup = {
    start: start,
    restore: restore,
    count: count,
    isReady: true
  };
})();
