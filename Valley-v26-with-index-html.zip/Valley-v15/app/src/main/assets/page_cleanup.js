(function () {
  'use strict';

  var VERSION = 10;
  if (window.ValleyPageCleanup && window.ValleyPageCleanup.version >= VERSION) {
    try { window.ValleyPageCleanup.applySaved(); } catch (_) {}
    return;
  }

  var hostKey = String(location.hostname || 'page').replace(/[^a-z0-9.-]/gi, '_');
  var storageKey = 'valley_cleanup_hidden_' + hostKey;
  var hiddenAttr = 'data-valley-cleanup-hidden';
  var styleId = 'valley-cleanup-style';
  var active = false;
  var selected = null;
  var selectedOriginalFilter = null;
  var highlight = null;
  var hideBtn = null;
  var bar = null;
  var menu = null;
  var labelEl = null;
  var undoBtn = null, cancelBtn = null, doneBtn = null, moreBtn = null;
  var session = [];          /* items hidden since this run started: { el, selector, added } */
  var dark = true;
  var rafPending = false;
  var downX = 0, downY = 0;
  var observer = null;
  var usingPointerEvents = !!window.PointerEvent;

  function readSelectors() {
    var values = [];
    try {
      var stored = JSON.parse(window.localStorage.getItem(storageKey) || '[]');
      if (Array.isArray(stored)) values = stored.filter(function (v) { return typeof v === 'string'; });
    } catch (_) {}
    if (Array.isArray(window.__valleyCleanupFallback)) {
      values = values.concat(window.__valleyCleanupFallback.filter(function (v) { return typeof v === 'string'; }));
    }
    return Array.from(new Set(values));
  }

  function saveSelectors(values) {
    window.__valleyCleanupFallback = values.slice();
    try { window.localStorage.setItem(storageKey, JSON.stringify(values)); } catch (_) {}
  }

  function count() { return readSelectors().length; }

  function isToolNode(node) {
    if (!node || !node.closest) return false;
    return !!node.closest('[data-valley-ui]');
  }

  function isVisible(el) {
    if (!el || el.nodeType !== 1 || !el.getBoundingClientRect) return false;
    var rect = el.getBoundingClientRect();
    if (rect.width < 8 || rect.height < 8) return false;
    var css;
    try { css = window.getComputedStyle(el); } catch (_) { return false; }
    return css.display !== 'none' && css.visibility !== 'hidden' && Number(css.opacity) !== 0;
  }

  function chooseElement(target) {
    if (!target || target.nodeType !== 1) return null;
    var node = target;
    // Avoid selecting tiny inline glyphs when the user taps an icon or text fragment.
    for (var i = 0; i < 3 && node.parentElement && node.parentElement !== document.body; i++) {
      var r = node.getBoundingClientRect();
      var p = node.parentElement.getBoundingClientRect();
      if ((r.width < 28 || r.height < 24) &&
          p.width <= window.innerWidth * 0.92 && p.height <= window.innerHeight * 0.92) {
        node = node.parentElement;
      } else break;
    }

    var best = node;
    var bestScore = -Infinity;
    var current = node;
    for (var depth = 0; current && current !== document.body &&
         current !== document.documentElement && depth < 6; depth++, current = current.parentElement) {
      if (!isVisible(current) || isToolNode(current)) continue;
      var rect = current.getBoundingClientRect();
      var area = Math.max(0, rect.width) * Math.max(0, rect.height);
      var ratio = area / Math.max(1, window.innerWidth * window.innerHeight);
      var role = (current.getAttribute('role') || '').toLowerCase();
      var hint = ((current.id || '') + ' ' +
        (typeof current.className === 'string' ? current.className : '') + ' ' + role).toLowerCase();
      var semantic = /dialog|alertdialog|banner|complementary/.test(role) ||
        /cookie|consent|privacy|modal|popup|newsletter|subscribe|paywall|advert/.test(hint);
      var position = window.getComputedStyle(current).position;
      var score = 10 - depth * 2;
      if (semantic) score += 30;
      if (position === 'fixed' || position === 'sticky') score += 8;
      if (ratio > 0.88) score -= 35;
      if (ratio > 0.72) score -= 12;
      if (area < 500) score -= 10;
      if (score > bestScore) { bestScore = score; best = current; }
      if (semantic) break;
    }
    return best;
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
    return String(value).replace(/[^a-zA-Z0-9_-]/g, function (ch) {
      return '\\' + ch.codePointAt(0).toString(16) + ' ';
    });
  }

  function makeSelector(el) {
    if (!el || !el.tagName) return null;
    if (el.id && !/^valley-cleanup/.test(el.id)) {
      var idSelector = '#' + cssEscape(el.id);
      try { if (document.querySelectorAll(idSelector).length === 1) return idSelector; } catch (_) {}
    }

    var parts = [];
    var node = el;
    while (node && node.nodeType === 1 && node !== document.documentElement && parts.length < 9) {
      var part = node.tagName.toLowerCase();
      if (node.id && !/^valley-cleanup/.test(node.id)) {
        part = '#' + cssEscape(node.id);
        parts.unshift(part);
        break;
      }
      var classes = Array.prototype.slice.call(node.classList || [])
        .filter(function (c) { return c.length < 48 && !/^valley-cleanup/.test(c); }).slice(0, 2);
      if (classes.length) part += '.' + classes.map(cssEscape).join('.');
      var parent = node.parentElement;
      if (parent) {
        var sameTag = Array.prototype.filter.call(parent.children, function (child) {
          return child.tagName === node.tagName;
        });
        if (sameTag.length > 1) part += ':nth-of-type(' + (sameTag.indexOf(node) + 1) + ')';
      }
      parts.unshift(part);
      var candidate = parts.join(' > ');
      try { if (document.querySelectorAll(candidate).length === 1) return candidate; } catch (_) {}
      node = parent;
    }
    var result = parts.join(' > ');
    try { return document.querySelectorAll(result).length ? result : null; } catch (_) { return null; }
  }

  function hideElement(el) {
    if (!el || el.nodeType !== 1 || el.hasAttribute(hiddenAttr)) return;
    el.setAttribute('data-valley-cleanup-old-display', el.style.getPropertyValue('display'));
    el.setAttribute('data-valley-cleanup-old-priority', el.style.getPropertyPriority('display'));
    el.setAttribute(hiddenAttr, '1');
    el.style.setProperty('display', 'none', 'important');
  }

  var applyQueued = false;
  function scheduleApply() {
    if (applyQueued) return;
    applyQueued = true;
    (window.requestAnimationFrame || window.setTimeout)(function () { applyQueued = false; applySaved(); });
  }

  function applySaved() {
    readSelectors().forEach(function (selector) {
      try { document.querySelectorAll(selector).forEach(hideElement); } catch (_) {}
    });
  }

  /* Styles are applied through the CSSOM (el.style.setProperty). Unlike a <style> element,
     this is not blocked by a site's Content-Security-Policy, so the picker UI shows on every page. */
  function setStyles(el, props) {
    Object.keys(props).forEach(function (k) { el.style.setProperty(k, props[k], 'important'); });
    return el;
  }

  function make(tag, id, props, text) {
    var el = document.createElement(tag);
    if (id) el.id = id;
    if (text) el.textContent = text;
    return setStyles(el, props);
  }

  var FONT = 'system-ui,-apple-system,Roboto,sans-serif';


  function ui(el) { el.setAttribute('data-valley-ui', '1'); return el; }

  function showElement(el) {
    if (!el || !el.hasAttribute || !el.hasAttribute(hiddenAttr)) return;
    var oldDisplay = el.getAttribute('data-valley-cleanup-old-display');
    var oldPriority = el.getAttribute('data-valley-cleanup-old-priority') || '';
    if (oldDisplay) el.style.setProperty('display', oldDisplay, oldPriority);
    else el.style.removeProperty('display');
    el.removeAttribute(hiddenAttr);
    el.removeAttribute('data-valley-cleanup-old-display');
    el.removeAttribute('data-valley-cleanup-old-priority');
  }

  /* ---------- look: matches Safari's "Hide Distracting Items" ---------- */
  var BLUE = '#2f8cf0';
  function theme() {
    return dark ? {
      bar: 'rgba(36,38,44,.80)', text: '#f2f2f6', faint: 'rgba(242,242,246,.34)',
      chip: 'rgba(255,255,255,.12)', line: 'rgba(255,255,255,.16)', shadow: '0 8px 28px rgba(0,0,0,.40)',
      menu: 'rgba(40,42,48,.94)'
    } : {
      bar: 'rgba(246,248,252,.84)', text: '#34363c', faint: 'rgba(52,54,60,.30)',
      chip: 'rgba(255,255,255,.72)', line: 'rgba(20,24,40,.10)', shadow: '0 8px 28px rgba(20,28,60,.20)',
      menu: 'rgba(250,251,254,.96)'
    };
  }

  function svg(paths, size, stroke, width) {
    var NS = 'http://www.w3.org/2000/svg';
    var el = document.createElementNS(NS, 'svg');
    el.setAttribute('viewBox', '0 0 24 24');
    el.setAttribute('width', String(size)); el.setAttribute('height', String(size));
    el.setAttribute('fill', 'none'); el.setAttribute('stroke', stroke);
    el.setAttribute('stroke-width', String(width || 2.2));
    el.setAttribute('stroke-linecap', 'round'); el.setAttribute('stroke-linejoin', 'round');
    el.style.setProperty('display', 'block', 'important');
    el.style.setProperty('pointer-events', 'none', 'important');
    paths.forEach(function (d) {
      var p = document.createElementNS(NS, 'path'); p.setAttribute('d', d); el.appendChild(p);
    });
    return el;
  }

  function circleButton(label, paths, color, width) {
    var b = ui(make('button', '', {
      display: 'flex', 'align-items': 'center', 'justify-content': 'center',
      width: '42px', height: '42px', 'min-width': '42px', padding: '0', margin: '0',
      border: '0', 'border-radius': '999px', background: 'transparent',
      'box-sizing': 'border-box', 'touch-action': 'manipulation', 'pointer-events': 'auto',
      transition: 'opacity .18s ease, transform .18s ease, background .18s ease',
      '-webkit-tap-highlight-color': 'transparent', outline: 'none', cursor: 'pointer'
    }));
    b.type = 'button';
    b.setAttribute('aria-label', label);
    b.appendChild(svg(paths, 21, color, width));
    return b;
  }

  function setEnabled(btn, on, tint) {
    if (!btn) return;
    btn.disabled = !on;
    btn.style.setProperty('opacity', on ? '1' : '.42', 'important');
    btn.style.setProperty('pointer-events', on ? 'auto' : 'none', 'important');
    if (tint) {
      var p = btn.querySelector('svg');
      if (p) p.setAttribute('stroke', on ? tint : theme().faint);
    }
  }

  function updateBar() {
    if (!bar) return;
    var n = session.length;
    if (labelEl) labelEl.textContent = n > 0 ? (n + (n === 1 ? ' item hidden' : ' items hidden')) : 'Select an item';
    setEnabled(undoBtn, n > 0, theme().text);
    setEnabled(doneBtn, n > 0, BLUE);
    var cx = cancelBtn && cancelBtn.querySelector('svg');
    if (cx) cx.setAttribute('stroke', BLUE);
  }

  function buildBar() {
    var t = theme();
    bar = ui(make('div', 'valley-cleanup-bar', {
      position: 'fixed', left: '50%', transform: 'translateX(-50%) translateY(24px)', opacity: '0',
      bottom: 'calc(16px + env(safe-area-inset-bottom, 0px))', 'z-index': '2147483647',
      width: 'min(420px, calc(100% - 20px))', height: '56px', 'box-sizing': 'border-box',
      display: 'flex', 'align-items': 'center', 'justify-content': 'space-between', gap: '2px', padding: '0 8px',
      background: t.bar, border: '1px solid ' + t.line, 'border-radius': '999px',
      'box-shadow': t.shadow, color: t.text, font: '500 15px/1.2 ' + FONT,
      'backdrop-filter': 'blur(26px) saturate(170%)', '-webkit-backdrop-filter': 'blur(26px) saturate(170%)',
      transition: 'transform .34s cubic-bezier(.22,.9,.3,1), opacity .22s ease', margin: '0',
      '-webkit-user-select': 'none', 'user-select': 'none', 'pointer-events': 'auto'
    }));

    undoBtn = circleButton('Undo last hidden item', ['M15 5l-7 7 7 7'], t.text, 2.2);
    cancelBtn = circleButton('Cancel', ['M6 6l12 12M18 6L6 18'], BLUE, 2.3);
    setStyles(cancelBtn, { width: '46px', 'min-width': '46px', background: t.chip, 'border-radius': '999px' });
    labelEl = ui(make('div', '', {
      flex: '1 1 auto', 'min-width': '0', 'text-align': 'center', color: t.text,
      font: '500 15px/1.2 ' + FONT, 'white-space': 'nowrap', overflow: 'hidden', 'text-overflow': 'ellipsis',
      padding: '0 4px', 'pointer-events': 'none', transition: 'opacity .16s ease'
    }, 'Select an item'));
    doneBtn = circleButton('Done', ['M5 12.5l4.5 4.5L19 7.5'], BLUE, 2.4);
    moreBtn = circleButton('More', [], t.text, 2);
    setStyles(moreBtn, { background: t.chip });
    /* three dots drawn as dots */
    var dots = moreBtn.querySelector('svg');
    dots.setAttribute('fill', t.text); dots.setAttribute('stroke', 'none');
    [5, 12, 19].forEach(function (x) {
      var c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      c.setAttribute('cx', String(x)); c.setAttribute('cy', '12'); c.setAttribute('r', '1.7');
      dots.appendChild(c);
    });
    setStyles(undoBtn, { background: t.chip });

    undoBtn.addEventListener('click', function (e) { swallow(e); undoLast(); });
    cancelBtn.addEventListener('click', function (e) { swallow(e); cancelRun(); });
    doneBtn.addEventListener('click', function (e) { swallow(e); stop(); });
    moreBtn.addEventListener('click', function (e) { swallow(e); toggleMenu(); });

    [undoBtn, cancelBtn, labelEl, doneBtn, moreBtn].forEach(function (n) { bar.appendChild(n); });
    document.body.appendChild(bar);
    updateBar();
    requestAnimationFrame(function () {
      if (!bar) return;
      bar.style.setProperty('transform', 'translateX(-50%) translateY(0)', 'important');
      bar.style.setProperty('opacity', '1', 'important');
    });
  }

  function swallow(e) {
    e.preventDefault(); e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
  }

  function closeMenu() { if (menu) { menu.remove(); menu = null; } }

  function toggleMenu() {
    if (menu) { closeMenu(); return; }
    var t = theme();
    menu = ui(make('div', 'valley-cleanup-menu', {
      position: 'fixed', right: 'max(10px, calc(50% - 210px))', 'z-index': '2147483647',
      bottom: 'calc(84px + env(safe-area-inset-bottom, 0px))', padding: '5px', 'border-radius': '20px',
      background: t.menu, border: '1px solid ' + t.line, 'box-shadow': t.shadow,
      'backdrop-filter': 'blur(24px) saturate(170%)', '-webkit-backdrop-filter': 'blur(24px) saturate(170%)',
      'box-sizing': 'border-box', 'min-width': '210px', 'pointer-events': 'auto'
    }));
    var total = count();
    var item = ui(make('button', '', {
      display: 'block', width: '100%', padding: '11px 14px', margin: '0', border: '0', background: 'transparent',
      'border-radius': '15px', 'text-align': 'left', color: total > 0 ? t.text : t.faint,
      font: '500 15px/1.2 ' + FONT, 'touch-action': 'manipulation', cursor: 'pointer'
    }, total > 0 ? 'Show Hidden Items (' + total + ')' : 'No hidden items'));
    item.type = 'button';
    item.addEventListener('click', function (e) {
      swallow(e); closeMenu();
      if (total > 0) { restoreAll(); }
    });
    menu.appendChild(item);
    document.body.appendChild(menu);
  }

  /* ---------- selection: blue outline + "Hide" pill ---------- */
  function visibleRect(el) {
    var r = el.getBoundingClientRect();
    var l = Math.max(0, r.left), t = Math.max(0, r.top);
    var rt = Math.min(window.innerWidth, r.right), b = Math.min(window.innerHeight, r.bottom);
    return { left: l, top: t, right: rt, bottom: b, width: Math.max(0, rt - l), height: Math.max(0, b - t) };
  }

  function layoutSelection() {
    rafPending = false;
    if (!selected || !selected.isConnected || !highlight) return;
    var v = visibleRect(selected);
    if (v.width < 4 || v.height < 4) { setStyles(highlight, { display: 'none' }); if (hideBtn) setStyles(hideBtn, { display: 'none' }); return; }
    setStyles(highlight, {
      display: 'block', left: v.left + 'px', top: v.top + 'px', width: v.width + 'px', height: v.height + 'px'
    });
    if (hideBtn) {
      setStyles(hideBtn, {
        display: 'flex',
        left: (v.left + v.width / 2) + 'px', top: (v.top + v.height / 2) + 'px'
      });
    }
  }
  function scheduleLayout() {
    if (rafPending) return;
    rafPending = true;
    (window.requestAnimationFrame || window.setTimeout)(layoutSelection);
  }

  function restoreSelectedBlur() {
    if (!selected || !selectedOriginalFilter) return;
    try {
      if (selectedOriginalFilter.value) {
        selected.style.setProperty('filter', selectedOriginalFilter.value, selectedOriginalFilter.priority);
      } else {
        selected.style.removeProperty('filter');
      }
      if (selectedOriginalFilter.transition) {
        selected.style.setProperty('transition', selectedOriginalFilter.transition, selectedOriginalFilter.transitionPriority);
      } else {
        selected.style.removeProperty('transition');
      }
    } catch (_) {}
    selectedOriginalFilter = null;
  }

  function deselect() {
    restoreSelectedBlur();
    selected = null;
    if (highlight) setStyles(highlight, { display: 'none' });
    if (hideBtn) setStyles(hideBtn, { display: 'none' });
  }

  function select(el) {
    if (!el || !el.isConnected || el === selected) return;
    deselect();
    selected = el;
    try {
      selectedOriginalFilter = {
        value: el.style.getPropertyValue('filter'),
        priority: el.style.getPropertyPriority('filter'),
        transition: el.style.getPropertyValue('transition'),
        transitionPriority: el.style.getPropertyPriority('transition')
      };
      el.style.setProperty('filter', 'blur(3px)', 'important');
      el.style.setProperty('transition', 'filter .16s ease', 'important');
    } catch (_) {}
    layoutSelection();
    if (hideBtn) {
      hideBtn.style.setProperty('transform', 'translate(-50%,-50%) scale(.8)', 'important');
      requestAnimationFrame(function () {
        if (hideBtn) hideBtn.style.setProperty('transform', 'translate(-50%,-50%) scale(1)', 'important');
      });
    }
  }

  function hideSelected() {
    var el = selected;
    if (!el || !el.isConnected) { deselect(); return; }
    var selector = makeSelector(el);
    if (!selector) { deselect(); return; }
    var list = readSelectors();
    var added = list.indexOf(selector) === -1;
    if (added) list.push(selector);
    restoreSelectedBlur();
    selected = null;
    if (highlight) setStyles(highlight, { display: 'none' });
    if (hideBtn) setStyles(hideBtn, { display: 'none' });
    /* a short fade, then the element is really hidden */
    var prevOpacity = el.style.getPropertyValue('opacity'), prevPrio = el.style.getPropertyPriority('opacity');
    var prevTransition = el.style.getPropertyValue('transition'), prevTransPrio = el.style.getPropertyPriority('transition');
    try {
      el.style.setProperty('transition', 'opacity .18s ease', 'important');
      el.style.setProperty('opacity', '0', 'important');
    } catch (_) {}
    setTimeout(function () {
      hideElement(el);
      try {
        if (prevOpacity) el.style.setProperty('opacity', prevOpacity, prevPrio); else el.style.removeProperty('opacity');
        if (prevTransition) el.style.setProperty('transition', prevTransition, prevTransPrio); else el.style.removeProperty('transition');
      } catch (_) {}
    }, 190);
    saveSelectors(list);
    session.push({ el: el, selector: selector, added: added });
    updateBar();
  }

  function removeSelector(selector) {
    var list = readSelectors().filter(function (v) { return v !== selector; });
    saveSelectors(list);
    /* readSelectors merges the in-memory fallback, so clear the stored value too */
    try { window.localStorage.setItem(storageKey, JSON.stringify(list)); } catch (_) {}
    window.__valleyCleanupFallback = list.slice();
  }

  function undoLast() {
    var item = session.pop();
    if (!item) return;
    if (item.added && !session.some(function (s) { return s.selector === item.selector; })) removeSelector(item.selector);
    showElement(item.el);
    try {
      item.el.style.setProperty('opacity', '0', 'important');
      item.el.style.setProperty('transition', 'opacity .22s ease', 'important');
      requestAnimationFrame(function () {
        item.el.style.removeProperty('opacity');
        setTimeout(function () { item.el.style.removeProperty('transition'); }, 240);
      });
    } catch (_) {}
    updateBar();
  }

  /* the cross: undo everything done in this run and leave */
  function cancelRun() {
    if (selected) { deselect(); return; }
    while (session.length) {
      var item = session.pop();
      if (item.added && !session.some(function (s) { return s.selector === item.selector; })) removeSelector(item.selector);
      showElement(item.el);
    }
    stop();
  }

  function restoreAll() {
    try { window.localStorage.removeItem(storageKey); } catch (_) {}
    window.__valleyCleanupFallback = [];
    document.querySelectorAll('[' + hiddenAttr + ']').forEach(showElement);
    session = [];
    updateBar();
  }

  function stop() {
    var wasActive = active;
    active = false;
    window.removeEventListener('pointerup', onPointerUp, true);
    window.removeEventListener('touchend', onTouchEnd, true);
    window.removeEventListener('click', onClick, true);
    window.removeEventListener('pointerdown', onDown, true);
    window.removeEventListener('touchstart', onDown, true);
    window.removeEventListener('keydown', onKeyDown, true);
    window.removeEventListener('scroll', scheduleLayout, true);
    window.removeEventListener('resize', scheduleLayout, true);
    if (observer) { observer.disconnect(); observer = null; }
    deselect();
    closeMenu();
    var oldBar = bar, oldHL = highlight, oldHide = hideBtn;
    bar = null; highlight = null; hideBtn = null; labelEl = null;
    undoBtn = cancelBtn = doneBtn = moreBtn = null;
    session = [];
    if (oldHL) oldHL.remove();
    if (oldHide) oldHide.remove();
    if (oldBar) {
      oldBar.style.setProperty('transform', 'translateX(-50%) translateY(24px)', 'important');
      oldBar.style.setProperty('opacity', '0', 'important');
      setTimeout(function () { oldBar.remove(); }, 260);
    }
    return wasActive;
  }

  function pickAt(x, y, event) {
    if (!active) return;
    var target = document.elementFromPoint(x, y);
    if (!target || isToolNode(target)) return;
    var candidate = chooseElement(target);
    if (!candidate || isToolNode(candidate)) return;
    if (event) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    }
    closeMenu();
    select(candidate);
  }

  function isToolEvent(event) { return isToolNode(event.target); }

  function onDown(event) {
    var p = (event.touches && event.touches[0]) || event;
    downX = p.clientX; downY = p.clientY;
  }

  function moved(x, y) { return Math.abs(x - downX) > 12 || Math.abs(y - downY) > 12; }

  function onPointerUp(event) {
    if (!active || event.button !== 0) return;
    if (isToolEvent(event)) return;
    if (moved(event.clientX, event.clientY)) return;
    pickAt(event.clientX, event.clientY, event);
  }

  function onTouchEnd(event) {
    if (!active || !event.changedTouches || !event.changedTouches.length) return;
    if (isToolEvent(event)) return;
    var touch = event.changedTouches[0];
    if (moved(touch.clientX, touch.clientY)) return;
    pickAt(touch.clientX, touch.clientY, event);
  }

  /* While picking, a tap must never reach the page: otherwise links and buttons would fire. */
  function onClick(event) {
    if (!active || isToolEvent(event)) return;
    event.preventDefault();
    event.stopPropagation();
    if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    if (!usingPointerEvents) pickAt(event.clientX, event.clientY, null);
  }

  function onKeyDown(event) {
    if (active && event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); cancelRun(); }
  }

  function start(opts) {
    if (opts === true || opts === false) opts = { dark: opts };
    if (opts && typeof opts.dark === 'boolean') dark = opts.dark;
    else if (!active && window.matchMedia) dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (active) return true;
    if (!document.body) return false;
    active = true;
    session = [];

    highlight = ui(make('div', 'valley-cleanup-highlight', {
      position: 'fixed', 'z-index': '2147483645', 'pointer-events': 'none', 'box-sizing': 'border-box',
      border: '2.5px solid ' + BLUE, 'border-radius': '14px', background: 'rgba(47,140,240,.07)',
      display: 'none', margin: '0', padding: '0',
      transition: 'left .16s ease, top .16s ease, width .16s ease, height .16s ease'
    }));
    document.body.appendChild(highlight);

    hideBtn = ui(make('button', 'valley-cleanup-hide', {
      position: 'fixed', 'z-index': '2147483646', display: 'none', transform: 'translate(-50%,-50%)',
      'align-items': 'center', 'justify-content': 'center', margin: '0', padding: '0 15px',
      height: '32px', 'min-width': '58px', border: '0', 'border-radius': '999px',
      background: BLUE, color: '#fff', font: '600 15px/1 ' + FONT,
      'box-shadow': '0 3px 12px rgba(30,90,170,.38)', 'touch-action': 'manipulation', 'pointer-events': 'auto',
      transition: 'transform .22s cubic-bezier(.34,1.4,.64,1)', cursor: 'pointer', outline: 'none',
      '-webkit-tap-highlight-color': 'transparent'
    }, 'Hide'));
    hideBtn.type = 'button';
    hideBtn.addEventListener('click', function (e) { swallow(e); hideSelected(); });
    document.body.appendChild(hideBtn);

    buildBar();

    window.addEventListener('click', onClick, true);
    if (usingPointerEvents) {
      window.addEventListener('pointerdown', onDown, true);
      window.addEventListener('pointerup', onPointerUp, true);
    } else {
      window.addEventListener('touchstart', onDown, { capture: true, passive: true });
      window.addEventListener('touchend', onTouchEnd, true);
    }
    window.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('scroll', scheduleLayout, true);
    window.addEventListener('resize', scheduleLayout, true);

    if (window.MutationObserver) {
      observer = new MutationObserver(function () {
        if (active) { scheduleApply(); if (selected) scheduleLayout(); }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
    return true;
  }

  function restore() {
    var previousCount = count();
    try { window.localStorage.removeItem(storageKey); } catch (_) {}
    window.__valleyCleanupFallback = [];
    document.querySelectorAll('[' + hiddenAttr + ']').forEach(showElement);
    stop();
    return previousCount;
  }

  applySaved();
  if (window.MutationObserver && document.documentElement) {
    var savedObserver = new MutationObserver(function () { scheduleApply(); });
    savedObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  window.ValleyPageCleanup = {
    version: VERSION,
    start: start,
    toggle: function () { if (active) { stop(); return false; } return start(); },
    stop: stop,
    restore: restore,
    count: count,
    applySaved: applySaved,
    isActive: function () { return active; },
    isReady: true
  };
})();
