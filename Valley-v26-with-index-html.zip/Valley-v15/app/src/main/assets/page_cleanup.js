(function () {
  'use strict';

  var VERSION = 7;
  if (window.ValleyPageCleanup && window.ValleyPageCleanup.version >= VERSION) {
    try { window.ValleyPageCleanup.applySaved(); } catch (_) {}
    return;
  }

  var hostKey = String(location.hostname || 'page').replace(/[^a-z0-9.-]/gi, '_');
  var storageKey = 'valley_cleanup_hidden_' + hostKey;
  var hiddenAttr = 'data-valley-cleanup-hidden';
  var styleId = 'valley-cleanup-style';
  var active = false;
  var selected = null;
  var hovered = null;
  var panel = null;
  var highlight = null;
  var doneButton = null;
  var observer = null;
  var usingPointerEvents = !!window.PointerEvent;

  function readSelectors() {
    var values = [];
    try {
      var stored = JSON.parse(window.localStorage.getItem(storageKey) || '[]');
      if (Array.isArray(stored)) values = stored.filter(function (v) { return typeof v === 'string'; });
    } catch (_) {}
    if (Array.isArray(window.__valleyCleanupFallback)) {
      values = values.concat(window.__valleyCleanupFallback.filter(function (v) { return typeof v === 'string'; }));
    }
    return Array.from(new Set(values));
  }

  function saveSelectors(values) {
    window.__valleyCleanupFallback = values.slice();
    try { window.localStorage.setItem(storageKey, JSON.stringify(values)); } catch (_) {}
  }

  function count() { return readSelectors().length; }

  function isToolNode(node) {
    if (!node || !node.closest) return false;
    return !!node.closest('#valley-cleanup-panel,#valley-cleanup-done,#valley-cleanup-highlight');
  }

  function isVisible(el) {
    if (!el || el.nodeType !== 1 || !el.getBoundingClientRect) return false;
    var rect = el.getBoundingClientRect();
    if (rect.width < 8 || rect.height < 8) return false;
    var css;
    try { css = window.getComputedStyle(el); } catch (_) { return false; }
    return css.display !== 'none' && css.visibility !== 'hidden' && Number(css.opacity) !== 0;
  }

  function chooseElement(target) {
    if (!target || target.nodeType !== 1) return null;
    var node = target;
    // Avoid selecting tiny inline glyphs when the user taps an icon or text fragment.
    for (var i = 0; i < 3 && node.parentElement && node.parentElement !== document.body; i++) {
      var r = node.getBoundingClientRect();
      var p = node.parentElement.getBoundingClientRect();
      if ((r.width < 28 || r.height < 24) &&
          p.width <= window.innerWidth * 0.92 && p.height <= window.innerHeight * 0.92) {
        node = node.parentElement;
      } else break;
    }

    var best = node;
    var bestScore = -Infinity;
    var current = node;
    for (var depth = 0; current && current !== document.body &&
         current !== document.documentElement && depth < 6; depth++, current = current.parentElement) {
      if (!isVisible(current) || isToolNode(current)) continue;
      var rect = current.getBoundingClientRect();
      var area = Math.max(0, rect.width) * Math.max(0, rect.height);
      var ratio = area / Math.max(1, window.innerWidth * window.innerHeight);
      var role = (current.getAttribute('role') || '').toLowerCase();
      var hint = ((current.id || '') + ' ' +
        (typeof current.className === 'string' ? current.className : '') + ' ' + role).toLowerCase();
      var semantic = /dialog|alertdialog|banner|complementary/.test(role) ||
        /cookie|consent|privacy|modal|popup|newsletter|subscribe|paywall|advert/.test(hint);
      var position = window.getComputedStyle(current).position;
      var score = 10 - depth * 2;
      if (semantic) score += 30;
      if (position === 'fixed' || position === 'sticky') score += 8;
      if (ratio > 0.88) score -= 35;
      if (ratio > 0.72) score -= 12;
      if (area < 500) score -= 10;
      if (score > bestScore) { bestScore = score; best = current; }
      if (semantic) break;
    }
    return best;
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
    return String(value).replace(/[^a-zA-Z0-9_-]/g, function (ch) {
      return '\\' + ch.codePointAt(0).toString(16) + ' ';
    });
  }

  function makeSelector(el) {
    if (!el || !el.tagName) return null;
    if (el.id && !/^valley-cleanup/.test(el.id)) {
      var idSelector = '#' + cssEscape(el.id);
      try { if (document.querySelectorAll(idSelector).length === 1) return idSelector; } catch (_) {}
    }

    var parts = [];
    var node = el;
    while (node && node.nodeType === 1 && node !== document.documentElement && parts.length < 9) {
      var part = node.tagName.toLowerCase();
      if (node.id && !/^valley-cleanup/.test(node.id)) {
        part = '#' + cssEscape(node.id);
        parts.unshift(part);
        break;
      }
      var classes = Array.prototype.slice.call(node.classList || [])
        .filter(function (c) { return c.length < 48 && !/^valley-cleanup/.test(c); }).slice(0, 2);
      if (classes.length) part += '.' + classes.map(cssEscape).join('.');
      var parent = node.parentElement;
      if (parent) {
        var sameTag = Array.prototype.filter.call(parent.children, function (child) {
          return child.tagName === node.tagName;
        });
        if (sameTag.length > 1) part += ':nth-of-type(' + (sameTag.indexOf(node) + 1) + ')';
      }
      parts.unshift(part);
      var candidate = parts.join(' > ');
      try { if (document.querySelectorAll(candidate).length === 1) return candidate; } catch (_) {}
      node = parent;
    }
    var result = parts.join(' > ');
    try { return document.querySelectorAll(result).length ? result : null; } catch (_) { return null; }
  }

  function hideElement(el) {
    if (!el || el.nodeType !== 1 || el.hasAttribute(hiddenAttr)) return;
    el.setAttribute('data-valley-cleanup-old-display', el.style.getPropertyValue('display'));
    el.setAttribute('data-valley-cleanup-old-priority', el.style.getPropertyPriority('display'));
    el.setAttribute(hiddenAttr, '1');
    el.style.setProperty('display', 'none', 'important');
  }

  function applySaved() {
    readSelectors().forEach(function (selector) {
      try { document.querySelectorAll(selector).forEach(hideElement); } catch (_) {}
    });
  }

  function addStyles() {
    if (document.getElementById(styleId)) return;
    var style = document.createElement('style');
    style.id = styleId;
    style.textContent =
      '[data-valley-cleanup-hidden="1"]{display:none!important}' +
      '#valley-cleanup-highlight{position:fixed!important;z-index:2147483645!important;pointer-events:none!important;' +
      'box-sizing:border-box!important;border:2px solid #19bfff!important;border-radius:10px!important;' +
      'background:rgba(25,191,255,.13)!important;box-shadow:0 0 0 9999px rgba(0,0,0,.16)!important;display:none!important}' +
      '#valley-cleanup-panel{position:fixed!important;z-index:2147483647!important;left:14px!important;right:14px!important;' +
      'bottom:calc(14px + env(safe-area-inset-bottom))!important;padding:16px!important;border-radius:18px!important;' +
      'color:#f7faff!important;background:rgba(19,25,35,.97)!important;border:1px solid rgba(255,255,255,.18)!important;' +
      'box-shadow:0 12px 38px rgba(0,0,0,.42)!important;font:500 15px/1.4 system-ui,-apple-system,sans-serif!important;' +
      '-webkit-backdrop-filter:blur(20px)!important;backdrop-filter:blur(20px)!important}' +
      '#valley-cleanup-panel .vpc-title{font-size:16px!important;font-weight:750!important;margin:0 0 5px!important}' +
      '#valley-cleanup-panel .vpc-desc{font-size:12px!important;opacity:.76!important;margin:0 0 10px!important;overflow-wrap:anywhere!important}' +
      '#valley-cleanup-panel button{display:block!important;width:100%!important;min-height:46px!important;border:0!important;' +
      'border-radius:12px!important;margin-top:8px!important;padding:10px!important;font:700 15px system-ui!important}' +
      '#valley-cleanup-panel .vpc-hide{background:#12aef0!important;color:#031522!important}' +
      '#valley-cleanup-panel .vpc-cancel{background:rgba(255,255,255,.13)!important;color:#fff!important}' +
      '#valley-cleanup-done{position:fixed!important;top:calc(14px + env(safe-area-inset-top))!important;right:14px!important;' +
      'z-index:2147483647!important;width:46px!important;height:46px!important;min-width:46px!important;min-height:46px!important;' +
      'padding:0!important;margin:0!important;border-radius:50%!important;display:flex!important;align-items:center!important;' +
      'justify-content:center!important;border:1px solid rgba(255,255,255,.55)!important;background:#079bdc!important;' +
      'color:#fff!important;font:700 23px/1 system-ui!important;box-shadow:0 4px 16px rgba(0,0,0,.34)!important;' +
      'touch-action:manipulation!important}';
    (document.head || document.documentElement).appendChild(style);
  }

  function updateHighlight(el) {
    hovered = el;
    if (!highlight) return;
    if (!el || !isVisible(el)) { highlight.style.display = 'none'; return; }
    var rect = el.getBoundingClientRect();
    highlight.style.display = 'block';
    highlight.style.left = Math.max(0, rect.left) + 'px';
    highlight.style.top = Math.max(0, rect.top) + 'px';
    highlight.style.width = Math.max(0, Math.min(window.innerWidth, rect.right) - Math.max(0, rect.left)) + 'px';
    highlight.style.height = Math.max(0, Math.min(window.innerHeight, rect.bottom) - Math.max(0, rect.top)) + 'px';
  }

  function closePanel() {
    if (panel) { panel.remove(); panel = null; }
    selected = null;
  }

  function stop() {
    active = false;
    window.removeEventListener('pointerup', onPointerUp, true);
    window.removeEventListener('touchend', onTouchEnd, true);
    window.removeEventListener('click', onClickFallback, true);
    window.removeEventListener('pointermove', onPointerMove, true);
    window.removeEventListener('touchmove', onTouchMove, true);
    window.removeEventListener('keydown', onKeyDown, true);
    window.removeEventListener('scroll', onViewportChange, true);
    window.removeEventListener('resize', onViewportChange, true);
    if (observer) { observer.disconnect(); observer = null; }
    if (highlight) { highlight.remove(); highlight = null; }
    if (doneButton) { doneButton.remove(); doneButton = null; }
    closePanel();
  }

  function confirmSelection(el) {
    if (!el || !el.isConnected) return;
    closePanel();
    selected = el;
    updateHighlight(el);
    var label = (el.innerText || el.getAttribute('aria-label') || el.tagName || 'Selected item')
      .trim().replace(/\s+/g, ' ');
    if (label.length > 110) label = label.slice(0, 107) + '...';

    panel = document.createElement('div');
    panel.id = 'valley-cleanup-panel';
    var title = document.createElement('div');
    title.className = 'vpc-title';
    title.textContent = 'Hide this item?';
    var desc = document.createElement('div');
    desc.className = 'vpc-desc';
    desc.textContent = label || 'Selected webpage element';
    var hide = document.createElement('button');
    hide.type = 'button'; hide.className = 'vpc-hide'; hide.textContent = 'Hide item';
    var cancel = document.createElement('button');
    cancel.type = 'button'; cancel.className = 'vpc-cancel'; cancel.textContent = 'Cancel';

    hide.addEventListener('click', function (event) {
      event.preventDefault(); event.stopPropagation();
      if (!selected || !selected.isConnected) { closePanel(); return; }
      var selector = makeSelector(selected);
      if (!selector) { closePanel(); return; }
      var list = readSelectors();
      if (list.indexOf(selector) === -1) list.push(selector);
      hideElement(selected);
      saveSelectors(list);
      closePanel();
      updateHighlight(null);
    });
    cancel.addEventListener('click', function (event) {
      event.preventDefault(); event.stopPropagation();
      closePanel(); updateHighlight(null);
    });
    panel.appendChild(title); panel.appendChild(desc); panel.appendChild(hide); panel.appendChild(cancel);
    document.body.appendChild(panel);
  }

  function pickAt(x, y, event) {
    if (!active || panel) return;
    var target = document.elementFromPoint(x, y);
    if (!target || isToolNode(target)) return;
    var candidate = chooseElement(target);
    if (!candidate || isToolNode(candidate)) return;
    if (event) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    }
    confirmSelection(candidate);
  }

  function onPointerUp(event) {
    if (!active || event.button !== 0) return;
    // Ignore the Done button; it remains a normal tappable control.
    if (isToolNode(event.target) && event.target.closest('#valley-cleanup-done')) return;
    pickAt(event.clientX, event.clientY, event);
  }

  function onTouchEnd(event) {
    if (!active || !event.changedTouches || !event.changedTouches.length) return;
    var touch = event.changedTouches[0];
    pickAt(touch.clientX, touch.clientY, event);
  }

  function onClickFallback(event) {
    if (!active || event.button > 0) return;
    if (isToolNode(event.target) && event.target.closest('#valley-cleanup-done')) return;
    pickAt(event.clientX, event.clientY, event);
  }

  function onPointerMove(event) {
    if (!active || panel) return;
    var target = document.elementFromPoint(event.clientX, event.clientY);
    if (target && !isToolNode(target)) updateHighlight(chooseElement(target));
  }

  function onTouchMove(event) {
    if (!active || panel || !event.touches || !event.touches.length) return;
    var touch = event.touches[0];
    var target = document.elementFromPoint(touch.clientX, touch.clientY);
    if (target && !isToolNode(target)) updateHighlight(chooseElement(target));
  }

  function onViewportChange() {
    if (active && hovered) updateHighlight(hovered);
  }

  function onKeyDown(event) {
    if (active && event.key === 'Escape') {
      event.preventDefault(); event.stopPropagation(); stop();
    }
  }

  function start() {
    if (active) return true;
    if (!document.body) return false;
    addStyles();
    active = true;

    highlight = document.createElement('div');
    highlight.id = 'valley-cleanup-highlight';
    document.body.appendChild(highlight);

    doneButton = document.createElement('button');
    doneButton.id = 'valley-cleanup-done';
    doneButton.type = 'button';
    doneButton.setAttribute('aria-label', 'Finish erasing');
    doneButton.textContent = '✓';
    doneButton.addEventListener('click', function (event) {
      event.preventDefault(); event.stopPropagation(); stop();
    });
    document.body.appendChild(doneButton);

    if (usingPointerEvents) {
      window.addEventListener('pointerup', onPointerUp, true);
      window.addEventListener('pointermove', onPointerMove, true);
    } else {
      window.addEventListener('touchend', onTouchEnd, true);
      window.addEventListener('touchmove', onTouchMove, { capture: true, passive: true });
      window.addEventListener('click', onClickFallback, true);
    }
    window.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('scroll', onViewportChange, true);
    window.addEventListener('resize', onViewportChange, true);

    if (window.MutationObserver) {
      observer = new MutationObserver(function () {
        if (active) applySaved();
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
    return true;
  }

  function restore() {
    var previousCount = count();
    try { window.localStorage.removeItem(storageKey); } catch (_) {}
    window.__valleyCleanupFallback = [];
    document.querySelectorAll('[' + hiddenAttr + ']').forEach(function (el) {
      var oldDisplay = el.getAttribute('data-valley-cleanup-old-display');
      var oldPriority = el.getAttribute('data-valley-cleanup-old-priority') || '';
      if (oldDisplay) el.style.setProperty('display', oldDisplay, oldPriority);
      else el.style.removeProperty('display');
      el.removeAttribute(hiddenAttr);
      el.removeAttribute('data-valley-cleanup-old-display');
      el.removeAttribute('data-valley-cleanup-old-priority');
    });
    stop();
    return previousCount;
  }

  applySaved();
  if (window.MutationObserver && document.documentElement) {
    var savedObserver = new MutationObserver(function () { applySaved(); });
    savedObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  window.ValleyPageCleanup = {
    version: VERSION,
    start: start,
    toggle: function () { if (active) { stop(); return false; } return start(); },
    stop: stop,
    restore: restore,
    count: count,
    applySaved: applySaved,
    isReady: true
  };
})();