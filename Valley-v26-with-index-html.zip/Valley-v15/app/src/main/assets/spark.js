/* Bricolage Grotesque — the app's typeface. Served from Valley's own asset host (with CORS),
   so overlays rendered on top of any website use the same letterforms as the app itself. */
(function () {
  try {
    if (document.getElementById('valley-bricolage-face')) return;
    var s = document.createElement('style');
    s.id = 'valley-bricolage-face';
    s.textContent = '@font-face{font-family:"Bricolage Grotesque";' +
      'src:url("https://appassets.androidplatform.net/assets/fonts/BricolageGrotesque-Variable.woff2") format("woff2");' +
      'font-weight:200 800;font-style:normal;font-display:swap}';
    (document.head || document.documentElement).appendChild(s);
  } catch (e) {}
})();
/* build: long-press menu (Summarise / Hide Address Bar), hide-to-nub
 * Long-press charges the pill as before, but the orb now opens a two-row collapsing
 * menu instead of summarising straight away. The menu pops out of the ORB - its
 * transform-origin is taken from the orb's live rect (falling back to the orb's fixed
 * spot at 2.5/3 screen height), so it springs from where the orb burst rather than
 * unfolding from the pill.
 *
 * SAFETY. openMenu() recovers if a previous menu was removed without resetting its
 * flag, and if building the menu throws it falls back to opening the summary rather
 * than doing nothing. Tapping outside the menu folds it away.
 *
 * SCOPE. openMenu lives in a different closure from the long-press timer (three IIFEs
 * apart), so calling it directly from the timer threw a ReferenceError inside a
 * setTimeout - silent, and the menu never appeared. It is now published as
 * window.ulaaOpenMenu and invoked through a guarded dispatch that falls back to the
 * summary if the menu cannot be reached.
 *
 * LONG-PRESS ON THE URL. The search feature had added an early return in down() when the
 * touch was over the URL text, which swallowed long-press there - it only worked on the
 * pill's empty edges. That return is gone: a tap on the URL still opens search through
 * its own click handler, and a long-press now charges and opens the menu. The label's
 * click ignores itself for 900ms after a long-press so both do not fire.
 *
 * THE BURST. The orb belonged to the summary's intro, which no longer runs, so nothing
 * was visible before the menu appeared. buildMenu now spawns a 26px glow at the origin
 * (the orb's rect if visible, else the touch point) that scales to 1.6 and fades as the
 * menu springs out of it.
 *
 * ROUTING FIX. A question that merely mentions a site used to be hijacked into that
 * site's own search, and the filler-word strip ate words from the middle of the query
 * ("Is wikipedia the largest encyclopedia in the world?" became "is largest in the
 * world?"). Questions - a trailing "?" or a leading what/who/why/how/is/are/... - now go
 * to Brave untouched; site routing only strips the site name and the filler immediately
 * around it.
 *
 * SMART SEARCH TOGGLE. A checkbox at the foot of the search panel switches the site
 * routing off: unticked, every query goes to Brave exactly as typed. The setting is kept
 * in localStorage ("ulaa-smart") and read at route time. Typed addresses still navigate
 * either way - reading a URL is not guessing.
 *
 * ORDER MATTERS IN openSearch. The checkbox is appended LAST and inside a try/catch:
 * it had been inserted before the Enter handler and the outside-tap dismiss, so when it
 * threw (calling smartOn from a different closure) the field, Enter and dismissal were
 * never wired at all - the panel opened and then did nothing. smartOn is now published
 * as window.ulaaSmartOn and every optional extra sits downstream of the required
 * wiring.
 *
 * r97 - ROOT CAUSE of the dead search panel. openSearch() lives in a different closure
 * from route()/smartOn(), so both threw ReferenceError when the panel tried to use them.
 * The throw happened before the Enter handler and the outside-tap dismiss were attached,
 * which is why the panel opened with only a field: no recents, no checkbox, Enter dead,
 * panel unable to close. Now: route is published as window.ulaaRoute, the core wiring
 * (Enter, dismiss, focus) is attached immediately after the field, and every optional
 * extra - animation, recents, the smart-search toggle - is isolated in its own try/catch
 * with a visible warning if it fails. Verified in a real browser: Enter calls the router,
 * an outside tap scales the panel away, the checkbox renders, no console errors.
 *
 * r98 - "recentCache is not defined". The storage adapter's own declaration
 * (var KEY / var recentCache) had been lost in an earlier rewrite, so loadRecents threw
 * and the panel showed no history. The diag line added in r97 is what surfaced it.
 * Recents, the smart-search toggle and the build tag now all render together.
 *
 * NAVIGATION VERB. "open flipkart", "go to example.com", "visit github" - a verb followed by a
 * site name, a bare word or an address now navigates instead of searching. A known site name
 * resolves to its own origin, a bare word tries .com, anything with a dot is an address. Two
 * ordinary words ("open source code") still go to search, because that is not a destination.
 *
 * NEAREST NAME. After a verb, a misspelt site is matched against a list of ~85 popular sites by
 * edit distance ("open flipkrt" -> flipkart.com, "visit amzon" -> amazon.in). A bare word with no
 * verb is never hijacked - that still searches.
 *
 * HIDE FOLDS INTO THE ORB. "Hide Address Bar" no longer leaves a plain translucent
 * circle: the row scales to 0.06 with its transform-origin at the orb spot
 * (width/2, height*2.5/3) and fades, and the summary's glowing orb appears in its place
 * as the tap target. Tapping it bursts the orb outward and springs the pill back.
 *
 * THE ORB IS DRAGGABLE. Slide it anywhere and it follows the finger, clamped 10px inside
 * the viewport; a drag never reopens the pill. A tap (no movement past 6px) brings the
 * taskbar back at its normal position, since the row itself was never moved.
 *
 * THE PILL SHRINKS INTO THE ORB. The orb is on screen almost immediately (scale 0.6 ->
 * 1 in .18s, opacity in .12s) so there is a visible destination; the row then collapses
 * to scale(0.04) over .38s with its origin on that point and only fades in the last
 * 120ms, so it stays solid while travelling in. At 360ms the orb pulses to 1.35 and back
 * - the swallow. Summarise folds the menu into the pill
 * and then opens the summary panel; Hide Address Bar folds the menu and tucks the row
 * away to an 18px nub at the bottom centre. Tapping the nub - or scrolling up - brings
 * the pill back. */
!function(){"use strict";const t="en",e="ulaa-url-bubble",n="ulaa-pill-row";function o(){if(!document.body)return;const o=new Set(["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","CODE","PRE","KBD","SAMP","SVG","CANVAS"]),r=["https://translate.googleapis.com/translate_a/single","https://clients5.google.com/translate_a/single"],a=new Map,i=new Map;let s=!1,l=!1,c="",d="",u=0;const p=t=>new Promise(e=>setTimeout(e,t));function f(t){const e=t.parentElement;if(!e)return!1;const n=e.getBoundingClientRect();return n.width>0&&n.bottom>0&&n.top<(window.innerHeight||0)}async function h(e){const n=encodeURIComponent(e);let o=null;for(let e=0;e<r.length;e++)for(let a=0;a<2;a++)try{const i=await fetch(r[e]+"?client=gtx&sl=auto&tl="+encodeURIComponent(t)+"&dt=t&q="+n);if(429===i.status){o=new Error("Google HTTP 429 (rate limited)"),await p(700*(a+1));continue}if(!i.ok){o=new Error("Google HTTP "+i.status);break}const s=await i.json();if("string"==typeof s[2]&&s[2]&&(d=s[2]),!Array.isArray(s[0])){o=new Error("Google: unexpected response");break}return s[0]}catch(t){o=new Error("Google: "+t.message)}throw o||new Error("Google failed")}async function m(t){const e=await h(t.join("\n")),n=new Map;for(const t of e){if(!Array.isArray(t))continue;const e=t[0],o=t[1];"string"==typeof e&&"string"==typeof o&&n.set(o.replace(/\s+$/,""),e.replace(/\s+$/,""))}return n}async function g(e){if(a.has(e))return a.get(e);try{const t=await async function(t){return(await h(t)).map(t=>t[0]).join("")}(e);return a.set(e,t),t}catch(n){try{const n=await async function(e){if(u>=80)throw new Error("fallback limit reached");if((new TextEncoder).encode(e).length>500)throw new Error("text too long for fallback");const n=d||function(){const t=(document.querySelector('meta[http-equiv="content-language"]')||{}).content||"",e=(document.querySelector('meta[property="og:locale"]')||{}).content||"";for(const n of[document.documentElement.getAttribute("lang")||"",t,e]){const t=n.toLowerCase().match(/^[a-z]{2,3}/);if(t)return t[0]}return""}()||"",o=!n||n===t,r=o?"autodetect|en":n+"|"+t;u++;const a="https://api.mymemory.translated.net/get?q="+encodeURIComponent(e)+"&langpair="+encodeURIComponent(r),i=await fetch(a);if(!i.ok)throw new Error("MyMemory HTTP "+i.status);const s=await i.json(),l=s&&s.responseStatus;if(l&&200!==Number(l))throw new Error(o?"fallback could not detect the source language":"MyMemory: "+(s.responseDetails||"status "+l));const c=s&&s.responseData&&s.responseData.translatedText;if(!c||/DISTINCT LANGUAGES|MYMEMORY WARNING|QUOTA|INVALID LANGUAGE|NO QUERY|AUTODETECT/i.test(c))throw new Error(o?"fallback could not detect the source language":"MyMemory: "+(c||"unexpected response"));return c}(e);return a.set(e,n),n}catch(t){throw new Error(n.message+"  |  fallback: "+t.message)}}}const y='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>',x='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>',b='<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12.87 15.07l-2.54-2.51.03-.03A17.52 17.52 0 0 0 14.07 6H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/></svg>',w="rgba(22,22,24,0.44)",E="#fff",v="1px solid rgba(255,255,255,0.22)",k="0 6px 24px rgba(0,0,0,0.28)",C="blur(18px) saturate(180%)",M=document.createElement("div");M.id=e,Object.assign(M.style,{position:"relative",flex:"0 1 auto",minWidth:"0",display:"flex",alignItems:"center",gap:"7px",maxWidth:"86vw",padding:"8px 10px 8px 14px",borderRadius:"999px",background:w,color:E,font:'500 13px/1.2 Bricolage Grotesque,-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',border:v,boxShadow:k,backdropFilter:C,WebkitBackdropFilter:C,pointerEvents:"none",userSelect:"none",whiteSpace:"nowrap",overflow:"hidden",transition:"opacity .22s ease, transform .22s ease"});const T=document.createElement("div");function L(t){const e=document.createElement("div");return Object.assign(e.style,{position:"relative",display:"flex",alignItems:"center",justifyContent:"center",boxSizing:"border-box",padding:"0",borderRadius:"999px",background:w,border:v,boxShadow:k,backdropFilter:C,WebkitBackdropFilter:C,color:E,pointerEvents:"auto",cursor:"pointer",userSelect:"none",flex:"0 0 auto",transition:"border-color .18s ease"}),e.title=t,e}T.id=n,Object.assign(T.style,{position:"fixed",left:"0",right:"0",bottom:"calc(14px + env(safe-area-inset-bottom, 0px))",zIndex:"2147483646",display:"flex",justifyContent:"center",alignItems:"center",gap:"8px",padding:"0 10px",boxSizing:"border-box",pointerEvents:"none",transition:"opacity .22s ease, transform .22s ease"});const S=L("Eraser menu"),R=L("Translate page");function I(t){const e=document.createElement("span");return e.style.position="relative",e.style.display="flex",e.style.alignItems="center",e.style.justifyContent="center",e.style.flex="0 0 auto",e.style.pointerEvents="auto",e.style.cursor="pointer",e.style.padding="4px",e.style.margin="-4px 0",e.style.borderRadius="999px",e.style.opacity="0.85",e.title=t,e}const A=document.createElement("span");A.style.position="relative",A.style.display="flex",A.style.alignItems="center",A.style.opacity="0.85",A.style.flex="0 0 auto";const j=document.createElement("span");j.style.position="relative",j.style.overflow="hidden",j.style.textOverflow="ellipsis",j.style.whiteSpace="nowrap",j.style.minWidth="0";const N=I("Translate page");N.innerHTML=b,N.style.margin="0",N.style.padding="0";const W=I("Copy link");W.innerHTML=y,W.style.margin="-4px -2px -4px 0";const H=I("Eraser menu");function O(){const t=(window.innerWidth||document.documentElement.clientWidth||360)-20;let e=M.offsetHeight||34;const n=2*e+16+68+(j.scrollWidth||0);S.style.width=e+"px",S.style.height=e+"px",R.style.width=e+"px",R.style.height=e+"px"}function F(){A.innerHTML="https:"===location.protocol?'<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10.5" width="16" height="10.5" rx="2.5"/><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/></svg>':'<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.9 1.9 18a2 2 0 0 0 1.7 3h16.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9.5v4"/><path d="M12 17h.01"/></svg>',j.textContent=function(){try{return new URL(location.href).hostname.replace(/^www\./,"")}catch(t){return location.host||location.href}}(),M.title=location.href,O()}H.innerHTML='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="8.5" width="13" height="8" rx="2.2" transform="rotate(-45 10 12.5)"/><path d="M4 20h16"/></svg>',H.style.display="flex",H.style.margin="0",H.style.padding="0",S.style.display="flex",S.appendChild(H),R.appendChild(N),M.appendChild(A),M.appendChild(j),M.appendChild(W),T.appendChild(S),T.appendChild(M),T.appendChild(R),document.body.appendChild(T),O(),window.addEventListener("resize",O),F();let B=location.href;function P(t,e){N.innerHTML=t,N.style.color=e||""}setInterval(function(){location.href!==B&&(B=location.href,F())},500),W.addEventListener("click",function(t){t.stopPropagation(),navigator.clipboard&&navigator.clipboard.writeText(location.href).then(function(){W.innerHTML=x,W.style.color="#6ee7a0",setTimeout(function(){W.innerHTML=y,W.style.color="",F()},1e3)}).catch(function(){})}),N.addEventListener("click",async function(t){if(t.stopPropagation(),l)return;if(s=!s,!s)return function(){for(const[t,e]of i)try{t.nodeValue=e}catch(t){}}(),P(b),void(N.title="Translate page");P("…"),N.title="Translating…",u=0;const n=await async function(){if(l)return{done:0,failed:0,total:0};l=!0;const t=function(t){const n=document.createTreeWalker(t,NodeFilter.SHOW_TEXT,{acceptNode(t){const n=t.nodeValue;if(!n||n.trim().length<2)return NodeFilter.FILTER_REJECT;const r=t.parentNode;return!r||o.has(r.nodeName)||r.isContentEditable||function(t){try{const n=t.parentElement;return!!(n&&n.closest&&n.closest("#"+e))}catch(t){return!1}}(t)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),r=[];let a;for(;a=n.nextNode();)r.push(a);return r}(document.body),n=t.filter(f).concat(t.filter(t=>!f(t))),r=new Set,s=[];for(const t of n){const e=t.nodeValue.trim();if(!r.has(e)&&(r.add(e),s.push(e),s.length>=600))break}const d=[];let u=[],h=0;for(const t of s)t.includes("\n")||t.length>400?d.push([t]):(u.length&&(u.length>=40||h+t.length+1>1500)&&(d.push(u),u=[],h=0),u.push(t),h+=t.length+1);u.length&&d.push(u);const y=new Map;let x=0;for(const t of d){if(1===t.length){try{y.set(t[0],await g(t[0]))}catch(t){x++,c=t.message}continue}let e=null;try{e=await m(t)}catch(t){c=t.message}for(const n of t)if(e&&e.has(n))y.set(n,e.get(n)),a.set(n,e.get(n));else try{y.set(n,await g(n))}catch(t){x++,c=t.message}await p(150)}const b=new Map;for(const e of t){const t=e.nodeValue.trim();b.has(t)||b.set(t,[]),b.get(t).push(e)}let w=0;for(const[t,e]of y){const n=b.get(t);if(n){for(const o of n)i.has(o)||i.set(o,o.nodeValue),o.nodeValue=o.nodeValue.replace(t,e);w++}}return l=!1,{done:w,failed:x,total:s.length}}();0===n.done&&n.failed>0?(s=!1,P("!","#ff8a8a"),N.title="Failed: "+c,setTimeout(function(){P(b),N.title="Translate page"},3e3)):n.failed>0?(P("!","#ffc27a"),N.title=n.done+" translated, "+n.failed+" failed — "+c,setTimeout(function(){P(x,"#6ee7a0"),N.title="Show original"},1800)):(P(x,"#6ee7a0"),N.title="Show original")});const z="ulaa-url-menu",V="ulaa-erasing",U="ulaa-erase-hover",G="#ffffff",D="#ffffff",Y=[];let X=!1,_=!1,q=null;const J=document.createElement("style");J.textContent="html."+V+", html."+V+" * { cursor: crosshair !important; }."+U+" { outline: 2px dashed rgba(220,88,97,0.95) !important; outline-offset: 2px !important; }",(document.head||document.documentElement).appendChild(J);const Q=document.createElement("div");function $(t,e){const n=document.createElement("button");return n.type="button",n.textContent=t,Object.assign(n.style,{display:"block",width:"100%",textAlign:"left",padding:"9px 12px",margin:"0",borderRadius:"11px",border:"none",background:"transparent",color:e,font:"inherit",fontWeight:"500",cursor:"pointer"}),n}Q.id=z,Object.assign(Q.style,{position:"fixed",left:"50%",bottom:"90px",transform:"translateX(-50%) translateY(8px) scale(0.98)",zIndex:"2147483645",minWidth:"172px",maxWidth:"86vw",padding:"6px",borderRadius:"16px",background:w,color:E,font:'500 14px/1.35 Bricolage Grotesque,-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',border:v,boxShadow:k,backdropFilter:C,WebkitBackdropFilter:C,opacity:"0",pointerEvents:"none",transition:"opacity .18s ease, transform .18s ease",boxSizing:"border-box"});const K=$("Erase",G),Z=$("Restore All",D),tt=document.createElement("div");[K,Z,tt].forEach(function(el){el.style.setProperty("text-transform","none","important")});function et(){K.style.background=X?"rgba(255,255,255,0.18)":"transparent",K.style.fontWeight=X?"600":"500"}function nt(){const t=Y.length;tt.textContent=0===t?"Nothing erased yet":t+(1===t?" item erased":" items erased"),Z.disabled=0===t,Z.style.color=0===t?"#ffffff":D,Z.style.opacity=0===t?"0.6":"1",Z.style.cursor=0===t?"default":"pointer",et()}function ot(t){if(_=t,t){Q.style.bottom="calc("+(14+(T.getBoundingClientRect().height||40)+8)+"px + env(safe-area-inset-bottom, 0px))";try{const t=Q.offsetWidth||172,e=S.getBoundingClientRect(),n=window.innerWidth||document.documentElement.clientWidth||360,o=e.left+e.width/2,r=Math.max(8+t/2,Math.min(o,n-8-t/2));Q.style.left=r+"px"}catch(t){}Q.style.opacity="1",Q.style.pointerEvents="auto",Q.style.transform="translateX(-50%) translateY(0) scale(1)"}else Q.style.opacity="0",Q.style.pointerEvents="none",Q.style.transform="translateX(-50%) translateY(8px) scale(0.98)"}function rt(){if(q){try{q.classList.remove(U)}catch(t){}q=null}}function at(t){if(!X)return;const o=t.target;o&&o.closest&&(o.closest("#"+e)||o.closest("#"+z)||o.closest("#"+n))||(t.preventDefault(),t.stopImmediatePropagation(),function(t){if(!t||1!==t.nodeType)return;if(t===document.body||t===document.documentElement)return;if(t.closest&&(t.closest("#"+e)||t.closest("#"+z)||t.closest("#"+n)))return;if(t.contains(T)||t.contains(Q))return;const o={el:t,display:t.style.display||""};Y.push(o);const r=function(t){let e="rgba(255,255,255,0.9)";try{const n=getComputedStyle(t).color;n&&"rgba(0, 0, 0, 0)"!==n&&(e=n)}catch(t){}const n=t.getBoundingClientRect(),o=Math.max(1,n.width*n.height),r=Math.max(6,Math.min(12,Math.round(o/6e3)||8));for(let t=0;t<r;t++){const t=document.createElement("span"),o=2+4*Math.random();Object.assign(t.style,{position:"fixed",left:n.left+Math.random()*Math.max(1,n.width)+"px",top:n.top+Math.random()*Math.max(1,n.height)+"px",width:o+"px",height:o+"px",borderRadius:"50%",background:e,opacity:"0.9",pointerEvents:"none",zIndex:"2147483647",willChange:"transform, opacity"}),document.body.appendChild(t);const r=90*(Math.random()-.5),a=90*(Math.random()-.5)-18,i=380+320*Math.random();if(t.animate){const e=t.animate([{transform:"translate(0,0) scale(1)",opacity:.9},{transform:"translate("+r+"px,"+a+"px) scale(0.15)",opacity:0}],{duration:i,easing:"cubic-bezier(.2,.7,.3,1)"});e.onfinish=function(){t.remove()},e.oncancel=function(){t.remove()}}else setTimeout(function(){t.remove()},i)}return t.animate?t.animate([{opacity:1,filter:"blur(0px)",transform:"scale(1)"},{opacity:0,filter:"blur(3px)",transform:"scale(0.94)"}],{duration:260,easing:"ease-in"}):null}(t),a=function(){-1!==Y.indexOf(o)&&(t.style.display="none")};r?r.onfinish=a:a(),nt()}(function(t){let e=t;for(let t=0;t<6&&e&&e!==document.body&&e!==document.documentElement;t++){let t="";try{t=getComputedStyle(e).display}catch(t){}if(t&&"inline"!==t&&"contents"!==t)return e;e=e.parentElement}return t}(o)))}function it(){document.body&&(document.body.contains(T)||document.body.appendChild(T),document.body.contains(Q)||document.body.appendChild(Q))}Object.assign(tt.style,{color:"#e6e6e6",fontSize:"11px",lineHeight:"1.3",padding:"4px 12px 6px"}),Q.appendChild(K),Q.appendChild(Z),Q.appendChild(tt),document.body.appendChild(Q),[K,Z].forEach(function(t){t.addEventListener("mouseenter",function(){t.style.background="rgba(255,255,255,0.12)"}),t.addEventListener("mouseleave",function(){t.style.background=function(t){return t===K&&X?"rgba(255,255,255,0.18)":"transparent"}(t)})}),H.addEventListener("click",function(t){t.stopPropagation(),ot(!_)}),document.addEventListener("click",function(t){if(!_)return;const o=t.target;o&&o.closest&&(o.closest("#"+e)||o.closest("#"+z)||o.closest("#"+n))||ot(!1)},!1),K.addEventListener("click",function(t){var e;t.stopPropagation(),X=e=!X,H.style.color=e?G:"",H.style.opacity=e?"1":"0.85",H.title=e?"Erasing — tap items to remove":"Eraser menu",S.style.borderColor=e?"rgba(220,88,97,0.75)":"rgba(255,255,255,0.22)",document.documentElement.classList.toggle(V,e),e||rt(),et(),X&&ot(!1)}),Z.addEventListener("click",function(t){t.stopPropagation(),function(){for(;Y.length;){const t=Y.pop();try{t.el.style.display=t.display||""}catch(t){}}nt()}()}),document.addEventListener("pointermove",function(t){if(!X)return;let o=null;try{o=document.elementFromPoint(t.clientX,t.clientY)}catch(t){}o!==q&&(rt(),!o||1!==o.nodeType||o===document.body||o===document.documentElement||!o.closest||o.closest("#"+e)||o.closest("#"+z)||o.closest("#"+n)||o.contains(T)||(q=o,o.classList.add(U)))},!0),document.addEventListener("click",at,!0),document.addEventListener("auxclick",at,!0),nt();try{new MutationObserver(it).observe(document.documentElement,{childList:!0})}catch(t){}setInterval(it,1e3)}document.getElementById(e)||(document.body?o():"loading"===document.readyState?document.addEventListener("DOMContentLoaded",o,{once:!0}):setTimeout(o,50))}();;(function () {  var lastEl = null, lastY = 0, dir = 0, chCache = 0, wired = 0, started = 0, blurT = null;  function rowEl() { return document.getElementById('ulaa-pill-row'); }  function parts() {    var r = rowEl();    if (!r || !r.children || r.children.length < 3) return null;    var b = r.children[1];    if (!b || !b.children || b.children.length < 3) return null;    return { row: r, left: r.children[0], bubble: b, right: r.children[2], shield: b.children[0], label: b.children[1], copy: b.children[2] };  }  function chPx() {    if (chCache) return chCache;    try {      var s = document.createElement('span');      s.style.cssText = 'position:absolute;left:-9999px;top:0;width:1ch;font:500 13px/1.2 Bricolage Grotesque,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif';      document.body.appendChild(s);      chCache = s.getBoundingClientRect().width || 7;      if (s.parentNode) s.parentNode.removeChild(s);    } catch (e) { chCache = 7; }    return chCache || 7;  }  function vw() { return window.innerWidth || document.documentElement.clientWidth || 360; }  function bigCh() {    var room = (vw() - 16) / 1.3 - 152;    return Math.max(14, Math.min(40, Math.floor(room / chPx())));  }  function wire(p) {    if (wired) return;    wired = 1;    p.label.style.setProperty("text-transform","none","important");    p.shield.style.boxSizing = 'border-box';    p.copy.style.boxSizing = 'border-box';        var enable = function () {      var D = '.38s cubic-bezier(.22,.61,.36,1)';    var t = 'max-width ' + D + ', opacity ' + D + ', height ' + D;      p.shield.style.transition = t;      p.copy.style.transition = t;      p.left.style.transition = t;      p.right.style.transition = t;      p.label.style.transition = 'max-width ' + D;    var bf = 'filter .15s ease';    p.left.style.transition += ', ' + bf;    p.right.style.transition += ', ' + bf;    p.shield.style.transition += ', ' + bf;    p.copy.style.transition += ', ' + bf;      p.bubble.style.transition = 'padding ' + D + ', transform ' + D;
    var BND = '.40s cubic-bezier(.34,1.33,.64,1)';
    p.bubble.style.setProperty('transition', 'padding ' + D, 'important');
    p.left.style.setProperty('transition', (p.left.style.transition || '') + ', transform ' + BND, 'important');
    p.right.style.setProperty('transition', (p.right.style.transition || '') + ', transform ' + BND, 'important');
    p.bubble.style.pointerEvents = 'auto';    p.row.style.setProperty('transition', 'opacity .22s ease, bottom ' + BND + ', gap ' + BND + ', padding ' + BND, 'important');
    [p.left, p.bubble, p.right].forEach(function (el) {
      el.style.transition = (el.style.transition ? el.style.transition + ', ' : '') + 'transform ' + D;
    });    };    var raf = window.requestAnimationFrame || function (f) { setTimeout(f, 16); };    raf(enable);  }  var contentH = 0;
  function show(p, big) {
    wire(p);
    var padT = big ? 8 : 4;
    if (!contentH) {
      var pt = 8;
      try { pt = parseFloat(getComputedStyle(p.bubble).paddingTop) || 8; } catch (e) {}
      contentH = Math.max(18, (p.bubble.offsetHeight || 34) - 2 * pt);
    }
    var h = contentH + 2 * padT;    p.shield.style.maxWidth = big ? '15px' : '0px';    p.shield.style.opacity = big ? '1' : '0';    p.shield.style.paddingRight = '4px';    p.copy.style.maxWidth = big ? '21px' : '0px';    p.copy.style.opacity = big ? '1' : '0';    p._h = h;
    var D2 = '.38s cubic-bezier(.22,.61,.36,1)';
    var tr = 'max-width ' + D2 + ', height ' + D2 + ', opacity .12s ease, transform ' + D2;
    p.left.style.overflow = 'hidden';
    p.right.style.overflow = 'hidden';
    // the boxes grow from zero width, so without clipping their icons spill out and
    // sit on the main pill's edges while the pills are still tiny
    p.left.style.overflow = 'hidden';
    p.right.style.overflow = 'hidden';
    p.left.style.setProperty('transition', tr, 'important');
    p.right.style.setProperty('transition', tr, 'important');
    p.left.style.maxWidth = big ? h + 'px' : '0px';
    p.left.style.opacity = big ? '1' : '0';
    p.left.style.setProperty('width', h + 'px', 'important');
    p.left.style.setProperty('height', (big ? h : 0) + 'px', 'important');    p.right.style.maxWidth = big ? h + 'px' : '0px';    p.right.style.opacity = big ? '1' : '0';    p.right.style.setProperty('width', h + 'px', 'important');
    p.right.style.setProperty('height', (big ? h : 0) + 'px', 'important');    p.bubble.style.paddingLeft = big ? '14px' : '8px';
    p.bubble.style.paddingRight = big ? '10px' : '8px';
    p.bubble.style.gap = big ? '7px' : '0px';
    p.bubble.style.paddingTop = big ? '8px' : '4px';
    p.bubble.style.paddingBottom = big ? '8px' : '4px';
    p.row.style.bottom = 'calc(' + (big ? 14 : 5) + 'px + env(safe-area-inset-bottom, 0px))';
    p.row.style.gap = big ? '8px' : '0px';
    p.row.style.padding = big ? '0 10px' : '0 6px';    p.label.style.maxWidth = Math.round(big ? bigCh() * 5.3 : 14 * 5.83) + 'px';  }  function apply(d, animate, spd) {
    var p = parts();
    if (!p) return;
    // harder scroll -> bigger overshoot. 0.3..4 px/ms maps to 1.22..2.05
    var sp = Math.min(4, Math.max(0.3, spd || 0.8));
    var c1 = (1.22 + (sp - 0.3) * 0.22).toFixed(2);
    var dur = (0.38 + Math.min(sp, 4) * 0.025).toFixed(2) + 's';
    var BN = dur + ' cubic-bezier(.34,' + c1 + ',.64,1)';
    // BN was being computed and dropped. Assign it here: apply() runs on every state
    // change, so it is the last writer and the bounce actually takes effect.
    p.bubble.style.transition = 'padding .38s cubic-bezier(.22,.61,.36,1), transform ' + BN;
    p.left.style.transition = (p.left.style.transition || '') + ', transform ' + BN;
    p.right.style.transition = (p.right.style.transition || '') + ', transform ' + BN;
    p.row.style.transition = 'opacity .22s ease, bottom ' + BN + ', gap ' + BN + ', padding ' + BN;    var wasBig = document.documentElement.classList.contains('ulaa-big');    var big = d < 0;
    document.documentElement.classList.toggle('ulaa-big', big);
    show(p, big);    var s = big ? 1.3 : 1;    p.label.style.fontSize = (big ? 13 / s : 11) + 'px';    p.label.style.lineHeight = '16px';    // a row scale pushed each pill outward by (s-1) x its distance from the row's
    // centre. Measuring that mid-animation gave a short value, so compute it instead:
    // the bubble is centred, and each side pill sits halfW + gap + sideW/2 away.
    var halfW = (p.bubble.offsetWidth || 200) / 2;
    var push = halfW * (s - 1);
    p.bubble.style.transformOrigin = 'center center';
    p.bubble.style.transform = 'scale(' + s + ')';
    p.left.style.transformOrigin = 'right center';
    p.left.style.transform = 'translateX(' + (-push).toFixed(1) + 'px) scale(' + s + ')';
    p.right.style.transformOrigin = 'left center';
    p.right.style.transform = 'translateX(' + push.toFixed(1) + 'px) scale(' + s + ')';
    p.row.style.transform = 'none';    if (started && animate) {      var shrink = wasBig && !big;      var els = [p.left, p.right, p.shield, p.copy];      els.forEach(function (el) { el.style.filter = shrink ? 'blur(3px)' : 'blur(0.5px)'; });      clearTimeout(blurT);      blurT = setTimeout(function () { els.forEach(function (el) { el.style.filter = 'none'; }); }, shrink ? 220 : 380);    }    started = 1;  }  var touching = 0, speed = 0, lastT = 0;
  function setTouch(v) { return function () { touching = v; }; }
  document.addEventListener('touchstart', setTouch(1), { capture: true, passive: true });
  document.addEventListener('touchend', setTouch(0), { capture: true, passive: true });
  document.addEventListener('touchcancel', setTouch(0), { capture: true, passive: true });
  document.addEventListener('mousedown', setTouch(1), true);
  document.addEventListener('mouseup', setTouch(0), true);
  function track(el, y) {
    if (document.getElementById('ulaa-nub') && y < lastY - 20 && window.ulaaShowPill) window.ulaaShowPill();
    if (el !== lastEl) { lastEl = el; lastY = y; dir = 0; return; }
    // momentum scrolling keeps firing after the finger lifts, and rubber-banding
    // reverses direction - both used to flip the state after release
    if (!touching) { lastY = y; return; }
    var dy = y - lastY;
    if (Math.abs(dy) < 24) return;
    var now = Date.now();
    var dt = Math.max(8, now - (lastT || now - 16));
    lastT = now;
    // px per ms, smoothed so one jittery event can't spike the bounce
    speed = speed ? speed * 0.6 + (Math.abs(dy) / dt) * 0.4 : Math.abs(dy) / dt;
    var d = dy > 0 ? 1 : -1;
    if (d !== dir) { dir = d; apply(d, 1, speed); }
    lastY = y;
  }  document.addEventListener('scroll', function (e) {    var t = e && e.target;    var el = (t && t.nodeType === 1) ? t : (document.scrollingElement || document.documentElement);    track(el, el ? (el.scrollTop || 0) : 0);  }, { capture: true, passive: true });  window.addEventListener('resize', function () { if (dir) apply(dir, 0); });
  window.ulaaSetBig = function (v) { apply(v ? -1 : 1, 1); };  apply(1, 0);})();;(function () {  var JUNK = /(published|last updated|updated on|read time|mins read|share this|follow us|subscribe|advertisement|sponsored|photo:|image:|express photo|afp|pti|ani)\b/i;  function clean(t) {    return t      .replace(/(?:[^\s]{1,14}\s+)?\d{1,2},\s*\d{4}(?:\s*\d{1,2}:\d{2})?\s*(?:IST|GMT|UTC|AM|PM)?/gi, ' ')      .replace(/(?:january|february|march|april|may|june|july|august|september|october|november|december)/gi, ' ')      .replace(/(?:जनवरी|फरवरी|फ़रवरी|मार्च|अप्रैल|मई|जून|जुलाई|अगस्त|सितंबर|सितम्बर|अक्टूबर|अक्तूबर|नवंबर|नवम्बर|दिसंबर|दिसम्बर)/g, ' ')      .replace(/\b\d{1,2}:\d{2}\s*(?:IST|GMT|UTC|AM|PM)\b/gi, ' ')      .replace(/(?:published|last updated|updated)\s*(?:on)?/gi, ' ')      .replace(/read\s*time\s*:?\s*\d+\s*mins?/gi, ' ')      .replace(/\b(?:विज्ञापन|अपडेट|प्रकाशित|में प्रकाशित)\b/g, ' ')      .replace(/\s+/g, ' ')      .trim();  }  function textOf(el) {    var t = el.innerText || el.textContent || '';    return t.replace(/\s+/g, ' ').trim();  }  function collect(root) {    var out = [], ps = root.querySelectorAll('p, li, blockquote');    for (var i = 0; i < ps.length; i++) {      var el = ps[i], t = clean(textOf(el));      if (t.length < 60) continue;      if (JUNK.test(t) && t.length < 180) continue;      var a = el.querySelectorAll('a'), link = 0;      for (var k = 0; k < a.length; k++) link += textOf(a[k]).length;      if (link > t.length * 0.4) continue;      out.push(t);    }    return out;  }  function root() {    var sel = ['article', 'main', '[role=main]', '[itemprop=articleBody]', '.post-content', '.entry-content', '#content'];    var best = null, score = 0;    for (var i = 0; i < sel.length; i++) {      var els = document.querySelectorAll(sel[i]);      for (var j = 0; j < els.length; j++) {        var t = collect(els[j]);        var n = 0;        for (var k = 0; k < t.length; k++) n += t[k].length;        if (n > score) { score = n; best = els[j]; }      }    }    if (best && score > 600) return best;    return document.body;  }  var AI_URL = 'https://text.pollinations.ai/openai';  var AI_MODEL = 'openai';  var aiShown = false;  function articleText() {    var ps = collect(root()), out = [], i, n = 0;    for (i = 0; i < ps.length; i++) {      if (n + ps[i].length > 7000) break;      out.push(ps[i]); n += ps[i].length;    }    return out.join('\n\n');  }  function askModel() {    function fallback(msg) {      if (aiShown || panel.style.display !== 'block') return;      aiShown = true;      showMsg(msg || 'Could not summarise this page');    }    var art = articleText();    if (!art || art.length < 200) { fallback('Page Cannot be summarised'); return; }    var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;    var timer = setTimeout(function () { if (ctrl) try { ctrl.abort(); } catch (e) {} }, 60000);    var req = {      model: AI_MODEL, max_tokens: 1200, temperature: 0.3, reasoning_effort: 'low', think: false,      messages: [        { role: 'system', content: 'You summarise news articles. Reply with ONLY the summary, as exactly two paragraphs of plain prose in the same language as the article, about 120 to 160 words in total. Compress the whole article into those two paragraphs: cover the main points, leave nothing important out, and do not add a third paragraph. No preamble, no headings, no bullet points, no markdown.' },        { role: 'user', content: art }      ]    };    if (ctrl) req.signal = ctrl.signal;
    function once() {
      var c2 = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var t2 = setTimeout(function () { if (c2) try { c2.abort(); } catch (e) {} }, 60000);
      var r2 = req;
      if (c2) { r2 = JSON.parse(JSON.stringify(req)); r2.signal = c2.signal; }
      return fetch(AI_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(r2) })
        .then(function (r) {
          if (r.status === 429 || r.status === 402) { clearTimeout(t2); return { busy: 1 }; }
          return r.ok ? r.json() : null;
        })
        .then(function (j) {
          clearTimeout(t2);
          if (j && j.busy) return { busy: 1 };
          var t = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
          return (t && t.length > 40) ? { text: t.replace(/^\s+|\s+$/g, '') } : { failed: 1 };
        })
        .catch(function () { clearTimeout(t2); return { failed: 1 }; });
    }
    function deliver(r) {
      if (r && r.text && !aiShown && panel.style.display === 'block') { aiShown = true; showText(r.text, ''); return true; }
      return false;
    }
    once().then(function (r1) {
      if (deliver(r1)) return;
      if (aiShown || panel.style.display !== 'block') return;
      setTimeout(function () {
        once().then(function (r2) {
          if (deliver(r2)) return;
          fallback(r1.busy || r2.busy ? 'Too many requests - try again in a moment' : 'Could not summarise this page');
        });
      }, r1.busy ? 12000 : 1500);
    });  }  function clearShine() {    body.style.backgroundImage = '';    body.style.backgroundSize = '';    body.style.webkitBackgroundClip = '';    body.style.backgroundClip = '';    body.style.color = '';    body.style.animation = '';  }  function showBusy() {    meta.textContent = '';    body.textContent = 'Generating Summary...';    body.style.backgroundImage = 'linear-gradient(100deg, rgba(255,255,255,0.30) 30%, #ffffff 50%, rgba(255,255,255,0.30) 70%)';    body.style.backgroundSize = '250% 100%';    body.style.webkitBackgroundClip = 'text';    body.style.backgroundClip = 'text';    body.style.color = 'transparent';    body.style.animation = 'ulaa-shine 1.7s linear infinite';    body.style.minHeight = '';    place();  }  function showMsg(t) {    clearShine();    meta.textContent = '';    body.style.minHeight = '';    body.textContent = t;    body.style.minHeight = body.offsetHeight + 'px';    place();  }  function showText(t, note) {    clearShine();    meta.textContent = note || '';    body.style.minHeight = '';    body.textContent = t;    body.style.minHeight = body.offsetHeight + 'px';    body.textContent = '';    place();    typeOut(t);  }  function poly(w, h, dentW, dentD, rad) {    var r = rad === undefined ? 26 : rad, H = h - dentD, pts = [], i, j, t, x, dx, y;    var per = 8;    function arc(cx, cy, a0, a1) {      for (j = 0; j <= per; j++) {        t = a0 + (a1 - a0) * (j / per);        pts.push([Math.round((cx + r * Math.cos(t)) * 10) / 10, Math.round((cy + r * Math.sin(t)) * 10) / 10]);      }    }    arc(r, r, Math.PI, 1.5 * Math.PI);    arc(w - r, r, 1.5 * Math.PI, 2 * Math.PI);    arc(w - r, H - r, 0, 0.5 * Math.PI);    for (i = 0; i <= 20; i++) {      x = (w - r) + (r - (w - r)) * (i / 20);      dx = x - w / 2;      y = H;      if (Math.abs(dx) < dentW / 2) y += dentD * (1 - Math.pow(Math.abs(dx) / (dentW / 2), 2));      pts.push([Math.round(x * 10) / 10, Math.round(y * 10) / 10]);    }    arc(r, H - r, 0.5 * Math.PI, Math.PI);    return pts;  }  var D = '.34s cubic-bezier(.22,.61,.36,1)';  var style = document.createElement('style');  style.textContent =    'html.ulaa-press,html.ulaa-press *{user-select:none !important;-webkit-user-select:none !important;-webkit-touch-callout:none !important}' +    '@keyframes ulaa-hue{to{filter:blur(16px) saturate(170%) hue-rotate(360deg)}}' +    '@property --ulaa-a{syntax:"<angle>";inherits:false;initial-value:0deg}'+'@keyframes ulaa-spin{to{--ulaa-a:360deg}}'+'@keyframes ulaa-shine{0%{background-position:150% 0}100%{background-position:-150% 0}}';  (document.head || document.documentElement).appendChild(style);  var glow = document.createElement('div');  glow.id = 'ulaa-sum-glow';  Object.assign(glow.style, {    position: 'fixed', left: '-2px', right: '-2px', top: '-2px', bottom: '-2px', zIndex: '2147483644',    pointerEvents: 'none', opacity: '0', transition: 'opacity .4s ease',    background: 'conic-gradient(from 0deg,#ff4d6d,#ffb347,#ffe066,#7ddf64,#4dd0e1,#5b8cff,#b06ab3,#ff4d6d)',    WebkitMaskImage: 'radial-gradient(ellipse 130% 120% at 50% 50%,transparent 58%,#000 100%)',    maskImage: 'radial-gradient(ellipse 130% 120% at 50% 50%,transparent 58%,#000 100%)',    filter: 'blur(16px) saturate(170%)', animation: 'ulaa-hue 3.4s linear infinite'  });  var panel = document.createElement('div');  panel.id = 'ulaa-sum';  Object.assign(panel.style, {    position: 'fixed', left: '50%', transform: 'translateX(-50%)', zIndex: '2147483647',    width: 'min(92vw,420px)', maxHeight: '58vh', display: 'none', boxSizing: 'border-box',    color: '#fff', overflow: 'hidden', opacity: '0',    transition: 'max-height .38s cubic-bezier(.22,.61,.36,1), opacity .38s cubic-bezier(.22,.61,.36,1), transform .46s cubic-bezier(.10,.86,.18,1)',    background: 'rgba(22,22,24,0.44)', backdropFilter: 'blur(18px) saturate(180%)', WebkitBackdropFilter: 'blur(18px) saturate(180%)',    font: '500 13.5px/1.5 Bricolage Grotesque,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif'  });  var ring = document.createElement('div');  Object.assign(ring.style, {    position: 'absolute', left: '0', top: '0', right: '0', bottom: '0', pointerEvents: 'none',    background: 'conic-gradient(from var(--ulaa-a,0deg), #ff4d6d, #ffb347, #ffe066, #7ddf64, #4dd0e1, #5b8cff, #b06ab3, #ff4d6d)',    animation: 'ulaa-spin 6s linear infinite'  });  var inner = document.createElement('div');  Object.assign(inner.style, { position: 'relative', maxHeight: 'calc(58vh - 10px)', overflowY: 'auto', overscrollBehavior: 'contain', WebkitOverflowScrolling: 'touch', padding: '16px 18px 24px' });  var head = document.createElement('div');  Object.assign(head.style, { display: 'flex', alignItems: 'center', gap: '7px', marginBottom: '8px', opacity: '0.72', fontSize: '11.5px' });  var title = document.createElement('span');  title.textContent = 'Summary';  var meta = document.createElement('span');  Object.assign(meta.style, { marginLeft: 'auto', opacity: '0.85', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minWidth: '0' });  function mkIcon(mark) {    var b = document.createElement('button');    b.type = 'button';    b.innerHTML = mark;    Object.assign(b.style, {      flex: '0 0 auto', width: '26px', height: '26px', padding: '0', borderRadius: '999px',      border: '1px solid rgba(255,255,255,0.16)', background: 'rgba(255,255,255,0.06)', color: '#fff',      display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', opacity: '0.9'    });    return b;  }  var copyMark = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>';  var tickMark = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>';  var xMark = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';  var copyBtn = mkIcon(copyMark), closeBtn = mkIcon(xMark);  copyBtn.title = 'Copy summary'; closeBtn.title = 'Close';  var body = document.createElement('div');  Object.assign(body.style, { whiteSpace: 'pre-wrap', wordBreak: 'break-word' });  head.appendChild(title); head.appendChild(meta); head.appendChild(copyBtn); head.appendChild(closeBtn);  inner.appendChild(head); inner.appendChild(body);  panel.appendChild(ring);  panel.appendChild(inner);  panel.style.setProperty('text-transform', 'none', 'important');  var typing = null, hideT = null;  function typeOut(txt) {    clearInterval(typing);    var i = 0, per = Math.max(4, Math.min(16, Math.round(2400 / Math.max(txt.length, 1))));    body.textContent = '';    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) { body.textContent = txt; return; }    typing = setInterval(function () {      i += 1;      body.textContent = txt.slice(0, i);      if (i >= txt.length) clearInterval(typing);    }, per);  }  function place() {    var row = document.getElementById('ulaa-pill-row');    var h = row ? row.getBoundingClientRect().height : 34;    panel.style.bottom = 'calc(14px + ' + Math.round(h) + 'px + 26px + env(safe-area-inset-bottom,0px))';    var w = panel.offsetWidth, ht = panel.offsetHeight;    if (!w || !ht) return;    var ins = 1.6, dw = 64, dd = 12;    var outer = poly(w, ht, dw, dd, 26);    var inner = poly(w - 2 * ins, ht - 2 * ins, dw - 2 * ins, dd, 26 - ins).map(function (p) {      return [p[0] + ins, p[1] + ins];    });    var shape = 'polygon(' + outer.map(function (p) { return p[0] + 'px ' + p[1] + 'px'; }).join(',') + ')';    panel.style.clipPath = shape;    panel.style.webkitClipPath = shape;    var path = 'M' + outer.map(function (p) { return p[0] + ' ' + p[1]; }).join('L') + 'Z' +               'M' + inner.map(function (p) { return p[0] + ' ' + p[1]; }).join('L') + 'Z';    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + ht + '" preserveAspectRatio="none">' +      '<path d="' + path + '" fill="#fff" fill-rule="evenodd"/></svg>';    var url = 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';    ring.style.maskImage = url; ring.style.webkitMaskImage = url;    ring.style.maskSize = '100% 100%'; ring.style.webkitMaskSize = '100% 100%';    ring.style.maskRepeat = 'no-repeat'; ring.style.webkitMaskRepeat = 'no-repeat';  }  function open() {    stopEmit();    clearInterval(stepT);    if (panel.style.display === 'block') return;    aiShown = false;    title.textContent = 'Summary';    meta.textContent = '';    body.textContent = '';    panel.style.display = 'block';    var osp = orbSpot(), od = Math.round((panel.getBoundingClientRect().bottom - osp[1]) * 10) / 10;    panel.style.transformOrigin = '50% calc(100% ' + (od >= 0 ? '- ' : '+ ') + Math.abs(od) + 'px)';    panel.style.transform = 'translateX(-50%) scale(0.02)';    panel.style.maxHeight = '58vh';    panel.style.opacity = '0.35';    body.style.minHeight = body.offsetHeight + 'px';    body.textContent = '';    place();    converge();    setTimeout(function () {      panel.style.maxHeight = '58vh';      panel.style.opacity = '1';      panel.style.transform = 'translateX(-50%) scale(1)';      askModel();    }, 660);    glow.style.opacity = '1';    setTimeout(function () { glow.style.opacity = '0'; }, 420);    showBusy();  }  try { window.ulaaSummaryOpen = open; } catch (e) {}
  function close() {    clearInterval(typing);    panel.style.maxHeight = '0px';    panel.style.opacity = '0';    clearTimeout(hideT);    hideT = setTimeout(function () { panel.style.display = 'none'; }, 400);    glow.style.opacity = '0';  }  copyBtn.addEventListener('click', function (e) {    e.stopPropagation();    if (navigator.clipboard) navigator.clipboard.writeText(body.textContent || '').catch(function () {});    copyBtn.innerHTML = tickMark;    setTimeout(function () { copyBtn.innerHTML = copyMark; }, 1200);  });  closeBtn.addEventListener('click', function (e) { e.stopPropagation(); close(); });  document.addEventListener('click', function (e) {    if (panel.style.display !== 'block') return;    var t = e.target;    if (t && t.closest && (t.closest('#ulaa-sum') || t.closest('#ulaa-pill-row'))) return;    close();  }, true);  var press = null, sx = 0, sy = 0, held = 0;  function bubble() { return document.getElementById('ulaa-url-bubble'); }  function inside(x, y) {    var b = bubble();    if (!b || !b.getBoundingClientRect) return false;    var r = b.getBoundingClientRect();    return r.width > 0 && x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;  }  var light = document.createElement('div');
  light.id = 'ulaa-press-light';
  Object.assign(light.style, {
    position: 'fixed', left: '0', top: '0', width: '186px', height: '186px', marginLeft: '-93px', marginTop: '-93px',
    borderRadius: '50%', pointerEvents: 'none', zIndex: '2147483645', opacity: '0',
    transition: 'opacity .22s ease-out',
    background: 'radial-gradient(circle, #ffffff 0%, rgba(255,255,255,0.97) 16%, rgba(255,255,255,0.80) 34%, rgba(255,255,255,0.50) 52%, rgba(255,255,255,0.26) 70%, rgba(255,255,255,0.10) 85%, rgba(255,255,255,0) 100%)',
    filter: 'blur(6px)', mixBlendMode: 'screen', willChange: 'opacity, transform'
  });
  var orb = document.createElement('div');
  orb.id = 'ulaa-orb';
  Object.assign(orb.style, {
    position: 'fixed', left: '0', top: '0', width: '18px', height: '18px', marginLeft: '-9px', marginTop: '-9px',
    borderRadius: '50%', pointerEvents: 'none', zIndex: '2147483646', opacity: '0',
    transition: 'opacity .18s ease-out, transform .18s ease-out',
    background: 'radial-gradient(circle, #ffffff 0%, rgba(255,255,255,0.92) 45%, rgba(255,255,255,0.30) 76%, rgba(255,255,255,0) 100%)',
    boxShadow: '0 0 16px 5px rgba(255,255,255,0.75)',
    mixBlendMode: 'screen', transform: 'scale(0.45)'
  });
  var LEVELS = [0, 0.067, 0.133, 0.2, 0.267, 0.333, 0.4, 0.467, 0.533, 0.6, 0.667, 0.733, 0.8, 0.867, 0.933, 1];
  var stepT = null, stepI = 0;
  function charge() {
    stepI = 0;
    clearInterval(stepT);
    light.style.transition = 'opacity .07s linear, transform .07s linear';
    stepT = setInterval(function () {
      if (stepI >= LEVELS.length) { clearInterval(stepT); return; }
      var v = LEVELS[stepI++];
      light.style.opacity = String(v);
      light.style.transform = 'scale(' + (0.62 + 0.38 * v).toFixed(3) + ')';
    }, 62.5);
  }
  function clipToPill(x, y) {
    var b = bubble();
    if (!b || !b.getBoundingClientRect) return;
    var r = b.getBoundingClientRect();
    if (!r.width) return;
    var m = 17, half = 93, soft = 10;
    var px = r.left - x + half - m;
    var py = r.top - y + half - m;
    var pw = r.width + 2 * m, ph = r.height + 2 * m;
    var rad = Math.max(3, r.height / 2 + m);
    try {
      var br = getComputedStyle(b).borderRadius;
      if (br) rad = (parseFloat(br) || 0) + m;
    } catch (e) {}
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 186 186">' +
      '<defs><filter id="f" x="-60%" y="-60%" width="220%" height="220%">' +
      '<feGaussianBlur stdDeviation="' + soft + '"/></filter></defs>' +
      '<rect x="' + px + '" y="' + py + '" width="' + pw + '" height="' + ph + '" rx="' + rad + '" ry="' + rad + '" fill="#fff" filter="url(#f)"/></svg>';
    var u = 'url("data:image/svg+xml;utf8,' + encodeURIComponent(svg) + '")';
    light.style.maskImage = u;
    light.style.webkitMaskImage = u;
    light.style.maskRepeat = 'no-repeat';
    light.style.webkitMaskRepeat = 'no-repeat';
    light.style.maskSize = '186px 186px';
    light.style.webkitMaskSize = '186px 186px';
  }
  var emitT = null;
  function spawnPart(x, y) {
    var p = document.createElement('div');
    var sz = 2 + Math.random() * 3;
    x += (Math.random() - 0.5) * 12;
    y += (Math.random() - 0.5) * 12;
    Object.assign(p.style, {
      position: 'fixed', left: x + 'px', top: y + 'px', width: sz + 'px', height: sz + 'px',
      marginLeft: (-sz / 2) + 'px', marginTop: (-sz / 2) + 'px', borderRadius: '50%',
      background: '#ffffff', pointerEvents: 'none', zIndex: '2147483645',
      mixBlendMode: 'screen', opacity: '0.95'
    });
    p.setAttribute('data-ulaa-particle', '1');
    document.body.appendChild(p);
    var a = Math.random() * Math.PI * 2, d = 26 + Math.random() * 46;
    var dx = Math.cos(a) * d, dy = Math.sin(a) * d;
    var dur = 480 + Math.random() * 420;
    var done = function () { if (p.parentNode) p.remove(); };
    try {
      var an = p.animate([
        { transform: 'translate(0,0) scale(1)', opacity: 0.95 },
        { transform: 'translate(' + dx.toFixed(1) + 'px,' + dy.toFixed(1) + 'px) scale(0.25)', opacity: 0 }
      ], { duration: dur, easing: 'cubic-bezier(.15,.7,.3,1)', fill: 'forwards' });
      an.onfinish = done;
    } catch (e) {}
    setTimeout(done, dur + 250);
  }
  function startEmit(x, y) {
    clearInterval(emitT);
    emitT = setInterval(function () {
      for (var i = 0; i < 8; i++) spawnPart(x, y);
    }, 85);
  }
  function stopEmit() { clearInterval(emitT); }
  function orbSpot() {
    var w = window.innerWidth || 400, h = window.innerHeight || 800;
    return [w / 2, h * 2.5 / 3];
  }
  function converge() {
    var sp = orbSpot(), ox = sp[0], oy = sp[1];
    light.style.transition = 'opacity .26s ease-in, transform .26s cubic-bezier(.55,0,.9,.4)';
    light.style.transform = 'translate(' + (ox - sx).toFixed(1) + 'px,' + (oy - sy).toFixed(1) + 'px) scale(0.16)';
    light.style.opacity = '0.9';
    setTimeout(function () { light.style.opacity = '0'; }, 230);
    orb.style.left = ox + 'px';
    orb.style.top = oy + 'px';
    orb.style.transform = 'scale(1)';
    orb.style.opacity = '1';
    setTimeout(function () {
      orb.style.transition = 'opacity .32s ease-out, transform .32s cubic-bezier(.10,.85,.20,1)';
      orb.style.transform = 'scale(2.7)';
      orb.style.opacity = '0';
      for (var i = 0; i < 14; i++) spawnPart(ox, oy);
    }, 300);
  }
  function lightOn(x, y) {
    light.style.left = x + 'px';
    light.style.top = y + 'px';
    light.style.transform = 'scale(0.62)';
    light.style.opacity = '0';
    clipToPill(x, y);
    charge();
    startEmit(x, y);
  }
  function lightOff() {
    clearInterval(stepT);
    stopEmit();
    light.style.transition = 'opacity .22s ease-out, transform .22s ease-out';
    light.style.opacity = '0';
  }
  var tapT = 0, tapWasBig = 1;
  var searchOn = 0, searchInput = null, searchPanel = null, outsideHandler = null, lastCloseAt = 0;
  function labelEl() {
    var b = bubble();
    return (b && b.children && b.children[1]) ? b.children[1] : null;
  }
  function overLabel(x, y) {
    var L = labelEl();
    if (!L || !L.getBoundingClientRect) return false;
    var r = L.getBoundingClientRect();
    return r.width > 0 && x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
  }
  // per-site search endpoints: naming a site opens that site's own search, which lands
  // on the real page instead of a search-engine results list
  var SITES = {
    flipkart: 'https://www.flipkart.com/search?q=',
    amazon: 'https://www.amazon.in/s?k=',
    myntra: 'https://www.myntra.com/search?q=',
    ajio: 'https://www.ajio.com/search/?text=',
    croma: 'https://www.croma.com/searchB?q=',
    snapdeal: 'https://www.snapdeal.com/search?keyword=',
    meesho: 'https://www.meesho.com/search?q=',
    nykaa: 'https://www.nykaa.com/search/result/?q=',
    tatacliq: 'https://www.tatacliq.com/search/?searchCategory=all&text=',
    reliancedigital: 'https://www.reliancedigital.in/search?q=',
    swiggy: 'https://www.swiggy.com/search?query=',
    zomato: 'https://www.zomato.com/search?q=',
    bookmyshow: 'https://in.bookmyshow.com/explore/movies?q=',
    makemytrip: 'https://www.makemytrip.com/flights/',
    paytm: 'https://paytm.com/',
    github: 'https://github.com/search?q=',
    wikipedia: 'https://en.wikipedia.org/w/index.php?search=',
    youtube: 'https://www.youtube.com/results?search_query=',
    reddit: 'https://www.reddit.com/search/?q=',
    stackoverflow: 'https://stackoverflow.com/search?q=',
    quora: 'https://www.quora.com/search?q=',
    imdb: 'https://www.imdb.com/find?q=',
    cricbuzz: 'https://www.cricbuzz.com/search?q=',
    ndtv: 'https://www.ndtv.com/search?searchtext='
  };
  function smartOn() {
    try { return localStorage.getItem('ulaa-smart') !== '0'; } catch (e) { return true; }
  }
  try { window.ulaaSmartOn = smartOn; window.ulaaRoute = route; } catch (e) {}
  function isQuestion(q) {
    if (/\?\s*$/.test(q)) return true;
    return /^(what|who|whom|whose|why|how|when|where|which|is|are|was|were|am|do|does|did|can|could|should|would|will|has|have|had)\b/i
      .test(q.replace(/^\s+/, ''));
  }
  var KNOWN = [
    'google.com','youtube.com','facebook.com','instagram.com','whatsapp.com','x.com','twitter.com',
    'reddit.com','wikipedia.org','linkedin.com','pinterest.com','quora.com','medium.com',
    'github.com','gitlab.com','stackoverflow.com','npmjs.com','vercel.com','netlify.com',
    'amazon.in','amazon.com','flipkart.com','myntra.com','ajio.com','meesho.com','snapdeal.com',
    'nykaa.com','croma.com','reliancedigital.in','tatacliq.com','paytm.com','phonepe.com',
    'swiggy.com','zomato.com','zepto.com','blinkit.com','bigbasket.com','bookmyshow.com',
    'makemytrip.com','irctc.co.in','redbus.in','uber.com',
    'ndtv.com','thehindu.com','hindustantimes.com','indianexpress.com',
    'bbc.com','cnn.com','reuters.com','theguardian.com','nytimes.com',
    'netflix.com','primevideo.com','hotstar.com','spotify.com','soundcloud.com',
    'imdb.com','cricbuzz.com','espn.com',
    'apple.com','microsoft.com','samsung.com','oneplus.in','mi.com','realme.com','vivo.com',
    'adobe.com','figma.com','canva.com','notion.so','slack.com','discord.com','telegram.org',
    'chatgpt.com','claude.ai','perplexity.ai','sarvam.ai',
    'accuweather.com','timeanddate.com','britannica.com','dictionary.com',
    'archive.org','wordpress.com','substack.com'
  ];
  function editDistance(a, b) {
    if (a === b) return 0;
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    var prev = [], i, j;
    for (j = 0; j <= b.length; j++) prev[j] = j;
    for (i = 1; i <= a.length; i++) {
      var cur = [i];
      for (j = 1; j <= b.length; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1,
                          prev[j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
      }
      prev = cur;
    }
    return prev[b.length];
  }
  function nearestSite(word) {
    var w = String(word).toLowerCase().replace(/[^a-z0-9]/g, '');
    if (w.length < 3) return null;
    var best = null, bestD = 99;
    for (var i = 0; i < KNOWN.length; i++) {
      var host = KNOWN[i], base = host.split('.')[0].replace(/[^a-z0-9]/g, '');
      var d = editDistance(w, base);
      if (base.indexOf(w) === 0) d = Math.min(d, 1);
      if (d < bestD) { bestD = d; best = host; }
    }
    var limit = w.length <= 4 ? 1 : (w.length <= 7 ? 2 : 3);
    return (best && bestD <= limit) ? 'https://' + best : null;
  }
  var NAV = /^(?:open|go\s+to|goto|visit|launch)\s+(.+)$/i;
  function navTarget(t) {
    t = t.trim().replace(/[.。,'"]+$/, '').trim();
    if (!t) return null;
    var key = t.toLowerCase().replace(/\s+/g, '');
    if (SITES[key]) { try { return new URL(SITES[key]).origin; } catch (e) {} }
    if (/^[a-z0-9-]+$/i.test(t)) {
      return nearestSite(t) || ('https://' + t.toLowerCase() + '.com');
    }
    if (/^[^\s\/?#]+\.[a-z]{2,}([\/?#].*)?$/i.test(t)) return 'https://' + t;
    return null;
  }
  function route(q) {
    var scheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(q);
    var bare = !scheme && !/\s/.test(q) && /^[^\s\/?#]+\.[a-z]{2,}([\/?#].*)?$/i.test(q);
    if (scheme) { location.href = q; return; }
    if (bare) { location.href = 'https://' + q; return; }
    var nav = q.match(NAV);
    if (nav) {
      var target = navTarget(nav[1]);
      if (target) { location.href = target; return; }
    }
    if (!smartOn()) {
      location.href = 'https://search.brave.com/search?q=' + encodeURIComponent(q);
      return;
    }
    // a question stays a question - naming a site inside it must not hijack it
    if (isQuestion(q)) {
      location.href = 'https://search.brave.com/search?q=' + encodeURIComponent(q);
      return;
    }
    var hit = '', name = '';
    for (var k in SITES) {
      if (SITES.hasOwnProperty(k) && new RegExp('\\b' + k + '\\b', 'i').test(q)) { hit = SITES[k]; name = k; break; }
    }
    if (hit) {
      var terms = q.replace(new RegExp('\\b' + name + '\\b', 'ig'), ' ')
                   .replace(/^\s*(price of|prices|price|cost of|cost|buy|buying|best|where to buy|order)\s+/i, '')
                   .replace(/\s+\b(on|from|at|in)\s*$/i, '')
                   .replace(/\s+/g, ' ').trim();
      location.href = hit + encodeURIComponent(terms || q);
      return;
    }
    location.href = 'https://search.brave.com/search?q=' + encodeURIComponent(q);
  }

  try { window.ulaaRoute = route; } catch (e) {}
  var KEY = 'ulaa-recent-search';
  var recentCache = [];

  function backend() {
    try { if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) return 'chrome'; } catch (e) {}
    try { if (typeof browser !== 'undefined' && browser.storage && browser.storage.local) return 'browser'; } catch (e) {}
    try { if (typeof GM_getValue === 'function' && typeof GM_setValue === 'function') return 'gm'; } catch (e) {}
    return 'local';
  }
  function parse(v) {
    if (!v) return [];
    if (Object.prototype.toString.call(v) === '[object Array]') return v;
    try { var a = JSON.parse(v); return Object.prototype.toString.call(a) === '[object Array]' ? a : []; }
    catch (e) { return []; }
  }
  function loadRecents(cb) {
    var b = backend();
    if (b === 'chrome') {
      try {
        chrome.storage.local.get([KEY], function (o) {
          recentCache = parse(o && o[KEY]); cb(recentCache.slice());
        });
        return;
      } catch (e) {}
    } else if (b === 'browser') {
      try {
        browser.storage.local.get(KEY).then(function (o) {
          recentCache = parse(o && o[KEY]); cb(recentCache.slice());
        }, function () { cb(recentCache.slice()); });
        return;
      } catch (e) {}
    } else if (b === 'gm') {
      try { recentCache = parse(GM_getValue(KEY, '[]')); } catch (e) {}
      cb(recentCache.slice());
      return;
    }
    try { recentCache = parse(localStorage.getItem(KEY)); } catch (e) { recentCache = []; }
    cb(recentCache.slice());
  }
  function saveRecents(arr) {
    recentCache = arr.slice();
    var b = backend();
    if (b === 'chrome') { try { var o = {}; o[KEY] = arr; chrome.storage.local.set(o); return; } catch (e) {} }
    else if (b === 'browser') { try { var o2 = {}; o2[KEY] = arr; browser.storage.local.set(o2); return; } catch (e) {} }
    else if (b === 'gm') { try { GM_setValue(KEY, JSON.stringify(arr)); return; } catch (e) {} }
    try { localStorage.setItem(KEY, JSON.stringify(arr)); } catch (e) {}
  }
  function addRecent(q) {
    var a = recentCache.filter(function (x) { return x !== q; });
    a.unshift(q);
    saveRecents(a.slice(0, 8));
  }
  function removeRecent(q) {
    var a = recentCache.filter(function (x) { return x !== q; });
    saveRecents(a);
    return a;
  }
  function clearRecents() { saveRecents([]); }
  function closeSearch(animate) {
    if (!searchOn) return;
    searchOn = 0;
    lastCloseAt = Date.now();
    if (outsideHandler) {
      try {
        document.removeEventListener('touchstart', outsideHandler, true);
        document.removeEventListener('mousedown', outsideHandler, true);
      } catch (e) {}
      outsideHandler = null;
    }
    var p = searchPanel;
    searchPanel = null; searchInput = null;
    if (!p) return;
    if (!animate) { if (p.parentNode) p.parentNode.removeChild(p); return; }
    // shrink toward the pill, so it looks like the panel folds back into it
    var b = bubble();
    var pr = p.getBoundingClientRect ? p.getBoundingClientRect() : null;
    var br = (b && b.getBoundingClientRect) ? b.getBoundingClientRect() : null;
    if (pr && br && pr.width && pr.height) {
      var ox = ((br.left + br.width / 2) - pr.left) / pr.width * 100;
      var oy = ((br.top + br.height / 2) - pr.top) / pr.height * 100;
      p.style.transformOrigin = Math.max(0, Math.min(100, ox)) + '% ' +
                                Math.max(0, Math.min(100, oy)) + '%';
    }
    p.style.transition = 'transform .26s cubic-bezier(.34,1.1,.64,1), opacity .26s ease';
    if (p.offsetHeight) {}
    p.style.transform = 'translateX(-50%) scale(0.12)';
    p.style.opacity = '0';
    setTimeout(function () { if (p.parentNode) p.parentNode.removeChild(p); }, 300);
  }
  function openSearch() {
    if (searchOn) return;
    if (Date.now() - lastCloseAt < 350) return;
    searchOn = 1;

    var vw = window.innerWidth || 360;
    var row = document.getElementById('ulaa-pill-row');
    var rowTop = (row && row.getBoundingClientRect) ? row.getBoundingClientRect().top
                                                    : (window.innerHeight - 60);
    var bottomGap = Math.max(8, (window.innerHeight || 700) - rowTop + 8);

    var panel = document.createElement('div');
    Object.assign(panel.style, {
      position: 'fixed', left: '50%', transform: 'translateX(-50%)',
      width: Math.max(220, vw - 24) + 'px', bottom: bottomGap + 'px',
      boxSizing: 'border-box', padding: '12px', borderRadius: '22px',
      zIndex: '2147483646', background: 'rgba(22,22,24,0.44)',
      border: '1px solid rgba(255,255,255,0.16)',
      boxShadow: '0 8px 28px rgba(0,0,0,0.45)',
      backdropFilter: 'blur(18px)', WebkitBackdropFilter: 'blur(18px)',
      font: '500 13px Bricolage Grotesque,-apple-system, BlinkMacSystemFont, sans-serif', color: '#fff'
    });
    document.body.appendChild(panel);
    searchPanel = panel;

    function diag(msg) {
      try {
        var d = document.createElement('div');
        d.textContent = '\u26a0 ' + msg;
        Object.assign(d.style, {
          marginTop: '8px', font: '500 10.5px Bricolage Grotesque,-apple-system, sans-serif', color: '#ff9c7d'
        });
        panel.appendChild(d);
      } catch (e) {}
    }

    var inp = document.createElement('input');
    inp.type = 'search';
    inp.placeholder = 'Search...';
    inp.setAttribute('enterkeyhint', 'search');
    Object.assign(inp.style, {
      display: 'block', width: '100%', boxSizing: 'border-box', height: '42px',
      borderRadius: '999px', border: '1px solid rgba(255,255,255,0.24)',
      background: 'rgba(22,22,24,0.66)', color: '#fff',
      font: '500 14px Bricolage Grotesque,-apple-system, sans-serif', padding: '0 16px', outline: 'none'
    });
    panel.appendChild(inp);
    searchInput = inp;

    /* ---- core wiring comes FIRST: nothing below can stop it ---- */
    inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        var q = (inp.value || '').trim();
        if (!q) return;
        try { addRecent(q); } catch (er) {}
        try {
          if (window.ulaaRoute) window.ulaaRoute(q);
          else if (typeof route === 'function') route(q);
          else diag('router unavailable');
        } catch (er) { diag('route: ' + er.message); }
      } else if (e.key === 'Escape') {
        closeSearch(true);
      }
    });
    ['touchstart', 'touchmove', 'touchend'].forEach(function (t) {
      inp.addEventListener(t, function (e) { e.stopPropagation(); }, { passive: true });
    });
    panel.addEventListener('click', function (e) { if (e && e.stopPropagation) e.stopPropagation(); });
    panel.addEventListener('touchstart', function () { panelTouchAt = Date.now(); }, { passive: true });

    outsideHandler = function (ev) {
      var t = ev && ev.target;
      if (!t) return;
      if (t === panel || (panel.contains && panel.contains(t))) return;
      closeSearch(true);
    };
    try {
      document.addEventListener('touchstart', outsideHandler, true);
      document.addEventListener('mousedown', outsideHandler, true);
    } catch (e) {}

    setTimeout(function () { try { inp.focus(); } catch (e) {} }, 40);

    /* ---- optional extras, each isolated so a failure is cosmetic ---- */
    try {
      var bEl = bubble();
      var pr0 = panel.getBoundingClientRect ? panel.getBoundingClientRect() : null;
      var br0 = (bEl && bEl.getBoundingClientRect) ? bEl.getBoundingClientRect() : null;
      var cx = 0, cy = 0;
      if (br0 && br0.width) { cx = br0.left + br0.width / 2; cy = br0.top + br0.height / 2; }
      else { cx = (window.innerWidth || 400) / 2; cy = (window.innerHeight || 800) / 2; }
      if (pr0 && pr0.width && pr0.height) {
        var ox0 = Math.max(0, Math.min(100, (cx - pr0.left) / pr0.width * 100));
        var oy0 = Math.max(0, Math.min(100, (cy - pr0.top) / pr0.height * 100));
        panel.style.transformOrigin = ox0 + '% ' + oy0 + '%';
      }
      panel.style.transition = 'none';
      panel.style.transform = 'translateX(-50%) scale(0.12)';
      panel.style.opacity = '0';
      if (panel.offsetHeight) {}
      panel.style.transition = 'transform .34s cubic-bezier(.34,1.4,.64,1), opacity .2s ease';
      panel.style.transform = 'translateX(-50%) scale(1)';
      panel.style.opacity = '1';
    } catch (e) { diag('anim: ' + e.message); }

    try {
      var sect = null;
      function renderRecents(list) {
        if (sect && sect.parentNode) sect.parentNode.removeChild(sect);
        sect = null;
        if (!list || !list.length) return;
        var section = document.createElement('div');
        var head = document.createElement('div');
        Object.assign(head.style, {
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          margin: '12px 2px 8px'
        });
        var lab = document.createElement('div');
        lab.textContent = 'Recent search:';
        Object.assign(lab.style, {
          fontSize: '11.5px', letterSpacing: '.04em',
          textTransform: 'uppercase', color: 'rgba(255,255,255,0.55)'
        });
        var clear = document.createElement('button');
        clear.type = 'button';
        clear.textContent = '\u00d7';
        Object.assign(clear.style, {
          border: '0', background: 'transparent', color: 'rgba(255,255,255,0.55)',
          font: '600 16px Bricolage Grotesque,-apple-system, sans-serif', padding: '0 4px', cursor: 'pointer'
        });
        clear.addEventListener('click', function (ev) {
          if (ev && ev.stopPropagation) ev.stopPropagation();
          clearRecents();
          if (section.parentNode) section.parentNode.removeChild(section);
        });
        head.appendChild(lab); head.appendChild(clear); section.appendChild(head);

        var wrap = document.createElement('div');
        Object.assign(wrap.style, {
          display: 'flex', flexWrap: 'wrap', gap: '7px', maxHeight: '34vh', overflowY: 'auto'
        });
        section.appendChild(wrap);

        list.forEach(function (q) {
          var chip = document.createElement('div');
          Object.assign(chip.style, {
            display: 'inline-flex', alignItems: 'center', gap: '6px', maxWidth: '100%',
            borderRadius: '999px', border: '1px solid rgba(255,255,255,0.22)',
            background: 'rgba(255,255,255,0.12)', padding: '6px 8px 6px 13px'
          });
          var txt = document.createElement('span');
          txt.textContent = q;
          Object.assign(txt.style, {
            maxWidth: '60vw', overflow: 'hidden', textOverflow: 'ellipsis',
            whiteSpace: 'nowrap', color: '#fff', font: '500 12.5px Bricolage Grotesque,-apple-system, sans-serif',
            cursor: 'pointer'
          });
          txt.addEventListener('click', function (ev) {
            if (ev && ev.stopPropagation) ev.stopPropagation();
            try { addRecent(q); } catch (er) {}
            closeSearch(true);
            try { if (window.ulaaRoute) window.ulaaRoute(q); } catch (er) {}
          });
          var x = document.createElement('button');
          x.type = 'button';
          x.textContent = '\u00d7';
          Object.assign(x.style, {
            border: '0', background: 'transparent', color: 'rgba(255,255,255,0.5)',
            font: '600 14px Bricolage Grotesque,-apple-system, sans-serif', lineHeight: '1',
            padding: '2px 4px', cursor: 'pointer'
          });
          x.addEventListener('click', function (ev) {
            if (ev && ev.stopPropagation) ev.stopPropagation();
            removeRecent(q);
            if (chip.parentNode) chip.parentNode.removeChild(chip);
            if (!wrap.children || !wrap.children.length) {
              if (section.parentNode) section.parentNode.removeChild(section);
            }
          });
          chip.appendChild(txt); chip.appendChild(x);
          wrap.appendChild(chip);
        });
        sect = section;
        panel.appendChild(section);
      }
      loadRecents(renderRecents);
    } catch (e) { diag('recents: ' + e.message); }

    try {
      var srow = document.createElement('label');
      Object.assign(srow.style, {
        display: 'flex', alignItems: 'center', gap: '9px', marginTop: '13px',
        cursor: 'pointer', userSelect: 'none'
      });
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      var smartNow = true;
      try { smartNow = window.ulaaSmartOn ? window.ulaaSmartOn() : true; } catch (e) {}
      cb.checked = smartNow;
      Object.assign(cb.style, {
        width: '17px', height: '17px', margin: '0', flex: '0 0 auto',
        accentColor: '#ff7a33', cursor: 'pointer'
      });
      cb.addEventListener('change', function () {
        try { localStorage.setItem('ulaa-smart', cb.checked ? '1' : '0'); } catch (e) {}
      });
      var stxt = document.createElement('span');
      stxt.textContent = 'Smart search';
      Object.assign(stxt.style, {
        font: '500 12.5px Bricolage Grotesque,-apple-system, sans-serif', color: 'rgba(255,255,255,0.72)'
      });
      var ver = document.createElement('span');
      ver.textContent = 'r98';
      Object.assign(ver.style, {
        marginLeft: 'auto', font: '500 10px Bricolage Grotesque,-apple-system, sans-serif',
        letterSpacing: '.12em', color: 'rgba(255,255,255,0.34)'
      });
      srow.appendChild(cb); srow.appendChild(stxt); srow.appendChild(ver);
      panel.appendChild(srow);
    } catch (e) { diag('toggle: ' + e.message); }
  }

  function wireSearch() {
    var L = labelEl();
    if (!L || (L.getAttribute && L.getAttribute('data-search'))) return;
    if (L.setAttribute) L.setAttribute('data-search', '1');
    L.style.pointerEvents = 'auto';
    L.style.cursor = 'text';
    L.addEventListener('click', function (e) {
      if (window.ulaaLongPress && Date.now() - window.ulaaLongPress < 900) return;
      if (!isBigNow()) return;
      if (e && e.stopPropagation) e.stopPropagation();
      openSearch();
    });
  }
  var menuEl = null, menuOpen = 0;
  function pillRow() { return document.getElementById('ulaa-pill-row'); }
  function foldMenu(then) {
    if (!menuOpen) { if (then) then(); return; }
    menuOpen = 0;
    var m = menuEl; menuEl = null;
    if (m) {
      m.style.transition = 'transform .24s cubic-bezier(.34,1.1,.64,1), opacity .2s ease';
      m.style.transform = 'translateX(-50%) scale(0.12)';
      m.style.opacity = '0';
      setTimeout(function () { if (m.parentNode) m.parentNode.removeChild(m); }, 280);
    }
    if (then) setTimeout(then, 250);
  }
  function openMenu() {
    // if a previous menu was removed without resetting the flag, recover
    if (menuOpen && (!menuEl || !menuEl.parentNode)) { menuOpen = 0; menuEl = null; }
    if (menuOpen) return;
    try { buildMenu(); } catch (e) {
      // menu could not be built - fall back to the old behaviour rather than nothing
      try { if (window.ulaaSummaryOpen) window.ulaaSummaryOpen(); } catch (e2) {}
    }
  }
  try { window.ulaaOpenMenu = openMenu; } catch (e) {}
  function buildMenu() {
    var b = bubble();
    var br = (b && b.getBoundingClientRect) ? b.getBoundingClientRect() : null;
    var m = document.createElement('div');
    Object.assign(m.style, {
      position: 'fixed', left: '50%',
      bottom: ((window.innerHeight || 700) - (br ? br.top : 60) + 10) + 'px',
      transform: 'translateX(-50%)', width: '188px', boxSizing: 'border-box',
      borderRadius: '16px', border: '1px solid rgba(255,255,255,0.18)',
      background: 'rgba(22,22,24,0.44)', backdropFilter: 'blur(16px)',
      WebkitBackdropFilter: 'blur(16px)', padding: '5px', zIndex: '2147483647',
      boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
      font: '500 13.5px Bricolage Grotesque,-apple-system, BlinkMacSystemFont, sans-serif', color: '#fff'
    });
    function mkRow(label, fn) {
      var r = document.createElement('button');
      r.type = 'button';
      r.textContent = label;
      Object.assign(r.style, {
        display: 'block', width: '100%', textAlign: 'left', border: '0',
        background: 'transparent', color: '#fff', padding: '11px 13px',
        borderRadius: '12px', font: '500 13.5px Bricolage Grotesque,-apple-system, sans-serif', cursor: 'pointer'
      });
      r.addEventListener('click', function (ev) {
        if (ev && ev.stopPropagation) ev.stopPropagation();
        fn();
      });
      return r;
    }
    m.appendChild(mkRow('Summarise', function () {
      foldMenu(function () { if (window.ulaaSummaryOpen) window.ulaaSummaryOpen(); });
    }));
    m.appendChild(mkRow('Hide Address Bar', function () {
      foldMenu(function () { hidePill(); });
    }));
    document.body.appendChild(m);
    menuEl = m; menuOpen = 1;
    setTimeout(function () {
      function away(ev) {
        var t = ev && ev.target;
        if (!t) return;
        if (t === m || (m.contains && m.contains(t))) return;
        try {
          if (document.removeEventListener) {
            document.removeEventListener('touchstart', away, true);
            document.removeEventListener('mousedown', away, true);
          }
        } catch (e) {}
        foldMenu();
      }
      try {
        document.addEventListener('touchstart', away, true);
        document.addEventListener('mousedown', away, true);
      } catch (e) {}
    }, 60);

    // the menu emerges from the ORB, not the pill: use the orb's live rect, or the
    // same spot the orb is drawn at if it has already faded out
    var orbEl = document.getElementById('ulaa-orb');
    var orbR = (orbEl && orbEl.getBoundingClientRect) ? orbEl.getBoundingClientRect() : null;
    var cx, cy;
    if (orbR && orbR.width && orbEl.style.opacity !== '0') {
      cx = orbR.left + orbR.width / 2;
      cy = orbR.top + orbR.height / 2;
    } else if (window.ulaaLastTouch) {
      cx = window.ulaaLastTouch.x;
      cy = window.ulaaLastTouch.y;
    } else {
      cx = (window.innerWidth || 400) / 2;
      cy = (window.innerHeight || 800) / 2;
    }
    if (m.getBoundingClientRect) {
      var mr = m.getBoundingClientRect();
      if (mr.width && mr.height) {
        var ox = (cx - mr.left) / mr.width * 100;
        var oy = (cy - mr.top) / mr.height * 100;
        m.style.transformOrigin = Math.max(0, Math.min(100, ox)) + '% ' +
                                  Math.max(0, Math.min(100, oy)) + '%';
      }
    }
    // a small orb at the origin, so the menu visibly bursts out of something
    var spark = document.createElement('div');
    Object.assign(spark.style, {
      position: 'fixed', left: cx + 'px', top: cy + 'px', width: '26px', height: '26px',
      marginLeft: '-13px', marginTop: '-13px', borderRadius: '50%',
      pointerEvents: 'none', zIndex: '2147483647',
      background: 'radial-gradient(circle, #ffffff 0%, rgba(255,255,255,0.9) 45%, rgba(255,255,255,0) 100%)',
      filter: 'blur(2px)', transform: 'scale(0.3)', opacity: '1',
      transition: 'transform .4s cubic-bezier(.34,1.4,.64,1), opacity .4s ease'
    });
    document.body.appendChild(spark);
    if (spark.offsetHeight) {}
    spark.style.transform = 'scale(1.6)';
    spark.style.opacity = '0';
    setTimeout(function () { if (spark.parentNode) spark.parentNode.removeChild(spark); }, 460);

    m.style.transition = 'none';
    m.style.transform = 'translateX(-50%) scale(0.12)';
    m.style.opacity = '0';
    if (m.offsetHeight) {}
    m.style.transition = 'transform .36s cubic-bezier(.34,1.4,.64,1), opacity .2s ease';
    m.style.transform = 'translateX(-50%) scale(1)';
    m.style.opacity = '1';
    try { lightOff(); } catch (e) {}       // glow clears only once the menu is out
  }
  function orbPoint() {
    var w = window.innerWidth || 400, h = window.innerHeight || 800;
    return [w / 2, h * 2.5 / 3];
  }
  function hidePill() {
    var r = pillRow();
    if (!r) return;
    var pt = orbPoint();
    var rr = r.getBoundingClientRect ? r.getBoundingClientRect() : null;
    if (rr && rr.width && rr.height) {
      var ox = Math.max(0, Math.min(100, (pt[0] - rr.left) / rr.width * 100));
      var oy = Math.max(0, Math.min(100, (pt[1] - rr.top) / rr.height * 100));
      r.style.transformOrigin = ox + '% ' + oy + '%';
    }
    r.style.transition = 'transform .38s cubic-bezier(.55,0,.9,.4), opacity .14s ease .26s';
    r.style.transform = 'scale(0.04)';
    r.style.opacity = '0';
    r.style.pointerEvents = 'none';

    // the pill folds into the same glowing orb the summary uses
    var orb = document.createElement('div');
    orb.id = 'ulaa-nub';
    Object.assign(orb.style, {
      position: 'fixed', left: pt[0] + 'px', top: pt[1] + 'px',
      width: '18px', height: '18px', marginLeft: '-9px', marginTop: '-9px',
      borderRadius: '50%', cursor: 'pointer', zIndex: '2147483646', opacity: '0',
      background: 'radial-gradient(circle, #ffffff 0%, rgba(255,255,255,0.92) 45%, ' +
                  'rgba(255,255,255,0.30) 76%, rgba(255,255,255,0) 100%)',
      filter: 'blur(1px)', transform: 'scale(0.6)',
      transition: 'transform .18s cubic-bezier(.34,1.4,.64,1), opacity .12s ease'
    });
    // drag the orb anywhere; a tap (no drag) brings the pill back where it belongs
    var dragging = 0, moved = 0, tsx = 0, tsy = 0, tox = 0, toy = 0;
    function place(x, y) {
      var w = window.innerWidth || 400, h = window.innerHeight || 800;
      x = Math.max(10, Math.min(w - 10, x));
      y = Math.max(10, Math.min(h - 10, y));
      orb.style.left = x + 'px';
      orb.style.top = y + 'px';
    }
    orb.addEventListener('touchstart', function (e) {
      var t = (e.touches && e.touches[0]) || e;
      dragging = 1; moved = 0;
      tsx = t.clientX; tsy = t.clientY;
      tox = parseFloat(orb.style.left) || 0;
      toy = parseFloat(orb.style.top) || 0;
      orb.style.transition = 'none';
      if (e.stopPropagation) e.stopPropagation();
    }, { passive: true });
    orb.addEventListener('touchmove', function (e) {
      if (!dragging) return;
      var t = (e.touches && e.touches[0]) || e;
      var dx = t.clientX - tsx, dy = t.clientY - tsy;
      if (Math.abs(dx) > 6 || Math.abs(dy) > 6) moved = 1;
      place(tox + dx, toy + dy);
      if (e.stopPropagation) e.stopPropagation();
      if (e.preventDefault) e.preventDefault();
    }, { passive: false });
    orb.addEventListener('touchend', function (e) {
      dragging = 0;
      orb.style.transition = 'opacity .2s ease-out, transform .2s ease-out';
      if (e.stopPropagation) e.stopPropagation();
      if (!moved) showPill();
    });
    orb.addEventListener('click', function (e) {
      if (e && e.stopPropagation) e.stopPropagation();
      if (moved) { moved = 0; return; }     // that was a drag, not a tap
      showPill();
    });
    document.body.appendChild(orb);
    if (orb.offsetHeight) {}
    orb.style.opacity = '1';
    orb.style.transform = 'scale(1)';
    // swallow: a pulse as the pill lands in it
    setTimeout(function () {
      if (!orb.parentNode) return;
      orb.style.transition = 'transform .22s cubic-bezier(.34,1.4,.64,1)';
      orb.style.transform = 'scale(1.35)';
      setTimeout(function () {
        if (orb.parentNode) orb.style.transform = 'scale(1)';
      }, 200);
    }, 360);
  }
  function showPill() {
    var r = pillRow();
    var orb = document.getElementById('ulaa-nub');
    if (orb) {
      orb.style.transition = 'transform .3s ease-out, opacity .3s ease-out';
      orb.style.transform = 'scale(2.4)';
      orb.style.opacity = '0';
      setTimeout(function () { if (orb.parentNode) orb.parentNode.removeChild(orb); }, 320);
    }
    if (!r) return;
    r.style.transition = 'transform .34s cubic-bezier(.34,1.4,.64,1), opacity .18s ease';
    r.style.transform = 'scale(1)';
    r.style.opacity = '1';
    r.style.pointerEvents = '';
  }
  try { window.ulaaShowPill = showPill; } catch (e) {}
  function isBigNow() { return document.documentElement.classList.contains('ulaa-big'); }
  function down(x, y) {
    if (searchOn) return;
    if (!inside(x, y)) return;
    wireSearch();
    // (a tap on the URL opens search via its own click handler; long-press still charges)
    tapT = Date.now(); tapWasBig = isBigNow();
    if (!tapWasBig) return;             // minimised: no charge, no summary
    held = 1; sx = x; sy = y;
    try { window.ulaaLastTouch = { x: x, y: y }; } catch (e) {}
    lightOn(x, y);    document.documentElement.classList.add('ulaa-press');    clearTimeout(press);    press = setTimeout(function () {
      try { window.ulaaLongPress = Date.now(); } catch (e) {}
      try {
        if (window.ulaaOpenMenu) { window.ulaaOpenMenu(); return; }
        if (typeof openMenu === 'function') { openMenu(); return; }
        if (window.ulaaSummaryOpen) window.ulaaSummaryOpen();
      } catch (e) {
        try { if (window.ulaaSummaryOpen) window.ulaaSummaryOpen(); } catch (e2) {}
      }
    }, 1000);  }  function move(x, y) {    if (!held) return;    if (Math.abs(x - sx) > 10 || Math.abs(y - sy) > 10) up();  }  function up() {
    lightOff(); clearTimeout(press); held = 0;
    document.documentElement.classList.remove('ulaa-press');
    if (!tapWasBig && !isBigNow() && tapT && Date.now() - tapT < 420 && window.ulaaSetBig) {
      // run exactly what a scroll-up runs, but out of the touchend handler and after a
      // forced reflow, so the browser has painted the start state before transitioning
      setTimeout(function () {
        if (!window.ulaaSetBig) return;
        if (document.body) { var _ = document.body.offsetHeight; }
        window.ulaaSetBig(1);
      }, 0);
    }
    tapT = 0;
  }  document.addEventListener('touchstart', function (e) {    if (e.touches && e.touches.length === 1) down(e.touches[0].clientX, e.touches[0].clientY);  }, { capture: true, passive: true });  document.addEventListener('touchmove', function (e) {    if (e.touches && e.touches[0]) move(e.touches[0].clientX, e.touches[0].clientY);  }, { capture: true, passive: true });  document.addEventListener('touchend', up, { capture: true, passive: true });  document.addEventListener('touchcancel', up, { capture: true, passive: true });  document.addEventListener('contextmenu', function (e) { if (held) e.preventDefault(); }, true);  document.addEventListener('mousedown', function (e) { down(e.clientX, e.clientY); }, true);  document.addEventListener('mousemove', function (e) { move(e.clientX, e.clientY); }, true);  document.addEventListener('mouseup', up, true);  function mount() {    if (!document.body) return;    if (!document.body.contains(glow)) document.body.appendChild(glow);    if (!document.body.contains(panel)) document.body.appendChild(panel);    if (!document.body.contains(light)) document.body.appendChild(light);
    if (!document.body.contains(orb)) document.body.appendChild(orb);  }  window.addEventListener('resize', function () { if (panel.style.display === 'block') place(); });  try {    if (typeof ResizeObserver !== 'undefined') {      new ResizeObserver(function () { if (panel.style.display === 'block') place(); }).observe(panel);    }  } catch (e) {}  mount();  try { new MutationObserver(mount).observe(document.documentElement, { childList: true }); } catch (e) {}  setInterval(mount, 1000);})();

;(function () {
  function byTitle(t) {
    var els = document.querySelectorAll('[title]');
    for (var i = 0; i < els.length; i++) if (els[i].title === t) return els[i];
    return null;
  }
  /* called by the browser shell: the native toolbar replaces the pill's own row */
  window.ulaaHidePill = function () {
    var r = document.getElementById('ulaa-pill-row');
    if (r) r.style.display = 'none';
    var q = document.getElementById('ulaa-url-menu');
    if (q) q.style.display = 'none';
    var n = document.getElementById('ulaa-nub');
    if (n && n.parentNode) n.parentNode.removeChild(n);
  };
  window.ulaaTranslate = function () {
    var el = byTitle('Translate page') || byTitle('Show original') || byTitle('Translating\u2026');
    if (el) el.click();
    return !!el;
  };
  window.ulaaEraser = function () {
    var el = byTitle('Eraser menu') || byTitle('Erasing \u2014 tap items to remove');
    if (el) el.click();
    return !!el;
  };
  window.ulaaSummarise = function () {
    try { if (window.ulaaSummaryOpen) { window.ulaaSummaryOpen(); return true; } } catch (e) {}
    return false;
  };
  window.ulaaSmartSet = function (on) {
    try { localStorage.setItem('ulaa-smart', on ? '1' : '0'); } catch (e) {}
  };
})();
