/* Valley privacy shield. Runs at document start in every https frame.
   Kotlin replaces __VALLEY_CFG__ with the current settings, e.g.
   {"ads":true,"banners":true,"fp":true,"webrtc":false,"gpc":true,"home":"appassets.androidplatform.net","exceptions":["example.com"]} */
(function (CFG) {
  'use strict';
  try {
    var host = String(location.hostname || '').toLowerCase();
    if (!host || host === CFG.home) return;
    if (location.protocol !== 'https:' && location.protocol !== 'http:') return;
    var ex = CFG.exceptions || [];
    for (var i = 0; i < ex.length; i++) {
      if (host === ex[i] || host.endsWith('.' + ex[i])) return;
    }
    if (window.__valleyShield) return;
    try { Object.defineProperty(window, '__valleyShield', { value: 1 }); } catch (_) { return; }

    var isTop = false;
    try { isTop = window.top === window; } catch (_) {}

    function def(obj, key, value) {
      try {
        Object.defineProperty(obj, key, {
          get: function () { return value; }, configurable: true, enumerable: true
        });
      } catch (_) {}
    }

    /* ---- Do Not Track + Global Privacy Control ---- */
    if (CFG.gpc && window.Navigator) {
      def(Navigator.prototype, 'globalPrivacyControl', true);
      def(Navigator.prototype, 'doNotTrack', '1');
    }

    /* ---- fingerprinting resistance ---- */
    if (CFG.fp) {
      var seed = (Math.random() * 4294967296) >>> 0;
      var rnd = function () { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

      if (window.Navigator) {
        def(Navigator.prototype, 'hardwareConcurrency', 4);
        def(Navigator.prototype, 'deviceMemory', 4);
        def(Navigator.prototype, 'getBattery', undefined);
      }

      /* canvas: flip the lowest bit of a few pixels so the hash differs but the picture does not.
         Large canvases (editors, games, screenshots) are left alone. */
      var noisify = function (data) {
        var n = data.length;
        if (n < 8) return;
        for (var k = 0; k < 24; k++) {
          var p = ((rnd() * (n / 4)) | 0) * 4 + ((rnd() * 3) | 0);
          data[p] = data[p] ^ 1;
        }
      };
      if (window.CanvasRenderingContext2D && window.HTMLCanvasElement) {
        var origGet = CanvasRenderingContext2D.prototype.getImageData;
        var origURL = HTMLCanvasElement.prototype.toDataURL;
        var origBlob = HTMLCanvasElement.prototype.toBlob;
        CanvasRenderingContext2D.prototype.getImageData = function () {
          var img = origGet.apply(this, arguments);
          try { if (img.width * img.height <= 2000000) noisify(img.data); } catch (_) {}
          return img;
        };
        var noisyCopy = function (canvas) {
          try {
            var w = canvas.width, h = canvas.height;
            if (!w || !h || w * h > 2000000) return null;
            var tmp = document.createElement('canvas');
            tmp.width = w; tmp.height = h;
            var c = tmp.getContext('2d');
            c.drawImage(canvas, 0, 0);
            var img = origGet.call(c, 0, 0, w, h);
            noisify(img.data);
            c.putImageData(img, 0, 0);
            return tmp;
          } catch (_) { return null; }
        };
        HTMLCanvasElement.prototype.toDataURL = function () {
          var copy = noisyCopy(this);
          return origURL.apply(copy || this, arguments);
        };
        HTMLCanvasElement.prototype.toBlob = function () {
          var copy = noisyCopy(this);
          return origBlob.apply(copy || this, arguments);
        };
      }

      /* audio fingerprinting: add inaudible noise once per decoded channel */
      if (window.AudioBuffer) {
        var origChan = AudioBuffer.prototype.getChannelData;
        var done = new WeakMap();
        AudioBuffer.prototype.getChannelData = function (ch) {
          var d = origChan.apply(this, arguments);
          try {
            var seen = done.get(this);
            if (!seen) { seen = {}; done.set(this, seen); }
            if (!seen[ch]) {
              seen[ch] = 1;
              for (var j = 0; j < d.length; j += 100) d[j] += (rnd() - 0.5) * 1e-7;
            }
          } catch (_) {}
          return d;
        };
      }

      /* WebGL: hide the real GPU vendor/renderer strings */
      [window.WebGLRenderingContext, window.WebGL2RenderingContext].forEach(function (C) {
        if (!C || !C.prototype) return;
        var gp = C.prototype.getParameter;
        C.prototype.getParameter = function (p) {
          if (p === 37445) return 'Google Inc.';
          if (p === 37446) return 'ANGLE (Generic Renderer)';
          return gp.apply(this, arguments);
        };
      });
    }

    /* ---- WebRTC: keep your real IP out of peer connections (can break video calls) ---- */
    if (CFG.webrtc) {
      ['RTCPeerConnection', 'webkitRTCPeerConnection'].forEach(function (name) {
        var Orig = window[name];
        if (!Orig) return;
        var Wrapped = function (cfg, constraints) {
          cfg = cfg || {};
          cfg.iceTransportPolicy = 'relay';
          return new Orig(cfg, constraints);
        };
        Wrapped.prototype = Orig.prototype;
        Wrapped.generateCertificate = Orig.generateCertificate;
        try { window[name] = Wrapped; } catch (_) {}
      });
    }

    if (!isTop) return;   /* cosmetic filtering only needs the top document */

    function injectCss(css, id) {
      function go() {
        if (document.getElementById(id)) return true;
        var parent = document.head || document.documentElement;
        if (!parent) return false;
        var s = document.createElement('style');
        s.id = id;
        s.textContent = css;
        parent.appendChild(s);
        return true;
      }
      if (!go()) {
        var mo = new MutationObserver(function () { if (go()) mo.disconnect(); });
        mo.observe(document, { childList: true, subtree: true });
      }
    }

    /* ---- hide ad slots ---- */
    if (CFG.ads) {
      var adSel = [
        'ins.adsbygoogle', '.adsbygoogle', '[id^="google_ads_iframe"]', '[id^="google_ads_frame"]',
        '[id^="div-gpt-ad"]', '[id^="gpt-ad"]', '.gpt-ad', '.dfp-ad', 'iframe[id^="aswift_"]',
        'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]', 'iframe[src*="/pagead/"]',
        'a[href*="doubleclick.net/"]', 'a[href*="googleadservices.com/"]',
        '[data-ad-slot]', '[data-google-query-id]', '[data-ad-client]',
        '.ad-slot', '.ad-unit', '.advert', '.advertisement', '.advertisment', '#advertisement',
        '.ad-banner', '.banner-ad', '.ad-container', '.ad-wrapper', '.sponsored-ad',
        '[aria-label="Advertisement"]', '[aria-label="advertisement"]',
        '.taboola', '[id^="taboola-"]', '.trc_rbox_container', '.OUTBRAIN', '.ob-widget', '[id^="outbrain"]',
        '[id^="mgid_"]', '#mgid', '.adthrive-ad', '[id^="adthrive-"]', '[id^="mv-ad"]',
        '.ezoic-ad', '[id^="ezoic-pub-ad"]', 'iframe[src*="adsterra"]', 'iframe[src*="exoclick"]'
      ].join(',');
      injectCss(adSel + '{display:none!important;visibility:hidden!important}', 'valley-shield-ads');
    }

    /* ---- hide cookie / consent banners and reject where a clear button exists ---- */
    if (CFG.banners) {
      var banSel = [
        '#onetrust-consent-sdk', '#onetrust-banner-sdk', '.onetrust-pc-dark-filter',
        '#CybotCookiebotDialog', '#CybotCookiebotDialogBodyUnderlay',
        '#didomi-host', '.didomi-popup-container', '#didomi-notice',
        '.qc-cmp2-container', '#qc-cmp2-container', '.fc-consent-root', '.fc-dialog-overlay',
        '#truste-consent-track', '#usercentrics-root', '#uc-banner-modal',
        '.osano-cm-window', '.osano-cm-dialog',
        '.cmplz-cookiebanner', '#cmplz-cookiebanner-container',
        '#cookie-law-info-bar', '#cookie-notice', '#cookie-notice-wrapper', '.cky-consent-container', '.cky-overlay',
        '#iubenda-cs-banner', '.iubenda-cs-container',
        'iframe[id^="sp_message_iframe"]', 'div[id^="sp_message_container"]',
        '.cc-window', '.cc-banner', '#cookieconsent', '.cookieconsent',
        '#gdpr-cookie-message', '#gdpr-cookie-notice', '.gdpr-cookie-notice',
        '#cookie-banner', '.cookie-banner', '#cookiebanner', '.cookiebanner',
        '#cookie-consent', '.cookie-consent', '#cookie-consent-banner', '.cookie-consent-banner',
        '#cookie-notification', '.cookie-notification', '.cookies-notice', '#cookies-banner',
        '#consent-banner', '.consent-banner', '#consent_blackbar', '#sp-cc', '.js-consent-banner',
        '#tarteaucitronRoot', '#termly-code-snippet-support', '[id^="hs-eu-cookie-confirmation"]',
        '.evidon-banner', '#_evidon_banner', '#ez-cookie-dialog'
      ].join(',');
      var unlock = 'body.sp-message-open,html.sp-message-open,body.didomi-popup-open,html.didomi-popup-open,' +
        'body.cookiebot-open,html.cookiebot-open,body.ot-no-scroll,html.ot-no-scroll';
      injectCss(banSel + '{display:none!important;visibility:hidden!important;pointer-events:none!important}' +
        unlock + '{overflow:auto!important;position:static!important}', 'valley-shield-banners');

      var rejectSel = [
        '#onetrust-reject-all-handler', '.ot-pc-refuse-all-handler',
        '#CybotCookiebotDialogBodyButtonDecline', '#CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll',
        '#didomi-notice-disagree-button', '.cmplz-deny', '.cky-btn-reject', '.cc-deny',
        '.iubenda-cs-reject-btn', '.osano-cm-denyAll', '.fc-cta-do-not-consent',
        '#wt-cli-reject-btn', '#cn-refuse-cookie', '#uc-btn-deny-banner',
        'button[data-testid="uc-deny-all-button"]'
      ];
      var clicked = {};
      var tries = 0;
      var reject = function () {
        for (var r = 0; r < rejectSel.length; r++) {
          if (clicked[rejectSel[r]]) continue;
          var el = document.querySelector(rejectSel[r]);
          if (el) { clicked[rejectSel[r]] = 1; try { el.click(); } catch (_) {} }
        }
      };
      var start = function () {
        reject();
        var mo = new MutationObserver(function () {
          if (++tries > 80) { mo.disconnect(); return; }
          reject();
        });
        mo.observe(document.documentElement, { childList: true, subtree: true });
        setTimeout(function () { try { mo.disconnect(); } catch (_) {} }, 12000);
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
      else start();
    }
  } catch (_) { /* never let the shield break a page */ }
})(__VALLEY_CFG__);
