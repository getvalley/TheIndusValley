# Eraser inline glass confirmation

- Removed the full-width confirmation card, title, and selected-item description box.
- The selected webpage element now receives a temporary 3px blur while confirmation is active.
- Hide Item and Cancel appear as two compact, neutral glass pills directly over the selected element.
- The controls use Valley-style translucent backgrounds, rounded shapes, subtle borders, and backdrop blur rather than Apple red/blue action colours.
- Original inline filter and transition styles are restored when cancelling or completing the hide action.
