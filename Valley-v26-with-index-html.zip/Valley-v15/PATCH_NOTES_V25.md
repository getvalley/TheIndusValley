# Valley V25 - swipe-to-delete and compact menu panels

- Added left-swipe gestures to Favourites, Recent Searches, and Recently Opened entries. Swiping left reveals the existing remove control; swiping right closes the reveal.
- Kept vertical spacing between rows unchanged.
- Updated the Bookmarks icon to a soft, thin-stroke open-book symbol.
- Changed menu sheet sizing from a fixed 204dp width to a measured content width with a small margin, capped to the available screen width, so the longest option has room.
- Kept Bookmarks and All Tabs in the existing side-by-side horizontal row.

Source-only update. It has not been compiled or tested on-device; run the GitHub Actions build before installing.
