# V26 toolbar and Reader repair

- The bottom toolbar now uses symmetric outer grid columns so the address capsule is centered on the viewport independently of side controls.
- The minimized address capsule has a stable width and remains visible and centered.
- The HTML toolbar's homepage/search mode is synchronized whenever a tab is attached, including swipe switching between already-loaded tabs.
- Refresh now calls WebView.reload() on the active tab.
- Common Google Translate banner/overlay elements are hidden on translated pages while retaining translated article content.
- Reader loading is single-flight to prevent duplicate asynchronous callbacks from toggling the overlay closed.

Validation performed: patch assertions and ZIP integrity. Android build and on-device UI behavior are not verified here.
