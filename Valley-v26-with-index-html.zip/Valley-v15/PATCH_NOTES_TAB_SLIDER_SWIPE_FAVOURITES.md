# Tab slider, swipe transition, and favourites notes

- Added subtle horizontal rails above and below the tab-group selector to make its slider track clearer.
- Tab-to-tab swipe now animates the incoming WebView from the swipe direction while the outgoing page snapshot moves away.
- Clears RenderEffect, alpha, translation, and pending WebView animations across tabs before switching. This addresses stale overview blur effects persisting on inactive tabs.
- The webpage overflow menu already contained a single `Add to Favourites` row, wired through `data-act="favourite"` to the native `addToList("list_favs")` handler. It was verified and retained without adding a duplicate.

Validation: ZIP integrity verified. JavaScript asset syntax checked with Node.js. Android Gradle compilation and device testing were not available in this environment.
