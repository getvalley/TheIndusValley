# V37 - light / dark choice reaches the native screens
- General settings (and the welcome tour) now tell the app which mode was chosen: light, dark or system.
- MainActivity stores it as `themePref`, applies it to the activity's resources (attachBaseContext at launch, updateConfiguration at runtime) and re-applies it after every system configuration change.
- Pal, the night-qualified drawables/colours, the menus, the Tabs page and the toolbar all read those resources, so they follow the choice; "system" still follows the phone.
- Not compiled here (no Gradle/Android SDK).
