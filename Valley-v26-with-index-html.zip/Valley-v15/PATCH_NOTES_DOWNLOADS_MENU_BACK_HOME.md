# Downloads menu and navigation panel adjustment

- Moved Downloads directly above Add Bookmark in the existing page menu.
- Kept Home out of the ••• page menu.
- Added a circular Home icon beside the navigation action button.
- Reduced the width of the Back/Forward action button to make room for Home.
- Existing menu card, typography, spacing, dividers, and bottom controls are otherwise untouched.
