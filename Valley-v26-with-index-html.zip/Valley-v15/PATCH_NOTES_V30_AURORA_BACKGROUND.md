# V30: aurora background and type pass (index.html only)
- New `<style id="valley-ad-backgrounds">` at the end of the head in app/src/main/assets/index.html.
- Grainy multi-colour gradient behind the page (light: peach, amber, olive, rose; dark: ember, olive, plum). Slow drift, off for reduced motion.
- Logo top edge faded so it blends in. Cards a bit clearer over the colour.
- Font families untouched. Sizes, spacing and alignment only: section titles 15 to 19px, rows and chips up about 1px, tiny labels 9.5 to 10.5px, wider card padding.
- To undo: delete that one style block.
