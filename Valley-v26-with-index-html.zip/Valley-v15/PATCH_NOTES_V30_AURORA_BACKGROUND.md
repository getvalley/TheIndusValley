# V30: aurora background and type pass (index.html only)
- New `<style id="valley-ad-backgrounds">` at the end of the head in app/src/main/assets/index.html.
- Grainy multi-colour gradient behind the page (light: peach, amber, olive, rose; dark: ember, olive, plum). Slow drift, off for reduced motion.
- Logo top edge faded so it blends in. Cards a bit clearer over the colour.
- Font families untouched. Sizes, spacing and alignment only: section titles 15 to 19px, rows and chips up about 1px, tiny labels 9.5 to 10.5px, wider card padding.
- To undo: delete that one style block.

## Per-page palettes
- showView() now sets `data-view` on <html>; CSS picks a palette and blob layout per page (home, history, downloads, security, about). Colours crossfade over 0.7s where @property is supported, and switch instantly otherwise.

## V32 performance pass
- Background is fully static: no drift animation, no colour crossfade (@property removed), no filter, layer is exactly screen size.
- Grain is a 128px pre-baked PNG instead of a live SVG turbulence filter.
- Frosted blur on cards reduced from 22px to 14px; removed on the nested tiles and chips inside cards.

## V33 drift back
- Drift restored (30s, translate only, layer is 8% oversized). Cards no longer use backdrop-filter; they use more opaque frosted fills so the moving background costs nothing extra.
- To stop the drift: delete the `animation:aurDrift ...` line in the body::before rule.

## V34 fast dial fix
- renderDial/renderFavs/renderSearches/renderOpened now skip rebuilding when their data is unchanged (data-sig check). The shell's ulaaRefresh() no longer recreates the tiles, so the entry animation doesn't replay and a tap isn't lost when the DOM is replaced mid-press.

## V35 stronger drift
- Drift now moves about 14% of the screen with a slight rotation over 18s (was about 14px over 30s, too small to see). Layer is 28% oversized so edges never show.
- Note: the page already turns all animation off when the phone's "Remove animations" / reduced motion setting is on.
