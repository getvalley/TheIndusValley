# Valley V23 - iOS-style multi-tab selection controls

Updated the multi-tab selection state to match the supplied reference:
- Hides the tabs search/settings row while selection mode is active.
- Adds a compact top-left action capsule with Close, Move, and an ellipsis menu.
- Adds a separate blue checkmark button at the top-right to finish selection.
- Keeps the bottom tab-group dock visible, including the tab count and group name.
- Selected tab previews get a blue outline and blue checkmark badge.
- Shows a small “N selected” pill on the first selected preview.
- Close closes the selected tabs; Move opens the group chooser; ellipsis opens the additional bulk actions.

The selection-mode controls are a source change only. The project has not been compiled in this environment; validate it with the repository's GitHub Actions workflow.
