# Valley V26 Debug Build Fix

## Root cause
`buildTabsPage()` opened a `run { ... }` scope for the horizontal tab-group selector, but the scope was not closed before the bottom-dock Done button was declared.

That left subsequent class members parsed as local declarations. It caused the `private is not applicable to local function` errors and unresolved references such as `motionBlur`, `dismissLater`, `prefs`, and `loadTabGroups`.

## Fix
Added the missing closing brace immediately after the selector's initial-centering post callback and before the Done button declaration.

No build workflow, Gradle configuration, or unrelated UI logic was changed.
