# v27 — theme sync, tab previews, Hide Distracting Items, slide-to-switch

- Toolbar: reader/reload are 30px circles (circular hit area); active reader button sits 4px further left; main pill is longer (60vw) and the side circles sit further out (gap 15px).
- "Eraser" is now "Hide Distracting Items" (tools list, long-press menu, page menu). Restore row reads "Show Hidden Items (N)".
- Hide Distracting Items (page_cleanup.js v10): blue outline + centred "Hide" pill, floating glass bar (‹ undo, ✕ cancel, label, ✓ done, … more). Label is "Select an item" until something is hidden, then "N item(s) hidden". The toolbar steps aside while the bar is up.
- Tab previews survive closing the app: each tab's picture and site icon are saved to filesDir/tab_images and reloaded on the next launch.
- Tabs page shows the site's icon (from the page, or fetched from the declared icon) instead of the orange dot; a first-letter tile is used until an icon is known.
- Light/dark: whole app follows the system (Pal.kt, values/ and values-night/ colours, drawables, toolbar.html, homepage). uiMode changes are handled live.
- Toolbar glass is a light tint in light mode.
- Homepage restyled to the app's look (flat background, glass cards, Inter, no paper/orbs/grain, no manual theme toggle).
- Swipe on the pill: the next/previous tab slides in over the current one and the pill slides with it.

Not compiled or run on a device here; JS was checked in headless Chromium.
