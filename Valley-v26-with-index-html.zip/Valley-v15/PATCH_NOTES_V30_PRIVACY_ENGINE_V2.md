# Valley v30 — Privacy Engine v2

## Network layer
- Blocklist grew from ~40 to ~290 domains (`assets/blocklist.txt`, loaded at startup; edit it to add your own). Covers ad exchanges, pop-up/push networks, mobile ad SDKs, measurement firms, data brokers, analytics/session-replay and social pixels. CDNs are intentionally excluded.
- New URL-pattern rules block third-party tracking pixels, analytics scripts (`analytics.js`, `fbevents.js`, `gtag.js`...), `/pagead/` and ad-frame paths even when the domain is not listed.
- A site's own hosts are never blocked (same-site check, with common multi-part TLDs such as co.uk).
- Tracking parameters (`utm_*`, `fbclid`, `gclid`, `msclkid`, `mc_eid`, `igshid`, `_hsenc`, ...) are stripped from links before the page loads (GET navigations only).
- Settings are cached instead of being parsed from SharedPreferences on every request.

## Page shield (`assets/privacy_shield.js`, runs before page scripts)
- Hides leftover ad slots and sponsored-widget containers.
- Hides cookie/consent banners for the common CMPs (OneTrust, Cookiebot, Didomi, Quantcast, Sourcepoint, Usercentrics, Osano, Complianz, CookieYes, iubenda, ...), clicks "Reject" where a stable button exists, and unlocks scrolling.
- Sends Do Not Track and Global Privacy Control.
- Fingerprint hardening: canvas and audio noise, generic WebGL vendor/renderer, fixed CPU-core/memory values, battery API removed.
- Optional WebRTC relay-only mode (off by default; can break video calls).
- Uses `addDocumentStartJavaScript` when the WebView supports it, otherwise falls back to injecting in `onPageStarted`.

## Cookies
- "Hide cookie banners" toggle.
- "Clear cookies when Valley restarts" toggle (off by default; cookies only, so bookmarks/history in the start page are kept).
- Third-party cookies remain blocked by default.

## Bug fix
- "Allow trackers on this website" never worked: the saved domain was compared with the *tracker's* host instead of the page you were on. Exceptions now apply to the page, and also switch the page shield off for that site.

## UI
- Privacy page has new toggles: tracker URL patterns, strip tracking parameters, hide ads, hide cookie banners, clear cookies on restart, reduce fingerprinting, DNT/GPC, WebRTC protection. Blocklist size is shown on the status card.

## Limits
- Domain/path blocking is not a full EasyList/uBlock engine; cosmetic hiding uses a fixed selector set, not per-site filters.
- Android WebView cannot add headers to subresource requests, so DNT/GPC is sent through JavaScript (`navigator.*`) only.
- Fingerprint noise does not stop a determined tracker; IP address and logins still identify you.
- Validation: JavaScript passes `node --check`; Kotlin was checked for brace balance only. It has NOT been compiled or run on a device.
