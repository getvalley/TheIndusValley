# Valley V26.3 Tabs Slider Adjustment

- The `N Tabs` / `N Selected` label is anchored to the horizontal centre of the main tabs pill.
- `Private` stays on the left side of the centred count.
- When viewing a named group, `Personal` appears immediately after `Private` and before the centred count as the return-to-default group.
- Other named groups appear in the right-hand scrolling lane; the currently open group is represented by the group name at the top rather than duplicated in the slider.
- Both slider lanes retain horizontal edge fading.
