# Valley V24 - Reader mode active indicator

- Adds the bright cyan circular background shown in the reference image to the Reader button while Reader Mode is actually open.
- Changes the reader glyph to a dark navy tint while active, matching the reference.
- Removes the active circle when Reader Mode is toggled off or when a different tab is attached.
- The active state is determined by checking whether the Reader overlay exists in the page, rather than merely assuming a tap succeeded.

Source-only change. Build and test with GitHub Actions; not compiled here.
