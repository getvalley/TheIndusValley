# Valley v26 Eraser Functional Fix

## What changed
- The existing Eraser UI and storage design are retained. The prior implementation already had a richer selection/confirmation flow than the Gemini sample.
- `page_cleanup.js` is now injected on every external page load independently of the Spark script, so Eraser availability no longer depends on Spark injection completing.
- The Erase bridge now resolves the selected tab safely, injects the current cleanup script, and starts selection mode in a sequenced callback.
- Restore now safely handles a missing tab/WebView and refreshes the Eraser count.
- Added Escape-key exit support and a `toggle()` API alias for compatibility. Touch selection continues to use document-level touch tracking and click capture, so it works on mobile without relying on mouse hover.
- Updated cleanup script version to 3 so an older injected version is replaced on subsequent page loads.

## Existing behaviour preserved
- Tap a page item to preview the selected block.
- Confirm with Hide Item or cancel.
- Saved selectors are scoped by hostname and reapplied on later visits.
- Restore clears saved selectors and unhides items.

Validation: ZIP integrity, JavaScript syntax check, and targeted Kotlin source checks passed. Android Gradle compilation and device testing were not performed.
