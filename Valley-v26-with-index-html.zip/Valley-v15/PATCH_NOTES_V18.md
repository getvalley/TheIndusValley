# Valley v18 patch notes

- Removed CSS press-scale feedback from the floating pills and menu rows to stop tap jitter.
- Opening a search/settings/navigation/page-tools panel now animates the full toolbar out of view.
- Panels and page-tools menu now expand from the pill's bottom edge; their bottom corners share the pill's horizontal bounds.
- Reworked frost capture to draw the active page WebView, crop the pixels beneath the pill and panel, blur them natively, and feed the images into the transparent toolbar WebView. This avoids relying on cross-WebView CSS backdrop-filter.
- On Valley's own homepage, the left side button becomes Search and the right side button becomes Voice Search. On other pages they remain Reader and Reload. Voice search uses Android's system speech-recognition UI and routes the recognized query through Valley's search routing.
- Address text is left-aligned and starts at the hostname; long addresses fade only at the right edge, and only when the hostname itself exceeds the available pill width.

Validation: toolbar JavaScript passes `node --check`. The Android Gradle build was not run in this environment because Gradle is not installed.
