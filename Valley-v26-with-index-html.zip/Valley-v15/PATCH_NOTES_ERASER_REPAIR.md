# Valley v26 Safari-style Eraser Repair

- Replaced the previous tap-the-exact-node eraser with a visual picker that highlights the likely containing element as the pointer moves.
- Tapping an item opens a confirmation panel showing a text preview before hiding it.
- Added safer ancestor selection to target whole banners, dialogs, popups, and content blocks instead of tiny nested spans.
- Saved hidden selectors per website and reapplies them when dynamic page content is inserted.
- Kept the existing Eraser menu, item counter, and Restore action.
- Added an explicit save failure message when website storage is unavailable.

The feature is inspired by Safari's manual Hide Distracting Items interaction. It does not submit cookie consent or change a site's consent choice; it only hides the selected page element.

Validation: ZIP integrity and JavaScript syntax check. Android compilation and device testing were not performed.
