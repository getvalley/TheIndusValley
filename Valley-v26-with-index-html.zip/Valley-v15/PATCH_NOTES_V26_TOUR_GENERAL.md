# Welcome tour: toolbar hidden, gear wording, moved to General

- The bottom toolbar is hidden while the welcome tour is open and comes back when it closes.
  index.html tells the app through a new `ValleyTour.active(bool)` bridge (MainActivity.kt: `TourBridge`,
  `tourOwner`, `syncToolbarVisibility()`). Only the Valley start page can use it.
- Tour text now says "(gear icon) → Security" instead of "Menu → Security", with the real gear icon drawn inline.
  The last step says to replay the tour from the gear icon → General.
- "Welcome tour" moved out of the gear menu and into the General page (same `menuTour` id, so the tour code is unchanged).
