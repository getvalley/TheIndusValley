# Welcome tour: toolbar hidden, gear wording, moved to General

- The bottom toolbar is hidden while the welcome tour is open and comes back when it closes.
  index.html tells the app through a new `ValleyTour.active(bool)` bridge (MainActivity.kt: `TourBridge`,
  `tourOwner`, `syncToolbarVisibility()`). Only the Valley start page can use it.
- Tour text now says "(gear icon) → Security" instead of "Menu → Security", with the real gear icon drawn inline.
  The last step says to replay the tour from the gear icon → General.
- "Welcome tour" moved out of the gear menu and into the General page (same `menuTour` id, so the tour code is unchanged).

# Default browser prompt

- Every time the app is opened, after 5 minutes of time on screen in that session, Valley asks:
  "Make Valley your default browser?" It shows once per opening, not again until the app is opened anew.
  "Set as default" opens the Android browser-role request (Android 10+) or the default apps settings on older versions.
  "Not now" closes it. It never shows if Valley is already the default.
- If the welcome tour or the tabs page is open at the 5-minute mark, it waits and tries again 30 seconds later.
- MainActivity.kt: `scheduleDefaultBrowserPrompt()`, `maybeShowDefaultBrowserPrompt()`, `requestDefaultBrowser()`, `onResume()`.
