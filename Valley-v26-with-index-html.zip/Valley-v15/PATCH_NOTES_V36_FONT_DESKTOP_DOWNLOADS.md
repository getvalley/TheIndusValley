# Valley v36 — Bricolage Grotesque, desktop-mode zoom, downloads

Three things were asked for: one typeface everywhere, a desktop site that renders at 100% instead
of 150% and stops running off the screen, and downloads that actually work.

## 1. Bricolage Grotesque is now the app's only typeface

Bundled, not fetched. Nothing in the app depends on Google Fonts any more.

**Native (Kotlin / XML)**
- `res/font/bricolage_grotesque_{regular,medium,semibold,bold,extrabold}.ttf` plus
  `res/font/bricolage_grotesque.xml`, a real family with weights 400/500/600/700/800.
- `Theme.Valley` (light and night) sets `android:fontFamily` and `android:textViewStyle`, so every
  TextView — inflated or built in code — inherits it.
- `MainActivity.appTypeface(weight, italic)` replaces the old `Inter Bold` asset loader and the
  hardcoded `Typeface.create("sans-serif" / "sans-serif-medium" / "serif")` calls.
- `pageHeader()` no longer mixes an italic serif (History, Downloads) with an upright bold sans
  (Bookmarks, Privacy, Tab Groups). All page headings are now Bricolage Bold 32 — the same voice
  the HTML pages already used.
- The old `assets/fonts/Inter_28pt-Bold.ttf` is gone.

**HTML (start page, toolbar)**
- `assets/fonts/BricolageGrotesque-Variable.woff2`: one variable file, weight axis 200–800, so a
  single `@font-face` covers every weight the UI asks for.
- `index.html`: the two Google Fonts `<link>`s and the preconnects are removed, `--sans` (and
  therefore `--serif`, `--tagline`, the page headings and the hardcoded Inter rules) point at
  Bricolage with Inter/system fallbacks.
- `toolbar.html`: same `@font-face`, every stack updated, including the canvas-drawn labels.

**Inside websites (reader mode, translate/summary overlays)**
- `reader.js`, `spark.js` and `page_cleanup.js` inject the same `@font-face`, served from the app's
  own asset host, and put Bricolage first in every stack.
- A font file is a CORS resource, so `FontAssetsPathHandler` (wrapping `AssetsPathHandler`) adds
  `Access-Control-Allow-Origin` for `.woff2/.woff/.ttf/.otf` only — that is what lets a page the
  user is reading load the app's typeface.
- Reader mode's default face is now Bricolage and the picker's first button is labelled
  "Bricolage" (Consolas and Garamond remain as reading options).

## 2. Desktop site: the whole page at 100%, not magnified

The page was being asked for a 980px desktop layout at `initial-scale=1`. On a phone that means the
layout is *magnified* — you see the left half of the page at what reads as 150%+ and the right half
is off screen. Desktop mode now **fits the whole page** instead:

- `applyViewportPolicy()` / `applyDesktopViewport()` set the layout viewport to 980px and the page
  scale to `screenWidthDp / 980`, so the entire desktop layout is on screen at once.
- That fit scale *is* 100%: it is written into `minimum-scale` (zoom-out stops there) and is what
  the zoom readout and "Reset" use, so the browser never sits above 100% in desktop mode.
  `zoomPercentFor()` divides the raw WebView scale by the tab's fit scale for the panel.
- After the viewport is applied, the page is measured (`contentWidthJs`) and if the site lays itself
  out wider than 980px — a 1200px container, a fixed-width grid — the layout viewport widens to the
  page's own width and is fitted again. That is the "website chips off the screen" case: the page is
  now scaled to include its real width instead of losing the right-hand side.
- `text-size-adjust:100%` keeps Chromium from autosizing text on the wide layout, `overflow-x:auto`
  on `html`/`body` re-enables panning on sites that hide it, and `pre` blocks scroll on their own.
- `textZoom = 100` in `setDesktopMode()` and in `buildWeb()`: the system font-size setting can no
  longer inflate web text either.
- Switching back to mobile clears the desktop style block and the fit scale.
- `resetPageZoom()` returns to the fit scale in desktop mode and to 1:1 in mobile mode.

## 3. Downloads that fail

The report was that some downloads *fail*, not that the files are badly named. These are the paths
that actually failed, and what changed.

**The download never started**
- Android 7–9: `WRITE_EXTERNAL_STORAGE` was never requested before handing the file to
  `DownloadManager`, so writing to the public Downloads folder failed immediately. The permission is
  now checked in `startBrowserDownload()` (and again on retry); the download is parked in
  `pendingStorageDownload` and resumes automatically once the prompt is accepted
  (`onRequestPermissionsResult`, request code 4712).
- `addRequestHeader` throws on non-ASCII values — a Referer with a unicode path or a Cookie with an
  unicode value killed the whole request. `headerSafe()` now strips anything outside printable ASCII.
- `setMimeType` throws on a malformed MIME string, which the page can supply. The MIME is validated
  before it reaches the request.
- `content://` links are streamed through the content resolver, and `intent:`/`market:`/`mailto:`
  links go to the system, instead of being rejected as "not supported".

**It reported success but there was no file**
- A 403, a 404, a rate limit or a login wall comes back as an HTML page, and DownloadManager calls
  that a completed download. `looksLikeErrorPage()` now catches it: the record becomes Failed with
  "The server sent a web page instead of the file", and it is retried inside the page — where the
  request carries the site's cookies, session and Referer — before being left as failed.
- The record keeps the MIME the file was *requested* with, so the retry and the extension logic
  still know what was wanted.

**It failed part-way, or the retry failed**
- Retries run in the tab the download came from (`downloadSources`), not in whichever tab is in
  front, because cookies and session only line up there.
- `failPageSave()` now stores the real reason from the in-page fetch: "The server refused the file
  (HTTP 403)", "The file is no longer on the server (HTTP 404)", "The server is rate limiting
  downloads (HTTP 429)", "The page blocked the download request".
- `DownloadManager`'s `COLUMN_REASON` is mapped to words (no space, name clash, server refused,
  transfer broke off, ...) and shown under the file name on the Downloads page.
- A retried record is marked local, so DownloadManager's old failed row for the same id can no longer
  flip the retry back to red while it is still downloading.

**Retry by hand**
- Failed rows on the Downloads page are tappable: `ValleyDownloads.retry(id)` re-fetches that file in
  the page that started it. The row says "… · Tap to retry".
- Name clashes: `uniqueDownloadName()` asks MediaStore on Android 10+ (plain file access cannot see
  the public Downloads folder there), and `ERROR_FILE_ALREADY_EXISTS` is treated as a clash to
  re-name and retry rather than a dead end.

**Still not solvable from the browser engine**
- A download behind a form POST cannot be replayed: WebView's download callback hands over a URL, not
  the request body. Those sites need the link opened normally.
- A retry runs `fetch()` in the page, so a site whose CSP forbids `connect-src` to its own download
  endpoint will report "The page blocked the download request".

## Build fix (the CI failure)

`DownloadManager.ERROR_BLOCKED` is not public API — it exists in the framework as value 1010 but has no
public constant, so `MainActivity.kt` did not compile. It is now matched by value, with a comment:

```kotlin
// 1010 is ERROR_BLOCKED: the constant exists in the framework but is not public API,
// so it is matched by value instead of by name
1010 -> "The download was blocked"
```

Every other `DownloadManager` constant used here (`ERROR_FILE_ALREADY_EXISTS`,
`ERROR_INSUFFICIENT_SPACE`, `ERROR_DEVICE_NOT_FOUND`, `ERROR_CANNOT_RESUME`, `ERROR_TOO_MANY_REDIRECTS`,
`ERROR_UNHANDLED_HTTP_CODE`, `ERROR_HTTP_DATA_ERROR`, `ERROR_FILE_ERROR`, `COLUMN_REASON`,
`COLUMN_MEDIA_TYPE`) is public.

## Validation

- All four JS assets pass `node --check`.
- Inline `<script>` blocks in `index.html` and `toolbar.html` pass `node --check`.
- `styles.xml`, `values-night/styles.xml`, `font/bricolage_grotesque.xml`, `activity_main.xml` and
  the manifest parse as well-formed XML.
- `MainActivity.kt` braces/parens/brackets balance.
- The Kotlin sources were compiled here against `android.jar` (platform 34), androidx.webkit 1.11.0
  and androidx.core 1.13.1 with the Kotlin 1.9.24 compiler: **0 errors**, 147 classes emitted. Only
  pre-existing deprecation warnings remain.
- The APK has **not** been compiled or run on a device in this environment (no Android SDK here);
  build it with your usual Gradle setup.
