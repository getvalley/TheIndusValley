Valley V26 Reader Mode - Font and Background Controls

- Reader mode remains a toggle and removes media from the extracted reading view.
- Added an adjacent reader background toggle beside the Inter / Consolas / Garamond font selector.
- Reader background defaults to white; the toggle switches to a neutral dark background and back to white.
- Both controls sit together at approximately 25% of the viewport height.
- Font choices continue to preview their respective typefaces and apply immediately to the article.


Reader active indicator update: the native reader-mode toolbar button now displays a distinct cyan-blue circular background with a subtle lighter outline while reader mode is active. The circle and active icon tint are cleared when reader mode is turned off.
