# Valley V26 Group Slider and Touch Fix

- Restored the horizontal tab-group selector as a persistent bottom-dock control, including while tab selection mode is active.
- Added dynamic half-viewport side insets so the selected group pill can sit exactly in the horizontal centre even when it is the only pill.
- Kept the `N Tab(s)` pill for orphan tabs and named labels for named groups; no per-group tab counts were added.
- The All Tabs action opens the active tab's group: orphan tabs show `1 Tab`/`N Tabs`, named groups show their name, and private tabs open Private.
- Removed the additional WebView edge-swipe recognizer so webpage controls retain their normal touch stream. Toolbar swipe-to-switch remains connected.
- Removed the grey native WebView foreground ripple that could sit over webpage content after a tab swipe.
- Temporary press feedback now clears its foreground drawable after release.
- Disabled Android's native long-press selection magnifier on Valley's own homepage WebView, while leaving long-press behaviour enabled on external webpages.

ZIP integrity and source-level checks passed. Android build and device behaviour have not been verified in this environment.
