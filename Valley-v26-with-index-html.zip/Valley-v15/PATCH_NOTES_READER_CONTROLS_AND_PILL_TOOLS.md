# Reader controls and toolbar actions

- The existing Reader implementation in `reader.js` already builds its own reader overlay, font picker, and light/dark toggle. Kept that single source of truth rather than adding a duplicate native overlay to `activity_main.xml`.
- Added `setReaderFont()` and `toggleReaderTheme()` JavaScript entry points that target the existing Reader overlay and its existing controls.
- Restored the toolbar's Reader icon action on webpages: tapping it calls the native Reader toggle. On the homepage it continues to open search.
- Moved Special Page Tools to a 480 ms long-press on the main pill, only when browsing a webpage. Long-pressing the Reader or Reload child controls does not trigger it.
- Settings long-press no longer opens Special Page Tools.
- No homepage customisation or external visual-search handoff changes were added.
