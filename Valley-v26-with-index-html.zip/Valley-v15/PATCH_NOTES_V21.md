# Valley v21 - Tabs overview layout

Changes in this patch:
- Added a fixed settings control at the top-left of the tabs overview.
- Kept the search field in its own remaining-width area so the settings control cannot overlap it.
- Added a bottom overview dock with New Tab, Private, a tab-count chip fixed to the horizontal centre, the current group name, and Done.
- The group name is a label/selector for the current view (for example, Personal or Tab Group 1), not a separate Personal action button.
- Added a horizontally scrollable group-name strip with edge fading when its contents overflow.
- Added a Private overview filter. Tapping it again returns to Personal.
- Kept the existing tab-card preview and close behavior.

Build note:
- This source patch has not been compiled in this environment. Please run the existing GitHub Actions build and share the first Kotlin error if one appears.
