# Valley v19 changes

- Added a rounded search field at the top of the native Tabs overview. It filters open tabs by title/URL as you type; submitting a query opens it as a new tab using the browser's existing routing.
- Removed the orb element and its animations. Long-pressing the main, menu, or navigation pill now shows a small localized radial glow at the press point and opens the page-tools panel directly.
- Added Voice Search to special page tools on normal webpages; it is hidden on Valley's homepage. Uses the existing Android system speech recognizer.
- Toolbar panels and page-tools now use the source pill's measured position as their transform origin and bottom anchor.
- Added Close This Tab to the normal-page settings panel and applied Apple system red (#FF3B30) to close actions, including tab-card close controls.
- Added horizontal swipe navigation on the main pill: right-to-left selects the next tab; left-to-right selects the previous tab, with a brief localized edge glow.

Validation: toolbar JavaScript extracted from toolbar.html passes `node --check`. Android Gradle build was not run in this environment.
