# Valley V26 group picker, toolbar, Reader and Eraser update

- Bottom tabs selector now displays only the current tab count. Group names are removed from that rail.
- Group selection is moved to the top group pill, with a left-biased label and chevron.
- Group picker expands from the top pill with an anchored scale/alpha morph; chevron rotates and resets on dismissal.
- Webpage toolbar controls now form a centered cluster instead of pushing the outer controls to the viewport edges.
- Minimized toolbar remains a centered address capsule.
- Reader extracts immediately with Valley's local parser rather than waiting for a CDN; Mozilla Readability remains an optional enhancement.
- Reader sanitization now preserves safe HTTP(S) article images and captions.
- Eraser action reinjects the page-tools script into the active webpage before invoking its eraser control.

Validation: JavaScript syntax and ZIP integrity checked. Android compilation and on-device layout/interaction are not verified here.
