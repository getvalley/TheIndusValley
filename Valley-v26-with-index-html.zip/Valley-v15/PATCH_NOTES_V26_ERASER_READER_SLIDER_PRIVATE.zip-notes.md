# Valley v26 patch notes

## Page Eraser
- Updated the cleanup script to version 4 so an older injected version cannot block the updated implementation.
- Added a page-session fallback for saved selectors when a website blocks localStorage.
- Element hiding now happens immediately; a storage failure no longer cancels the hide action.

## Reader indicator
- The visible toolbar is `toolbar.html` inside `toolbarWeb`; the old native `R.id.reader` button is only a fallback and was not the visible control.
- Added `ulaaSetReaderActive()` to the visible toolbar and wired the Kotlin reader state to it.
- The active Reader control now receives a cyan circular background, border, and glow. It resets when returning to the homepage.

## Tab-group slider
- Removed the 130 ms debounce and 230 ms delayed switch.
- A group switches as soon as a meaningful portion of its chip enters the slider's central area.
- The nearest qualifying chip wins to reduce accidental selection of a neighboring group.

## Private placement
- Moved the Private chip before the ungrouped `N Tabs` chip.

## Validation
- JavaScript syntax checks passed for `page_cleanup.js` and the inline scripts in `toolbar.html`.
- ZIP integrity checked after packaging.
- Android Gradle compilation and on-device behavior have not been tested in this environment.
