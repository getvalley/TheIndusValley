# Valley v26 Privacy Engine

- Added a Privacy & Protection entry to the toolbar settings panel.
- Added a native privacy dashboard with a blocked-request counter.
- Made the existing built-in tracker/ad domain blocklist configurable, enabled by default.
- Added per-domain tracker exceptions for the currently open website.
- Added a third-party-cookie setting, disabled by default, applied to existing and newly created tabs.
- Added a clear cookies and WebView cache action with confirmation.
- Added a counter reset action.
- Preserved existing HTTPS-upgrade and Safe Browsing behaviour.

Limitations:
- The blocklist is a fixed built-in list, not a frequently updated EasyList/uBlock-style rules engine.
- The counter measures blocked subresource requests, not unique trackers or prevented tracking events.
- Android WebView uses a shared cookie store across tabs; cookie clearing affects all sites.
- This does not provide complete anonymity or prevent all fingerprinting/first-party tracking.

Validation: ZIP integrity and source-level structural checks. Android compilation and device testing were not performed.
