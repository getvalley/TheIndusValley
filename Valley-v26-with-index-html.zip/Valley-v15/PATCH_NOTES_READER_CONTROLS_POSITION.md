# Valley v26 Reader Controls Position

- Moved the Reader font selector and light/dark toggle upward.
- The control group now sits at `12vh` from the top of the viewport, approximately 0.35/3 of the page height.
- Kept the controls horizontally centered and fixed in place while the article scrolls.
- No Reader font, theme, or extraction behaviour was changed.

Validation: ZIP integrity and targeted source check passed. Android build and device layout testing were not performed.
