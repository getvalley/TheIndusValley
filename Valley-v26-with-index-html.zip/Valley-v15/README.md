Valley v36 — Bricolage Grotesque, desktop-mode zoom, downloads

- The whole app now uses Bricolage Grotesque: bundled fonts in res/font for the native UI (theme
  fontFamily + appTypeface()), one variable woff2 for the start page and toolbar, and an injected
  @font-face for reader mode and the on-page overlays. Google Fonts is no longer loaded.
- Desktop mode fits the whole page: the 980px layout (or the page's own width, when it is wider) is
  scaled to the screen and that scale is 100% — the floor, the reset target and the zoom readout. It
  no longer magnifies the page and loses the right-hand side.
- Downloads that failed now start and finish: the storage permission is requested on Android 7-9,
  request headers and MIME types are sanitised so they cannot throw, a 403/login wall saved as an HTML
  page is detected as a failure, retries run in the tab that started the download, failures carry a
  readable reason, and failed rows are tappable to retry.
- Details: PATCH_NOTES_V36_FONT_DESKTOP_DOWNLOADS.md

Valley v15 — reader/reload symbols and direct pill navigation

- Replaced the reader-mode symbol with the requested webpage/reading-lines glyph: a rounded rectangular page outline with horizontal lines beneath it.
- Replaced the reload symbol with a cleaner clockwise circular refresh arrow matching the supplied reference.
- Updated both the HTML toolbar SVGs and Android drawable resources so the symbols remain consistent wherever the toolbar implementation is used.
- Made the left navigation pill explicitly consume its click event and invoke the native back/forward action directly; it no longer relies on opening the navigation panel to navigate. The selected direction still follows the existing Back/Forward mode.
- Added explicit preventDefault/stopPropagation to reader and reload controls to avoid parent click handling interfering with their actions.

Validation: inline toolbar JavaScript passes `node --check`. The Android APK has not been compiled or tested on-device in this environment.
