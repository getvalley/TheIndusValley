# Valley v26 Bookmarks and History Refresh

- Reworked the native Bookmarks overview into a two-column card grid consistent with the Tabs overview.
- Added instant search across saved favourites and bookmarks.
- Added direct Open and Remove actions, plus a long-press menu for each saved page.
- Preserved the existing SharedPreferences storage keys (`list_favs` and `list_bookmarks`).
- Refreshed the homepage History view with glass-style panels, a pill-shaped filter, and compact two-column history cards.
- Kept existing history recording, filtering, individual deletion, and clear-all behaviour intact.

Validation performed: ZIP integrity and source-level structural checks. Android compilation and on-device UI testing were not performed.
