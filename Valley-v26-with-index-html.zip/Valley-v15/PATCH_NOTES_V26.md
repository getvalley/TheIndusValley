# Valley V26 - Manage Tab Groups

- Added **Manage Tab Groups** to the tabs-page settings panel.
- Added a dedicated management page styled after the supplied reference: title row with Edit/Done and a blue check, a tab-group list, a separate Private card, and a creation card.
- Personal is shown as the default group and remains fixed.
- Edit/Done reveals Rename and Delete actions for named groups. Deleting a group returns its tabs to Personal; it does not close those tabs.
- New Empty Tab Group creates an empty named group.
- New Tab Group with N Tabs moves currently unassigned non-private tabs from Personal into the new group.
- Both creation actions show a **Name** dialog before creating the group.
- Group names and URL membership are persisted in SharedPreferences.

Build status: source package only. This environment does not have the project Gradle wrapper or Android SDK build setup, so the APK has not been compiled or device-tested.
