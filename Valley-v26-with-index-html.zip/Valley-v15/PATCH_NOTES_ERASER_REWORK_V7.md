# Page Eraser rework (v7)

- Replaced the previous document-level click-only picker with a capture-phase window-level picker.
- Uses Pointer Events on modern Android WebView and touch/click fallbacks on older engines.
- Uses `elementFromPoint` so the highlight overlay never intercepts page interaction.
- Added viewport repositioning, a persistent finish control, Escape cancellation, and a confirmation panel.
- Keeps selector persistence best-effort, with an in-memory fallback when site storage is unavailable.
- Runs script installation and `start()` in one `evaluateJavascript` call to remove the previous two-call timing gap.
- Preserved the existing dynamic light/dark launcher icon resources.

Validation: JavaScript syntax checked with Node.js and ZIP integrity checked. Android Gradle build and on-device WebView interaction testing were not available in this environment.
