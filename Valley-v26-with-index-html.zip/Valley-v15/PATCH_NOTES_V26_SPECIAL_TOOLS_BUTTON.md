# V26 special page tools button

- The Reader button now opens/closes the special page tools surface on webpages.
- On the homepage, the same button retains its Search behavior.
- The special page tools surface morphs from the Reader button's position.
- Long-pressing the address pill no longer opens the special page tools menu.
- Existing long-press behavior for navigation and settings buttons is preserved.
- Outside taps dismiss the tools surface; tapping the Reader button toggles it.

Validation: source-level patch assertions and ZIP integrity. Android build and device behavior are not verified.
