# History page: freeze + deleted items coming back

## Respawn (root cause)
The ValleyHistory / ValleyDownloads bridges were attached in onPageFinished. WebView only exposes an
added interface to the NEXT page load, so the start page that was already showing never had them.
Deleting on the History page changed localStorage only; native storage kept the item, and the next
native -> page sync put it back.

- Bridges are now registered once in buildWeb (non-private tabs), before any load.
- Access is gated: each method checks trustedHomeViews, which onPageStarted fills only for the Valley
  start page in a non-private tab. Any other page calling them gets a no-op.
- syncHistoryWithHomepage no longer pushes a copy of the data into localStorage (that could land after a
  delete). It just asks the page to refresh; the page pulls ValleyHistory.snapshot() itself.
- History deletes/clears call native first, then re-pull the native snapshot before re-rendering.
- Search removal in the page is now case-insensitive, matching native.

## Freeze
The page built up to 200 rows per list, each with up to 3 favicon requests (including a direct
https://<host>/favicon.ico to every visited site), and rebuilt them several times on open.

- Favicons load only when the row scrolls into view (IntersectionObserver).
- History shows 40 rows per list with a "Show more" button.
- Renders are coalesced into one per tick (view switch + native refresh no longer rebuild everything back to back).

Not built/run here (no Android SDK). Touched: MainActivity.kt, assets/index.html.
