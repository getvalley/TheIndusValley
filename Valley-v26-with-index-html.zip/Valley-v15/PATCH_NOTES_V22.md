# Valley V22 - Tab context menu and pinning

Changes:
- Long-pressing a tab card opens a tab-specific context menu and triggers a brief localized radial glow from the press point.
- Added Pin Tab / Unpin Tab. Pinned tabs sort before unpinned tabs in the overview and show a pin marker before the tab title.
- Added Duplicate Tab, which opens a new tab at the same URL.
- Added Select Tabs mode. Tap additional cards to add/remove them from the selection, then tap the centred selection-count chip to open bulk actions.
- Bulk actions include moving selected tabs to Personal or a named group, pinning all selected tabs, and closing all selected tabs.
- Added Move Tab for moving one tab to Personal or a named group.
- Added Close Tab and Close Other Tabs. Close Other Tabs keeps the tab whose menu was opened and closes every other tab.
- Destructive menu labels use title case, including “Close Tab” and “Close Other Tabs”.

Limitations:
- The current project stores group membership by URL, not by unique tab ID. If two tabs have the same URL, moving one can affect the group membership of the other.
- This source patch has not been compiled here because a Gradle installation is not available in this environment. Run the GitHub Actions build and share the first error if it fails.
