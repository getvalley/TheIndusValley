# Valley V26 reader and tabs overview patch

- Reworked Reader Mode extraction to handle common article containers and generic page text.
- Reader Mode builds a text-only article view, excluding page images and other media from the rendered reader content.
- Added a font selector with live Inter, Consolas, and Garamond previews.
- Added a separate reader background toggle for pure white and neutral dark themes.
- Reader controls are positioned at approximately one quarter of the viewport height.
- Kept the native reader button's cyan active state integration.
- Rebuilt the tabs overview dock as three separate floating pills: add, group slider, and confirm.
- The group slider places Private before the tab count and Personal/named groups after it, with horizontal edge fading.
- The current group name remains at the top; selection mode displays the selected-tab count there.
- Moved the tabs options control out of the scrolling content into a permanent floating pill.
- Disabled text selection and long-press text callouts on the Valley homepage while leaving input fields editable.
