# V26.2 tab-group slider adjustment

- Personal remains the default tab group and is not shown as a permanent slider chip.
- Personal appears as a switch destination only while viewing a named tab group.
- Private remains at the left of the tab count; named groups remain after the count.
