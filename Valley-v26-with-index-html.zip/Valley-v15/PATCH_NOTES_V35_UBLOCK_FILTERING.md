# V35 - uBlock Origin style filtering

Android WebView cannot run browser extensions, so uBlock Origin itself cannot be installed.
Valley now has a built-in engine that reads the same filter lists and syntax.

- `FilterEngine.kt`: network filters (||host^, wildcards, @@ exceptions, $third-party, resource types,
  $domain=, $denyallow, $important) and cosmetic filters (##, #@#). Unsupported rules are skipped.
- `FilterLists.kt`: downloads uBlock filters (+badware, privacy, unbreak, quick-fixes), EasyList,
  EasyPrivacy and Peter Lowe's list into app storage. `assets/ubo-filters.txt` is a small seed used until then.
- Privacy page: new "UBLOCK-STYLE FILTERING" card (toggles, update now, My filters).
- Requests are checked in `shouldInterceptRequest`; element hiding is injected on page commit/finish.
- Not supported: scriptlets (##+js), procedural cosmetics, removeparam, regex filters, $popup.
