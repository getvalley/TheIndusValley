# Page Eraser v8

- Picker UI (highlight, confirm panel, done button, hint) is now styled through the CSSOM instead of a <style> element. Sites with a strict Content-Security-Policy block injected <style> tags, which left the picker unstyled and effectively invisible.
- Taps are swallowed while erasing, so links and buttons on the page no longer fire.
- Tap vs drag threshold, so scrolling in erase mode does not select an item.
- "Tap an item to hide it" hint shows when erase mode starts.
- All Eraser entry points (long-press menu row, toolbar tool, toolbar Erase button) now call one Kotlin function, startEraser(), which injects page_cleanup.js and starts it in a single evaluation. The long-press row previously went through spark.js, which only clicked a hidden element from the old pill.
- toolbar.html native(): arguments are only passed when defined. The Android Java bridge matches methods by argument count, so calling a no-argument method like reload(), eraserErase(), voiceSearch() or hidebar() with an extra `undefined` argument failed silently. This is the likely reason the Erase and Reload buttons only ran their JS animation and did nothing else.
- MutationObserver re-apply is throttled to one run per frame.

Validation: node --check, plus a headless Chromium run under a strict CSP (pick, hide, persist, restore, link blocked while erasing). Android build and on-device testing were not possible here.

## Reader false "couldn't extract" toast

- The old check looked for the reader overlay right after toggling. Closing the reader, or a page where extraction takes a moment (Readability loads in the background), counted as a failure and showed the toast even though the reader opened or was working.
- reader.js now reports its state (`ulaaReaderState`: open / pending / none). MainActivity reports "opened", "closed", "pending" or "failed". Closing never toasts, and a pending extraction is re-checked for up to about 4 seconds before any failure message.

## Tab restore and cookie flush

- Open tabs are saved when the app goes to the background (`onPause`) and brought back on the next launch. Saved per tab: address, title, pin state and tab group. Not saved: private tabs, start-page tabs, back/forward history, scroll position.
- Only the tab you were on loads at launch. The others load the first time you open them (`Tab.pendingUrl`), so reopening the app does not load every tab at once. At most 20 tabs are restored.
- If you left the app on the start page or in a private tab, you land on a fresh start page as before, with your other tabs still there.
- A restored tab keeps its group only if that group still exists.
- `CookieManager.flush()` runs in `onPause`, so logins reach disk before Android can end the app.
- Places that read a tab's address (search filter, tab menu, copy link, duplicate, group save) now use `Tab.url`, which also covers tabs that have not loaded yet.
