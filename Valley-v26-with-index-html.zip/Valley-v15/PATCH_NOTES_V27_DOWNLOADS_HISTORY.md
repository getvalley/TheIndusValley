# V27 – Downloads, history sync, status pill, headings

- ••• panel: "Downloads" row above "Add Bookmark" (toolbar.html + `downloads` action) opens the Downloads view of the start page (works from any page and from private tabs via a normal tab).
- Back/Forward panel: round Home button immediately right of the long Back/Forward button.
- Downloads are permanent: Valley keeps its own record (`valley_downloads`), independent of DownloadManager. Entries are removed only with the × button or "Clear all" – files on the device are never deleted.
- Downloads page redesigned (cards, size/date, progress, status chips, per-item remove, empty state).
- Native glass status pill: "Downloading <file>" with spinner + progress bar, "Downloaded <file>" with tick + Open, "Download failed". Shows on every page.
- History: native storage is the single source of truth; the page pulls a snapshot (`ValleyHistory.snapshot`) before every render and removals are synchronous, so deleted items no longer come back. Deleting in one place refreshes the other.
- History page redesigned: single-column rows with icon, title, host · time, delete; fixed duplicated lines / cramped 2-column grid.
- History / Downloads / Bookmarks headings: Inter Bold, upright. Native Bookmarks header uses assets/fonts/Inter-Bold.ttf if present (else system bold sans).
Not built/tested here (no Gradle/Android SDK in this environment).
