# V26 white touch glow

- Replaced blue tab-card long-press bloom with a white circular glow.
- Added bounded white ripple feedback to pressable controls and menu rows.
- Short controls use a radius based on their height so the effect reaches top-to-bottom.
- Large surfaces use a circular radius based on finger contact dimensions and capped to 28% of element width / 48% of height, so it cannot stretch from far left to far right.
- Tab swipe switching now produces a brief white circular touch glow near the direction edge.

Validation: source patch assertions and ZIP integrity. Android compilation and device rendering are not verified.
