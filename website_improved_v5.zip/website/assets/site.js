/* Valley site: scroll reveal, scroll progress, nav state, video power-saving */
(function () {
  var d = document, root = d.documentElement;
  var reduce = matchMedia("(prefers-reduced-motion:reduce)").matches;

  /* ---------- 1. Fade-in on scroll ---------- */
  var groups = [
    ".hero h1, .hero-copy, .pills a",
    ".page-hero h1, .page-hero .lead",
    ".statement, .sec-head, .tile, .steps li, .fine",
    ".night .cols > div, .night .list li",
    ".group, .group > h2, .group .list li, .card, .note, .band, .closing, form.bug label, .cta-row"
  ];
  var seen = new Set(), items = [];
  groups.forEach(function (sel) {
    d.querySelectorAll(sel).forEach(function (el) {
      if (seen.has(el) || el.closest(".nav,footer,.stage")) return;
      seen.add(el); items.push(el);
    });
  });

  /* stagger siblings that share a parent so they cascade instead of popping together */
  var byParent = new Map();
  items.forEach(function (el) {
    var p = el.parentElement;
    if (!byParent.has(p)) byParent.set(p, []);
    byParent.get(p).push(el);
  });
  byParent.forEach(function (kids) {
    kids.forEach(function (el, i) { el.style.setProperty("--d", Math.min(i, 6) * 90 + "ms"); });
  });

  if (reduce || !("IntersectionObserver" in window)) {
    items.forEach(function (el) { el.classList.add("rv", "in"); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });
    items.forEach(function (el) { el.classList.add("rv"); io.observe(el); });
  }

  /* ---------- 2. Scroll progress bar + nav shadow ---------- */
  var bar = d.createElement("div");
  bar.className = "progress"; bar.setAttribute("aria-hidden", "true");
  d.body.appendChild(bar);
  var nav = d.querySelector(".nav"), ticking = false;
  function onScroll() {
    var h = root.scrollHeight - innerHeight;
    bar.style.transform = "scaleX(" + (h > 0 ? Math.min(scrollY / h, 1) : 0) + ")";
    if (nav) nav.classList.toggle("scrolled", scrollY > 12);
    ticking = false;
  }
  addEventListener("scroll", function () {
    if (!ticking) { ticking = true; requestAnimationFrame(onScroll); }
  }, { passive: true });
  onScroll();

  /* ---------- 3. Gentle hero parallax (desktop, motion allowed) ---------- */
  var stage = d.querySelector(".stage");
  if (stage && !reduce && matchMedia("(min-width:901px)").matches) {
    var floats = stage.querySelectorAll(".float"), pt = false;
    addEventListener("scroll", function () {
      if (pt) return; pt = true;
      requestAnimationFrame(function () {
        var r = stage.getBoundingClientRect();
        if (r.bottom > 0 && r.top < innerHeight) {
          var p = (innerHeight - r.top) / (innerHeight + r.height) - 0.5;
          floats.forEach(function (f, i) { f.style.setProperty("--py", (p * (i % 2 ? -50 : 50)).toFixed(1) + "px"); });
        }
        pt = false;
      });
    }, { passive: true });
  }

  /* ---------- 4. Pause videos that are off screen (saves battery and data) ---------- */
  var vids = d.querySelectorAll("video");
  if ("IntersectionObserver" in window && vids.length) {
    var vo = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        var v = e.target;
        if (e.isIntersecting) { if (v.dataset.hold) return; var p = v.play(); if (p && p.catch) p.catch(function () {}); }
        else v.pause();
      });
    }, { threshold: 0.15 });
    vids.forEach(function (v) { vo.observe(v); });
  }
})();
(function () {
  var d = document, root = d.documentElement, reduce = matchMedia("(prefers-reduced-motion:reduce)").matches;
  /* theme toggle + menu (shared by every page) */
  var tb = d.getElementById("theme");
  if (tb) tb.onclick = function () {
    var n = root.dataset.theme === "dark" ? "light" : "dark"; root.dataset.theme = n;
    try { localStorage.setItem("valley-theme", n); } catch (e) {}
    var m = d.querySelector("meta[name=theme-color]"); if (m) m.content = n === "dark" ? "#0a0807" : "#f5f2ec";
  };
  var b = d.getElementById("ddb"), mm = d.getElementById("ddm");
  if (b && mm) {
    var close = function () { mm.hidden = true; b.setAttribute("aria-expanded", "false"); };
    b.onclick = function (e) { e.stopPropagation(); var o = mm.hidden; mm.hidden = !o; b.setAttribute("aria-expanded", String(o)); };
    d.addEventListener("click", function (e) { if (!mm.contains(e.target)) close(); });
    d.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
  }
  /* videos: pause button; stay paused for reduced motion */
  d.querySelectorAll("video").forEach(function (v) {
    v.muted = true;
    var btn = d.createElement("button"); btn.type = "button"; btn.className = "vpause";
    function set(p) { btn.textContent = p ? "Play" : "Pause"; btn.setAttribute("aria-label", p ? "Play video" : "Pause video"); }
    if (reduce) { v.removeAttribute("autoplay"); v.pause(); v.dataset.hold = "1"; } else { var pl = v.play(); if (pl && pl.catch) pl.catch(function () {}); }
    set(!!v.dataset.hold);
    btn.onclick = function () { if (v.paused) { delete v.dataset.hold; v.play(); set(false); } else { v.dataset.hold = "1"; v.pause(); set(true); } };
    v.parentElement.appendChild(btn);
  });
  /* founder caseboard: the red string is drawn by scroll position, so scrolling up un-draws it */
  var board = d.querySelector(".board"); if (!board) return;
  var cards = [].slice.call(board.querySelectorAll(".ex")), pins = cards.map(function (c) { return c.querySelector(".pin"); });
  var svg = board.querySelector(".string"), live = svg.querySelector(".live-path"), ghost = svg.querySelector(".ghost");
  var bar = d.querySelector(".dash .bar i"), cnt = d.querySelector(".dash .cnt"), ys = [], lens = [], total = 1, N = cards.length;
  if (!reduce) board.classList.add("armed");
  function layout() {
    var r0 = board.getBoundingClientRect(), pts = pins.map(function (p) { var r = p.getBoundingClientRect(); return [r.left + r.width / 2 - r0.left, r.top + r.height / 2 - r0.top]; });
    svg.setAttribute("viewBox", "0 0 " + r0.width + " " + r0.height);
    var dd = "M" + pts[0][0] + " " + pts[0][1]; ys = []; lens = [0]; live.style.strokeDasharray = "none"; live.setAttribute("d", dd);
    pts.forEach(function (p, i) {
      if (i) { var q = pts[i - 1]; dd += " Q" + (p[0] + q[0]) / 2 + " " + ((p[1] + q[1]) / 2 + 36) + " " + p[0] + " " + p[1]; live.setAttribute("d", dd); lens.push(live.getTotalLength()); }
      ys.push(p[1]);
    });
    total = lens[N - 1] || 1; ghost.setAttribute("d", dd); live.style.strokeDasharray = total; update();
  }
  function update() {
    if (!ys.length) return;
    var y = reduce ? 1e9 : innerHeight * 0.62 - board.getBoundingClientRect().top, tip = 0;
    if (y >= ys[N - 1]) tip = total;
    else if (y > ys[0]) for (var i = 1; i < N; i++) if (y <= ys[i]) { tip = lens[i - 1] + (lens[i] - lens[i - 1]) * (y - ys[i - 1]) / (ys[i] - ys[i - 1]); break; }
    live.style.strokeDashoffset = total - tip;
    var n = 0; cards.forEach(function (c, i) { var on = y >= ys[i] - 40; c.classList.toggle("on", on); if (on) n++; });
    cnt.textContent = n === N ? "Case closed" : "Evidence " + n + " of " + N;
    bar.style.transform = "scaleX(" + (tip / total) + ")";
  }
  var tk = false;
  addEventListener("scroll", function () { if (!tk) { tk = true; requestAnimationFrame(function () { update(); tk = false; }); } }, { passive: true });
  addEventListener("resize", layout); addEventListener("load", layout);
  if ("ResizeObserver" in window) new ResizeObserver(layout).observe(board);
  layout();
})();

/* changelog: rendered from changelog.json, the same file the Valley app syncs with; the static markup is the fallback */
(function () {
  var box = document.getElementById("changelog"); if (!box || !window.fetch) return;
  function e(x) { return String(x == null ? "" : x).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  fetch("changelog.json", { cache: "no-cache" }).then(function (r) { return r.ok ? r.json() : Promise.reject(); }).then(function (j) {
    if (!j || !j.releases || !j.releases.length) return;
    box.innerHTML = j.releases.map(function (r) {
      var meta = [r.codename, r.platform, r.date, r.current ? "Current" : ""].filter(Boolean).join(" · ");
      return '<div class="group"><h2>Valley ' + e(r.version) + '<br><span class="muted" style="font-weight:500;font-size:1.1rem;letter-spacing:0">' + e(meta) + '</span></h2><div class="card"><h3>' + e(r.title) + '</h3>' +
        (r.body || []).map(function (p) { return "<p>" + e(p) + "</p>"; }).join("") +
        (r.path ? '<p><a href="' + e(r.path) + '">' + e(r.linkLabel || "Learn more") + "</a></p>" : "") + "</div></div>";
    }).join("");
  }).catch(function () {});
})();
